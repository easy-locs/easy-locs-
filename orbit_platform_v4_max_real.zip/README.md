# Orbit Platform V4 Max Real

This package is the next heavy block with:
- marketplace quality gate
- shop creation with logo requirement
- wallet history and chat payment flow
- property separated accounting
- delivery orchestration
- calls shell
- image pipeline
- admin audit
- system monitor

## Run
1. Copy `.env.example` to `.env`
2. Fill Supabase credentials
3. Apply `supabase/schema.sql`
4. npm install
5. npm run dev
