import { useEffect } from "react";
import { fetchShops } from "@/services/shopService";
import { usePlatformStore } from "@/store/platformStore";

export function useShops() {
  const shops = usePlatformStore((s) => s.shops);
  const setShops = usePlatformStore((s) => s.setShops);

  useEffect(() => {
    void fetchShops().then(setShops).catch(console.error);
  }, [setShops]);

  return shops;
}
