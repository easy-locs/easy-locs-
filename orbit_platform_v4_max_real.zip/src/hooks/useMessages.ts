import { useEffect } from "react";
import { fetchMessages } from "@/services/chatService";
import { usePlatformStore } from "@/store/platformStore";

export function useMessages(conversationId: string) {
  const messages = usePlatformStore((s) => s.messages);
  const setMessages = usePlatformStore((s) => s.setMessages);

  useEffect(() => {
    void fetchMessages(conversationId).then(setMessages).catch(console.error);
  }, [conversationId, setMessages]);

  return messages;
}
