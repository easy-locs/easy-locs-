import { useEffect } from "react";
import { fetchTransactions } from "@/services/walletService";
import { usePlatformStore } from "@/store/platformStore";

export function useTransactions() {
  const transactions = usePlatformStore((s) => s.transactions);
  const setTransactions = usePlatformStore((s) => s.setTransactions);

  useEffect(() => {
    void fetchTransactions().then(setTransactions).catch(console.error);
  }, [setTransactions]);

  return transactions;
}
