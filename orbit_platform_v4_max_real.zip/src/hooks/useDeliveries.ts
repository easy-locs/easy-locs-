import { useEffect } from "react";
import { fetchDeliveries } from "@/services/deliveryService";
import { usePlatformStore } from "@/store/platformStore";

export function useDeliveries() {
  const deliveries = usePlatformStore((s) => s.deliveries);
  const setDeliveries = usePlatformStore((s) => s.setDeliveries);

  useEffect(() => {
    void fetchDeliveries().then(setDeliveries).catch(console.error);
  }, [setDeliveries]);

  return deliveries;
}
