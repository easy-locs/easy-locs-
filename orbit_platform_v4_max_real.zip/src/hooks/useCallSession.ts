import { useEffect } from "react";
import { on } from "@/core/relay";
import { usePlatformStore } from "@/store/platformStore";

export function useCallSession() {
  const callState = usePlatformStore((s) => s.callState);
  const setCallState = usePlatformStore((s) => s.setCallState);

  useEffect(() => {
    return on("CALL_UPDATED", (payload: any) => setCallState(payload));
  }, [setCallState]);

  return callState;
}
