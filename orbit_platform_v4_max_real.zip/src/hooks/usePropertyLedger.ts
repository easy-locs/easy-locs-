import { useEffect } from "react";
import { fetchPropertyTransactions } from "@/services/propertyService";
import { usePlatformStore } from "@/store/platformStore";

export function usePropertyLedger(propertyId: string) {
  const properties = usePlatformStore((s) => s.properties);
  const setProperties = usePlatformStore((s) => s.setProperties);

  useEffect(() => {
    void fetchPropertyTransactions(propertyId).then(setProperties).catch(console.error);
  }, [propertyId, setProperties]);

  return properties;
}
