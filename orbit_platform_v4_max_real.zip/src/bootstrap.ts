import { initOrchestrator } from "@/engine/orchestrator";
import { initSyncEngine } from "@/engine/syncEngine";
import { runtimeAudit } from "@/core/audit";
import { usePlatformStore } from "@/store/platformStore";
import { requestNotifications } from "@/services/notificationService";

export async function bootstrapApp() {
  initOrchestrator();
  initSyncEngine();
  runtimeAudit().forEach((message) => usePlatformStore.getState().addIssue({ area: "runtime", message }));
  void requestNotifications();
}
