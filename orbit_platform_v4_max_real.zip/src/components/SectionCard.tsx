import { ReactNode } from "react";

export function SectionCard({ title, subtitle, children }: { title: string; subtitle?: string; children: ReactNode }) {
  return (
    <section className="card">
      <div>
        <div className="h2">{title}</div>
        {subtitle ? <div className="muted small">{subtitle}</div> : null}
      </div>
      {children}
    </section>
  );
}
