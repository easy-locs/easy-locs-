import { useState } from "react";
import { validateListing } from "@/validators/listing";
import { createListing } from "@/services/marketplaceService";
import { usePlatformStore } from "@/store/platformStore";

export function ListingForm() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("45");
  const [shopLogo, setShopLogo] = useState("https://logo.example");
  const [status, setStatus] = useState("");
  const addListing = usePlatformStore((s) => s.addListing);

  async function submit() {
    try {
      validateListing({
        title,
        description,
        images: ["a", "b"],
        price: Number(price),
        shopLogo
      });
      const row = await createListing({
        title,
        description,
        price: Number(price),
        shop_logo: shopLogo
      });
      addListing(row);
      setStatus("Listing created");
    } catch (e: any) {
      setStatus(e.message);
    }
  }

  return (
    <div className="col">
      <input className="input" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
      <textarea className="textarea" placeholder="Description" value={description} onChange={(e) => setDescription(e.target.value)} />
      <input className="input" placeholder="Price" value={price} onChange={(e) => setPrice(e.target.value)} />
      <input className="input" placeholder="Shop logo URL" value={shopLogo} onChange={(e) => setShopLogo(e.target.value)} />
      <button className="btn" onClick={() => void submit()}>Validate and publish</button>
      {status ? <div className="msg">{status}</div> : null}
    </div>
  );
}
