import { useTransactions } from "@/hooks/useTransactions";

export function TransactionList() {
  const txs = useTransactions();
  return (
    <div className="col">
      {txs.map((tx, i) => (
        <div key={tx.id ?? i} className="msg">
          <div className="row">
            <strong>{((tx.amount_minor || 0) / 100).toFixed(2)} {tx.currency}</strong>
            <span className="pill">{tx.status}</span>
          </div>
          <div className="code">{tx.reference}</div>
          <div className="code">{tx.crypto_id}</div>
        </div>
      ))}
    </div>
  );
}
