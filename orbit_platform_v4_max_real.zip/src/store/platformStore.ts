import { create } from "zustand";
import type { ChatMessage, DeliveryJob, Listing, PropertyTransaction, Shop, WalletTransaction } from "@/types/domain";

type State = {
  messages: ChatMessage[];
  transactions: WalletTransaction[];
  listings: Listing[];
  properties: PropertyTransaction[];
  deliveries: DeliveryJob[];
  shops: Shop[];
  issues: { area: string; message: string }[];
  callState: { peerId: string; status: string } | null;
  setMessages: (rows: ChatMessage[]) => void;
  addMessage: (row: ChatMessage) => void;
  setTransactions: (rows: WalletTransaction[]) => void;
  addTransaction: (row: WalletTransaction) => void;
  setListings: (rows: Listing[]) => void;
  addListing: (row: Listing) => void;
  setProperties: (rows: PropertyTransaction[]) => void;
  setDeliveries: (rows: DeliveryJob[]) => void;
  addDelivery: (row: DeliveryJob) => void;
  setShops: (rows: Shop[]) => void;
  addShop: (row: Shop) => void;
  addIssue: (issue: { area: string; message: string }) => void;
  setCallState: (state: { peerId: string; status: string } | null) => void;
};

export const usePlatformStore = create<State>((set) => ({
  messages: [],
  transactions: [],
  listings: [],
  properties: [],
  deliveries: [],
  shops: [],
  issues: [],
  callState: null,
  setMessages: (messages) => set({ messages }),
  addMessage: (row) => set((s) => ({ messages: [...s.messages, row] })),
  setTransactions: (transactions) => set({ transactions }),
  addTransaction: (row) => set((s) => ({ transactions: [row, ...s.transactions] })),
  setListings: (listings) => set({ listings }),
  addListing: (row) => set((s) => ({ listings: [row, ...s.listings] })),
  setProperties: (properties) => set({ properties }),
  setDeliveries: (deliveries) => set({ deliveries }),
  addDelivery: (row) => set((s) => ({ deliveries: [row, ...s.deliveries] })),
  setShops: (shops) => set({ shops }),
  addShop: (row) => set((s) => ({ shops: [row, ...s.shops] })),
  addIssue: (issue) => set((s) => ({ issues: [...s.issues, issue] })),
  setCallState: (callState) => set({ callState })
}));
