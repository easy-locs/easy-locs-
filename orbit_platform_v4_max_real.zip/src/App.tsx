import { BrowserRouter, NavLink, Route, Routes } from "react-router-dom";
import { DashboardPage } from "@/pages/DashboardPage";
import { ChatPage } from "@/pages/ChatPage";
import { WalletPage } from "@/pages/WalletPage";
import { MarketplacePage } from "@/pages/MarketplacePage";
import { PropertyPage } from "@/pages/PropertyPage";
import { DeliveryPage } from "@/pages/DeliveryPage";
import { CallsPage } from "@/pages/CallsPage";
import { ShopsPage } from "@/pages/ShopsPage";
import { ImagePipelinePage } from "@/pages/ImagePipelinePage";
import { AdminAuditPage } from "@/pages/AdminAuditPage";
import { SystemMonitorPage } from "@/pages/SystemMonitorPage";
import { SecurityPage } from "@/pages/SecurityPage";

function BottomNav() {
  const items = [
    ["/", "Core"],
    ["/chat", "Chat"],
    ["/wallet", "Wallet"],
    ["/marketplace", "Market"],
    ["/property", "Property"],
    ["/delivery", "Delivery"],
    ["/calls", "Calls"],
    ["/shops", "Shops"],
    ["/images", "Images"],
    ["/admin", "Admin"]
  ] as const;
  return (
    <nav className="bottom">
      {items.map(([to, label]) => (
        <NavLink key={to} to={to} className={({ isActive }) => isActive ? "nav active" : "nav"}>
          {label}
        </NavLink>
      ))}
    </nav>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <div className="shell">
        <div className="wrap">
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/chat" element={<ChatPage />} />
            <Route path="/wallet" element={<WalletPage />} />
            <Route path="/marketplace" element={<MarketplacePage />} />
            <Route path="/property" element={<PropertyPage />} />
            <Route path="/delivery" element={<DeliveryPage />} />
            <Route path="/calls" element={<CallsPage />} />
            <Route path="/shops" element={<ShopsPage />} />
            <Route path="/images" element={<ImagePipelinePage />} />
            <Route path="/admin" element={<AdminAuditPage />} />
            <Route path="/monitor" element={<SystemMonitorPage />} />
            <Route path="/security" element={<SecurityPage />} />
          </Routes>
        </div>
        <BottomNav />
      </div>
    </BrowserRouter>
  );
}
