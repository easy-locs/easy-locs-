export async function requestNotifications() {
  if (!("Notification" in window)) return "unsupported";
  return Notification.requestPermission();
}

export function sendLocalNotification(title: string, body: string) {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  new Notification(title, { body });
}
