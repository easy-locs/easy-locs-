import { supabase } from "@/lib/supabase";
import type { Shop } from "@/types/domain";

export async function fetchShops() {
  const { data, error } = await supabase.from("shops").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as Shop[];
}

export async function createShop(payload: Partial<Shop>) {
  const { data, error } = await supabase.from("shops").insert(payload).select().single();
  if (error) throw error;
  return data as Shop;
}
