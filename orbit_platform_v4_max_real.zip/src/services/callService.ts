import { emit } from "@/core/relay";
type CallState = { peerId: string; status: "idle" | "ringing" | "active" | "ended" };
let currentCall: CallState | null = null;

export async function startCall(peerId: string) {
  currentCall = { peerId, status: "ringing" };
  emit("CALL_UPDATED", currentCall);
  return currentCall;
}

export async function acceptCall() {
  if (!currentCall) return null;
  currentCall = { ...currentCall, status: "active" };
  emit("CALL_UPDATED", currentCall);
  return currentCall;
}

export async function endCall() {
  if (!currentCall) return null;
  currentCall = { ...currentCall, status: "ended" };
  emit("CALL_UPDATED", currentCall);
  return currentCall;
}
