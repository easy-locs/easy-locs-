import { supabase } from "@/lib/supabase";
import type { ChatMessage } from "@/types/domain";

export async function fetchMessages(conversationId: string) {
  const { data, error } = await supabase.from("messages").select("*").eq("conversation_id", conversationId).order("created_at", { ascending: true });
  if (error) throw error;
  return (data ?? []) as ChatMessage[];
}

export async function sendMessage(payload: Partial<ChatMessage>) {
  const { data, error } = await supabase.from("messages").insert(payload).select().single();
  if (error) throw error;
  return data as ChatMessage;
}
