import { supabase } from "@/lib/supabase";
import type { PropertyTransaction } from "@/types/domain";

export async function fetchPropertyTransactions(propertyId: string) {
  const { data, error } = await supabase.from("property_transactions").select("*").eq("property_id", propertyId).order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as PropertyTransaction[];
}
