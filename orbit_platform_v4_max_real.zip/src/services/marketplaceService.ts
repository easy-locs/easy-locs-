import { supabase } from "@/lib/supabase";
import type { Listing } from "@/types/domain";

export async function fetchListings() {
  const { data, error } = await supabase.from("listings").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as Listing[];
}

export async function createListing(payload: Partial<Listing>) {
  const { data, error } = await supabase.from("listings").insert(payload).select().single();
  if (error) throw error;
  return data as Listing;
}
