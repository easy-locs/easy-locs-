import { supabase } from "@/lib/supabase";
import type { WalletTransaction } from "@/types/domain";

export async function fetchTransactions() {
  const { data, error } = await supabase.from("wallet_transactions").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as WalletTransaction[];
}

export async function createTransaction(payload: Partial<WalletTransaction>) {
  const { data, error } = await supabase.from("wallet_transactions").insert(payload).select().single();
  if (error) throw error;
  return data as WalletTransaction;
}
