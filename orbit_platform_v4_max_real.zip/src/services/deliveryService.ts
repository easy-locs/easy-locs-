import { supabase } from "@/lib/supabase";
import type { DeliveryJob } from "@/types/domain";

export async function fetchDeliveries() {
  const { data, error } = await supabase.from("delivery_jobs").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as DeliveryJob[];
}

export async function createDelivery(orderId: string) {
  const { data, error } = await supabase.from("delivery_jobs").insert({ order_id: orderId, status: "pending" }).select().single();
  if (error) throw error;
  return data as DeliveryJob;
}
