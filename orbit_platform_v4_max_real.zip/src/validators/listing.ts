export function validateListing(input:{title:string;description:string;images:string[];price:number;shopLogo?:string|null}) {
  if (!input.shopLogo) throw new Error("Logo obligatoire");
  if (input.title.trim().length < 10) throw new Error("Titre trop court");
  if (input.description.trim().length < 30) throw new Error("Description insuffisante");
  if (input.images.length < 2) throw new Error("Minimum 2 images");
  if (input.price <= 0) throw new Error("Prix obligatoire");
  return 100;
}
