export type ChatMessage = {
  id?: string;
  conversation_id: string;
  content?: string | null;
  ciphertext?: string | null;
  type?: "text" | "payment" | "system";
  created_at?: string;
};

export type WalletTransaction = {
  id?: string;
  sender_orbit_id: string;
  receiver_orbit_id: string;
  amount_minor: number;
  currency: string;
  reference: string;
  crypto_id: string;
  status: "pending" | "completed" | "failed";
  signed_payload_b64: string;
  created_at?: string;
};

export type Listing = {
  id?: string;
  title: string;
  description: string;
  price: number;
  shop_logo: string;
  created_at?: string;
};

export type PropertyTransaction = {
  id?: string;
  property_id: string;
  type: "income" | "expense";
  amount: number;
  currency: string;
  note?: string | null;
  created_at?: string;
};

export type DeliveryJob = {
  id?: string;
  order_id?: string | null;
  status: "pending" | "accepted" | "in_progress" | "completed" | "cancelled";
  created_at?: string;
};

export type Shop = {
  id?: string;
  name: string;
  logo_url: string;
  verified: boolean;
  created_at?: string;
};
