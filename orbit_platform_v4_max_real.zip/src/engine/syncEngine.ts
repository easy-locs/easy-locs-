import { on } from "@/core/relay";
import { addJob } from "@/core/retryEngine";

let booted = false;

export function initSyncEngine() {
  if (booted) return;
  booted = true;

  on("TX_CREATED", (tx: any) => {
    addJob(async () => {
      console.log("[sync] tx", tx);
    }, 2, "SYNC_TX");
  });

  on("DELIVERY_CREATED", (delivery: any) => {
    addJob(async () => {
      console.log("[sync] delivery", delivery);
    }, 2, "SYNC_DELIVERY");
  });
}
