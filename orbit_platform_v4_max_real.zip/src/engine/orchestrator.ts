import { emit, on } from "@/core/relay";
import { addJob } from "@/core/retryEngine";
import { createTransaction } from "@/services/walletService";
import { createDelivery } from "@/services/deliveryService";
import { sendLocalNotification } from "@/services/notificationService";
import { usePlatformStore } from "@/store/platformStore";

let booted = false;

export function initOrchestrator() {
  if (booted) return;
  booted = true;

  on("PAYMENT_IN_CHAT", (payload: any) => {
    addJob(async () => {
      const tx = await createTransaction(payload);
      usePlatformStore.getState().addTransaction(tx);
      emit("TX_CREATED", tx);
    }, 3, "PAYMENT_IN_CHAT");
  });

  on("TX_CREATED", (tx: any) => {
    addJob(async () => {
      const completed = { ...tx, status: "completed" };
      emit("TX_COMPLETED", completed);
      sendLocalNotification("Transaction completed", completed.reference ?? "payment");
    }, 1, "TX_CREATED");
  });

  on("TX_COMPLETED", (payload: any) => {
    addJob(async () => {
      const delivery = await createDelivery(payload.id ?? payload.reference);
      usePlatformStore.getState().addDelivery(delivery);
      emit("DELIVERY_CREATED", delivery);
    }, 3, "TX_COMPLETED");
  });
}
