export function SecurityPage() {
  return (
    <>
      <div className="card hero">
        <h1 className="title">Security</h1>
        <p className="muted">Reserved block for hardened encryption, ghost, and identity layers.</p>
      </div>
      <div className="grid-2">
        <div className="card">
          <div className="h2">Current state</div>
          <ul>
            <li>Architecture ready for stronger crypto layer</li>
            <li>Platform flows already orchestrated</li>
            <li>Can be upgraded with E2EE and wallet signing</li>
          </ul>
        </div>
        <div className="card">
          <div className="h2">Next hardening</div>
          <ul>
            <li>Local key store</li>
            <li>Signed envelopes</li>
            <li>Ghost TTL and wipe</li>
            <li>Secure wallet confirmations</li>
          </ul>
        </div>
      </div>
    </>
  );
}
