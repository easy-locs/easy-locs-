import { ListingForm } from "@/components/ListingForm";
import { usePlatformStore } from "@/store/platformStore";

export function MarketplacePage() {
  const listings = usePlatformStore((s) => s.listings);

  return (
    <>
      <div className="card hero">
        <h1 className="title">Marketplace</h1>
        <p className="muted">Quality gate, anti-brouillon, logo required.</p>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="cover" />
          <div className="h2">Publish clean listing</div>
          <ListingForm />
        </div>

        <div className="card">
          <div className="h2">Listings</div>
          {listings.map((l, i) => (
            <div className="msg" key={l.id ?? i}>
              <div className="row">
                <strong>{l.title}</strong>
                <span className="pill">{l.price} AED</span>
              </div>
              <div className="muted">{l.description}</div>
              <div className="code">{l.shop_logo}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
