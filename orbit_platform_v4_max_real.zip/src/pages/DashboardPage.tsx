import { SectionCard } from "@/components/SectionCard";
import { StatTile } from "@/components/StatTile";
import { usePlatformStore } from "@/store/platformStore";

export function DashboardPage() {
  const issues = usePlatformStore((s) => s.issues);
  const transactions = usePlatformStore((s) => s.transactions);
  const deliveries = usePlatformStore((s) => s.deliveries);

  return (
    <>
      <div className="card hero">
        <div className="row">
          <div>
            <h1 className="title">Orbit Platform V4 Max Real</h1>
            <p className="muted">Marketplace + Property + Wallet + Delivery + Calls + Audit + Images</p>
          </div>
          <span className="pill">heavy block</span>
        </div>
      </div>

      <div className="grid-4">
        <StatTile label="Transactions" value={String(transactions.length)} />
        <StatTile label="Deliveries" value={String(deliveries.length)} />
        <StatTile label="Issues" value={String(issues.length)} />
        <StatTile label="Modules" value="10" />
      </div>

      <SectionCard title="Runtime issues">
        {issues.length === 0 ? <div className="pill success">No blocking runtime issues detected</div> : issues.map((i, idx) => <div className="msg" key={idx}>{i.area}: {i.message}</div>)}
      </SectionCard>
    </>
  );
}
