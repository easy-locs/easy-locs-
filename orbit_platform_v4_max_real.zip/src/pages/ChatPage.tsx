import { useState } from "react";
import { useMessages } from "@/hooks/useMessages";
import { usePlatformStore } from "@/store/platformStore";
import { sendMessage } from "@/services/chatService";
import { emit } from "@/core/relay";

export function ChatPage() {
  const [text, setText] = useState("");
  const messages = useMessages("demo-conversation");
  const addMessage = usePlatformStore((s) => s.addMessage);

  async function sendText() {
    const row = await sendMessage({
      conversation_id: "demo-conversation",
      content: text,
      type: "text"
    });
    addMessage(row);
    setText("");
  }

  function sendPayment() {
    emit("PAYMENT_IN_CHAT", {
      sender_orbit_id: "demo-user",
      receiver_orbit_id: "demo-peer",
      amount_minor: 2500,
      currency: "AED",
      reference: "TEMP",
      crypto_id: crypto.randomUUID(),
      status: "pending",
      signed_payload_b64: "demo-signature"
    });
  }

  return (
    <>
      <div className="card hero">
        <h1 className="title">Communication</h1>
        <p className="muted">Chat + payment in chat + system flow.</p>
      </div>

      <div className="card">
        <div className="col">
          {messages.map((m, i) => <div key={m.id ?? i} className="msg">{m.content ?? m.ciphertext ?? "message"}</div>)}
        </div>
        <textarea className="textarea" value={text} onChange={(e) => setText(e.target.value)} placeholder="Write message..." />
        <div className="row">
          <button className="btn secondary" onClick={() => void sendText()}>Send message</button>
          <button className="btn" onClick={sendPayment}>Send payment</button>
        </div>
      </div>
    </>
  );
}
