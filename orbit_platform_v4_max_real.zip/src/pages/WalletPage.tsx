import { TransactionList } from "@/components/TransactionList";
import { useTransactions } from "@/hooks/useTransactions";

export function WalletPage() {
  const txs = useTransactions();
  const balance = txs.filter((t) => t.status === "completed").reduce((s, t) => s + (t.amount_minor || 0), 0);

  return (
    <>
      <div className="card hero">
        <h1 className="title">Wallet</h1>
        <p className="muted">Visible balance, traceability, references, history.</p>
      </div>
      <div className="grid-2">
        <div className="card">
          <div className="muted">Balance</div>
          <div className="kpi">{(balance / 100).toFixed(2)} AED</div>
        </div>
        <div className="card">
          <div className="h2">Visible features</div>
          <ul>
            <li>Balance</li>
            <li>Send / Receive</li>
            <li>History</li>
            <li>Reference codes</li>
          </ul>
        </div>
      </div>
      <div className="card">
        <div className="h2">History</div>
        <TransactionList />
      </div>
    </>
  );
}
