import { useState } from "react";
import { startCall, acceptCall, endCall } from "@/services/callService";
import { useCallSession } from "@/hooks/useCallSession";

export function CallsPage() {
  const [peerId, setPeerId] = useState("demo-peer");
  const call = useCallSession();

  return (
    <>
      <div className="card hero">
        <h1 className="title">Calls</h1>
        <p className="muted">Call signaling shell integrated into the platform.</p>
      </div>
      <div className="card">
        <input className="input" value={peerId} onChange={(e) => setPeerId(e.target.value)} />
        <div className="row">
          <button className="btn" onClick={() => void startCall(peerId)}>Start</button>
          <button className="btn secondary" onClick={() => void acceptCall()}>Accept</button>
          <button className="btn secondary" onClick={() => void endCall()}>End</button>
        </div>
        <div className="msg">
          <div className="row">
            <strong>Call state</strong>
            <span className="pill">{call?.status ?? "idle"}</span>
          </div>
          <div className="code">{call ? JSON.stringify(call, null, 2) : "No active call"}</div>
        </div>
      </div>
    </>
  );
}
