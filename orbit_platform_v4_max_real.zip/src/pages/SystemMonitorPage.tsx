import { useEffect, useState } from "react";

export function SystemMonitorPage() {
  const [logs, setLogs] = useState<string[]>([]);

  useEffect(() => {
    const id = setInterval(() => {
      setLogs((prev) => [...prev.slice(-25), "System heartbeat " + new Date().toISOString()]);
    }, 1500);
    return () => clearInterval(id);
  }, []);

  return (
    <>
      <div className="card hero">
        <h1 className="title">System Monitor</h1>
        <p className="muted">Live engine activity.</p>
      </div>
      <div className="card">
        {logs.map((log, i) => <div key={i} className="msg">{log}</div>)}
      </div>
    </>
  );
}
