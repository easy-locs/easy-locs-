import { runtimeAudit } from "@/core/audit";

export function AdminAuditPage() {
  const issues = runtimeAudit();
  return (
    <>
      <div className="card hero">
        <h1 className="title">Admin Audit</h1>
        <p className="muted">Runtime checks and integration visibility.</p>
      </div>
      <div className="card">
        {issues.length === 0 ? <div className="pill success">No runtime blockers</div> : issues.map((issue, i) => <div key={i} className="msg">{issue}</div>)}
      </div>
      <div className="card">
        <ul>
          <li>Supabase credentials check</li>
          <li>Routes check</li>
          <li>Marketplace / Wallet / Property / Delivery visible</li>
          <li>Calls / Shops / Images present</li>
        </ul>
      </div>
    </>
  );
}
