import { useState } from "react";
import { resizeImage, scoreImageMeta } from "@/services/imageService";

export function ImagePipelinePage() {
  const [status, setStatus] = useState("");
  const [score, setScore] = useState<number | null>(null);

  async function handle(file: File | null) {
    if (!file) return;
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = async () => {
      setScore(scoreImageMeta(img.width, img.height));
      await resizeImage(file);
      setStatus("Image processed");
      URL.revokeObjectURL(url);
    };
    img.onerror = () => {
      setStatus("Image failed");
      URL.revokeObjectURL(url);
    };
    img.src = url;
  }

  return (
    <>
      <div className="card hero">
        <h1 className="title">Image Pipeline</h1>
        <p className="muted">Resize and score visuals for marketplace and menu.</p>
      </div>
      <div className="card">
        <input className="input" type="file" accept="image/*" onChange={(e) => void handle(e.target.files?.[0] ?? null)} />
        {score !== null ? <div className="pill">Quality score {score}</div> : null}
        {status ? <div className="msg">{status}</div> : null}
      </div>
    </>
  );
}
