import { useState } from "react";
import { createShop } from "@/services/shopService";
import { useShops } from "@/hooks/useShops";
import { usePlatformStore } from "@/store/platformStore";

export function ShopsPage() {
  const shops = useShops();
  const addShop = usePlatformStore((s) => s.addShop);
  const [name, setName] = useState("");
  const [logo, setLogo] = useState("");
  const [status, setStatus] = useState("");

  async function submit() {
    try {
      if (!logo) throw new Error("Logo obligatoire");
      const row = await createShop({ name, logo_url: logo, verified: false });
      addShop(row);
      setStatus("Shop created");
    } catch (e: any) {
      setStatus(e.message);
    }
  }

  return (
    <>
      <div className="card hero">
        <h1 className="title">Shops</h1>
        <p className="muted">Brand gate and structured shop profiles.</p>
      </div>
      <div className="grid-2">
        <div className="card">
          <input className="input" placeholder="Shop name" value={name} onChange={(e) => setName(e.target.value)} />
          <input className="input" placeholder="Logo URL" value={logo} onChange={(e) => setLogo(e.target.value)} />
          <button className="btn" onClick={() => void submit()}>Create shop</button>
          {status ? <div className="msg">{status}</div> : null}
        </div>
        <div className="card">
          <div className="h2">Shops</div>
          {shops.map((shop, i) => (
            <div className="msg" key={shop.id ?? i}>
              <div className="row">
                <strong>{shop.name}</strong>
                <span className="pill">{shop.verified ? "verified" : "draft"}</span>
              </div>
              <div className="code">{shop.logo_url}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
