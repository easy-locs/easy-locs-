import { useDeliveries } from "@/hooks/useDeliveries";

export function DeliveryPage() {
  const deliveries = useDeliveries();
  return (
    <>
      <div className="card hero">
        <h1 className="title">Delivery</h1>
        <p className="muted">Transaction complete should create delivery automatically.</p>
      </div>
      <div className="card">
        <div className="h2">Jobs</div>
        {deliveries.map((d, i) => (
          <div key={d.id ?? i} className="msg">
            <div className="row">
              <strong>{d.order_id ?? d.id}</strong>
              <span className="pill">{d.status}</span>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
