import { initPosEngine } from "@/engine/posEngine";

export async function bootstrapApp() {
  initPosEngine();
}
