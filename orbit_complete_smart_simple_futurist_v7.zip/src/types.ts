export type CartItem = {
  productId: string;
  name: string;
  qty: number;
  priceMinor: number;
};

export type Product = {
  id: string;
  name: string;
  priceMinor: number;
  category: string;
};

export type PosOrder = {
  id?: string;
  order_ref: string;
  customer_name?: string | null;
  items: CartItem[];
  total_minor: number;
  currency: string;
  payment_method: "cash" | "card" | "wallet";
  payment_status: "pending" | "completed" | "failed";
  requires_delivery: boolean;
  status: "draft" | "paid" | "in_kitchen" | "ready" | "delivering" | "completed";
  qr_code_value?: string | null;
  created_at?: string;
};

export type WalletTransaction = {
  id?: string;
  sender_orbit_id: string;
  receiver_orbit_id: string;
  amount_minor: number;
  currency: string;
  reference: string;
  crypto_id: string;
  status: "pending" | "completed" | "failed";
  signed_payload_b64: string;
  reference_type?: string | null;
  reference_id?: string | null;
  requires_delivery?: boolean | null;
  created_at?: string;
};

export type DeliveryJob = {
  id?: string;
  order_id?: string | null;
  source?: string | null;
  status: "pending" | "accepted" | "in_progress" | "completed" | "cancelled";
  created_at?: string;
};

export type TimelineEvent = {
  id: string;
  order_ref: string;
  stage: "order_created" | "payment_confirmed" | "wallet_recorded" | "delivery_created";
  detail: string;
  created_at: string;
};

export type Property = {
  id?: string;
  title: string;
  city: string;
  status: "occupied" | "vacant" | "maintenance";
  listing_mode?: "long_term" | "short_term" | "sale" | null;
};

export type PropertyTransaction = {
  id?: string;
  property_id: string;
  type: "income" | "expense";
  amount: number;
  currency: string;
  note?: string | null;
  created_at?: string;
};
