import { create } from "zustand";
import type { CartItem, DeliveryJob, PosOrder, Product, Property, PropertyTransaction, TimelineEvent, WalletTransaction } from "@/types";

const seedProducts: Product[] = [
  { id: "p1", name: "Margherita", priceMinor: 3500, category: "Pizza" },
  { id: "p2", name: "Pepperoni", priceMinor: 4200, category: "Pizza" },
  { id: "p3", name: "Chicken BBQ", priceMinor: 4500, category: "Pizza" },
  { id: "p4", name: "Coca Cola", priceMinor: 800, category: "Drink" },
  { id: "p5", name: "7Up", priceMinor: 800, category: "Drink" },
  { id: "p6", name: "Water", priceMinor: 500, category: "Drink" }
];

type State = {
  products: Product[];
  cart: CartItem[];
  orders: PosOrder[];
  txs: WalletTransaction[];
  deliveries: DeliveryJob[];
  timeline: TimelineEvent[];
  qrValue: string;
  runtimeLogs: string[];
  properties: Property[];
  propertyLedger: PropertyTransaction[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  setOrders: (rows: PosOrder[]) => void;
  addOrder: (row: PosOrder) => void;
  setTxs: (rows: WalletTransaction[]) => void;
  addTx: (row: WalletTransaction) => void;
  setDeliveries: (rows: DeliveryJob[]) => void;
  addDelivery: (row: DeliveryJob) => void;
  addTimeline: (row: TimelineEvent) => void;
  setQrValue: (value: string) => void;
  addRuntimeLog: (value: string) => void;
  setProperties: (rows: Property[]) => void;
  setPropertyLedger: (rows: PropertyTransaction[]) => void;
};

export const useAppStore = create<State>((set) => ({
  products: seedProducts,
  cart: [],
  orders: [],
  txs: [],
  deliveries: [],
  timeline: [],
  qrValue: "",
  runtimeLogs: [],
  properties: [],
  propertyLedger: [],
  addToCart: (product) => set((s) => {
    const existing = s.cart.find((i) => i.productId === product.id);
    if (existing) {
      return { cart: s.cart.map((i) => i.productId === product.id ? { ...i, qty: i.qty + 1 } : i) };
    }
    return { cart: [...s.cart, { productId: product.id, name: product.name, qty: 1, priceMinor: product.priceMinor }] };
  }),
  removeFromCart: (productId) => set((s) => ({
    cart: s.cart.flatMap((i) => {
      if (i.productId != productId) return [i];
      if (i.qty <= 1) return [];
      return [{ ...i, qty: i.qty - 1 }];
    })
  })),
  clearCart: () => set({ cart: [] }),
  setOrders: (orders) => set({ orders }),
  addOrder: (row) => set((s) => ({ orders: [row, ...s.orders] })),
  setTxs: (txs) => set({ txs }),
  addTx: (row) => set((s) => ({ txs: [row, ...s.txs] })),
  setDeliveries: (deliveries) => set({ deliveries }),
  addDelivery: (row) => set((s) => ({ deliveries: [row, ...s.deliveries] })),
  addTimeline: (row) => set((s) => ({ timeline: [row, ...s.timeline] })),
  setQrValue: (qrValue) => set({ qrValue }),
  addRuntimeLog: (value) => set((s) => ({ runtimeLogs: [value, ...s.runtimeLogs].slice(0, 60) })),
  setProperties: (properties) => set({ properties }),
  setPropertyLedger: (propertyLedger) => set({ propertyLedger })
}));
