type Job = { task: () => Promise<void>; retries: number; label?: string };
const queue: Job[] = [];
let running = false;

export function addJob(task: () => Promise<void>, retries = 3, label = "job") {
  queue.push({ task, retries, label });
  void run();
}

async function run() {
  if (running) return;
  running = true;
  while (queue.length) {
    const job = queue.shift()!;
    try {
      await job.task();
    } catch (e) {
      console.error("[retry]", job.label, e);
      if (job.retries > 0) queue.push({ ...job, retries: job.retries - 1 });
    }
  }
  running = false;
}
