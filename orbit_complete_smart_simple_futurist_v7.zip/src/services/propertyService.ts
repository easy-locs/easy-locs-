import { supabase } from "@/lib/supabase";
import type { Property, PropertyTransaction } from "@/types";

export async function fetchProperties() {
  const { data, error } = await supabase.from("properties").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as Property[];
}

export async function fetchPropertyLedger() {
  const { data, error } = await supabase.from("property_transactions").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as PropertyTransaction[];
}
