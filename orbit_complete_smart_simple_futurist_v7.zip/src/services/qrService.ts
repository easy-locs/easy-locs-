export function renderAsciiQr(value: string) {
  const chars = value.split("").map((c, i) => ((c.charCodeAt(0) + i) % 2 === 0 ? "██" : "  "));
  let out = "";
  for (let i = 0; i < chars.length; i += 12) out += chars.slice(i, i + 12).join("") + "\n";
  return out || "QR";
}

export function parseQrValue(value: string) {
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}
