import { supabase } from "@/lib/supabase";
import type { WalletTransaction } from "@/types";

export async function createWalletTransaction(payload: Partial<WalletTransaction>) {
  const { data, error } = await supabase.from("wallet_transactions").insert(payload).select().single();
  if (error) throw error;
  return data as WalletTransaction;
}

export async function fetchWalletTransactions() {
  const { data, error } = await supabase.from("wallet_transactions").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as WalletTransaction[];
}
