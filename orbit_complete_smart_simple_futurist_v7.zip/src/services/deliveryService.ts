import { supabase } from "@/lib/supabase";
import type { DeliveryJob } from "@/types";

export async function createDelivery(orderId: string, source = "v7_auto_trigger") {
  const { data, error } = await supabase.from("delivery_jobs").insert({
    order_id: orderId,
    status: "pending",
    source
  }).select().single();
  if (error) throw error;
  return data as DeliveryJob;
}

export async function fetchDeliveries() {
  const { data, error } = await supabase.from("delivery_jobs").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as DeliveryJob[];
}
