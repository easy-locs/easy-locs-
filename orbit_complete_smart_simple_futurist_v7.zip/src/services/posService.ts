import { supabase } from "@/lib/supabase";
import type { PosOrder } from "@/types";

export function makeOrderRef() {
  return "POS-" + Math.random().toString(36).slice(2, 8).toUpperCase();
}

export function buildQrValue(orderRef: string, amountMinor: number, currency: string) {
  return JSON.stringify({
    type: "pos_payment",
    order_ref: orderRef,
    amount_minor: amountMinor,
    currency
  });
}

export async function createOrder(order: Partial<PosOrder>) {
  const { data, error } = await supabase.from("pos_orders").insert(order).select().single();
  if (error) throw error;
  return data as PosOrder;
}

export async function fetchOrders() {
  const { data, error } = await supabase.from("pos_orders").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as PosOrder[];
}

export async function markOrderPaid(id: string) {
  const { data, error } = await supabase
    .from("pos_orders")
    .update({ payment_status: "completed", status: "paid" })
    .eq("id", id)
    .select()
    .single();
  if (error) throw error;
  return data as PosOrder;
}
