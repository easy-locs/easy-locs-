import { BrowserRouter, NavLink, Route, Routes } from "react-router-dom";
import { HomePage } from "@/pages/HomePage";
import { PosPage } from "@/pages/PosPage";
import { QrPage } from "@/pages/QrPage";
import { OrdersPage } from "@/pages/OrdersPage";
import { WalletPage } from "@/pages/WalletPage";
import { DeliveryPage } from "@/pages/DeliveryPage";
import { RuntimePage } from "@/pages/RuntimePage";
import { SecurityPage } from "@/pages/SecurityPage";
import { PropertyEntryPage } from "@/pages/property/PropertyEntryPage";
import { LandlordDashboardPage } from "@/pages/property/LandlordDashboardPage";
import { TenantDashboardPage } from "@/pages/property/TenantDashboardPage";
import { MarketplacePage } from "@/pages/MarketplacePage";
import { BusinessPage } from "@/pages/BusinessPage";

function BottomNav() {
  const items = [
    ["/", "Core"],
    ["/marketplace", "Market"],
    ["/business", "Business"],
    ["/pos", "POS"],
    ["/wallet", "Wallet"],
    ["/delivery", "Delivery"],
    ["/property", "Property"],
    ["/runtime", "Runtime"],
    ["/security", "Security"]
  ] as const;

  return (
    <nav className="bottom">
      {items.map(([to, label]) => (
        <NavLink key={to} to={to} className={({ isActive }) => isActive ? "nav active" : "nav"}>
          {label}
        </NavLink>
      ))}
    </nav>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <div className="shell">
        <div className="wrap">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/marketplace" element={<MarketplacePage />} />
            <Route path="/business" element={<BusinessPage />} />
            <Route path="/pos" element={<PosPage />} />
            <Route path="/qr" element={<QrPage />} />
            <Route path="/orders" element={<OrdersPage />} />
            <Route path="/wallet" element={<WalletPage />} />
            <Route path="/delivery" element={<DeliveryPage />} />
            <Route path="/runtime" element={<RuntimePage />} />
            <Route path="/security" element={<SecurityPage />} />
            <Route path="/property" element={<PropertyEntryPage />} />
            <Route path="/property/landlord" element={<LandlordDashboardPage />} />
            <Route path="/property/tenant" element={<TenantDashboardPage />} />
          </Routes>
        </div>
        <BottomNav />
      </div>
    </BrowserRouter>
  );
}
