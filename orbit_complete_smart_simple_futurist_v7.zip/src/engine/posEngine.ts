import { on } from "@/core/relay";
import { addJob } from "@/core/retryEngine";
import { markOrderPaid } from "@/services/posService";
import { createWalletTransaction } from "@/services/walletService";
import { createDelivery } from "@/services/deliveryService";
import { useAppStore } from "@/store/appStore";

let booted = false;

export function initPosEngine() {
  if (booted) return;
  booted = true;

  on("POS_PAYMENT_CONFIRMED", ({ order }: any) => {
    addJob(async () => {
      useAppStore.getState().addRuntimeLog(`Confirming payment for ${order.order_ref}`);
      const paid = await markOrderPaid(order.id);
      useAppStore.getState().addOrder(paid);
      useAppStore.getState().addTimeline({
        id: crypto.randomUUID(),
        order_ref: paid.order_ref,
        stage: "payment_confirmed",
        detail: `QR payment confirmed for ${paid.order_ref}`,
        created_at: new Date().toISOString()
      });

      const tx = await createWalletTransaction({
        sender_orbit_id: "customer-wallet",
        receiver_orbit_id: "merchant-wallet",
        amount_minor: paid.total_minor,
        currency: paid.currency,
        reference: paid.order_ref,
        crypto_id: crypto.randomUUID(),
        status: "completed",
        signed_payload_b64: "pos-signature",
        reference_type: "order",
        reference_id: paid.id ?? paid.order_ref,
        requires_delivery: paid.requires_delivery
      });
      useAppStore.getState().addTx(tx);
      useAppStore.getState().addTimeline({
        id: crypto.randomUUID(),
        order_ref: paid.order_ref,
        stage: "wallet_recorded",
        detail: `Wallet transaction created for ${paid.order_ref}`,
        created_at: new Date().toISOString()
      });

      if (paid.requires_delivery) {
        const delivery = await createDelivery(paid.id ?? paid.order_ref, "v7_pos_trigger");
        useAppStore.getState().addDelivery(delivery);
        useAppStore.getState().addTimeline({
          id: crypto.randomUUID(),
          order_ref: paid.order_ref,
          stage: "delivery_created",
          detail: `Delivery job created for ${paid.order_ref}`,
          created_at: new Date().toISOString()
        });
      }

      useAppStore.getState().clearCart();
    }, 3, "POS_PAYMENT_CONFIRMED");
  });
}
