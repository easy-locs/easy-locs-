import { useEffect } from "react";
import { fetchWalletTransactions } from "@/services/walletService";
import { useAppStore } from "@/store/appStore";

export function WalletPage() {
  const txs = useAppStore((s) => s.txs);
  const setTxs = useAppStore((s) => s.setTxs);

  useEffect(() => {
    void fetchWalletTransactions().then(setTxs).catch(console.error);
  }, [setTxs]);

  const balance = txs.filter((t) => t.status === "completed").reduce((s, t) => s + (t.amount_minor || 0), 0);

  return (
    <>
      <div className="card hero">
        <h1 className="title">Wallet</h1>
        <p className="muted">QR settlement, references, completed balance.</p>
      </div>
      <div className="grid-2">
        <div className="card">
          <div className="muted">Balance</div>
          <div className="kpi">{(balance / 100).toFixed(2)} AED</div>
        </div>
        <div className="card">
          <div className="h2">Transactions</div>
          <div className="col">
            {txs.map((tx, i) => (
              <div key={tx.id ?? i} className="msg">
                <div className="row">
                  <strong>{((tx.amount_minor || 0) / 100).toFixed(2)} {tx.currency}</strong>
                  <span className="pill">{tx.status}</span>
                </div>
                <div className="small">reference_type: {tx.reference_type ?? "-"}</div>
                <div className="small">requires_delivery: {String(tx.requires_delivery ?? false)}</div>
                <div className="receipt">{tx.reference}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
