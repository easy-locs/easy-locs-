import { useMemo, useState } from "react";
import { useAppStore } from "@/store/appStore";
import { buildQrValue, createOrder, makeOrderRef } from "@/services/posService";
import { renderAsciiQr } from "@/services/qrService";

export function PosPage() {
  const { products, cart, addToCart, removeFromCart, setQrValue, qrValue, addOrder, addTimeline } = useAppStore();
  const [customer, setCustomer] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "card" | "wallet">("wallet");
  const [requiresDelivery, setRequiresDelivery] = useState(true);
  const [status, setStatus] = useState("");

  const totalMinor = useMemo(() => cart.reduce((sum, item) => sum + item.qty * item.priceMinor, 0), [cart]);

  async function createPosOrder() {
    try {
      const orderRef = makeOrderRef();
      const qr = buildQrValue(orderRef, totalMinor, "AED");
      const order = await createOrder({
        order_ref: orderRef,
        customer_name: customer || null,
        items: cart,
        total_minor: totalMinor,
        currency: "AED",
        payment_method: paymentMethod,
        payment_status: paymentMethod === "cash" ? "completed" : "pending",
        requires_delivery: requiresDelivery,
        status: paymentMethod === "cash" ? "paid" : "draft",
        qr_code_value: qr
      });
      addOrder(order);
      addTimeline({
        id: crypto.randomUUID(),
        order_ref: order.order_ref,
        stage: "order_created",
        detail: `Order ${order.order_ref} created`,
        created_at: new Date().toISOString()
      });
      setQrValue(qr);
      setStatus(`Order created: ${order.order_ref}`);
    } catch (e: any) {
      setStatus(e.message);
    }
  }

  return (
    <>
      <div className="card hero">
        <h1 className="title">POS / Caisse tactile</h1>
        <p className="muted">Large buttons, simple flow, QR ready.</p>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="h2">Menu</div>
          <div className="product-grid">
            {products.map((p) => (
              <button key={p.id} className="product" onClick={() => addToCart(p)}>
                <strong>{p.name}</strong>
                <span className="muted">{p.category}</span>
                <span>{(p.priceMinor / 100).toFixed(2)} AED</span>
              </button>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="h2">Cart</div>
          <div className="col">
            {cart.map((item) => (
              <div key={item.productId} className="msg">
                <div className="row">
                  <strong>{item.name}</strong>
                  <span>{item.qty} × {(item.priceMinor / 100).toFixed(2)}</span>
                </div>
                <div className="row">
                  <span className="pill">{((item.qty * item.priceMinor) / 100).toFixed(2)} AED</span>
                  <button className="btn secondary" onClick={() => removeFromCart(item.productId)}>-1</button>
                </div>
              </div>
            ))}
          </div>

          <input className="input" placeholder="Customer name" value={customer} onChange={(e) => setCustomer(e.target.value)} />
          <select className="select" value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value as any)}>
            <option value="wallet">Wallet / QR</option>
            <option value="cash">Cash</option>
            <option value="card">Card</option>
          </select>

          <label className="pill">
            <input type="checkbox" checked={requiresDelivery} onChange={(e) => setRequiresDelivery(e.target.checked)} />
            Requires delivery
          </label>

          <div className="row">
            <div>
              <div className="muted">Total</div>
              <div className="kpi">{(totalMinor / 100).toFixed(2)} AED</div>
            </div>
            <button className="btn" onClick={() => void createPosOrder()}>Create order</button>
          </div>

          {status ? <div className="msg">{status}</div> : null}
        </div>
      </div>

      <div className="card">
        <div className="h2">Payment QR</div>
        <div className="qr-box">
          <pre className="receipt">{qrValue ? renderAsciiQr(qrValue) : "No QR yet"}</pre>
        </div>
        <div className="receipt">{qrValue || "No QR payload"}</div>
      </div>
    </>
  );
}
