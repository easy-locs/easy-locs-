import { useEffect } from "react";
import { fetchOrders } from "@/services/posService";
import { useAppStore } from "@/store/appStore";

export function OrdersPage() {
  const orders = useAppStore((s) => s.orders);
  const timeline = useAppStore((s) => s.timeline);
  const setOrders = useAppStore((s) => s.setOrders);

  useEffect(() => {
    void fetchOrders().then(setOrders).catch(console.error);
  }, [setOrders]);

  return (
    <>
      <div className="card hero">
        <h1 className="title">Orders</h1>
        <p className="muted">Order state and clear timeline.</p>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="h2">Orders</div>
          <div className="col">
            {orders.map((order, i) => (
              <div key={order.id ?? i} className="msg">
                <div className="row">
                  <strong>{order.order_ref}</strong>
                  <span className="pill">{order.status}</span>
                </div>
                <div className="row">
                  <span>{(order.total_minor / 100).toFixed(2)} {order.currency}</span>
                  <span className="pill">{order.payment_status}</span>
                </div>
                <div className="small muted">requires_delivery: {String(order.requires_delivery)}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="h2">Timeline</div>
          <div className="timeline">
            {timeline.map((event) => (
              <div key={event.id} className="timeline-item">
                <strong>{event.order_ref}</strong>
                <span className="pill">{event.stage}</span>
                <div className="muted small">{event.detail}</div>
                <div className="small">{event.created_at}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
