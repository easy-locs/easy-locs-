export function SecurityPage() {
  return (
    <>
      <div className="card hero">
        <h1 className="title">Security</h1>
        <p className="muted">Reserved block for hardened crypto, ghost mode, wallet signing and relay privacy.</p>
      </div>
      <div className="grid-2">
        <div className="card">
          <div className="h2">Current</div>
          <ul>
            <li>Structured payment chain</li>
            <li>Explicit requires_delivery logic</li>
            <li>Timeline and runtime visibility</li>
          </ul>
        </div>
        <div className="card">
          <div className="h2">Next</div>
          <ul>
            <li>Encrypted envelopes</li>
            <li>Signed wallet confirmation</li>
            <li>Ghost TTL and wipe</li>
          </ul>
        </div>
      </div>
    </>
  );
}
