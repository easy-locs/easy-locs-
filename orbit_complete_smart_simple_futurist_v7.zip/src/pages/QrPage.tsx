import { useState } from "react";
import { parseQrValue } from "@/services/qrService";
import { fetchOrders } from "@/services/posService";
import { emit } from "@/core/relay";

export function QrPage() {
  const [input, setInput] = useState("");
  const [status, setStatus] = useState("");

  async function confirmPayment() {
    const parsed = parseQrValue(input);
    if (!parsed) {
      setStatus("Invalid QR payload");
      return;
    }
    const orders = await fetchOrders();
    const found = orders.find((o) => o.order_ref === parsed.order_ref);
    if (!found) {
      setStatus("Order not found");
      return;
    }
    emit("POS_PAYMENT_CONFIRMED", { order: found });
    setStatus(`Payment confirmed for ${found.order_ref}`);
  }

  return (
    <>
      <div className="card hero">
        <h1 className="title">QR Payment</h1>
        <p className="muted">Paste or scan QR payload and confirm payment.</p>
      </div>
      <div className="card">
        <textarea className="textarea" value={input} onChange={(e) => setInput(e.target.value)} placeholder="Paste QR payload..." />
        <button className="btn" onClick={() => void confirmPayment()}>Confirm QR payment</button>
        {status ? <div className="msg">{status}</div> : null}
      </div>
    </>
  );
}
