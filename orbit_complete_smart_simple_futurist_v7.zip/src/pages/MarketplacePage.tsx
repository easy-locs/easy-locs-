export function MarketplacePage() {
  return (
    <>
      <div className="card hero">
        <h1 className="title">Marketplace</h1>
        <p className="muted">Public listings, products and services. Property stays managed separately but can be listed later.</p>
      </div>
      <div className="grid-3">
        <div className="card"><div className="cover" /><div className="h2">Products</div></div>
        <div className="card"><div className="cover" /><div className="h2">Services</div></div>
        <div className="card"><div className="cover" /><div className="h2">Listings</div></div>
      </div>
    </>
  );
}
