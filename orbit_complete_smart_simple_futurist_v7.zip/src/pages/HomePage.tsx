export function HomePage() {
  return (
    <>
      <div className="card hero">
        <div className="row">
          <div>
            <h1 className="title">Orbit V7 Complete</h1>
            <p className="muted">Smart, simple, futurist platform with separated business and property management.</p>
          </div>
          <span className="pill">complete pack</span>
        </div>
      </div>

      <div className="grid-4">
        <div className="card"><div className="muted">Marketplace</div><div className="kpi">Clean</div></div>
        <div className="card"><div className="muted">Business</div><div className="kpi">Linked</div></div>
        <div className="card"><div className="muted">Property</div><div className="kpi">Separate</div></div>
        <div className="card"><div className="muted">POS + QR</div><div className="kpi">Ready</div></div>
      </div>
    </>
  );
}
