import { useEffect } from "react";
import { fetchProperties, fetchPropertyLedger } from "@/services/propertyService";
import { useAppStore } from "@/store/appStore";

export function LandlordDashboardPage() {
  const properties = useAppStore((s) => s.properties);
  const ledger = useAppStore((s) => s.propertyLedger);
  const setProperties = useAppStore((s) => s.setProperties);
  const setLedger = useAppStore((s) => s.setPropertyLedger);

  useEffect(() => {
    void fetchProperties().then(setProperties).catch(console.error);
    void fetchPropertyLedger().then(setLedger).catch(console.error);
  }, [setProperties, setLedger]);

  const income = ledger.filter((r) => r.type === "income").reduce((s, r) => s + Number(r.amount || 0), 0);
  const expenses = ledger.filter((r) => r.type === "expense").reduce((s, r) => s + Number(r.amount || 0), 0);

  return (
    <>
      <div className="card hero">
        <h1 className="title">Landlord</h1>
        <p className="muted">Dashboard, properties, units, tenants, rent tracking, maintenance, documents, accounting and publish listings.</p>
      </div>

      <div className="grid-4">
        <div className="card"><div className="muted">Properties</div><div className="kpi">{properties.length}</div></div>
        <div className="card"><div className="muted">Income</div><div className="kpi">{income.toFixed(2)}</div></div>
        <div className="card"><div className="muted">Expenses</div><div className="kpi">{expenses.toFixed(2)}</div></div>
        <div className="card"><div className="muted">Listings sync</div><div className="kpi">Ready</div></div>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="h2">Landlord sections</div>
          <div className="grid-2">
            <button className="btn secondary">Dashboard</button>
            <button className="btn secondary">Properties</button>
            <button className="btn secondary">Units</button>
            <button className="btn secondary">Tenants</button>
            <button className="btn secondary">Rent Tracking</button>
            <button className="btn secondary">Maintenance</button>
            <button className="btn secondary">Documents</button>
            <button className="btn secondary">Accounting</button>
            <button className="btn ghost">Publish Listings</button>
          </div>
        </div>

        <div className="card">
          <div className="h2">Properties</div>
          <div className="col">
            {properties.map((p, i) => (
              <div key={p.id ?? i} className="msg">
                <div className="row">
                  <strong>{p.title}</strong>
                  <span className="pill">{p.status}</span>
                </div>
                <div className="small">city: {p.city}</div>
                <div className="small">listing_mode: {p.listing_mode ?? "-"}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
