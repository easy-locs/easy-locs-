import { useNavigate } from "react-router-dom";

export function PropertyEntryPage() {
  const navigate = useNavigate();

  return (
    <>
      <div className="card hero">
        <h1 className="title">Property Management</h1>
        <p className="muted">Choose one role first. One screen = one decision.</p>
      </div>

      <div className="grid-2">
        <button className="role" onClick={() => navigate("/property/landlord")}>
          <strong>Landlord</strong>
          <span className="muted">Manage properties, rents, tenants, accounting and listings.</span>
        </button>

        <button className="role" onClick={() => navigate("/property/tenant")}>
          <strong>Tenant</strong>
          <span className="muted">Access rent, payments, documents and maintenance requests.</span>
        </button>
      </div>
    </>
  );
}
