export function TenantDashboardPage() {
  return (
    <>
      <div className="card hero">
        <h1 className="title">Tenant</h1>
        <p className="muted">My property, rent, payments, maintenance requests and documents.</p>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="h2">Tenant sections</div>
          <div className="grid-2">
            <button className="btn secondary">My Property</button>
            <button className="btn secondary">My Rent</button>
            <button className="btn secondary">Payments</button>
            <button className="btn secondary">Maintenance Requests</button>
            <button className="btn secondary">Documents</button>
          </div>
        </div>

        <div className="card">
          <div className="h2">Simple future UX</div>
          <ul>
            <li>No landlord tools on tenant screen</li>
            <li>No crowded mixed layout</li>
            <li>Large smart buttons</li>
            <li>Clean mobile-first flow</li>
          </ul>
        </div>
      </div>
    </>
  );
}
