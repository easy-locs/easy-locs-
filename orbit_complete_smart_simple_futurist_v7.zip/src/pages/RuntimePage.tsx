import { useAppStore } from "@/store/appStore";

export function RuntimePage() {
  const logs = useAppStore((s) => s.runtimeLogs);
  return (
    <>
      <div className="card hero">
        <h1 className="title">Runtime</h1>
        <p className="muted">Observe the live execution of the payment chain.</p>
      </div>
      <div className="card">
        <div className="col">
          {logs.map((log, i) => <div key={i} className="msg">{log}</div>)}
        </div>
      </div>
    </>
  );
}
