import { Link } from "react-router-dom";

export function BusinessPage() {
  return (
    <>
      <div className="card hero">
        <h1 className="title">Your Business</h1>
        <p className="muted">Shops, orders, POS, wallet, delivery and business analytics only.</p>
      </div>

      <div className="grid-3">
        <div className="card">
          <div className="h2">Operations</div>
          <div className="col">
            <Link className="btn secondary" to="/pos">Open POS</Link>
            <Link className="btn secondary" to="/orders">Orders</Link>
            <Link className="btn secondary" to="/wallet">Wallet</Link>
            <Link className="btn secondary" to="/delivery">Delivery</Link>
          </div>
        </div>

        <div className="card">
          <div className="h2">Smart shortcut</div>
          <div className="muted">Property management is not mixed here.</div>
          <Link className="btn ghost" to="/property">Open Property Management</Link>
        </div>

        <div className="card">
          <div className="h2">Quick KPIs</div>
          <div className="row"><span className="muted">Properties</span><span className="pill">separate module</span></div>
          <div className="row"><span className="muted">POS</span><span className="pill">active</span></div>
          <div className="row"><span className="muted">Delivery</span><span className="pill">linked</span></div>
        </div>
      </div>
    </>
  );
}
