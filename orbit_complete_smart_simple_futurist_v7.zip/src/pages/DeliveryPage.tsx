import { useEffect } from "react";
import { fetchDeliveries } from "@/services/deliveryService";
import { useAppStore } from "@/store/appStore";

export function DeliveryPage() {
  const deliveries = useAppStore((s) => s.deliveries);
  const setDeliveries = useAppStore((s) => s.setDeliveries);

  useEffect(() => {
    void fetchDeliveries().then(setDeliveries).catch(console.error);
  }, [setDeliveries]);

  return (
    <>
      <div className="card hero">
        <h1 className="title">Delivery</h1>
        <p className="muted">Only order payments with requires_delivery = true create jobs.</p>
      </div>
      <div className="card">
        <div className="col">
          {deliveries.map((row, i) => (
            <div key={row.id ?? i} className="msg">
              <div className="row">
                <strong>{row.order_id}</strong>
                <span className="pill">{row.status}</span>
              </div>
              <div className="small">source: {row.source ?? "-"}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
