create table if not exists pos_orders (
  id uuid primary key default gen_random_uuid(),
  order_ref text not null unique,
  customer_name text null,
  items jsonb not null default '[]'::jsonb,
  total_minor bigint not null,
  currency text not null default 'AED',
  payment_method text not null,
  payment_status text not null default 'pending',
  requires_delivery boolean not null default true,
  status text not null default 'draft',
  qr_code_value text null,
  created_at timestamptz not null default now()
);

create table if not exists wallet_transactions (
  id uuid primary key default gen_random_uuid(),
  sender_orbit_id text not null,
  receiver_orbit_id text not null,
  amount_minor bigint not null,
  currency text not null,
  reference text not null,
  crypto_id text not null,
  status text not null default 'pending',
  signed_payload_b64 text not null,
  reference_type text null,
  reference_id text null,
  requires_delivery boolean null default false,
  created_at timestamptz not null default now()
);

create table if not exists delivery_jobs (
  id uuid primary key default gen_random_uuid(),
  order_id text null,
  source text null,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table if not exists properties (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  city text not null,
  status text not null default 'vacant',
  listing_mode text null,
  created_at timestamptz not null default now()
);

create table if not exists property_transactions (
  id uuid primary key default gen_random_uuid(),
  property_id text not null,
  type text not null,
  amount numeric not null,
  currency text not null default 'AED',
  note text null,
  created_at timestamptz not null default now()
);
