# Orbit V7 Complete

This package continues the platform with:
- marketplace page
- business page
- POS + QR flow
- wallet settlement
- auto delivery trigger
- property management separated from business
- landlord / tenant role entry
- landlord and tenant dedicated dashboards
- smart simple futurist UI

## Run
1. Copy `.env.example` to `.env`
2. Fill Supabase credentials
3. Apply `supabase/schema.sql`
4. npm install
5. npm run dev
