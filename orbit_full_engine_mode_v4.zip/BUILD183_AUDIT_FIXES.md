BUILD 183 AUDIT FIXES
- DeliveryOfferSheet now accepts real distance, packageClass, and currency props.
- MenuImageNormalizerCard now revokes previous object URLs, cleans up on unmount, and shows errors.
- buildNormalizedFilename now respects output MIME type extension.
- canReleaseEscrow now validates photo/signature payloads, lat+lng, geo accuracy, and optional confirmation code.
- DeliveryRadarMap now exposes placeholder vs connected mode to avoid overstating map completeness.
