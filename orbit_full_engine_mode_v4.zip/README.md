# Orbit UI Secure Lovable Pack

This pack is designed to be pushed into Lovable for the visible UI and flow wiring.

## Included
- Orbit ID bootstrap without phone number
- Local key persistence
- Signed prekey generation and publication
- Session state with counters
- Envelope encryption and local decryption flow
- Ghost TTL state
- Wallet payment signing and references
- Relay privacy packing page
- React pages for Core / Chat / Wallet / Relay / Security

## Run
1. Copy `.env.example` to `.env`
2. Add Supabase URL and anon key
3. Apply `supabase/schema.sql`
4. `npm install`
5. `npm run dev`

## Honest note
This pack is UI-ready and structurally serious.
It is not a complete production Signal-compatible protocol or native secure enclave integration.
Those require additional native / audited work.
