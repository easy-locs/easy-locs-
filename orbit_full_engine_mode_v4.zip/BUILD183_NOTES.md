BUILD 183
- Added menu image detector + smart normalizer for harmonized food photos
- Detects portrait / square / landscape inputs
- Recommends preset automatically
- Resizes and center-crops to Deliveroo/menu-friendly output
- Demo page added: FullBuild183MenuImageDemo.tsx
