export type IdentityState = {
  orbitId: string;
  deviceId: string;
};

export type DevicePublicBundle = {
  orbit_id: string;
  device_id: string;
  sign_public_jwk: JsonWebKey;
  kex_public_jwk: JsonWebKey;
};

export type SignedPrekey = {
  orbit_id: string;
  key_id: string;
  public_jwk: JsonWebKey;
  signature_b64: string;
  used: boolean;
};

export type SecureEnvelope = {
  id?: string;
  conversation_id: string;
  sender_orbit_id: string;
  sender_device_id: string;
  receiver_orbit_id: string;
  ratchet_counter: number;
  ghost: boolean;
  expires_at?: string | null;
  aad: string;
  iv: number[];
  ciphertext: string;
  signature_b64: string;
  created_at?: string;
};

export type WalletTransaction = {
  reference: string;
  crypto_id: string;
  sender_orbit_id: string;
  receiver_orbit_id: string;
  amount_minor: number;
  currency: string;
  status: "pending" | "completed" | "failed";
  chat_conversation_id?: string | null;
  signed_payload_b64: string;
  created_at?: string;
};
