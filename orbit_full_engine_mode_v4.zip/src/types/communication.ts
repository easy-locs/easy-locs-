export type OrbitConversationMode = "standard" | "ghost";
export type OrbitMessageKind = "text" | "attachment" | "system";
export type OrbitCallType = "audio" | "video";
export type OrbitDeliveryState = "sending" | "sent" | "delivered" | "read" | "failed";

export type OrbitParticipant = {
  id: string;
  displayName: string;
  avatarUrl?: string;
  isVerified?: boolean;
  isOnline?: boolean;
};

export type OrbitAttachment = {
  id: string;
  filename: string;
  mimeType: string;
  sizeBytes: number;
  encryptedBlobRef?: string;
  expiresAt?: string;
};

export type OrbitMessage = {
  id: string;
  conversationId: string;
  senderId: string;
  body: string;
  kind: OrbitMessageKind;
  createdAt: string;
  deliveryState: OrbitDeliveryState;
  attachments?: OrbitAttachment[];
  isEphemeral?: boolean;
  expiresAt?: string;
};

export type OrbitConversation = {
  id: string;
  title: string;
  mode: OrbitConversationMode;
  participants: OrbitParticipant[];
  lastMessagePreview?: string;
  lastActivityAt: string;
  unreadCount: number;
  isLocked?: boolean;
  ttlSeconds?: number;
};

export type OrbitGhostSession = {
  sessionId: string;
  unlockedAt: string;
  expiresAt: string;
  biometricRequired: boolean;
};

export type OrbitDeviceIdentity = {
  deviceId: string;
  fingerprint: string;
  createdAt: string;
  publicKeyHint: string;
};

export type OrbitKeyEnvelope = {
  keyId: string;
  algorithm: string;
  createdAt: string;
  expiresAt?: string;
  materialB64: string;
};
