export type RadarDriver = {
  id: string;
  lat: number;
  lng: number;
  heading?: number;
  speed?: number;
  status: "idle" | "busy" | "offline";
  vehicleType?: "bike" | "scooter" | "car" | "van";
};

export type RadarOrder = {
  id: string;
  lat: number;
  lng: number;
  status: "pending" | "assigned" | "picked_up" | "delivered";
  createdAt: string;
  packageClass?: "light" | "medium" | "heavy";
};

export type HeatPoint = {
  lat: number;
  lng: number;
  intensity: number;
};
