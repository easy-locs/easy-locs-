export function getPackageClass(weightKg: number, volumeScore = 1): "light" | "medium" | "heavy" {
  const score = weightKg * volumeScore;

  if (score <= 2) return "light";
  if (score <= 10) return "medium";
  return "heavy";
}

export function canDriverHandlePackage(
  vehicleType: "bike" | "scooter" | "car" | "van",
  packageClass: "light" | "medium" | "heavy"
) {
  if (packageClass === "light") return true;
  if (packageClass === "medium") return vehicleType !== "bike";
  return vehicleType === "car" || vehicleType === "van";
}
