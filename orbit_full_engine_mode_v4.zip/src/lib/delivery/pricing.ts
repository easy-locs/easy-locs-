export type DeliveryOffer = {
  id: string;
  orderId: string;
  driverId: string;
  mode: "fixed" | "progressive";
  basePrice: number;
  pricePerKm?: number;
  minPrice?: number;
  heavySurcharge?: number;
  etaMin?: number;
};

export function computeDeliveryPrice(params: {
  distanceKm: number;
  packageClass: "light" | "medium" | "heavy";
  offer: DeliveryOffer;
}) {
  const { distanceKm, packageClass, offer } = params;

  let total =
    offer.mode === "fixed"
      ? offer.basePrice
      : offer.basePrice + distanceKm * (offer.pricePerKm ?? 0);

  if (packageClass === "heavy") {
    total += offer.heavySurcharge ?? 0;
  }

  if (offer.minPrice) {
    total = Math.max(total, offer.minPrice);
  }

  return Math.round(total * 100) / 100;
}
