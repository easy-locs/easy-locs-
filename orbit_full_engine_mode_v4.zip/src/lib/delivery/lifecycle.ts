export type DeliveryMissionStatus =
  | "created"
  | "bidding"
  | "driver_selected"
  | "escrow_locked"
  | "picked_up"
  | "in_transit"
  | "proof_submitted"
  | "released"
  | "cancelled";

export type DeliveryProof = {
  photoTaken: boolean;
  photoUrl?: string;
  signatureCaptured: boolean;
  signatureData?: string;
  qrScanned: boolean;
  qrCode?: string;
  geoLat: number | null;
  geoLng: number | null;
  geoAccuracy: number | null;
  recipientName?: string;
  notes?: string;
  deliveredAt?: string;
  confirmationCode?: string;
  confirmationCodeMatched?: boolean;
};

export function canReleaseEscrow(
  proof: DeliveryProof,
  options: {
    requireConfirmationCode?: boolean;
    maxGeoAccuracyMeters?: number;
  } = {}
) {
  const { requireConfirmationCode = false, maxGeoAccuracyMeters = 100 } = options;

  const hasPhoto = proof.photoTaken && !!proof.photoUrl;
  const hasSignature = proof.signatureCaptured && !!proof.signatureData;
  const hasGeo = proof.geoLat !== null && proof.geoLng !== null;
  const hasAcceptableGeo =
    proof.geoAccuracy === null || proof.geoAccuracy <= maxGeoAccuracyMeters;
  const hasDeliveryTime = !!proof.deliveredAt;
  const hasConfirmation =
    !requireConfirmationCode || (!!proof.confirmationCode && !!proof.confirmationCodeMatched);

  return !!(hasPhoto && hasSignature && hasGeo && hasAcceptableGeo && hasDeliveryTime && hasConfirmation);
}
