export type RouteMetrics = {
  distanceKm: number;
  estimatedMinutes: number;
  demandLevel: "low" | "normal" | "high";
  surgeMultiplier: number;
};

export function buildRouteMetrics(params: {
  distanceKm: number;
  averageSpeedKmh?: number;
  activeOrders?: number;
  activeDrivers?: number;
}): RouteMetrics {
  const {
    distanceKm,
    averageSpeedKmh = 24,
    activeOrders = 0,
    activeDrivers = 0,
  } = params;

  const safeDistance = Math.max(0, distanceKm);
  const speed = Math.max(8, averageSpeedKmh);
  const ratio = activeDrivers <= 0 ? activeOrders : activeOrders / activeDrivers;

  let demandLevel: RouteMetrics["demandLevel"] = "low";
  let surgeMultiplier = 1;

  if (ratio >= 2.2) {
    demandLevel = "high";
    surgeMultiplier = 1.2;
  } else if (ratio >= 1.2) {
    demandLevel = "normal";
    surgeMultiplier = 1.08;
  }

  const estimatedMinutes = Math.max(6, Math.round((safeDistance / speed) * 60) + 6);

  return {
    distanceKm: Number(safeDistance.toFixed(1)),
    estimatedMinutes,
    demandLevel,
    surgeMultiplier,
  };
}
