import type { OrbitCallType } from "@/types/communication";
import { randomHex } from "@/lib/security/secure-storage";

export type OrbitCallSession = {
  id: string;
  type: OrbitCallType;
  state: "idle" | "ringing" | "connecting" | "active" | "ended";
  startedAt?: string;
};

export function createCallSession(type: OrbitCallType): OrbitCallSession {
  return {
    id: `call_${randomHex(10)}`,
    type,
    state: "ringing",
  };
}
