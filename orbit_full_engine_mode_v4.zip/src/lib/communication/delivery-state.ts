import type { OrbitDeliveryState, OrbitMessage } from "@/types/communication";

export function getNextDeliveryState(current: OrbitDeliveryState): OrbitDeliveryState {
  if (current === "sending") return "sent";
  if (current === "sent") return "delivered";
  if (current === "delivered") return "read";
  return current;
}

export function advanceMessageDelivery(message: OrbitMessage): OrbitMessage {
  return { ...message, deliveryState: getNextDeliveryState(message.deliveryState) };
}
