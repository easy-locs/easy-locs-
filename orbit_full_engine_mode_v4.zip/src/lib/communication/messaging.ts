import type { OrbitConversation, OrbitConversationMode, OrbitMessage, OrbitParticipant } from "@/types/communication";
import { randomHex } from "@/lib/security/secure-storage";

export function createDemoConversations(): OrbitConversation[] {
  return [
    {
      id: "conv_standard_ops",
      title: "Operations HQ",
      mode: "standard",
      unreadCount: 3,
      lastActivityAt: new Date().toISOString(),
      lastMessagePreview: "Driver Lina is 4 min away.",
      participants: demoParticipants(["me", "lina", "ops"]),
    },
    {
      id: "conv_ghost_exec",
      title: "Ghost Exec",
      mode: "ghost",
      unreadCount: 1,
      lastActivityAt: new Date(Date.now() - 1000 * 60 * 11).toISOString(),
      lastMessagePreview: "Preview hidden",
      ttlSeconds: 900,
      isLocked: true,
      participants: demoParticipants(["me", "ceo"]),
    },
  ];
}

export function createDemoMessages(conversationId: string, mode: OrbitConversationMode): OrbitMessage[] {
  const now = Date.now();
  const base: OrbitMessage[] = [
    {
      id: `msg_${randomHex(8)}`,
      conversationId,
      senderId: "lina",
      body: mode === "ghost" ? "Ghost note: supplier route changed." : "Supplier route changed, ETA 9 min.",
      kind: "text",
      createdAt: new Date(now - 1000 * 60 * 14).toISOString(),
      deliveryState: "read",
      isEphemeral: mode === "ghost",
      expiresAt: mode === "ghost" ? new Date(now + 1000 * 60 * 10).toISOString() : undefined,
    },
    {
      id: `msg_${randomHex(8)}`,
      conversationId,
      senderId: "me",
      body: mode === "ghost" ? "Keep channel silent." : "Copy that. Keep me posted.",
      kind: "text",
      createdAt: new Date(now - 1000 * 60 * 8).toISOString(),
      deliveryState: "read",
      isEphemeral: mode === "ghost",
      expiresAt: mode === "ghost" ? new Date(now + 1000 * 60 * 8).toISOString() : undefined,
    },
  ];
  return base;
}

export function makeOutgoingMessage(conversationId: string, body: string, senderId = "me", mode: OrbitConversationMode = "standard"): OrbitMessage {
  const now = Date.now();
  return {
    id: `msg_${randomHex(10)}`,
    conversationId,
    senderId,
    body,
    kind: "text",
    createdAt: new Date(now).toISOString(),
    deliveryState: "sending",
    isEphemeral: mode === "ghost",
    expiresAt: mode === "ghost" ? new Date(now + 1000 * 60 * 15).toISOString() : undefined,
  };
}

function demoParticipants(ids: string[]): OrbitParticipant[] {
  const all: Record<string, OrbitParticipant> = {
    me: { id: "me", displayName: "You", isVerified: true, isOnline: true },
    lina: { id: "lina", displayName: "Lina Driver", isOnline: true },
    ops: { id: "ops", displayName: "Ops Desk", isVerified: true },
    ceo: { id: "ceo", displayName: "Exec", isVerified: true },
  };
  return ids.map((id) => all[id]);
}
