import type { OrbitAttachment } from "@/types/communication";
import { prepareEncryptedAttachment } from "@/lib/security/attachment-crypto";

export async function prepareOrbitAttachments(files: File[]): Promise<OrbitAttachment[]> {
  const prepared = await Promise.all(files.map((file) => prepareEncryptedAttachment(file)));
  return prepared.map((item) => ({
    id: item.id,
    filename: item.filename,
    mimeType: item.mimeType,
    sizeBytes: item.sizeBytes,
    encryptedBlobRef: item.encryptedBlobRef,
    expiresAt: new Date(Date.now() + 1000 * 60 * 30).toISOString(),
  }));
}
