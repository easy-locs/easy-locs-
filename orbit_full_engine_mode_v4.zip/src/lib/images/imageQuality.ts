export type ImageQualityReport = {
  score: number;
  status: "good" | "review" | "poor";
  reasons: string[];
};

export function scoreMenuImageQuality(params: {
  width: number;
  height: number;
  aspectRatio: number;
}): ImageQualityReport {
  const { width, height, aspectRatio } = params;
  let score = 100;
  const reasons: string[] = [];

  if (width < 1000 || height < 700) {
    score -= 25;
    reasons.push("Source resolution is low for premium menu exports.");
  }

  if (aspectRatio < 0.9) {
    score -= 15;
    reasons.push("Portrait framing will need stronger crop attention.");
  }

  if (aspectRatio > 2.2) {
    score -= 10;
    reasons.push("Very wide framing may cut important toppings.");
  }

  const status = score >= 85 ? "good" : score >= 65 ? "review" : "poor";
  return { score, status, reasons };
}
