export type MenuImagePreset = "deliveroo-card" | "hero-wide" | "square-thumb";

export type NormalizerPresetConfig = {
  width: number;
  height: number;
  quality: number;
  mimeType: "image/jpeg" | "image/webp" | "image/png";
};

export type MenuImageAnalysis = {
  width: number;
  height: number;
  aspectRatio: number;
  orientation: "landscape" | "portrait" | "square";
  recommendedPreset: MenuImagePreset;
  cropZoom: number;
  offsetX: number;
  offsetY: number;
  warning?: string;
};

export const MENU_IMAGE_PRESETS: Record<MenuImagePreset, NormalizerPresetConfig> = {
  "deliveroo-card": {
    width: 1200,
    height: 800,
    quality: 0.9,
    mimeType: "image/jpeg",
  },
  "hero-wide": {
    width: 1920,
    height: 1080,
    quality: 0.9,
    mimeType: "image/jpeg",
  },
  "square-thumb": {
    width: 1080,
    height: 1080,
    quality: 0.92,
    mimeType: "image/jpeg",
  },
};

export function detectMenuImagePreset(aspectRatio: number): MenuImagePreset {
  if (aspectRatio >= 1.7) return "hero-wide";
  if (aspectRatio <= 1.1) return "square-thumb";
  return "deliveroo-card";
}

export function analyzeMenuImage(width: number, height: number): MenuImageAnalysis {
  const aspectRatio = width / Math.max(height, 1);
  const orientation = aspectRatio > 1.05 ? "landscape" : aspectRatio < 0.95 ? "portrait" : "square";
  const recommendedPreset = detectMenuImagePreset(aspectRatio);
  const preset = MENU_IMAGE_PRESETS[recommendedPreset];
  const targetRatio = preset.width / preset.height;

  let cropZoom = 1;
  let warning: string | undefined;

  if (aspectRatio < targetRatio) {
    cropZoom = targetRatio / Math.max(aspectRatio, 0.01);
    if (orientation === "portrait") {
      warning = "Portrait image detected. Smart center crop recommended for a harmonized menu.";
    }
  } else if (aspectRatio > targetRatio) {
    cropZoom = aspectRatio / targetRatio;
  }

  return {
    width,
    height,
    aspectRatio,
    orientation,
    recommendedPreset,
    cropZoom: Number(cropZoom.toFixed(2)),
    offsetX: 0.5,
    offsetY: 0.45,
    warning,
  };
}

export async function loadImageFromFile(file: File): Promise<HTMLImageElement> {
  const dataUrl = await fileToDataUrl(file);

  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export async function normalizeMenuImage(
  file: File,
  presetName: MenuImagePreset = "deliveroo-card",
  focus: { x?: number; y?: number } = { x: 0.5, y: 0.45 }
): Promise<Blob> {
  const img = await loadImageFromFile(file);
  const preset = MENU_IMAGE_PRESETS[presetName];
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");

  if (!ctx) throw new Error("Canvas not available");

  canvas.width = preset.width;
  canvas.height = preset.height;

  const sourceRatio = img.width / img.height;
  const targetRatio = preset.width / preset.height;

  let sx = 0;
  let sy = 0;
  let sw = img.width;
  let sh = img.height;

  if (sourceRatio > targetRatio) {
    sw = img.height * targetRatio;
    sx = (img.width - sw) * clamp01(focus.x ?? 0.5);
    sx = Math.min(Math.max(0, sx), img.width - sw);
  } else if (sourceRatio < targetRatio) {
    sh = img.width / targetRatio;
    sy = (img.height - sh) * clamp01(focus.y ?? 0.45);
    sy = Math.min(Math.max(0, sy), img.height - sh);
  }

  ctx.drawImage(img, sx, sy, sw, sh, 0, 0, preset.width, preset.height);

  return await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (!blob) return reject(new Error("Unable to export normalized image"));
        resolve(blob);
      },
      preset.mimeType,
      preset.quality
    );
  });
}

export function buildNormalizedFilename(originalName: string, presetName: MenuImagePreset) {
  const safe = originalName
    .toLowerCase()
    .replace(/\.[^.]+$/, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");

  return `${safe || "menu-image"}-${presetName}${getExtensionForMimeType(MENU_IMAGE_PRESETS[presetName].mimeType)}`;
}

function getExtensionForMimeType(mimeType: NormalizerPresetConfig["mimeType"]) {
  if (mimeType === "image/png") return ".png";
  if (mimeType === "image/webp") return ".webp";
  return ".jpg";
}

function clamp01(value: number) {
  return Math.min(1, Math.max(0, value));
}
