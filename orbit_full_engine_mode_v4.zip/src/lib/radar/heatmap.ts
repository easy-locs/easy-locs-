import type { HeatPoint, RadarOrder } from "@/types/radar";

export function buildHeatmapPoints(orders: RadarOrder[]): HeatPoint[] {
  const buckets = new Map<string, HeatPoint>();

  for (const order of orders) {
    const lat = Math.round(order.lat * 100) / 100;
    const lng = Math.round(order.lng * 100) / 100;
    const key = `${lat}:${lng}`;
    const existing = buckets.get(key);

    if (existing) {
      existing.intensity += 1;
    } else {
      buckets.set(key, { lat, lng, intensity: 1 });
    }
  }

  return [...buckets.values()];
}
