import { randomHex } from "@/lib/security/secure-storage";

export type PreparedEncryptedAttachment = {
  id: string;
  filename: string;
  mimeType: string;
  sizeBytes: number;
  encryptedBlobRef: string;
  ivHint: string;
};

export async function prepareEncryptedAttachment(file: File): Promise<PreparedEncryptedAttachment> {
  return {
    id: `att_${randomHex(10)}`,
    filename: file.name,
    mimeType: file.type || "application/octet-stream",
    sizeBytes: file.size,
    encryptedBlobRef: `enc_${randomHex(18)}`,
    ivHint: randomHex(16),
  };
}
