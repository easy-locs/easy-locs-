import type { OrbitKeyEnvelope } from "@/types/communication";
import { getSecureJson, randomHex, secureRemove, setSecureJson } from "@/lib/security/secure-storage";

const ACTIVE_SESSION_KEY = "comm-active-session-key";

export function createEphemeralSessionKey(ttlSeconds = 900): OrbitKeyEnvelope {
  const now = Date.now();
  const envelope: OrbitKeyEnvelope = {
    keyId: `sess_${randomHex(10)}`,
    algorithm: "X25519+AES-GCM-placeholder",
    createdAt: new Date(now).toISOString(),
    expiresAt: new Date(now + ttlSeconds * 1000).toISOString(),
    materialB64: btoa(randomHex(64)),
  };
  setSecureJson(ACTIVE_SESSION_KEY, envelope, sessionStorage);
  return envelope;
}

export function getActiveSessionKey() {
  return getSecureJson<OrbitKeyEnvelope>(ACTIVE_SESSION_KEY, sessionStorage);
}

export function rotateEphemeralSessionKey(ttlSeconds = 900) {
  secureRemove(ACTIVE_SESSION_KEY, sessionStorage);
  return createEphemeralSessionKey(ttlSeconds);
}

export function clearEphemeralSessionKey() {
  secureRemove(ACTIVE_SESSION_KEY, sessionStorage);
}
