import type { OrbitDeviceIdentity } from "@/types/communication";
import { getSecureJson, randomHex, setSecureJson } from "@/lib/security/secure-storage";

const DEVICE_KEY = "device-identity";

function buildFingerprint(seed: string) {
  return seed.match(/.{1,4}/g)?.slice(0, 8).join("-") ?? seed;
}

export function ensureOrbitDeviceIdentity(): OrbitDeviceIdentity {
  const existing = getSecureJson<OrbitDeviceIdentity>(DEVICE_KEY);
  if (existing) return existing;

  const seed = randomHex(40);
  const identity: OrbitDeviceIdentity = {
    deviceId: `dev_${randomHex(12)}`,
    fingerprint: buildFingerprint(seed),
    createdAt: new Date().toISOString(),
    publicKeyHint: `pk_${seed.slice(0, 16)}`,
  };
  setSecureJson(DEVICE_KEY, identity);
  return identity;
}

export function getOrbitDeviceIdentity() {
  return getSecureJson<OrbitDeviceIdentity>(DEVICE_KEY);
}
