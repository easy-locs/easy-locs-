const ORBIT_PREFIX = "orbit:";

function fullKey(key: string) {
  return `${ORBIT_PREFIX}${key}`;
}

export function setSecureJson<T>(key: string, value: T, storage: Storage = localStorage) {
  storage.setItem(fullKey(key), JSON.stringify(value));
}

export function getSecureJson<T>(key: string, storage: Storage = localStorage): T | null {
  const raw = storage.getItem(fullKey(key));
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export function secureRemove(key: string, storage: Storage = localStorage) {
  const fk = fullKey(key);
  const existing = storage.getItem(fk);
  if (existing) {
    try {
      storage.setItem(fk, "0".repeat(Math.max(existing.length, 64)));
      storage.setItem(fk, randomHex(Math.max(existing.length, 64)));
    } catch {}
  }
  storage.removeItem(fk);
}

export function securePurgePrefix(prefix = ORBIT_PREFIX, storage: Storage = localStorage) {
  const keys: string[] = [];
  for (let i = 0; i < storage.length; i += 1) {
    const key = storage.key(i);
    if (key?.startsWith(prefix)) keys.push(key);
  }
  keys.forEach((key) => {
    try {
      const existing = storage.getItem(key);
      if (existing) {
        storage.setItem(key, "0".repeat(Math.max(existing.length, 64)));
      }
    } catch {}
    storage.removeItem(key);
  });
}

export function randomHex(len = 32) {
  const arr = new Uint8Array(Math.ceil(len / 2));
  crypto.getRandomValues(arr);
  return Array.from(arr, (b) => b.toString(16).padStart(2, "0")).join("").slice(0, len);
}
