import type { OrbitGhostSession } from "@/types/communication";
import { clearEphemeralSessionKey, createEphemeralSessionKey } from "@/lib/security/session-keys";
import { getSecureJson, randomHex, securePurgePrefix, secureRemove, setSecureJson } from "@/lib/security/secure-storage";

const GHOST_SESSION_KEY = "ghost-session";
let ttlTimer: ReturnType<typeof setInterval> | null = null;

export function activateGhostSession(ttlSeconds = 15 * 60, biometricRequired = true): OrbitGhostSession {
  const now = Date.now();
  const session: OrbitGhostSession = {
    sessionId: `ghost_${randomHex(12)}`,
    unlockedAt: new Date(now).toISOString(),
    expiresAt: new Date(now + ttlSeconds * 1000).toISOString(),
    biometricRequired,
  };
  createEphemeralSessionKey(ttlSeconds);
  setSecureJson(GHOST_SESSION_KEY, session, sessionStorage);
  sessionStorage.setItem("orbit:ghost-active", "true");
  return session;
}

export function getGhostSession() {
  return getSecureJson<OrbitGhostSession>(GHOST_SESSION_KEY, sessionStorage);
}

export function isGhostActive() {
  const session = getGhostSession();
  return !!session && new Date(session.expiresAt).getTime() > Date.now();
}

export function getGhostRemainingMs() {
  const session = getGhostSession();
  if (!session) return 0;
  return Math.max(0, new Date(session.expiresAt).getTime() - Date.now());
}

export function deactivateGhostSession() {
  clearEphemeralSessionKey();
  secureRemove(GHOST_SESSION_KEY, sessionStorage);
  secureRemove("ghost-active", sessionStorage);
  sessionStorage.removeItem("orbit:ghost-active");
}

export function panicGhostPurge() {
  clearEphemeralSessionKey();
  securePurgePrefix("orbit:", sessionStorage);
}

export function startGhostSessionMonitor(onExpire?: () => void) {
  if (ttlTimer) clearInterval(ttlTimer);
  ttlTimer = setInterval(() => {
    if (!isGhostActive()) {
      deactivateGhostSession();
      onExpire?.();
      if (ttlTimer) {
        clearInterval(ttlTimer);
        ttlTimer = null;
      }
    }
  }, 4000);

  return () => {
    if (ttlTimer) {
      clearInterval(ttlTimer);
      ttlTimer = null;
    }
  };
}
