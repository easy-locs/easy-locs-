export type ConversationMode = "standard" | "ghost";

export type GhostMessagePolicy = {
  ttlSeconds: number;
  hidePreview: boolean;
  localOnlyCache?: boolean;
  requireBiometric?: boolean;
};

export const defaultGhostPolicy: GhostMessagePolicy = {
  ttlSeconds: 60,
  hidePreview: true,
  localOnlyCache: true,
  requireBiometric: false,
};
