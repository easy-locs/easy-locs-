import { createClient } from "@supabase/supabase-js";

export const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL ?? "https://YOUR_PROJECT.supabase.co",
  import.meta.env.VITE_SUPABASE_ANON_KEY ?? "YOUR_ANON_KEY"
);
