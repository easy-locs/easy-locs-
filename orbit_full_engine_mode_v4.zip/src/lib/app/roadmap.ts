export type ProductAreaStatus = {
  area: string;
  status: "ready" | "partial" | "missing";
  note: string;
};

export const orbitBuild184Status: ProductAreaStatus[] = [
  {
    area: "UI system",
    status: "ready",
    note: "Premium dark shell, cards, buttons and stat pills are reusable.",
  },
  {
    area: "Delivery pricing",
    status: "partial",
    note: "Now supports mission context, but still needs real distance provider and runtime API wiring.",
  },
  {
    area: "Delivery radar",
    status: "partial",
    note: "HUD is ready. Real map engine, GPS streams and clustering still need host-app integration.",
  },
  {
    area: "Seller operations",
    status: "partial",
    note: "Build 184 adds a route-ready workspace shell, not a database-backed dashboard yet.",
  },
  {
    area: "Menu media pipeline",
    status: "partial",
    note: "Build 184 adds batch preparation and QA, but not subject detection or cloud asset persistence.",
  },
  {
    area: "Ghost mode",
    status: "missing",
    note: "Only policy/UI foundation exists. Encryption and secure storage must be implemented in the main repo.",
  },
];
