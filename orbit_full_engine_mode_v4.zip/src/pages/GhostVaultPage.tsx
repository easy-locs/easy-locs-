import React from "react";
import OrbitPageShell from "@/components/ui/OrbitPageShell";
import GhostEntrySheet from "@/components/communication/GhostEntrySheet";
import { useGhostSession } from "@/hooks/communication/useGhostSession";

export default function GhostVaultPage() {
  const ghost = useGhostSession();

  return (
    <OrbitPageShell>
      <div className="mx-auto max-w-xl">
        <GhostEntrySheet
          active={ghost.active}
          remainingMs={ghost.remainingMs}
          onActivate={ghost.activate}
          onDeactivate={ghost.deactivate}
          onPanic={ghost.panicPurge}
        />
      </div>
    </OrbitPageShell>
  );
}
