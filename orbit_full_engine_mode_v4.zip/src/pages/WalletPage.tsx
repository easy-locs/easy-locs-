import { useEffect, useState } from "react";
import { initWalletEngine } from "../engine/walletEngine";
import { emit } from "../core/relay";
import { useChatStore } from "../store/chatStore";
import { useSecurityStore } from "../store/securityStore";

let booted = false;

export function WalletPage() {
  const [amount, setAmount] = useState("2500");
  const [currency, setCurrency] = useState("AED");
  const txs = useChatStore((s) => s.transactions);
  const lastRef = useSecurityStore((s) => s.lastReference);

  useEffect(() => {
    if (!booted) {
      initWalletEngine();
      booted = true;
    }
  }, []);

  function send() {
    emit("WALLET_SEND", {
      receiver_orbit_id: "peer-orbit-demo",
      amount_minor: Number(amount),
      currency,
      conversationId: "demo-conversation"
    });
  }

  return (
    <>
      <div className="card hero">
        <h1 className="title">Wallet</h1>
        <p className="sub">Send money in chat with signed payloads, references, and cryptographic IDs.</p>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="row">
            <span className="pill">Payment via chat</span>
            <span className="pill">last ref {lastRef ?? "-"}</span>
          </div>
          <input className="input" value={amount} onChange={(e) => setAmount(e.target.value)} />
          <select className="select" value={currency} onChange={(e) => setCurrency(e.target.value)}>
            <option>AED</option>
            <option>EUR</option>
            <option>LOCS</option>
          </select>
          <button className="btn" onClick={send}>Create signed payment</button>
        </div>

        <div className="card">
          <div className="h2">Transactions</div>
          {txs.map((tx) => (
            <div className="msg" key={tx.crypto_id}>
              <div className="row">
                <strong>{tx.amount_minor} {tx.currency}</strong>
                <span className="pill">{tx.status}</span>
              </div>
              <div className="muted">{tx.reference}</div>
              <div className="code">{tx.crypto_id}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
