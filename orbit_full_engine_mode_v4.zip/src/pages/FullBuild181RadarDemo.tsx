import React from "react";
import DeliveryRadarMap from "@/components/radar/DeliveryRadarMap";
import OrbitPageShell from "@/components/ui/OrbitPageShell";

const drivers = [
  { id: "D1", lat: 25.2048, lng: 55.2708, status: "idle", vehicleType: "scooter" as const },
  { id: "D2", lat: 25.2148, lng: 55.2808, status: "busy", vehicleType: "car" as const },
  { id: "D3", lat: 25.2248, lng: 55.2908, status: "idle", vehicleType: "van" as const },
];

const orders = [
  { id: "O1", lat: 25.2048, lng: 55.2708, status: "pending", createdAt: new Date().toISOString(), packageClass: "light" as const },
  { id: "O2", lat: 25.2148, lng: 55.2808, status: "assigned", createdAt: new Date().toISOString(), packageClass: "medium" as const },
  { id: "O3", lat: 25.2141, lng: 55.2804, status: "pending", createdAt: new Date().toISOString(), packageClass: "heavy" as const },
];

export default function FullBuild181RadarDemo() {
  return (
    <OrbitPageShell>
      <DeliveryRadarMap drivers={drivers} orders={orders} />
    </OrbitPageShell>
  );
}
