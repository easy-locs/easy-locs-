import { useMemo } from "react";
import { multiHopPack, multiHopPeek } from "../relay/multihop";

export function RelayPage() {
  const firstHop = useMemo(() => {
    const packed = multiHopPack({ type: "secure-envelope", conversation_id: "demo-conversation" }, ["relay-a", "relay-b", "relay-c"]);
    return multiHopPeek(packed);
  }, []);

  return (
    <>
      <div className="card hero">
        <h1 className="title">Relay Privacy</h1>
        <p className="sub">UI model for multi-hop packaging before transport routing.</p>
      </div>

      <div className="card">
        <div className="row">
          <strong>First hop envelope</strong>
          <span className="pill">{firstHop.hop}</span>
        </div>
        <div className="code">{JSON.stringify(firstHop, null, 2)}</div>
      </div>
    </>
  );
}
