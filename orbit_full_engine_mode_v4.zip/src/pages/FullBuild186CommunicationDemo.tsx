import React from "react";
import CommunicationPage from "@/pages/CommunicationPage";

export default function FullBuild186CommunicationDemo() {
  return <CommunicationPage />;
}
