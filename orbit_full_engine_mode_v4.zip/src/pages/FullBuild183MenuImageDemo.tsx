import React from "react";
import OrbitPageShell from "@/components/ui/OrbitPageShell";
import GrowthHero from "@/components/growth/GrowthHero";
import MenuImageNormalizerCard from "@/components/images/MenuImageNormalizerCard";

export default function FullBuild183MenuImageDemo() {
  return (
    <OrbitPageShell>
      <div className="space-y-6">
        <GrowthHero />
        <MenuImageNormalizerCard />
      </div>
    </OrbitPageShell>
  );
}
