import { useRuntimeAudit } from "@/hooks/useRuntimeAudit";

export function DashboardPage() {
  const audits = useRuntimeAudit();
  return (
    <>
      <div className="card hero">
        <div className="row">
          <div>
            <h1 className="title">Orbit Full Engine Mode</h1>
            <p className="sub">Integrated repo pack with communication, wallet, relay, security, delivery, property, and runtime audit.</p>
          </div>
          <span className="pill">integration v4</span>
        </div>
      </div>

      <div className="grid-3">
        <div className="card"><div className="h2">Communication</div><div className="muted">Secure pages + existing Orbit communication workspace.</div></div>
        <div className="card"><div className="h2">Wallet</div><div className="muted">Signed transactions, references, crypto IDs, sync hooks.</div></div>
        <div className="card"><div className="h2">Relay</div><div className="muted">Multi-hop packing model and orchestrator-driven sync.</div></div>
      </div>

      <div className="card">
        <div className="h2">Runtime audit</div>
        <div className="grid-3">
          {audits.map((item) => (
            <div key={item.name} className="msg">
              <div className="row">
                <strong>{item.name}</strong>
                <span className="pill">{item.ok ? "ok" : "check"}</span>
              </div>
              <div className="muted">{item.details}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}