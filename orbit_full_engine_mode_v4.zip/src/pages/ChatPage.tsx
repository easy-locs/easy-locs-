import { useEffect, useMemo, useState } from "react";
import { emit } from "../core/relay";
import { initChatEngine } from "../engine/chatEngine";
import { useChatStore } from "../store/chatStore";
import { useSecurityStore } from "../store/securityStore";
import { enableGhost, disableGhost, readGhostState } from "../security/ghost";

let booted = false;

export function ChatPage() {
  const [text, setText] = useState("");
  const [ghost, setGhost] = useState(false);
  const envelopes = useChatStore((s) => s.envelopes);
  const plaintext = useChatStore((s) => s.plaintextById);
  const conversationId = useChatStore((s) => s.conversationId);
  const orbitId = useSecurityStore((s) => s.orbitId);
  const ghostActive = useSecurityStore((s) => s.ghostActive);
  const setGhostActive = useSecurityStore((s) => s.setGhostActive);

  useEffect(() => {
    if (!booted) {
      initChatEngine();
      booted = true;
    }
    emit("CHAT_LOAD", { conversationId });
    const id = setInterval(() => {
      setGhostActive(readGhostState().active);
    }, 1000);
    return () => clearInterval(id);
  }, [conversationId, setGhostActive]);

  useEffect(() => {
    if (envelopes.length > 0) emit("CHAT_DECRYPT", { conversationId });
  }, [conversationId, envelopes.length]);

  const rows = useMemo(() => envelopes.filter((e) => e.conversation_id === conversationId), [conversationId, envelopes]);

  function send() {
    if (!text.trim() || !orbitId) return;
    emit("CHAT_SEND", {
      conversationId,
      text,
      ghost,
      sender_orbit_id: orbitId,
      sender_device_id: "local-device",
      receiver_orbit_id: "peer-orbit-demo"
    });
    setText("");
  }

  return (
    <>
      <div className="card hero">
        <div className="row">
          <div>
            <h1 className="title">Secure Chat</h1>
            <p className="sub">Ciphertext is stored. Plaintext appears only after local decrypt.</p>
          </div>
          <span className="pill">{ghostActive ? "ghost session active" : "ghost session inactive"}</span>
        </div>
      </div>

      <div className="card">
        <div className="row">
          <span className="pill">{conversationId}</span>
          <div className="row">
            <button className="btn secondary" onClick={() => { enableGhost(); setGhostActive(true); }}>Start Ghost</button>
            <button className="btn secondary" onClick={() => { disableGhost(); setGhostActive(false); }}>Stop Ghost</button>
          </div>
        </div>

        <div style={{ display: "grid", gap: 10 }}>
          {rows.map((row, idx) => {
            const key = row.id ?? `${idx}`;
            return (
              <div key={key} className="msg">
                <div>{plaintext[key] ?? "[encrypted payload]"}</div>
                <div className="row">
                  <span className="pill">{row.ghost ? "ghost" : "standard"}</span>
                  <span className="code">ctr {row.ratchet_counter}</span>
                </div>
                <div className="code">{row.ciphertext}</div>
              </div>
            );
          })}
        </div>

        <textarea className="textarea" value={text} onChange={(e) => setText(e.target.value)} placeholder="Write secure message..." />
        <div className="row">
          <label className="pill">
            <input type="checkbox" checked={ghost} onChange={(e) => setGhost(e.target.checked)} /> Ghost message
          </label>
          <button className="btn" onClick={send}>Encrypt and send</button>
        </div>
      </div>
    </>
  );
}
