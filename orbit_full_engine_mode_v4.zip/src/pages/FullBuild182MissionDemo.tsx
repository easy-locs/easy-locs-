import React from "react";
import DeliveryOfferSheet from "@/components/delivery/DeliveryOfferSheet";
import DeliveryProofPanel from "@/components/delivery/DeliveryProofPanel";
import MissionStatusCard from "@/components/delivery/MissionStatusCard";
import GhostConversationCard from "@/components/ghost/GhostConversationCard";
import GhostModeEntry from "@/components/ghost/GhostModeEntry";
import OrbitPageShell from "@/components/ui/OrbitPageShell";
import { defaultGhostPolicy } from "@/lib/ghost/policy";

const offers = [
  { id: "OF1", orderId: "O1", driverId: "D1", mode: "fixed" as const, basePrice: 18, etaMin: 19 },
  { id: "OF2", orderId: "O1", driverId: "D2", mode: "progressive" as const, basePrice: 12, pricePerKm: 1.75, minPrice: 16, etaMin: 15 },
];

const proof = {
  photoTaken: true,
  signatureCaptured: true,
  qrScanned: false,
  geoLat: 25.2048,
  geoLng: 55.2708,
  geoAccuracy: 8,
  recipientName: "Front desk",
  notes: "Delivered hot",
  deliveredAt: new Date().toISOString(),
};

export default function FullBuild182MissionDemo() {
  return (
    <OrbitPageShell>
      <div className="space-y-4">
        <GhostModeEntry />
        <div className="grid gap-4 lg:grid-cols-3">
          <DeliveryOfferSheet offers={offers} />
          <MissionStatusCard status="proof_submitted" />
          <DeliveryProofPanel proof={proof} />
        </div>
        <GhostConversationCard mode="ghost" policy={defaultGhostPolicy} />
      </div>
    </OrbitPageShell>
  );
}
