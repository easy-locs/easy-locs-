import React from "react";
import OrbitPageShell from "@/components/ui/OrbitPageShell";
import GrowthHero from "@/components/growth/GrowthHero";
import DeliveryRadarMap from "@/components/radar/DeliveryRadarMap";
import SellerMissionWorkspace from "@/components/workspace/SellerMissionWorkspace";
import OrbitOperationsBoard from "@/components/workspace/OrbitOperationsBoard";
import MenuImageBatchUploader from "@/components/images/MenuImageBatchUploader";

const drivers = [
  { id: "D1", lat: 25.2048, lng: 55.2708, status: "idle" as const, vehicleType: "scooter" as const },
  { id: "D2", lat: 25.2101, lng: 55.2742, status: "busy" as const, vehicleType: "car" as const },
  { id: "D3", lat: 25.2129, lng: 55.2675, status: "idle" as const, vehicleType: "van" as const },
  { id: "D4", lat: 25.2142, lng: 55.2692, status: "idle" as const, vehicleType: "car" as const },
];

const orders = [
  { id: "O1", lat: 25.2048, lng: 55.2708, status: "pending" as const, createdAt: new Date().toISOString(), packageClass: "light" as const },
  { id: "O2", lat: 25.2041, lng: 55.2704, status: "assigned" as const, createdAt: new Date().toISOString(), packageClass: "medium" as const },
  { id: "O3", lat: 25.2101, lng: 55.2742, status: "pending" as const, createdAt: new Date().toISOString(), packageClass: "heavy" as const },
  { id: "O4", lat: 25.2129, lng: 55.2675, status: "pending" as const, createdAt: new Date().toISOString(), packageClass: "medium" as const },
  { id: "O5", lat: 25.2142, lng: 55.2692, status: "picked_up" as const, createdAt: new Date().toISOString(), packageClass: "light" as const },
];

export default function FullBuild185IntegrationDemo() {
  return (
    <OrbitPageShell>
      <div className="space-y-6">
        <GrowthHero />
        <OrbitOperationsBoard />
        <DeliveryRadarMap drivers={drivers} orders={orders} mode="connected" />
        <SellerMissionWorkspace />
        <MenuImageBatchUploader />
      </div>
    </OrbitPageShell>
  );
}
