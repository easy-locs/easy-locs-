import React, { useState } from "react";
import CommunicationInbox from "@/components/communication/CommunicationInbox";
import ConversationView from "@/components/communication/ConversationView";
import GhostEntrySheet from "@/components/communication/GhostEntrySheet";
import GhostLockScreen from "@/components/communication/GhostLockScreen";
import CallPanel from "@/components/communication/CallPanel";
import OrbitPageShell from "@/components/ui/OrbitPageShell";
import { useCallSession } from "@/hooks/communication/useCallSession";
import { useConversations } from "@/hooks/communication/useConversations";
import { useGhostSession } from "@/hooks/communication/useGhostSession";
import { useMessages } from "@/hooks/communication/useMessages";
import { ensureOrbitDeviceIdentity } from "@/lib/security/device-identity";

export default function CommunicationPage() {
  const identity = ensureOrbitDeviceIdentity();
  const { conversations, selectedConversation, selectedId, setSelectedId } = useConversations();
  const { messages, sendMessage } = useMessages(selectedConversation);
  const ghost = useGhostSession();
  const call = useCallSession();
  const [ghostLocked, setGhostLocked] = useState(true);

  const canOpenConversation = selectedConversation?.mode !== "ghost" || ghost.active;

  return (
    <OrbitPageShell>
      <div className="mb-4 rounded-[28px] border border-white/10 bg-white/5 p-5 text-white shadow-2xl backdrop-blur-xl">
        <div className="text-[11px] uppercase tracking-[0.2em] text-cyan-300/80">Orbit communication</div>
        <h1 className="mt-2 text-3xl font-bold">Standard + Ghost workspace</h1>
        <p className="mt-2 max-w-3xl text-sm text-white/60">
          Full module shell for inbox, conversation, secure ghost entry, device identity, and call signaling — designed to integrate without breaking the existing Orbit structure.
        </p>
        <div className="mt-4 text-xs text-white/45">Device fingerprint: {identity.fingerprint}</div>
      </div>

      <div className="grid gap-4 xl:grid-cols-[0.9fr,1.35fr,0.85fr]">
        <CommunicationInbox conversations={conversations} selectedId={selectedId} onSelect={setSelectedId} />

        <div className="space-y-4">
          {selectedConversation?.mode === "ghost" && ghost.active && ghostLocked ? (
            <GhostLockScreen locked={ghostLocked} onUnlock={(pin) => {
              const ok = pin === "246810";
              if (ok) setGhostLocked(false);
              return ok;
            }} />
          ) : canOpenConversation ? (
            <ConversationView
              conversation={selectedConversation}
              messages={messages}
              onSend={sendMessage}
              onStartCall={call.start}
            />
          ) : (
            <div className="rounded-[28px] border border-white/10 bg-white/5 p-6 text-white shadow-2xl backdrop-blur-xl">
              Unlock Ghost to open this conversation.
            </div>
          )}
          <CallPanel call={call.call} onConnect={call.connect} onEnd={call.end} onClear={call.clear} />
        </div>

        <GhostEntrySheet
          active={ghost.active}
          remainingMs={ghost.remainingMs}
          onActivate={(ttl, biometric) => {
            ghost.activate(ttl, biometric);
            setGhostLocked(true);
          }}
          onDeactivate={() => {
            ghost.deactivate();
            setGhostLocked(true);
          }}
          onPanic={() => {
            ghost.panicPurge();
            setGhostLocked(true);
          }}
        />
      </div>
    </OrbitPageShell>
  );
}
