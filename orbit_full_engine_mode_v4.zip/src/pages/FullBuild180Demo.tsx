import React from "react";
import GrowthHero from "@/components/growth/GrowthHero";
import ReferralCards from "@/components/growth/ReferralCards";
import OrbitPageShell from "@/components/ui/OrbitPageShell";

export default function FullBuild180Demo() {
  return (
    <OrbitPageShell>
      <div className="mx-auto max-w-3xl space-y-4">
        <GrowthHero />
        <ReferralCards />
      </div>
    </OrbitPageShell>
  );
}
