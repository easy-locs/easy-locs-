import { useEffect, useState } from "react";
import { loadJwk } from "../security/keystore";
import { useSecurityStore } from "../store/securityStore";

export function SecurityPage() {
  const { orbitId, deviceId } = useSecurityStore();
  const [signReady, setSignReady] = useState(false);
  const [kexReady, setKexReady] = useState(false);

  useEffect(() => {
    void loadJwk("sign-private").then((v) => setSignReady(Boolean(v)));
    void loadJwk("kex-private").then((v) => setKexReady(Boolean(v)));
  }, []);

  return (
    <>
      <div className="card hero">
        <h1 className="title">Security Status</h1>
        <p className="sub">Check local keys and identity bootstrap.</p>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="kv">
            <strong>Orbit ID</strong>
            <div className="code">{orbitId ?? "bootstrapping..."}</div>
          </div>
          <div className="kv">
            <strong>Device ID</strong>
            <div className="code">{deviceId ?? "-"}</div>
          </div>
        </div>

        <div className="card">
          <div className="row">
            <span className="pill">{signReady ? "sign key ready" : "sign key missing"}</span>
            <span className="pill">{kexReady ? "kex key ready" : "kex key missing"}</span>
          </div>
          <ul>
            <li>Private keys stored locally in IndexedDB keystore</li>
            <li>Public bundles published for remote discovery</li>
            <li>Signed prekeys generated at bootstrap</li>
          </ul>
        </div>
      </div>
    </>
  );
}
