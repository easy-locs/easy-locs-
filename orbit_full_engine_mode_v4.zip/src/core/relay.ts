type Handler<T = any> = (payload: T) => void | Promise<void>;
const listeners = new Map<string, Set<Handler>>();

export function emit<T = any>(type: string, payload: T) {
  const set = listeners.get(type);
  if (!set) return;
  for (const fn of set) {
    Promise.resolve(fn(payload)).catch((error) => console.error("[relay]", type, error));
  }
}

export function on<T = any>(type: string, handler: Handler<T>) {
  if (!listeners.has(type)) listeners.set(type, new Set());
  listeners.get(type)!.add(handler as Handler);
  return () => listeners.get(type)?.delete(handler as Handler);
}
