import { emit, on } from "@/core/relay";
import { enqueueRetry } from "@/core/retryQueue";
import { enableGhost, readGhostState } from "@/security/ghost";

let ready = false;

export function initOrbitOrchestrator() {
  if (ready) return;
  ready = true;

  on("PAYMENT_CREATED", async ({ orderId }: { orderId: string }) => {
    emit("DELIVERY_CREATE_REQUEST", { orderId });
  });

  on("GHOST_ACTIVATE", ({ ttlMs = 300000 }: { ttlMs?: number }) => {
    enableGhost(ttlMs);
    emit("GHOST_STATUS_CHANGED", readGhostState());
  });

  on("STORE_ENVELOPE_RELIABLE", (payload: { taskId: string; run: () => Promise<void> }) => {
    enqueueRetry({ id: payload.taskId, run: payload.run, maxAttempts: 4 });
  });
}