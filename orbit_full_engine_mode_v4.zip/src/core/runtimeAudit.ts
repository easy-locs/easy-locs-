export type AuditResult = { name: string; ok: boolean; details: string };

export function runRuntimeAudit(): AuditResult[] {
  const checks: AuditResult[] = [];
  checks.push({ name: "window.crypto", ok: typeof window !== "undefined" && !!window.crypto?.subtle, details: "WebCrypto availability" });
  checks.push({ name: "indexedDB", ok: typeof window !== "undefined" && !!window.indexedDB, details: "Local secure persistence" });
  checks.push({ name: "Notification", ok: typeof window !== "undefined" && "Notification" in window, details: "Notification API available" });
  return checks;
}