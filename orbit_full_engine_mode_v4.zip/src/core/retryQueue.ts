export type RetryTask = { id: string; run: () => Promise<void>; attempts: number; maxAttempts: number };
const pending: RetryTask[] = [];
let active = false;

export function enqueueRetry(task: Omit<RetryTask, "attempts">) {
  pending.push({ ...task, attempts: 0 });
  void drainQueue();
}

async function drainQueue() {
  if (active) return;
  active = true;
  while (pending.length) {
    const task = pending.shift()!;
    try {
      await task.run();
    } catch (error) {
      task.attempts += 1;
      if (task.attempts < task.maxAttempts) pending.push(task);
      console.error("[retryQueue]", task.id, error);
    }
  }
  active = false;
}