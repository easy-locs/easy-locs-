import { on } from "../core/relay";
import { useSecurityStore } from "../store/securityStore";
import { makeReference } from "../wallet/reference";
import { loadJwk } from "../security/keystore";
import { importEcdsaPrivate } from "../security/keyImport";
import { signWalletPayload } from "../wallet/sign";
import { sha256Hex } from "../security/audit";
import { insertWalletTx } from "../services/walletService";
import { useChatStore } from "../store/chatStore";

let ready = false;

export function initWalletEngine() {
  if (ready) return;
  ready = true;

  on("WALLET_SEND", async ({
    receiver_orbit_id,
    amount_minor,
    currency,
    conversationId
  }: {
    receiver_orbit_id: string;
    amount_minor: number;
    currency: string;
    conversationId: string;
  }) => {
    const sender_orbit_id = useSecurityStore.getState().orbitId;
    if (!sender_orbit_id) throw new Error("Missing sender identity");

    const reference = makeReference();
    useSecurityStore.getState().setLastReference(reference);

    const payload = {
      reference,
      sender_orbit_id,
      receiver_orbit_id,
      amount_minor,
      currency,
      chat_conversation_id: conversationId
    };

    const signJwk = await loadJwk("sign-private");
    if (!signJwk) throw new Error("Missing signing key");
    const signPrivate = await importEcdsaPrivate(signJwk);
    const signed_payload_b64 = await signWalletPayload(signPrivate, payload);
    const crypto_id = await sha256Hex(JSON.stringify(payload));

    const tx = await insertWalletTx({
      ...payload,
      signed_payload_b64,
      crypto_id,
      status: "pending"
    });

    useChatStore.getState().addTransaction(tx);
  });
}
