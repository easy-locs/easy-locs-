import { emit, on } from "../core/relay";
import { createSession, nextSeed } from "../security/session";
import { encryptEnvelope, decryptEnvelope } from "../security/e2ee";
import { fetchConversation, insertEnvelope } from "../services/envelopeService";
import { useChatStore } from "../store/chatStore";
import { loadJwk } from "../security/keystore";
import { importEcdsaPrivate } from "../security/keyImport";
import { signJson } from "../security/identity";
import { acceptCounter } from "../security/replayGuard";

const sessions = new Map<string, Awaited<ReturnType<typeof createSession>>>();
let ready = false;

async function getSession(conversationId: string) {
  if (!sessions.has(conversationId)) {
    const seed = crypto.getRandomValues(new Uint8Array(32)).buffer;
    sessions.set(conversationId, await createSession(seed));
  }
  return sessions.get(conversationId)!;
}

export function initChatEngine() {
  if (ready) return;
  ready = true;

  on("CHAT_LOAD", async ({ conversationId }: { conversationId: string }) => {
    const rows = await fetchConversation(conversationId);
    rows.forEach((row) => useChatStore.getState().addEnvelope(row));
  });

  on("CHAT_SEND", async ({
    conversationId,
    text,
    ghost,
    sender_orbit_id,
    sender_device_id,
    receiver_orbit_id
  }: {
    conversationId: string;
    text: string;
    ghost: boolean;
    sender_orbit_id: string;
    sender_device_id: string;
    receiver_orbit_id: string;
  }) => {
    const session = await getSession(conversationId);
    const seed = await nextSeed(session, "send");
    const aad = `${conversationId}:${session.sendCounter - 1}`;
    const encrypted = await encryptEnvelope(seed.buffer, text, aad);

    const signJwk = await loadJwk("sign-private");
    if (!signJwk) throw new Error("Missing signing key");
    const signPrivate = await importEcdsaPrivate(signJwk);

    const unsignedPayload = {
      conversation_id: conversationId,
      sender_orbit_id,
      sender_device_id,
      receiver_orbit_id,
      ratchet_counter: session.sendCounter - 1,
      ghost,
      expires_at: ghost ? new Date(Date.now() + 300000).toISOString() : null,
      aad,
      iv: encrypted.iv,
      ciphertext: encrypted.ciphertext
    };

    const signature_b64 = await signJson(signPrivate, unsignedPayload);
    const stored = await insertEnvelope({ ...unsignedPayload, signature_b64 });
    useChatStore.getState().addEnvelope(stored);
  });

  on("CHAT_DECRYPT", async ({ conversationId }: { conversationId: string }) => {
    const session = await getSession(conversationId);
    const rows = useChatStore.getState().envelopes.filter((e) => e.conversation_id === conversationId);
    for (const row of rows) {
      if (!acceptCounter(conversationId, row.ratchet_counter)) continue;
      const seed = await nextSeed(session, "recv");
      const text = await decryptEnvelope(seed.buffer, {
        iv: row.iv,
        ciphertext: row.ciphertext,
        aad: row.aad
      });
      useChatStore.getState().addPlaintext(row.id ?? `${row.ratchet_counter}`, text);
      emit("CHAT_DECRYPTED", { id: row.id, text });
    }
  });
}
