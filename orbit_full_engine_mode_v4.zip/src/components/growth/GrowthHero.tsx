import React from "react";
import OrbitButton from "@/components/ui/OrbitButton";
import OrbitCard from "@/components/ui/OrbitCard";

export default function GrowthHero() {
  return (
    <OrbitCard className="relative overflow-hidden p-5 md:p-6">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(139,92,246,0.22),transparent_35%),radial-gradient(circle_at_bottom_left,rgba(34,211,238,0.14),transparent_30%)]" />
      <div className="relative">
        <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-fuchsia-300/80">Growth live</div>
        <h1 className="mt-2 text-2xl font-bold tracking-tight text-white md:text-4xl">Referrals, rewards and viral loops</h1>
        <p className="mt-2 max-w-2xl text-sm text-white/60 md:text-base">Premium growth layer designed to turn buyers, merchants and drivers into repeat users and promoters.</p>
        <div className="mt-5 flex flex-wrap gap-3">
          <OrbitButton>Invite now</OrbitButton>
          <OrbitButton variant="ghost">View rewards</OrbitButton>
        </div>
      </div>
    </OrbitCard>
  );
}
