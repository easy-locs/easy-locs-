import React from "react";

const items = [
  ["Invite friends", "+50 LOCS"],
  ["First order reward", "+1 free item"],
  ["Merchant referral", "+boost credit"],
  ["Driver invite", "+priority slot"],
];

export default function ReferralCards() {
  return (
    <div className="grid grid-cols-2 gap-3">
      {items.map(([title,reward]) => (
        <button key={title} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-left shadow-lg backdrop-blur-xl transition-all active:scale-[0.985]">
          <div className="text-sm font-bold text-white">{title}</div>
          <div className="mt-1 text-xs text-fuchsia-300">{reward}</div>
        </button>
      ))}
    </div>
  );
}
