import React, { useMemo, useState } from "react";
import DeliveryOfferSheet from "@/components/delivery/DeliveryOfferSheet";
import DeliveryPricingCalculator from "@/components/delivery/DeliveryPricingCalculator";
import DeliveryProofPanel from "@/components/delivery/DeliveryProofPanel";
import MissionStatusCard from "@/components/delivery/MissionStatusCard";
import OrbitButton from "@/components/ui/OrbitButton";
import OrbitCard from "@/components/ui/OrbitCard";
import OrbitStatPill from "@/components/ui/OrbitStatPill";
import { canReleaseEscrow, type DeliveryMissionStatus, type DeliveryProof } from "@/lib/delivery/lifecycle";
import { getPackageClass } from "@/lib/delivery/matching";
import type { DeliveryOffer } from "@/lib/delivery/pricing";
import { buildRouteMetrics } from "@/lib/delivery/routeMetrics";

type Props = {
  branchName?: string;
  currency?: string;
};

const demoOffers: DeliveryOffer[] = [
  { id: "OF-1", orderId: "JOB-1", driverId: "AHMED", mode: "fixed", basePrice: 17, minPrice: 17, etaMin: 17 },
  { id: "OF-2", orderId: "JOB-1", driverId: "LINA", mode: "progressive", basePrice: 10, pricePerKm: 2.2, minPrice: 16, etaMin: 14 },
  { id: "OF-3", orderId: "JOB-1", driverId: "OMAR", mode: "progressive", basePrice: 11, pricePerKm: 1.9, minPrice: 15, heavySurcharge: 4, etaMin: 20 },
];

const proof: DeliveryProof = {
  photoTaken: true,
  photoUrl: "proof-photo.jpg",
  signatureCaptured: true,
  signatureData: "signed",
  qrScanned: true,
  qrCode: "ORDER-4452",
  geoLat: 25.2048,
  geoLng: 55.2708,
  geoAccuracy: 9,
  deliveredAt: new Date().toISOString(),
  recipientName: "Reception",
  notes: "Delivered hot",
  confirmationCode: "4452",
  confirmationCodeMatched: true,
};

const statuses: DeliveryMissionStatus[] = [
  "created",
  "bidding",
  "driver_selected",
  "escrow_locked",
  "picked_up",
  "in_transit",
  "proof_submitted",
  "released",
];

export default function SellerMissionWorkspace({
  branchName = "Dubai Marina branch",
  currency = "AED",
}: Props) {
  const [distanceKm, setDistanceKm] = useState(6.5);
  const [weightKg, setWeightKg] = useState(1.8);
  const [volumeScore, setVolumeScore] = useState(1);
  const [activeOrders, setActiveOrders] = useState(8);
  const [activeDrivers, setActiveDrivers] = useState(5);
  const [status, setStatus] = useState<DeliveryMissionStatus>("bidding");
  const [selectedOfferId, setSelectedOfferId] = useState(demoOffers[0].id);

  const packageClass = useMemo(() => getPackageClass(weightKg, volumeScore), [weightKg, volumeScore]);
  const route = useMemo(
    () => buildRouteMetrics({ distanceKm, activeOrders, activeDrivers }),
    [distanceKm, activeOrders, activeDrivers]
  );

  const selectedOffer = demoOffers.find((offer) => offer.id === selectedOfferId) ?? demoOffers[0];
  const escrowReady = canReleaseEscrow(proof, {
    requireConfirmationCode: true,
    maxGeoAccuracyMeters: 20,
  });

  return (
    <div className="space-y-4">
      <OrbitCard className="p-5 md:p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="text-[11px] uppercase tracking-[0.2em] text-cyan-300/80">Seller operations</div>
            <h2 className="mt-2 text-2xl font-bold text-white">Mission workspace</h2>
            <p className="mt-2 max-w-2xl text-sm text-white/60">
              Stronger integration shell for quote context, route pressure, offer selection and release readiness in one place.
            </p>
          </div>
          <div className="rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs text-white/65">
            {branchName}
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <OrbitStatPill label="Distance" value={`${route.distanceKm.toFixed(1)} km`} accent="cyan" />
          <OrbitStatPill label="ETA" value={`${route.estimatedMinutes} min`} accent="green" />
          <OrbitStatPill label="Demand" value={route.demandLevel} accent="amber" />
          <OrbitStatPill label="Package" value={packageClass} accent="fuchsia" />
          <OrbitStatPill label="Escrow" value={escrowReady ? "ready" : "blocked"} accent={escrowReady ? "green" : "amber"} />
        </div>

        <div className="mt-5 grid gap-4 lg:grid-cols-[1.2fr,0.8fr]">
          <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
            <div className="text-sm font-semibold text-white">Mission context</div>
            <div className="mt-3 grid gap-3 md:grid-cols-3">
              <Input label="Distance (km)" value={distanceKm} step={0.5} min={0} onChange={setDistanceKm} />
              <Input label="Weight (kg)" value={weightKg} step={0.1} min={0} onChange={setWeightKg} />
              <Input label="Volume score" value={volumeScore} step={1} min={1} onChange={setVolumeScore} />
              <Input label="Active orders" value={activeOrders} step={1} min={0} onChange={setActiveOrders} />
              <Input label="Active drivers" value={activeDrivers} step={1} min={0} onChange={setActiveDrivers} />
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {statuses.map((next) => (
                <OrbitButton
                  key={next}
                  variant={next === status ? "secondary" : "ghost"}
                  className="px-3 py-2 text-xs"
                  onClick={() => setStatus(next)}
                >
                  {next}
                </OrbitButton>
              ))}
            </div>
          </div>

          <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
            <div className="text-sm font-semibold text-white">Selected mission relay</div>
            <div className="mt-3 space-y-2 text-sm text-white/65">
              <RelayRow label="Selected driver" value={selectedOffer.driverId} />
              <RelayRow label="Pricing mode" value={selectedOffer.mode} />
              <RelayRow label="Estimated ETA" value={`${selectedOffer.etaMin ?? route.estimatedMinutes} min`} />
              <RelayRow label="Escrow release" value={escrowReady ? "Proof complete" : "Missing validation"} />
            </div>
            <div className="mt-4 rounded-2xl border border-white/10 bg-black/10 px-3 py-3 text-sm text-white/60">
              Next real relay: connect this shell to your host app event bus or API so selected offer, status, and proof flow stay synchronized for seller, buyer, and driver.
            </div>
          </div>
        </div>
      </OrbitCard>

      <div className="grid gap-4 xl:grid-cols-[1.25fr,1fr]">
        <DeliveryPricingCalculator
          offers={demoOffers}
          packageClass={packageClass}
          currency={currency}
          route={route}
          selectedOfferId={selectedOfferId}
          onSelectOffer={setSelectedOfferId}
        />
        <DeliveryOfferSheet
          offers={demoOffers}
          distanceKm={route.distanceKm}
          packageClass={packageClass}
          currency={currency}
        />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.2fr,0.9fr,0.9fr]">
        <MissionStatusCard status={status} />
        <DeliveryProofPanel proof={proof} />
        <OrbitCard className="p-4">
          <div className="text-[11px] uppercase tracking-[0.18em] text-fuchsia-300/80">Release gate</div>
          <div className="mt-2 text-xl font-bold text-white">Escrow readiness</div>
          <div className="mt-3 space-y-2 text-sm text-white/65">
            <RelayRow label="Photo" value={proof.photoTaken && proof.photoUrl ? "ok" : "missing"} />
            <RelayRow label="Signature" value={proof.signatureCaptured && proof.signatureData ? "ok" : "missing"} />
            <RelayRow label="Geo" value={proof.geoLat !== null && proof.geoLng !== null ? `${proof.geoAccuracy ?? "?"}m` : "missing"} />
            <RelayRow label="Code" value={proof.confirmationCodeMatched ? "matched" : "not matched"} />
          </div>
          <div className={`mt-4 rounded-2xl border px-3 py-3 text-sm ${escrowReady ? "border-emerald-300/20 bg-emerald-400/10 text-emerald-100" : "border-amber-300/20 bg-amber-400/10 text-amber-100"}`}>
            {escrowReady ? "Release conditions satisfied for this shell." : "Release still blocked until every proof relay is present."}
          </div>
        </OrbitCard>
      </div>
    </div>
  );
}

function Input({ label, value, onChange, step, min }: { label: string; value: number; onChange: (n: number) => void; step: number; min: number; }) {
  return (
    <label className="text-sm text-white/70">
      {label}
      <input
        type="number"
        min={min}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value) || 0)}
        className="mt-2 w-full rounded-2xl border border-white/10 bg-black/20 px-3 py-2 text-white outline-none"
      />
    </label>
  );
}

function RelayRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-black/10 px-3 py-2">
      <div>{label}</div>
      <div className="font-semibold text-white">{value}</div>
    </div>
  );
}
