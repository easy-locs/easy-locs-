import React from "react";
import OrbitCard from "@/components/ui/OrbitCard";
import OrbitStatPill from "@/components/ui/OrbitStatPill";
import { orbitBuild184Status } from "@/lib/app/roadmap";

const integrationRelays = [
  "seller → mission create",
  "mission → quote engine",
  "offer → selection",
  "selection → escrow hold",
  "proof → release gate",
  "menu media → asset library",
];

export default function OrbitOperationsBoard() {
  return (
    <div className="grid gap-4 lg:grid-cols-[1.1fr,0.9fr]">
      <OrbitCard className="p-5 md:p-6">
        <div className="text-[11px] uppercase tracking-[0.2em] text-cyan-300/80">Program analysis</div>
        <h2 className="mt-2 text-2xl font-bold text-white">Current platform readiness</h2>
        <p className="mt-2 max-w-2xl text-sm text-white/60">
          Honest status board for what is already solid, what is partial and what still needs real production implementation.
        </p>
        <div className="mt-4 space-y-3">
          {orbitBuild184Status.map((item) => (
            <div key={item.area} className="rounded-3xl border border-white/10 bg-white/5 p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="text-sm font-semibold text-white">{item.area}</div>
                <div className={`rounded-full px-3 py-1 text-xs font-semibold ${item.status === "ready" ? "bg-emerald-500/15 text-emerald-300" : item.status === "partial" ? "bg-amber-500/15 text-amber-200" : "bg-red-500/15 text-red-200"}`}>
                  {item.status}
                </div>
              </div>
              <div className="mt-2 text-sm text-white/60">{item.note}</div>
            </div>
          ))}
        </div>
      </OrbitCard>

      <div className="space-y-4">
        <OrbitCard className="p-5 md:p-6">
          <div className="text-[11px] uppercase tracking-[0.2em] text-fuchsia-300/80">What comes next</div>
          <h2 className="mt-2 text-2xl font-bold text-white">Professional integration priorities</h2>
          <div className="mt-4 flex flex-wrap gap-2">
            <OrbitStatPill label="1" value="Seller flow" accent="cyan" />
            <OrbitStatPill label="2" value="Driver flow" accent="amber" />
            <OrbitStatPill label="3" value="Menu media" accent="green" />
            <OrbitStatPill label="4" value="Realtime" accent="fuchsia" />
          </div>
          <div className="mt-4 space-y-2 text-sm text-white/65">
            <div className="rounded-2xl border border-white/10 bg-black/10 px-3 py-2">Wire mission creation to your real repo, API and permissions.</div>
            <div className="rounded-2xl border border-white/10 bg-black/10 px-3 py-2">Connect a real map engine before promising live tracking.</div>
            <div className="rounded-2xl border border-white/10 bg-black/10 px-3 py-2">Move menu photos into a persistent asset library with versioning.</div>
            <div className="rounded-2xl border border-white/10 bg-black/10 px-3 py-2">Only after that should Ghost mode move from premium concept to secure product feature.</div>
          </div>
        </OrbitCard>

        <OrbitCard className="p-5 md:p-6">
          <div className="text-[11px] uppercase tracking-[0.2em] text-amber-300/80">Relay audit</div>
          <h2 className="mt-2 text-2xl font-bold text-white">Missing integration relays</h2>
          <div className="mt-4 space-y-2 text-sm text-white/65">
            {integrationRelays.map((relay) => (
              <div key={relay} className="rounded-2xl border border-white/10 bg-black/10 px-3 py-2">
                {relay}
              </div>
            ))}
          </div>
        </OrbitCard>
      </div>
    </div>
  );
}
