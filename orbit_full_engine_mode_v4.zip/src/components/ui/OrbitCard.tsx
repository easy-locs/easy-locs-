import React from "react";

type Props = React.PropsWithChildren<{ className?: string }>;

export default function OrbitCard({ children, className = "" }: Props) {
  return (
    <div className={`rounded-[28px] border border-white/10 bg-white/5 shadow-2xl backdrop-blur-xl ${className}`.trim()}>
      {children}
    </div>
  );
}
