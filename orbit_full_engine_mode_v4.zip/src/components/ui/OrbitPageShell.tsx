import React from "react";

export default function OrbitPageShell({ children }: React.PropsWithChildren) {
  return (
    <main className="min-h-screen bg-[#030712] text-white">
      <div className="mx-auto max-w-6xl px-4 py-4 md:px-6 md:py-6">{children}</div>
    </main>
  );
}
