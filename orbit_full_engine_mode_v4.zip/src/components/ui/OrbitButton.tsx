import React from "react";

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost";
};

export default function OrbitButton({
  variant = "primary",
  className = "",
  ...props
}: Props) {
  const styles = {
    primary: "bg-white text-slate-900",
    secondary: "border border-fuchsia-400/20 bg-fuchsia-500/15 text-fuchsia-200",
    ghost: "border border-white/10 bg-white/5 text-white",
  }[variant];

  return (
    <button
      {...props}
      className={`inline-flex items-center justify-center rounded-2xl px-4 py-3 text-sm font-semibold transition active:scale-[0.985] ${styles} ${className}`.trim()}
    />
  );
}
