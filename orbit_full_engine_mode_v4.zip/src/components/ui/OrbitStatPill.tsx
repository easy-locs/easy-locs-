import React from "react";

type Props = {
  label: string;
  value: string;
  accent?: "fuchsia" | "cyan" | "green" | "amber";
};

export default function OrbitStatPill({ label, value, accent = "fuchsia" }: Props) {
  const color = {
    fuchsia: "text-fuchsia-300",
    cyan: "text-cyan-300",
    green: "text-emerald-300",
    amber: "text-amber-300",
  }[accent];

  return (
    <div className="rounded-full border border-white/10 bg-white/5 px-3 py-2 backdrop-blur-xl">
      <div className="text-[10px] uppercase tracking-[0.18em] text-white/45">{label}</div>
      <div className={`text-sm font-semibold ${color}`}>{value}</div>
    </div>
  );
}
