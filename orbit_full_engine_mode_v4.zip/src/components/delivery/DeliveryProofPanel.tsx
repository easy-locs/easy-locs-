import React from "react";
import OrbitCard from "@/components/ui/OrbitCard";
import type { DeliveryProof } from "@/lib/delivery/lifecycle";
import { canReleaseEscrow } from "@/lib/delivery/lifecycle";

export default function DeliveryProofPanel({ proof }: { proof: DeliveryProof }) {
  const ready = canReleaseEscrow(proof);

  const rows = [
    ["Photo", proof.photoTaken ? "Ready" : "Missing"],
    ["Signature", proof.signatureCaptured ? "Ready" : "Missing"],
    ["Geo", proof.geoLat !== null ? "Ready" : "Missing"],
    ["QR", proof.qrScanned ? "Ready" : "Optional"],
    ["Recipient", proof.recipientName || "Unknown"],
  ];

  return (
    <OrbitCard className="p-4">
      <div className="flex items-center justify-between">
        <div className="text-sm font-semibold text-white">Proof pack</div>
        <div className={`rounded-full px-3 py-1 text-xs font-semibold ${ready ? "bg-emerald-500/15 text-emerald-300" : "bg-amber-500/15 text-amber-300"}`}>
          {ready ? "Escrow releasable" : "Waiting proof"}
        </div>
      </div>
      <div className="mt-3 space-y-2">
        {rows.map(([label, value]) => (
          <div key={String(label)} className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-3 py-2">
            <div className="text-sm text-white/65">{label}</div>
            <div className="text-sm font-semibold text-white">{value}</div>
          </div>
        ))}
      </div>
    </OrbitCard>
  );
}
