import React from "react";
import OrbitCard from "@/components/ui/OrbitCard";
import type { DeliveryMissionStatus } from "@/lib/delivery/lifecycle";

const steps: DeliveryMissionStatus[] = [
  "created",
  "bidding",
  "driver_selected",
  "escrow_locked",
  "picked_up",
  "in_transit",
  "proof_submitted",
  "released",
];

export default function MissionStatusCard({ status }: { status: DeliveryMissionStatus }) {
  const activeIndex = steps.indexOf(status);

  return (
    <OrbitCard className="p-4">
      <div className="text-sm font-semibold text-white">Mission lifecycle</div>
      <div className="mt-3 space-y-2">
        {steps.map((step, index) => (
          <div key={step} className={`rounded-2xl border px-3 py-2 text-sm ${index <= activeIndex ? "border-emerald-400/30 bg-emerald-500/10 text-emerald-200" : "border-white/10 bg-white/5 text-white/55"}`}>
            {index + 1}. {step}
          </div>
        ))}
      </div>
    </OrbitCard>
  );
}
