import React from "react";
import OrbitCard from "@/components/ui/OrbitCard";
import OrbitStatPill from "@/components/ui/OrbitStatPill";
import type { DeliveryOffer } from "@/lib/delivery/pricing";
import { computeDeliveryPrice } from "@/lib/delivery/pricing";
import type { RouteMetrics } from "@/lib/delivery/routeMetrics";

type PackageClass = "light" | "medium" | "heavy";

type Props = {
  offers: DeliveryOffer[];
  packageClass: PackageClass;
  currency?: string;
  route: RouteMetrics;
  selectedOfferId?: string;
  onSelectOffer?: (offerId: string) => void;
};

export default function DeliveryPricingCalculator({
  offers,
  packageClass,
  currency = "AED",
  route,
  selectedOfferId,
  onSelectOffer,
}: Props) {
  return (
    <OrbitCard className="p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="text-[11px] uppercase tracking-[0.18em] text-cyan-300/80">Quote engine</div>
          <div className="mt-2 text-xl font-bold text-white">Mission pricing calculator</div>
          <div className="mt-2 text-sm text-white/60">
            Route-aware comparison using distance, package class and demand multiplier.
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <OrbitStatPill label="Distance" value={`${route.distanceKm.toFixed(1)} km`} accent="cyan" />
          <OrbitStatPill label="ETA" value={`${route.estimatedMinutes} min`} accent="green" />
          <OrbitStatPill label="Demand" value={route.demandLevel} accent="amber" />
          <OrbitStatPill label="Surge" value={`${route.surgeMultiplier.toFixed(2)}x`} accent="fuchsia" />
        </div>
      </div>

      <div className="mt-4 space-y-3">
        {offers.map((offer) => {
          const raw = computeDeliveryPrice({
            distanceKm: route.distanceKm,
            packageClass,
            offer,
          });
          const total = Math.round(raw * route.surgeMultiplier * 100) / 100;
          const selected = offer.id === selectedOfferId;

          return (
            <button
              key={offer.id}
              type="button"
              onClick={() => onSelectOffer?.(offer.id)}
              className={`w-full rounded-3xl border p-4 text-left transition ${selected ? "border-cyan-300/45 bg-cyan-400/10" : "border-white/10 bg-white/5"}`}
            >
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="text-sm font-semibold text-white">Driver {offer.driverId}</div>
                  <div className="mt-1 text-xs text-white/55">
                    {offer.mode} pricing · ETA {offer.etaMin ?? route.estimatedMinutes} min
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs uppercase tracking-[0.16em] text-fuchsia-300">Final quote</div>
                  <div className="mt-1 text-2xl font-bold text-white">{currency} {total.toFixed(2)}</div>
                </div>
              </div>

              <div className="mt-3 grid gap-2 md:grid-cols-4">
                <InfoCell label="Base" value={`${currency} ${offer.basePrice.toFixed(2)}`} />
                <InfoCell label="Per km" value={`${currency} ${(offer.pricePerKm ?? 0).toFixed(2)}`} />
                <InfoCell label="Floor" value={`${currency} ${(offer.minPrice ?? 0).toFixed(2)}`} />
                <InfoCell label="Heavy fee" value={`${currency} ${(offer.heavySurcharge ?? 0).toFixed(2)}`} />
              </div>
            </button>
          );
        })}
      </div>
    </OrbitCard>
  );
}

function InfoCell({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-black/10 px-3 py-2 text-xs text-white/60">
      {label} <span className="ml-1 font-semibold text-white">{value}</span>
    </div>
  );
}
