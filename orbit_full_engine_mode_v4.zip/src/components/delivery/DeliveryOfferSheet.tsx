import React from "react";
import OrbitCard from "@/components/ui/OrbitCard";
import type { DeliveryOffer } from "@/lib/delivery/pricing";
import { computeDeliveryPrice } from "@/lib/delivery/pricing";

type PackageClass = "light" | "medium" | "heavy";

type Props = {
  offers: DeliveryOffer[];
  distanceKm?: number;
  packageClass?: PackageClass;
  currency?: string;
};

export default function DeliveryOfferSheet({
  offers,
  distanceKm = 0,
  packageClass = "medium",
  currency = "AED",
}: Props) {
  return (
    <OrbitCard className="p-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="text-sm font-semibold text-white">Delivery offers</div>
          <div className="mt-1 text-xs text-white/60">
            Based on {distanceKm.toFixed(1)} km · {packageClass} package
          </div>
        </div>
        <div className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] uppercase tracking-[0.18em] text-white/55">
          Live quote context
        </div>
      </div>

      <div className="mt-3 space-y-2">
        {offers.map((offer) => {
          const price = computeDeliveryPrice({
            distanceKm,
            packageClass,
            offer,
          });

          return (
            <div key={offer.id} className="rounded-2xl border border-white/10 bg-white/5 p-3">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="text-sm font-semibold text-white">Driver {offer.driverId}</div>
                  <div className="mt-1 text-xs text-white/60">ETA {offer.etaMin ?? 0} min</div>
                </div>
                <div className="text-right">
                  <div className="text-xs uppercase tracking-[0.16em] text-fuchsia-300">{offer.mode}</div>
                  <div className="mt-2 text-lg font-bold text-white">{currency} {price.toFixed(2)}</div>
                </div>
              </div>

              <div className="mt-3 grid gap-2 sm:grid-cols-3">
                <div className="rounded-xl border border-white/10 bg-black/10 px-3 py-2 text-xs text-white/60">
                  Base <span className="ml-1 font-semibold text-white">{currency} {offer.basePrice.toFixed(2)}</span>
                </div>
                <div className="rounded-xl border border-white/10 bg-black/10 px-3 py-2 text-xs text-white/60">
                  Per km <span className="ml-1 font-semibold text-white">{currency} {(offer.pricePerKm ?? 0).toFixed(2)}</span>
                </div>
                <div className="rounded-xl border border-white/10 bg-black/10 px-3 py-2 text-xs text-white/60">
                  Min <span className="ml-1 font-semibold text-white">{currency} {(offer.minPrice ?? 0).toFixed(2)}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </OrbitCard>
  );
}
