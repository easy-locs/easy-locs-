import React from "react";
import OrbitCard from "@/components/ui/OrbitCard";
import type { ConversationMode, GhostMessagePolicy } from "@/lib/ghost/policy";

export default function GhostConversationCard({
  mode,
  policy,
}: {
  mode: ConversationMode;
  policy: GhostMessagePolicy;
}) {
  return (
    <OrbitCard className="p-4">
      <div className="flex items-center justify-between">
        <div className="text-sm font-semibold text-white">Conversation security</div>
        <div className={`rounded-full px-3 py-1 text-xs font-semibold ${mode === "ghost" ? "bg-fuchsia-500/15 text-fuchsia-200" : "bg-cyan-500/15 text-cyan-200"}`}>
          {mode}
        </div>
      </div>
      <div className="mt-3 space-y-2 text-sm text-white/70">
        <div className="rounded-2xl border border-white/10 bg-white/5 px-3 py-2">TTL: {policy.ttlSeconds}s</div>
        <div className="rounded-2xl border border-white/10 bg-white/5 px-3 py-2">Hide preview: {policy.hidePreview ? "yes" : "no"}</div>
        <div className="rounded-2xl border border-white/10 bg-white/5 px-3 py-2">Local-only cache: {policy.localOnlyCache ? "yes" : "no"}</div>
        <div className="rounded-2xl border border-white/10 bg-white/5 px-3 py-2">Biometric lock: {policy.requireBiometric ? "yes" : "no"}</div>
      </div>
    </OrbitCard>
  );
}
