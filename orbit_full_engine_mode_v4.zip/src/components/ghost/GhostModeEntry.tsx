import React from "react";
import OrbitCard from "@/components/ui/OrbitCard";
import OrbitButton from "@/components/ui/OrbitButton";

export default function GhostModeEntry() {
  return (
    <OrbitCard className="relative overflow-hidden p-5">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(139,92,246,0.18),transparent_28%)]" />
      <div className="relative">
        <div className="text-[11px] uppercase tracking-[0.22em] text-fuchsia-300/80">Ghost mode</div>
        <div className="mt-2 text-xl font-bold text-white">Private, premium, ultra-controlled conversations</div>
        <div className="mt-2 text-sm text-white/60">Foundation only in Build 182. Full encrypted transport and hardened storage should be implemented in the main product architecture.</div>
        <div className="mt-4 flex gap-3">
          <OrbitButton variant="secondary">Enable ghost</OrbitButton>
          <OrbitButton variant="ghost">Policy</OrbitButton>
        </div>
      </div>
    </OrbitCard>
  );
}
