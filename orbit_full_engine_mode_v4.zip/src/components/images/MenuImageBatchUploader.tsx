import React, { useMemo, useState } from "react";
import OrbitButton from "@/components/ui/OrbitButton";
import OrbitCard from "@/components/ui/OrbitCard";
import OrbitStatPill from "@/components/ui/OrbitStatPill";
import {
  analyzeMenuImage,
  buildNormalizedFilename,
  MENU_IMAGE_PRESETS,
  MenuImagePreset,
} from "@/lib/images/menuImageNormalizer";
import { scoreMenuImageQuality } from "@/lib/images/imageQuality";

type BatchItem = {
  id: string;
  file: File;
  preset: MenuImagePreset;
  ratio: string;
  orientation: string;
  suggestedName: string;
  qualityScore: number;
  qualityStatus: "good" | "review" | "poor";
  reasons: string[];
  warning?: string;
};

export default function MenuImageBatchUploader() {
  const [items, setItems] = useState<BatchItem[]>([]);
  const [globalPreset, setGlobalPreset] = useState<MenuImagePreset | "smart">("smart");

  async function addFiles(fileList: FileList | null) {
    if (!fileList?.length) return;

    const nextItems: BatchItem[] = [];

    for (const file of Array.from(fileList)) {
      const imageInfo = await readDimensions(file);
      const analysis = analyzeMenuImage(imageInfo.width, imageInfo.height);
      const quality = scoreMenuImageQuality({
        width: imageInfo.width,
        height: imageInfo.height,
        aspectRatio: analysis.aspectRatio,
      });
      nextItems.push({
        id: `${file.name}-${file.size}-${file.lastModified}`,
        file,
        preset: analysis.recommendedPreset,
        ratio: analysis.aspectRatio.toFixed(2),
        orientation: analysis.orientation,
        suggestedName: buildNormalizedFilename(file.name, analysis.recommendedPreset),
        warning: analysis.warning,
        qualityScore: quality.score,
        qualityStatus: quality.status,
        reasons: quality.reasons,
      });
    }

    setItems((current) => {
      const merged = [...current, ...nextItems];
      const unique = new Map<string, BatchItem>();
      merged.forEach((item) => unique.set(item.id, item));
      return [...unique.values()];
    });
  }

  const summary = useMemo(() => {
    return {
      count: items.length,
      deliveroo: items.filter((item) => item.preset === "deliveroo-card").length,
      hero: items.filter((item) => item.preset === "hero-wide").length,
      square: items.filter((item) => item.preset === "square-thumb").length,
      warned: items.filter((item) => item.warning || item.qualityStatus !== "good").length,
      avgScore: items.length
        ? Math.round(items.reduce((acc, item) => acc + item.qualityScore, 0) / items.length)
        : 0,
    };
  }, [items]);

  function applyPreset(preset: MenuImagePreset | "smart") {
    setGlobalPreset(preset);
    if (preset === "smart") return;
    setItems((current) =>
      current.map((item) => ({
        ...item,
        preset,
        suggestedName: buildNormalizedFilename(item.file.name, preset),
      }))
    );
  }

  return (
    <OrbitCard className="p-5 md:p-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="text-[11px] uppercase tracking-[0.2em] text-fuchsia-300/80">Batch menu prep</div>
          <h2 className="mt-2 text-2xl font-bold text-white">Multi-photo harmonizer queue</h2>
          <p className="mt-2 max-w-2xl text-sm text-white/60">
            Stronger prep layer with smart preset routing, quality scoring and export naming for menu teams.
          </p>
        </div>
        <label className="inline-flex cursor-pointer items-center justify-center rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-semibold text-white">
          Add photos
          <input className="hidden" type="file" accept="image/*" multiple onChange={(e) => void addFiles(e.target.files)} />
        </label>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <OrbitStatPill label="Images" value={String(summary.count)} accent="cyan" />
        <OrbitStatPill label="Deliveroo" value={String(summary.deliveroo)} accent="green" />
        <OrbitStatPill label="Hero" value={String(summary.hero)} accent="fuchsia" />
        <OrbitStatPill label="Square" value={String(summary.square)} accent="amber" />
        <OrbitStatPill label="Quality avg" value={summary.count ? `${summary.avgScore}/100` : "-"} accent="cyan" />
      </div>

      {summary.warned > 0 && (
        <div className="mt-4 rounded-2xl border border-amber-300/20 bg-amber-400/10 px-4 py-3 text-sm text-amber-100">
          {summary.warned} image{summary.warned > 1 ? "s" : ""} should be reviewed before publishing.
        </div>
      )}

      <div className="mt-4 flex flex-wrap gap-3">
        <OrbitButton variant={globalPreset === "smart" ? "secondary" : "ghost"} className="px-3 py-2 text-xs" onClick={() => applyPreset("smart")}>Smart routing</OrbitButton>
        {(Object.keys(MENU_IMAGE_PRESETS) as MenuImagePreset[]).map((preset) => (
          <OrbitButton
            key={preset}
            variant={globalPreset === preset ? "secondary" : "ghost"}
            className="px-3 py-2 text-xs"
            onClick={() => applyPreset(preset)}
          >
            Apply {preset}
          </OrbitButton>
        ))}
      </div>

      <div className="mt-4 overflow-hidden rounded-3xl border border-white/10">
        <div className="grid grid-cols-[1.5fr,0.8fr,0.8fr,0.8fr,1.4fr] gap-0 border-b border-white/10 bg-white/5 px-4 py-3 text-[11px] uppercase tracking-[0.18em] text-white/45">
          <div>Source</div>
          <div>Preset</div>
          <div>Ratio</div>
          <div>Quality</div>
          <div>Suggested export</div>
        </div>
        <div className="divide-y divide-white/10">
          {items.length === 0 ? (
            <div className="px-4 py-6 text-sm text-white/55">No food photos loaded yet.</div>
          ) : (
            items.map((item) => (
              <div key={item.id} className="grid grid-cols-[1.5fr,0.8fr,0.8fr,0.8fr,1.4fr] gap-0 px-4 py-3 text-sm text-white/75">
                <div>
                  <div className="font-semibold text-white">{item.file.name}</div>
                  <div className="mt-1 text-xs text-white/45">{item.orientation}</div>
                  {item.warning && <div className="mt-1 text-xs text-amber-200">{item.warning}</div>}
                  {item.reasons[0] && <div className="mt-1 text-xs text-white/50">{item.reasons[0]}</div>}
                </div>
                <div>{item.preset}</div>
                <div>{item.ratio}</div>
                <div>
                  <div className={`inline-flex rounded-full px-2 py-1 text-xs font-semibold ${item.qualityStatus === "good" ? "bg-emerald-500/15 text-emerald-300" : item.qualityStatus === "review" ? "bg-amber-500/15 text-amber-200" : "bg-red-500/15 text-red-200"}`}>
                    {item.qualityScore}/100
                  </div>
                </div>
                <div className="break-all">{item.suggestedName}</div>
              </div>
            ))
          )}
        </div>
      </div>
    </OrbitCard>
  );
}

async function readDimensions(file: File): Promise<{ width: number; height: number }> {
  const objectUrl = URL.createObjectURL(file);
  const img = new Image();

  return new Promise((resolve, reject) => {
    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      resolve({ width: img.width, height: img.height });
    };

    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error(`Unable to read ${file.name}`));
    };

    img.src = objectUrl;
  });
}
