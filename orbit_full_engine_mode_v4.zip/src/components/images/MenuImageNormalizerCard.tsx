import React, { useEffect, useMemo, useState } from "react";
import OrbitCard from "@/components/ui/OrbitCard";
import OrbitButton from "@/components/ui/OrbitButton";
import OrbitStatPill from "@/components/ui/OrbitStatPill";
import {
  analyzeMenuImage,
  buildNormalizedFilename,
  MENU_IMAGE_PRESETS,
  MenuImagePreset,
  normalizeMenuImage,
} from "@/lib/images/menuImageNormalizer";

type Props = {
  title?: string;
};

export default function MenuImageNormalizerCard({ title = "Menu image harmonizer" }: Props) {
  const [file, setFile] = useState<File | null>(null);
  const [preset, setPreset] = useState<MenuImagePreset>("deliveroo-card");
  const [analysis, setAnalysis] = useState<ReturnType<typeof analyzeMenuImage> | null>(null);
  const [exporting, setExporting] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [filename, setFilename] = useState<string>("");
  const [error, setError] = useState<string | null>(null);

  const presetConfig = useMemo(() => MENU_IMAGE_PRESETS[preset], [preset]);

  useEffect(() => {
    return () => {
      if (downloadUrl) URL.revokeObjectURL(downloadUrl);
    };
  }, [downloadUrl]);

  async function onPick(nextFile: File) {
    setError(null);
    setFile(nextFile);
    setAnalysis(null);
    setFilename("");
    setDownloadUrl((current) => {
      if (current) URL.revokeObjectURL(current);
      return null;
    });

    const objectUrl = URL.createObjectURL(nextFile);
    const img = new Image();

    img.onload = () => {
      try {
        const result = analyzeMenuImage(img.width, img.height);
        setPreset(result.recommendedPreset);
        setAnalysis(result);
      } finally {
        URL.revokeObjectURL(objectUrl);
      }
    };

    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      setError("Unable to read this image. Please try another file.");
    };

    img.src = objectUrl;
  }

  async function onNormalize() {
    if (!file) return;

    setError(null);
    setExporting(true);

    try {
      const blob = await normalizeMenuImage(file, preset);
      const nextUrl = URL.createObjectURL(blob);

      setDownloadUrl((current) => {
        if (current) URL.revokeObjectURL(current);
        return nextUrl;
      });
      setFilename(buildNormalizedFilename(file.name, preset));
    } catch (err) {
      console.error("[menu-image-normalizer] failed", err);
      setError("Normalization failed. Please try another image or preset.");
    } finally {
      setExporting(false);
    }
  }

  return (
    <OrbitCard className="p-5 md:p-6">
      <div className="flex flex-col gap-4">
        <div>
          <div className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan-300/80">Image QA</div>
          <h2 className="mt-2 text-xl font-bold text-white">{title}</h2>
          <p className="mt-2 text-sm text-white/60">
            Detects bad ratios, recommends the right crop, then resizes every food photo to a clean menu format.
          </p>
        </div>

        <label className="rounded-2xl border border-dashed border-white/15 bg-white/5 p-4 text-sm text-white/80">
          <div>Select food image</div>
          <input
            type="file"
            accept="image/*"
            className="mt-3 block w-full text-sm"
            onChange={(e) => {
              const nextFile = e.target.files?.[0];
              if (nextFile) void onPick(nextFile);
            }}
          />
        </label>

        {analysis && (
          <div className="flex flex-wrap gap-2">
            <OrbitStatPill label="Ratio" value={analysis.aspectRatio.toFixed(2)} />
            <OrbitStatPill label="Orientation" value={analysis.orientation} />
            <OrbitStatPill label="Preset" value={analysis.recommendedPreset} />
            <OrbitStatPill label="Crop zoom" value={`${analysis.cropZoom}x`} />
          </div>
        )}

        <div className="grid gap-3 md:grid-cols-3">
          {(Object.keys(MENU_IMAGE_PRESETS) as MenuImagePreset[]).map((key) => {
            const cfg = MENU_IMAGE_PRESETS[key];
            const selected = preset === key;
            return (
              <button
                key={key}
                type="button"
                onClick={() => setPreset(key)}
                className={`rounded-2xl border p-3 text-left transition ${selected ? "border-cyan-300/50 bg-cyan-400/10" : "border-white/10 bg-white/5"}`}
              >
                <div className="text-sm font-semibold text-white">{key}</div>
                <div className="mt-1 text-xs text-white/60">{cfg.width} × {cfg.height}</div>
              </button>
            );
          })}
        </div>

        {analysis?.warning && (
          <div className="rounded-2xl border border-amber-300/20 bg-amber-400/10 px-4 py-3 text-sm text-amber-100">
            {analysis.warning}
          </div>
        )}

        {error && (
          <div className="rounded-2xl border border-red-300/20 bg-red-400/10 px-4 py-3 text-sm text-red-100">
            {error}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3">
          <OrbitButton onClick={onNormalize} disabled={!file || exporting}>
            {exporting ? "Normalizing..." : "Normalize image"}
          </OrbitButton>
          <div className="text-sm text-white/60">
            Target output: {presetConfig.width} × {presetConfig.height}
          </div>
          {downloadUrl && (
            <a
              href={downloadUrl}
              download={filename}
              className="inline-flex items-center justify-center rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-semibold text-white"
            >
              Download normalized file
            </a>
          )}
        </div>
      </div>
    </OrbitCard>
  );
}
