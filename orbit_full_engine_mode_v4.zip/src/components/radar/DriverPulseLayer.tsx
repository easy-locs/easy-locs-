import React from "react";
import type { RadarDriver } from "@/types/radar";
import OrbitCard from "@/components/ui/OrbitCard";

export default function DriverPulseLayer({ drivers }: { drivers: RadarDriver[] }) {
  return (
    <OrbitCard className="p-4">
      <div className="text-sm font-semibold text-white">Live drivers</div>
      <div className="mt-3 grid gap-2 md:grid-cols-2">
        {drivers.map((driver) => (
          <div key={driver.id} className="rounded-2xl border border-white/10 bg-white/5 px-3 py-2">
            <div className="flex items-center justify-between">
              <div className="text-sm font-semibold text-white">Driver {driver.id}</div>
              <div className="text-xs text-cyan-300">{driver.vehicleType ?? "scooter"}</div>
            </div>
            <div className="mt-1 text-xs text-white/55">{driver.status} · {driver.lat}, {driver.lng}</div>
          </div>
        ))}
      </div>
    </OrbitCard>
  );
}
