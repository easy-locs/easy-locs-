import React from "react";
import type { HeatPoint } from "@/types/radar";
import OrbitCard from "@/components/ui/OrbitCard";

export default function HeatZones({ points }: { points: HeatPoint[] }) {
  return (
    <OrbitCard className="p-4">
      <div className="text-sm font-semibold text-white">Heat zones</div>
      <div className="mt-3 space-y-2">
        {points.map((point) => (
          <div key={`${point.lat}-${point.lng}`} className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-3 py-2">
            <div className="text-xs text-white/60">{point.lat}, {point.lng}</div>
            <div className="rounded-full bg-fuchsia-500/15 px-2 py-1 text-xs font-semibold text-fuchsia-200">Intensity {point.intensity}</div>
          </div>
        ))}
      </div>
    </OrbitCard>
  );
}
