import React, { useState } from "react";
import OrbitButton from "@/components/ui/OrbitButton";
import OrbitCard from "@/components/ui/OrbitCard";

type Props = {
  active: boolean;
  remainingMs: number;
  onActivate: (ttlSeconds?: number, biometricRequired?: boolean) => void;
  onDeactivate: () => void;
  onPanic: () => void;
};

export default function GhostEntrySheet({ active, remainingMs, onActivate, onDeactivate, onPanic }: Props) {
  const [ttlMinutes, setTtlMinutes] = useState(15);

  return (
    <OrbitCard className="p-4">
      <div className="text-[11px] uppercase tracking-[0.2em] text-fuchsia-300/80">Ghost mode</div>
      <div className="mt-2 text-xl font-bold text-white">Hardened private layer</div>
      <p className="mt-2 text-sm text-white/60">
        Separate vault-style session with TTL, local purge hooks, hidden previews, and dedicated session keys.
      </p>

      <div className="mt-4 rounded-2xl border border-white/10 bg-black/10 p-3 text-sm text-white/70">
        <div className="flex items-center justify-between gap-3">
          <span>State</span>
          <span className={active ? "text-emerald-300" : "text-white/60"}>{active ? "Active" : "Locked"}</span>
        </div>
        <div className="mt-2 flex items-center justify-between gap-3">
          <span>TTL</span>
          <span className="text-white">{active ? `${Math.ceil(remainingMs / 1000)}s left` : `${ttlMinutes} min`}</span>
        </div>
      </div>

      {!active ? (
        <div className="mt-4 space-y-3">
          <label className="block text-sm text-white/70">
            Session TTL (minutes)
            <input
              type="number"
              min={1}
              max={60}
              value={ttlMinutes}
              onChange={(e) => setTtlMinutes(Number(e.target.value) || 15)}
              className="mt-2 w-full rounded-2xl border border-white/10 bg-black/20 px-3 py-2 text-white outline-none"
            />
          </label>
          <OrbitButton className="w-full" onClick={() => onActivate(ttlMinutes * 60, true)}>
            Enter Ghost
          </OrbitButton>
        </div>
      ) : (
        <div className="mt-4 flex gap-3">
          <OrbitButton variant="ghost" className="flex-1" onClick={onDeactivate}>Exit</OrbitButton>
          <OrbitButton variant="secondary" className="flex-1" onClick={onPanic}>Panic purge</OrbitButton>
        </div>
      )}
    </OrbitCard>
  );
}
