import React, { useMemo, useState } from "react";
import OrbitButton from "@/components/ui/OrbitButton";
import OrbitCard from "@/components/ui/OrbitCard";

type Props = {
  locked: boolean;
  onUnlock: (pin: string) => boolean;
};

export default function GhostLockScreen({ locked, onUnlock }: Props) {
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");

  const masked = useMemo(() => "•".repeat(pin.length), [pin]);

  if (!locked) return null;

  return (
    <OrbitCard className="p-5">
      <div className="text-[11px] uppercase tracking-[0.18em] text-fuchsia-300/80">Ghost vault</div>
      <div className="mt-2 text-2xl font-bold text-white">Unlock required</div>
      <p className="mt-2 text-sm text-white/60">Use a local PIN or device biometric bridge in the host app.</p>

      <div className="mt-4 rounded-2xl border border-white/10 bg-black/20 p-4 text-center text-2xl tracking-[0.5em] text-white">
        {masked || "••••"}
      </div>

      <input
        type="password"
        inputMode="numeric"
        maxLength={6}
        value={pin}
        onChange={(e) => {
          setPin(e.target.value.replace(/\D/g, "").slice(0, 6));
          setError("");
        }}
        className="mt-4 w-full rounded-2xl border border-white/10 bg-black/20 px-3 py-3 text-center text-white outline-none"
        placeholder="Enter 6-digit PIN"
      />

      {error ? <div className="mt-3 text-sm text-rose-300">{error}</div> : null}

      <OrbitButton
        className="mt-4 w-full"
        onClick={() => {
          if (!onUnlock(pin)) {
            setError("Invalid local PIN.");
            return;
          }
          setPin("");
        }}
      >
        Unlock Ghost
      </OrbitButton>
    </OrbitCard>
  );
}
