import React, { useMemo, useState } from "react";
import OrbitButton from "@/components/ui/OrbitButton";
import OrbitCard from "@/components/ui/OrbitCard";
import type { OrbitConversation, OrbitMessage } from "@/types/communication";

type Props = {
  conversation: OrbitConversation | null;
  messages: OrbitMessage[];
  onSend: (body: string) => void;
  onStartCall: (type: "audio" | "video") => void;
};

export default function ConversationView({ conversation, messages, onSend, onStartCall }: Props) {
  const [draft, setDraft] = useState("");

  const title = useMemo(() => conversation?.title ?? "No conversation", [conversation]);

  return (
    <OrbitCard className="p-4">
      <div className="flex items-center justify-between gap-3 border-b border-white/10 pb-3">
        <div>
          <div className="text-[11px] uppercase tracking-[0.16em] text-white/50">Conversation</div>
          <div className="mt-1 text-xl font-bold text-white">{title}</div>
        </div>
        {conversation ? (
          <div className="flex gap-2">
            <OrbitButton variant="ghost" className="px-3 py-2 text-xs" onClick={() => onStartCall("audio")}>Audio</OrbitButton>
            <OrbitButton variant="ghost" className="px-3 py-2 text-xs" onClick={() => onStartCall("video")}>Video</OrbitButton>
          </div>
        ) : null}
      </div>

      <div className="mt-4 space-y-3">
        {messages.map((message) => {
          const mine = message.senderId === "me";
          return (
            <div key={message.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[78%] rounded-3xl px-4 py-3 ${mine ? "bg-white text-slate-900" : "bg-black/20 text-white border border-white/10"}`}>
                <div className="text-sm leading-6">{message.body}</div>
                <div className={`mt-2 text-[11px] ${mine ? "text-slate-500" : "text-white/45"}`}>
                  {new Date(message.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} • {message.deliveryState}
                  {message.isEphemeral ? " • ghost" : ""}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 flex gap-3">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder={conversation?.mode === "ghost" ? "Ghost message" : "Type a message"}
          className="flex-1 rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-white outline-none"
        />
        <OrbitButton onClick={() => {
          onSend(draft);
          setDraft("");
        }}>
          Send
        </OrbitButton>
      </div>
    </OrbitCard>
  );
}
