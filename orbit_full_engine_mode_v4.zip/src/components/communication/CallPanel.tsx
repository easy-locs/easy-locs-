import React from "react";
import OrbitButton from "@/components/ui/OrbitButton";
import OrbitCard from "@/components/ui/OrbitCard";
import type { OrbitCallType } from "@/types/communication";

type Props = {
  call: {
    id: string;
    type: OrbitCallType;
    state: "idle" | "ringing" | "connecting" | "active" | "ended";
    startedAt?: string;
  } | null;
  onConnect: () => void;
  onEnd: () => void;
  onClear: () => void;
};

export default function CallPanel({ call, onConnect, onEnd, onClear }: Props) {
  if (!call) return null;

  return (
    <OrbitCard className="p-4">
      <div className="text-[11px] uppercase tracking-[0.18em] text-cyan-300/80">Secure call shell</div>
      <div className="mt-2 text-xl font-bold text-white">{call.type === "video" ? "Video" : "Audio"} call</div>
      <div className="mt-2 text-sm text-white/60">State: {call.state}</div>
      {call.startedAt ? <div className="mt-1 text-xs text-white/40">Started {new Date(call.startedAt).toLocaleTimeString()}</div> : null}
      <div className="mt-4 flex gap-3">
        {call.state !== "active" && call.state !== "ended" ? (
          <OrbitButton variant="ghost" onClick={onConnect}>Connect</OrbitButton>
        ) : null}
        {call.state !== "ended" ? <OrbitButton variant="secondary" onClick={onEnd}>End</OrbitButton> : null}
        {call.state === "ended" ? <OrbitButton onClick={onClear}>Dismiss</OrbitButton> : null}
      </div>
    </OrbitCard>
  );
}
