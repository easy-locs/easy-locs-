import React from "react";
import OrbitCard from "@/components/ui/OrbitCard";
import type { OrbitConversation } from "@/types/communication";

type Props = {
  conversations: OrbitConversation[];
  selectedId?: string;
  onSelect: (id: string) => void;
};

export default function CommunicationInbox({ conversations, selectedId, onSelect }: Props) {
  return (
    <OrbitCard className="p-3">
      <div className="px-2 py-2 text-[11px] uppercase tracking-[0.18em] text-cyan-300/80">Orbit communication</div>
      <div className="space-y-2">
        {conversations.map((conversation) => {
          const isSelected = selectedId === conversation.id;
          const preview = conversation.mode === "ghost" ? "Preview hidden" : (conversation.lastMessagePreview || "No messages yet");
          return (
            <button
              key={conversation.id}
              onClick={() => onSelect(conversation.id)}
              className={`w-full rounded-2xl border px-3 py-3 text-left transition ${isSelected ? "border-fuchsia-300/35 bg-fuchsia-400/10" : "border-white/10 bg-black/10 hover:bg-white/5"}`}
            >
              <div className="flex items-center justify-between gap-3">
                <div className="font-semibold text-white">{conversation.title}</div>
                <div className={`rounded-full px-2 py-1 text-[10px] uppercase tracking-[0.16em] ${conversation.mode === "ghost" ? "bg-fuchsia-400/15 text-fuchsia-200" : "bg-cyan-400/15 text-cyan-200"}`}>
                  {conversation.mode}
                </div>
              </div>
              <div className="mt-2 text-sm text-white/60">{preview}</div>
              <div className="mt-3 flex items-center justify-between text-xs text-white/45">
                <span>{new Date(conversation.lastActivityAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                <span>{conversation.unreadCount} unread</span>
              </div>
            </button>
          );
        })}
      </div>
    </OrbitCard>
  );
}
