export function makeReference() {
  return "EL-" + Math.random().toString(36).slice(2, 8).toUpperCase();
}
