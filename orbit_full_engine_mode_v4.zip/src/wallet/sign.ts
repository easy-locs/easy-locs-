export async function signWalletPayload(privateKey: CryptoKey, payload: unknown) {
  const bytes = new TextEncoder().encode(JSON.stringify(payload));
  const sig = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, privateKey, bytes);
  return btoa(String.fromCharCode(...new Uint8Array(sig)));
}
