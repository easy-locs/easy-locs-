import { useMemo } from "react";
import { runRuntimeAudit } from "@/core/runtimeAudit";

export function useRuntimeAudit() {
  return useMemo(() => runRuntimeAudit(), []);
}