import { useEffect, useMemo, useState } from "react";
import type { OrbitConversation } from "@/types/communication";
import { fetchConversations } from "@/services/conversationService";

export function useConversations() {
  const [conversations, setConversations] = useState<OrbitConversation[]>([]);
  const [selectedId, setSelectedId] = useState<string>("");

  useEffect(() => {
    void fetchConversations().then((rows) => {
      setConversations(rows);
      setSelectedId((prev) => prev || rows[0]?.id || "");
    });
  }, []);

  const selectedConversation = useMemo(
    () => conversations.find((item) => item.id === selectedId) ?? conversations[0] ?? null,
    [conversations, selectedId]
  );

  return { conversations, setConversations, selectedId, setSelectedId, selectedConversation };
}