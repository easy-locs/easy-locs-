import { useMemo, useState } from "react";
import type { OrbitCallType } from "@/types/communication";
import { createCallSession } from "@/lib/communication/call-signaling";

export function useCallSession() {
  const [call, setCall] = useState<ReturnType<typeof createCallSession> | null>(null);

  return useMemo(() => ({
    call,
    start: (type: OrbitCallType) => setCall(createCallSession(type)),
    connect: () => setCall((prev) => prev ? { ...prev, state: "active", startedAt: new Date().toISOString() } : prev),
    end: () => setCall((prev) => prev ? { ...prev, state: "ended" } : prev),
    clear: () => setCall(null),
  }), [call]);
}
