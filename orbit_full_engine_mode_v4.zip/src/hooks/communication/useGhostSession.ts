import { useEffect, useMemo, useState } from "react";
import { activateGhostSession, deactivateGhostSession, getGhostRemainingMs, getGhostSession, isGhostActive, panicGhostPurge, startGhostSessionMonitor } from "@/lib/security/ghost-security";

export function useGhostSession() {
  const [active, setActive] = useState(isGhostActive());
  const [remainingMs, setRemainingMs] = useState(getGhostRemainingMs());

  useEffect(() => {
    const stop = startGhostSessionMonitor(() => {
      setActive(false);
      setRemainingMs(0);
    });
    const timer = setInterval(() => setRemainingMs(getGhostRemainingMs()), 1000);
    return () => {
      stop();
      clearInterval(timer);
    };
  }, []);

  return useMemo(() => ({
    session: getGhostSession(),
    active,
    remainingMs,
    activate: (ttlSeconds = 15 * 60, biometricRequired = true) => {
      activateGhostSession(ttlSeconds, biometricRequired);
      setActive(true);
      setRemainingMs(getGhostRemainingMs());
    },
    deactivate: () => {
      deactivateGhostSession();
      setActive(false);
      setRemainingMs(0);
    },
    panicPurge: () => {
      panicGhostPurge();
      setActive(false);
      setRemainingMs(0);
    },
  }), [active, remainingMs]);
}
