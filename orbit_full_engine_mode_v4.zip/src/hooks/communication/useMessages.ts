import { useEffect, useMemo, useState } from "react";
import type { OrbitConversation, OrbitMessage } from "@/types/communication";
import { fetchConversation } from "@/services/envelopeService";
import { useChatStore } from "@/store/chatStore";
import { emit } from "@/core/relay";
import { on } from "@/core/relay";

export function useMessages(conversation: OrbitConversation | null) {
  const envelopes = useChatStore((s) => s.envelopes);
  const plaintextById = useChatStore((s) => s.plaintextById);
  const addEnvelope = useChatStore((s) => s.addEnvelope);

  useEffect(() => {
    if (!conversation) return;
    void fetchConversation(conversation.id).then((rows) => rows.forEach(addEnvelope));
  }, [conversation, addEnvelope]);

  useEffect(() => {
    return on("CHAT_SYSTEM_NOTICE", (payload: any) => {
      if (!conversation) return;
      addEnvelope({
        id: crypto.randomUUID(),
        conversation_id: conversation.id,
        sender_orbit_id: "system",
        sender_device_id: "system",
        receiver_orbit_id: "*",
        ratchet_counter: Date.now(),
        ghost: false,
        aad: `system:${conversation.id}`,
        iv: [],
        ciphertext: payload.text,
        signature_b64: "system",
        created_at: new Date().toISOString()
      } as any);
    });
  }, [conversation, addEnvelope]);

  const messages = useMemo<OrbitMessage[]>(() => {
    if (!conversation) return [];
    const now = Date.now();
    return envelopes
      .filter((row) => row.conversation_id === conversation.id)
      .filter((row) => !row.expires_at || new Date(row.expires_at).getTime() > now)
      .map((row, idx) => ({
        id: row.id ?? `${idx}`,
        conversationId: row.conversation_id,
        senderId: row.sender_orbit_id === "system" ? "ops" : row.sender_orbit_id,
        body: plaintextById[row.id ?? `${idx}`] ?? (row.sender_orbit_id === "system" ? row.ciphertext : "[encrypted payload]"),
        kind: "text",
        createdAt: row.created_at ?? new Date().toISOString(),
        deliveryState: "delivered",
        isEphemeral: row.ghost,
        expiresAt: row.expires_at ?? undefined,
      }));
  }, [conversation, envelopes, plaintextById]);

  const sendMessage = (body: string) => {
    if (!conversation || !body.trim()) return;
    emit("CHAT_SEND", {
      conversationId: conversation.id,
      text: body.trim(),
      ghost: conversation.mode === "ghost",
      sender_orbit_id: "demo-orbit-id",
      sender_device_id: "demo-device-id",
      receiver_orbit_id: conversation.participants.find((p) => p.id !== "me")?.id ?? "peer-orbit-demo",
    });
  };

  return { messages, sendMessage };
}