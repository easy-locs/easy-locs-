import { create } from "zustand";

type SecurityStore = {
  orbitId: string | null;
  deviceId: string | null;
  ghostActive: boolean;
  lastReference: string | null;
  setIdentity: (orbitId: string, deviceId: string) => void;
  setGhostActive: (active: boolean) => void;
  setLastReference: (ref: string | null) => void;
};

export const useSecurityStore = create<SecurityStore>((set) => ({
  orbitId: null,
  deviceId: null,
  ghostActive: false,
  lastReference: null,
  setIdentity: (orbitId, deviceId) => set({ orbitId, deviceId }),
  setGhostActive: (ghostActive) => set({ ghostActive }),
  setLastReference: (lastReference) => set({ lastReference })
}));
