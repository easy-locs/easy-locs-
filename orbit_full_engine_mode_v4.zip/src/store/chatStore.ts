import { create } from "zustand";
import type { SecureEnvelope, WalletTransaction } from "../types";

type ChatStore = {
  conversationId: string;
  envelopes: SecureEnvelope[];
  plaintextById: Record<string, string>;
  transactions: WalletTransaction[];
  setConversationId: (id: string) => void;
  addEnvelope: (env: SecureEnvelope) => void;
  addPlaintext: (id: string, text: string) => void;
  setTransactions: (rows: WalletTransaction[]) => void;
  addTransaction: (tx: WalletTransaction) => void;
};

export const useChatStore = create<ChatStore>((set) => ({
  conversationId: "demo-conversation",
  envelopes: [],
  plaintextById: {},
  transactions: [],
  setConversationId: (conversationId) => set({ conversationId }),
  addEnvelope: (env) => set((s) => ({ envelopes: [...s.envelopes, env] })),
  addPlaintext: (id, text) => set((s) => ({ plaintextById: { ...s.plaintextById, [id]: text } })),
  setTransactions: (transactions) => set({ transactions }),
  addTransaction: (tx) => set((s) => ({ transactions: [tx, ...s.transactions] }))
}));
