import { emit } from "@/core/relay";
import { insertEnvelope } from "@/services/envelopeService";
import type { SecureEnvelope } from "@/types";

export async function persistEnvelopeReliably(envelope: SecureEnvelope) {
  emit("STORE_ENVELOPE_RELIABLE", {
    taskId: `env-${envelope.conversation_id}-${envelope.ratchet_counter}`,
    run: async () => {
      await insertEnvelope(envelope);
    }
  });
}