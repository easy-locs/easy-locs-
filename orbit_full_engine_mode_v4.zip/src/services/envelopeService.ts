import { supabase } from "../lib/supabase";
import type { SecureEnvelope } from "../types";

export async function insertEnvelope(row: SecureEnvelope) {
  const { data, error } = await supabase.from("secure_envelopes").insert(row).select().single();
  if (error) throw error;
  return data as SecureEnvelope;
}

export async function fetchConversation(conversationId: string) {
  const { data, error } = await supabase
    .from("secure_envelopes")
    .select("*")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: true });

  if (error) throw error;
  return (data ?? []) as SecureEnvelope[];
}
