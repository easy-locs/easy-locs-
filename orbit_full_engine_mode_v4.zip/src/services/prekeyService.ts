import { supabase } from "../lib/supabase";
import type { SignedPrekey } from "../types";

export async function publishPrekeys(rows: SignedPrekey[]) {
  const { error } = await supabase.from("orbit_prekeys").insert(rows);
  if (error) throw error;
}
