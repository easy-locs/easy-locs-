import { supabase } from "../lib/supabase";
import type { DevicePublicBundle } from "../types";

export async function upsertDevice(bundle: DevicePublicBundle) {
  const { error } = await supabase.from("orbit_devices").upsert(bundle);
  if (error) throw error;
}
