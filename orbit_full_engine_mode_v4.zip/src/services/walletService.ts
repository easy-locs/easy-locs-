import { supabase } from "../lib/supabase";
import type { WalletTransaction } from "../types";

export async function insertWalletTx(row: WalletTransaction) {
  const { data, error } = await supabase.from("wallet_transactions").insert(row).select().single();
  if (error) throw error;
  return data as WalletTransaction;
}

export async function fetchWalletTxs(orbitId: string) {
  const { data, error } = await supabase
    .from("wallet_transactions")
    .select("*")
    .or(`sender_orbit_id.eq.${orbitId},receiver_orbit_id.eq.${orbitId}`)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as WalletTransaction[];
}
