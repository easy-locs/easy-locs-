import { emit, on } from "@/core/relay";

let ready = false;
export function initModuleSyncService() {
  if (ready) return;
  ready = true;

  on("WALLET_TX_SYNCED", (tx) => {
    emit("CHAT_SYSTEM_NOTICE", { text: `Wallet transaction ${tx.reference} synced`, tx });
  });

  on("DELIVERY_STATUS_SYNCED", (job) => {
    emit("CHAT_SYSTEM_NOTICE", { text: `Delivery ${job.id} is now ${job.status}`, job });
  });
}