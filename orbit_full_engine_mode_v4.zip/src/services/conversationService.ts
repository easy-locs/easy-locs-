import { supabase } from "@/lib/supabase";
import type { OrbitConversation } from "@/types/communication";
import { createDemoConversations } from "@/lib/communication/messaging";

export async function fetchConversations(): Promise<OrbitConversation[]> {
  try {
    const { data, error } = await supabase.from("orbit_conversations").select("*").order("last_activity_at", { ascending: false });
    if (error || !data) return createDemoConversations();
    return data.map((row: any) => ({
      id: row.id,
      title: row.title,
      mode: row.mode,
      participants: row.participants ?? [],
      lastMessagePreview: row.last_message_preview ?? (row.mode === "ghost" ? "Preview hidden" : "No messages yet"),
      lastActivityAt: row.last_activity_at ?? new Date().toISOString(),
      unreadCount: row.unread_count ?? 0,
      isLocked: row.is_locked ?? false,
      ttlSeconds: row.ttl_seconds ?? undefined,
    })) as OrbitConversation[];
  } catch {
    return createDemoConversations();
  }
}