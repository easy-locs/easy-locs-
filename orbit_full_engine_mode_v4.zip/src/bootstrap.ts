import { createLocalIdentity } from "./security/identity";
import { exportJwk } from "./security/keyImport";
import { saveJwk } from "./security/keystore";
import { upsertDevice } from "./services/deviceService";
import { generateSignedPrekeys } from "./security/prekeys";
import { publishPrekeys } from "./services/prekeyService";
import { useSecurityStore } from "./store/securityStore";

let booted = false;

export async function bootstrapApp() {
  if (booted) return;
  booted = true;

  const identity = await createLocalIdentity();
  useSecurityStore.getState().setIdentity(identity.orbitId, identity.deviceId);

  await saveJwk("sign-private", await exportJwk(identity.signKeyPair.privateKey));
  await saveJwk("kex-private", await exportJwk(identity.kexKeyPair.privateKey));
  await saveJwk("sign-public", await exportJwk(identity.signKeyPair.publicKey));
  await saveJwk("kex-public", await exportJwk(identity.kexKeyPair.publicKey));

  await upsertDevice({
    orbit_id: identity.orbitId,
    device_id: identity.deviceId,
    sign_public_jwk: await exportJwk(identity.signKeyPair.publicKey),
    kex_public_jwk: await exportJwk(identity.kexKeyPair.publicKey)
  });

  const prekeys = await generateSignedPrekeys(identity.signKeyPair.privateKey, 8);
  await publishPrekeys(prekeys.map((r) => ({ ...r, orbit_id: identity.orbitId, used: false })));
}
