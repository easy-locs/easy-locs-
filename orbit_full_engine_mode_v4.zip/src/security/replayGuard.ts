const seen = new Map<string, Set<number>>();

export function acceptCounter(conversationId: string, counter: number) {
  if (!seen.has(conversationId)) seen.set(conversationId, new Set());
  const set = seen.get(conversationId)!;
  if (set.has(counter)) return false;
  set.add(counter);
  return true;
}
