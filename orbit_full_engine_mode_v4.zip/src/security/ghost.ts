const K_ACTIVE = "orbit:ghost:active";
const K_TTL = "orbit:ghost:ttl";

export function enableGhost(ttlMs = 5 * 60 * 1000) {
  sessionStorage.setItem(K_ACTIVE, "true");
  sessionStorage.setItem(K_TTL, String(Date.now() + ttlMs));
}

export function disableGhost() {
  sessionStorage.removeItem(K_ACTIVE);
  sessionStorage.removeItem(K_TTL);
}

export function readGhostState() {
  const active = sessionStorage.getItem(K_ACTIVE) === "true";
  const ttl = Number(sessionStorage.getItem(K_TTL) ?? "0");
  const remainingMs = Math.max(0, ttl - Date.now());
  if (!active || remainingMs <= 0) {
    disableGhost();
    return { active: false, remainingMs: 0 };
  }
  return { active: true, remainingMs };
}
