import { hkdfBytes } from "./hkdf";

async function importAes(seed: ArrayBuffer) {
  const aesRaw = await hkdfBytes(seed, "orbit-aes-key", 32);
  return crypto.subtle.importKey("raw", aesRaw, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}

export async function encryptEnvelope(seed: ArrayBuffer, text: string, aad: string) {
  const key = await importAes(seed);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv, additionalData: new TextEncoder().encode(aad) },
    key,
    new TextEncoder().encode(text)
  );
  return {
    iv: Array.from(iv),
    ciphertext: btoa(String.fromCharCode(...new Uint8Array(encrypted)))
  };
}

export async function decryptEnvelope(seed: ArrayBuffer, payload: { iv: number[]; ciphertext: string; aad: string }) {
  const key = await importAes(seed);
  const bytes = Uint8Array.from(atob(payload.ciphertext), (c) => c.charCodeAt(0));
  const decrypted = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: new Uint8Array(payload.iv), additionalData: new TextEncoder().encode(payload.aad) },
    key,
    bytes
  );
  return new TextDecoder().decode(decrypted);
}
