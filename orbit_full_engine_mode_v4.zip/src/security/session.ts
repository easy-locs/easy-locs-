import { hkdfBytes } from "./hkdf";

export type SessionState = {
  rootSeed: ArrayBuffer;
  sendCounter: number;
  recvCounter: number;
};

export async function createSession(seed: ArrayBuffer): Promise<SessionState> {
  const root = await hkdfBytes(seed, "orbit-session-root", 32);
  return { rootSeed: root.buffer, sendCounter: 0, recvCounter: 0 };
}

export async function nextSeed(session: SessionState, direction: "send" | "recv") {
  const counter = direction === "send" ? session.sendCounter++ : session.recvCounter++;
  return hkdfBytes(session.rootSeed, `orbit-msg-${direction}-${counter}`, 32);
}
