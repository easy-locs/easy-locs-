async function importRaw(seed: ArrayBuffer) {
  return crypto.subtle.importKey("raw", seed, "HKDF", false, ["deriveBits", "deriveKey"]);
}

export async function hkdfBytes(seed: ArrayBuffer, info: string, length = 32) {
  const key = await importRaw(seed);
  const bits = await crypto.subtle.deriveBits(
    {
      name: "HKDF",
      hash: "SHA-256",
      salt: new Uint8Array(32),
      info: new TextEncoder().encode(info)
    },
    key,
    length * 8
  );
  return new Uint8Array(bits);
}
