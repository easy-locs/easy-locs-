import { exportJwk } from "./keyImport";

export async function createLocalIdentity() {
  const signKeyPair = await crypto.subtle.generateKey(
    { name: "ECDSA", namedCurve: "P-256" },
    true,
    ["sign", "verify"]
  );
  const kexKeyPair = await crypto.subtle.generateKey(
    { name: "ECDH", namedCurve: "P-256" },
    true,
    ["deriveBits", "deriveKey"]
  );

  const signPublic = await exportJwk(signKeyPair.publicKey);
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(JSON.stringify(signPublic)));
  const orbitId = Array.from(new Uint8Array(digest)).map((n) => n.toString(16).padStart(2, "0")).join("").slice(0, 32);

  return {
    orbitId,
    deviceId: crypto.randomUUID(),
    signKeyPair,
    kexKeyPair
  };
}

export async function signJson(privateKey: CryptoKey, payload: unknown) {
  const bytes = new TextEncoder().encode(JSON.stringify(payload));
  const sig = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, privateKey, bytes);
  return btoa(String.fromCharCode(...new Uint8Array(sig)));
}
