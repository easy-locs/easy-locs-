export async function exportJwk(key: CryptoKey) {
  return crypto.subtle.exportKey("jwk", key);
}
export async function importEcdsaPrivate(jwk: JsonWebKey) {
  return crypto.subtle.importKey("jwk", jwk, { name: "ECDSA", namedCurve: "P-256" }, true, ["sign"]);
}
export async function importEcdhPrivate(jwk: JsonWebKey) {
  return crypto.subtle.importKey("jwk", jwk, { name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits", "deriveKey"]);
}
