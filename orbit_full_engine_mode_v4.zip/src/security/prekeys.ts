import { exportJwk } from "./keyImport";
import { signJson } from "./identity";

export async function generateSignedPrekeys(signPrivateKey: CryptoKey, count = 8) {
  const rows: { key_id: string; public_jwk: JsonWebKey; signature_b64: string }[] = [];
  for (let i = 0; i < count; i++) {
    const pair = await crypto.subtle.generateKey(
      { name: "ECDH", namedCurve: "P-256" },
      true,
      ["deriveBits", "deriveKey"]
    );
    const public_jwk = await exportJwk(pair.publicKey);
    const signature_b64 = await signJson(signPrivateKey, public_jwk);
    rows.push({
      key_id: crypto.randomUUID(),
      public_jwk,
      signature_b64
    });
  }
  return rows;
}
