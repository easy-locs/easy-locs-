export function bytesToB64(bytes: Uint8Array) {
  return btoa(String.fromCharCode(...bytes));
}
export function b64ToBytes(value: string) {
  return Uint8Array.from(atob(value), (c) => c.charCodeAt(0));
}
