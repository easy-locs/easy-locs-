export type RelayLayer = {
  hop: string;
  next: string | null;
  payload_b64: string;
};

export function multiHopPack(raw: unknown, hops: string[]) {
  let current = btoa(JSON.stringify(raw));
  for (let i = hops.length - 1; i >= 0; i--) {
    current = btoa(JSON.stringify({
      hop: hops[i],
      next: i === hops.length - 1 ? null : hops[i + 1],
      payload_b64: current
    } satisfies RelayLayer));
  }
  return current;
}

export function multiHopPeek(layerB64: string) {
  return JSON.parse(atob(layerB64)) as RelayLayer;
}
