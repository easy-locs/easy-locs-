import { BrowserRouter, NavLink, Route, Routes } from "react-router-dom";
import { DashboardPage } from "./pages/DashboardPage";
import { ChatPage } from "./pages/ChatPage";
import { WalletPage } from "./pages/WalletPage";
import { RelayPage } from "./pages/RelayPage";
import { SecurityPage } from "./pages/SecurityPage";
import CommunicationPage from "./pages/CommunicationPage";
import GhostVaultPage from "./pages/GhostVaultPage";
import FullBuild186CommunicationDemo from "./pages/FullBuild186CommunicationDemo";
import FullBuild185IntegrationDemo from "./pages/FullBuild185IntegrationDemo";
import FullBuild184ProDemo from "./pages/FullBuild184ProDemo";
import FullBuild183MenuImageDemo from "./pages/FullBuild183MenuImageDemo";
import FullBuild190V1Demo from "./pages/FullBuild190V1Demo";

function BottomNav() {
  const items = [
    ["/", "Core"],
    ["/chat", "Chat"],
    ["/wallet", "Wallet"],
    ["/communication", "Orbit"],
    ["/security", "Security"]
  ] as const;
  return (
    <nav className="bottom">
      {items.map(([to, label]) => (
        <NavLink key={to} to={to} className={({ isActive }) => isActive ? "nav active" : "nav"}>{label}</NavLink>
      ))}
    </nav>
  );
}

export default function App(){
  return (
    <BrowserRouter>
      <div className="shell">
        <div className="wrap">
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/chat" element={<ChatPage />} />
            <Route path="/wallet" element={<WalletPage />} />
            <Route path="/relay" element={<RelayPage />} />
            <Route path="/security" element={<SecurityPage />} />
            <Route path="/communication" element={<CommunicationPage />} />
            <Route path="/ghost" element={<GhostVaultPage />} />
            <Route path="/demo/186" element={<FullBuild186CommunicationDemo />} />
            <Route path="/demo/185" element={<FullBuild185IntegrationDemo />} />
            <Route path="/demo/184" element={<FullBuild184ProDemo />} />
            <Route path="/demo/183" element={<FullBuild183MenuImageDemo />} />
            <Route path="/demo/190" element={<FullBuild190V1Demo />} />
          </Routes>
        </div>
        <BottomNav />
      </div>
    </BrowserRouter>
  )
}