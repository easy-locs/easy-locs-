create table if not exists orbit_devices (
  orbit_id text not null,
  device_id text not null,
  sign_public_jwk jsonb not null,
  kex_public_jwk jsonb not null,
  created_at timestamptz not null default now(),
  primary key (orbit_id, device_id)
);

create table if not exists orbit_prekeys (
  orbit_id text not null,
  key_id text primary key,
  public_jwk jsonb not null,
  signature_b64 text not null,
  used boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists secure_envelopes (
  id uuid primary key default gen_random_uuid(),
  conversation_id text not null,
  sender_orbit_id text not null,
  sender_device_id text not null,
  receiver_orbit_id text not null,
  ratchet_counter integer not null,
  ghost boolean not null default false,
  expires_at timestamptz null,
  aad text not null,
  iv jsonb not null,
  ciphertext text not null,
  signature_b64 text not null,
  created_at timestamptz not null default now()
);

create table if not exists wallet_transactions (
  reference text not null,
  crypto_id text primary key,
  sender_orbit_id text not null,
  receiver_orbit_id text not null,
  amount_minor bigint not null,
  currency text not null,
  status text not null default 'pending',
  chat_conversation_id text null,
  signed_payload_b64 text not null,
  created_at timestamptz not null default now()
);
