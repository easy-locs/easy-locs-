import React from "react";

export default function MerchantActionPanel() {
  const actions = ["Add Product", "Send Offer", "Manage Orders", "Boost Shop"];
  return (
    <div className="rounded-3xl border bg-card/80 p-4 shadow-lg">
      <div className="mb-3 text-sm font-semibold">Quick actions</div>
      <div className="grid grid-cols-2 gap-3">
        {actions.map((a) => (
          <button key={a} className="rounded-2xl border p-3 text-left text-sm font-medium transition-all active:scale-[0.98]">
            {a}
          </button>
        ))}
      </div>
    </div>
  );
}
