import React from "react";

export default function MerchantActionDock() {
  const actions = ["Add product", "Orders", "Send offer", "Analytics"];
  return (
    <section className="rounded-[26px] border border-white/10 bg-white/5 p-4 backdrop-blur-xl">
      <div className="mb-3 text-sm font-bold text-white">Quick actions</div>
      <div className="grid grid-cols-2 gap-3">
        {actions.map((a) => (
          <button key={a} className="rounded-2xl border border-white/10 bg-black/20 p-3 text-left text-sm font-medium text-white transition-all active:scale-[0.985]">
            {a}
          </button>
        ))}
      </div>
    </section>
  );
}
