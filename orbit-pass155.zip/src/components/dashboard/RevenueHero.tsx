import React from "react";

export default function RevenueHero() {
  return (
    <section className="relative overflow-hidden rounded-[28px] border border-white/10 bg-[#08111f] p-5 shadow-2xl">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(16,185,129,0.12),transparent_30%),radial-gradient(circle_at_bottom_right,rgba(34,211,238,0.10),transparent_28%)]" />
      <div className="relative flex items-start justify-between gap-4">
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-wide text-emerald-300/80">Business live</div>
          <div className="mt-2 text-3xl font-bold text-white">AED 48.2k</div>
          <div className="mt-1 text-sm text-white/55">Revenue this period</div>
        </div>
        <button className="rounded-2xl bg-white px-4 py-2 text-sm font-semibold text-slate-900">Boost shop</button>
      </div>
    </section>
  );
}
