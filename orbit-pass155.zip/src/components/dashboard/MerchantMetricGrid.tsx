import React from "react";

const cards = [
  ["Orders", "284"],
  ["Pending", "19"],
  ["Customers", "91"],
  ["CTR", "4.8%"],
];

export default function MerchantMetricGrid() {
  return (
    <div className="grid grid-cols-2 gap-3">
      {cards.map(([label, value]) => (
        <div key={label} className="rounded-2xl border border-white/10 bg-white/5 p-4 shadow-lg backdrop-blur-xl">
          <div className="text-xs text-white/55">{label}</div>
          <div className="mt-2 text-2xl font-bold text-white">{value}</div>
        </div>
      ))}
    </div>
  );
}
