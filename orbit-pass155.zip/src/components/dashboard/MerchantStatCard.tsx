import React from "react";

export default function MerchantStatCard({
  label = "Revenue",
  value = "0",
  accent = "text-primary"
}: { label?: string; value?: string; accent?: string }) {
  return (
    <div className="rounded-2xl border bg-card/80 p-4 shadow-sm backdrop-blur transition-all active:scale-[0.98]">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className={`mt-2 text-2xl font-bold ${accent}`}>{value}</div>
    </div>
  );
}
