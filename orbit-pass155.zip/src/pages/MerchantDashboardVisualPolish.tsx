import React from "react";
import MerchantStatCard from "@/components/dashboard/MerchantStatCard";
import MerchantActionPanel from "@/components/dashboard/MerchantActionPanel";

export default function MerchantDashboardVisualPolish() {
  return (
    <main className="mx-auto max-w-3xl space-y-4 p-4">
      <section className="grid grid-cols-3 gap-3">
        <MerchantStatCard label="Revenue" value="12.4k" />
        <MerchantStatCard label="Orders" value="284" />
        <MerchantStatCard label="Customers" value="91" />
      </section>
      <MerchantActionPanel />
    </main>
  );
}
