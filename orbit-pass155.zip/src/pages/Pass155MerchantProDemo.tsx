import React from "react";
import RevenueHero from "@/components/dashboard/RevenueHero";
import MerchantMetricGrid from "@/components/dashboard/MerchantMetricGrid";
import MerchantActionDock from "@/components/dashboard/MerchantActionDock";

export default function Pass155MerchantProDemo() {
  return (
    <main className="min-h-screen bg-[#030712] p-4">
      <div className="mx-auto max-w-3xl space-y-4">
        <RevenueHero />
        <MerchantMetricGrid />
        <MerchantActionDock />
      </div>
    </main>
  );
}
