import { supabase } from "@/integrations/supabase/client";
import { platformBus } from "@/lib/shared/platform-bus";

export interface RequestGatewayOptions extends RequestInit {
  timeoutMs?: number;
  retries?: number;
  query?: Record<string, string | number | boolean | undefined | null>;
  emitType?: string;
}

function buildUrl(base: string, query?: RequestGatewayOptions["query"]) {
  if (!query) return base;
  const url = new URL(base);
  Object.entries(query).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      url.searchParams.set(key, String(value));
    }
  });
  return url.toString();
}

export async function requestJson<T = unknown>(url: string, options: RequestGatewayOptions = {}): Promise<T> {
  const { timeoutMs = 12000, retries = 1, query, emitType, headers, ...rest } = options;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const session = (await supabase.auth.getSession()).data.session;
    const response = await fetch(buildUrl(url, query), {
      ...rest,
      headers: {
        ...(rest.body !== undefined ? { "Content-Type": "application/json" } : {}),
        ...(session?.access_token ? { Authorization: `Bearer ${session.access_token}` } : {}),
        ...(import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ? { apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY } : {}),
        ...(headers || {}),
      },
      signal: controller.signal,
    });

    if (!response.ok) {
      const text = await response.text().catch(() => "");
      throw new Error(text || `HTTP ${response.status}`);
    }

    const isJson = response.headers.get("content-type")?.includes("application/json");
    const data = (isJson ? await response.json().catch(() => ({})) : await response.text().catch(() => "")) as T;
    if (emitType) {
      platformBus.emit("system:sync_completed", { type: emitType, ok: true }, "system", {
        userId: session?.user?.id,
      });
    }
    return data;
  } catch (error) {
    if (retries > 0) {
      return requestJson<T>(url, { ...options, retries: retries - 1, timeoutMs: Math.round(timeoutMs * 1.25) });
    }
    if (emitType) {
      platformBus.emit("system:sync_completed", { type: emitType, ok: false, error: error instanceof Error ? error.message : String(error) }, "system", {
        userId: session?.user?.id,
      });
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

export async function invokeEdge<T = unknown>(fnName: string, body?: unknown, method: "GET" | "POST" = "POST"): Promise<T> {
  const base = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/${fnName}`;
  return requestJson<T>(base, {
    method,
    body: method === "POST" ? JSON.stringify(body ?? {}) : undefined,
    emitType: `edge:${fnName}:${method.toLowerCase()}`,
  });
}

export function bridgeAsync<T>(promise: Promise<T>, type: string) {
  return promise
    .then((data) => {
      platformBus.emit("system:sync_completed", { type, ok: true }, "system");
      return data;
    })
    .catch((error) => {
      console.error(`[orbit-connection] ${type} failed`, error);
      throw error;
    });
}
