import React from "react";
import HomeHeroPremium from "@/components/home/HomeHeroPremium";
import HomeQuickActionsPremium from "@/components/home/HomeQuickActionsPremium";

export default function HomeVisualPolish() {
  return (
    <main className="mx-auto max-w-2xl space-y-4 p-4">
      <HomeHeroPremium />
      <HomeQuickActionsPremium />
    </main>
  );
}
