import React from "react";
import PremiumHomeHero from "@/components/home/PremiumHomeHero";
import HomeRailPremium from "@/components/home/HomeRailPremium";

export default function Pass154HomeWowDemo() {
  return (
    <main className="min-h-screen bg-[#030712] p-4 space-y-4">
      <div className="mx-auto max-w-3xl space-y-4">
        <PremiumHomeHero />
        <HomeRailPremium />
        <HomeRailPremium title="Fast delivery now" />
      </div>
    </main>
  );
}
