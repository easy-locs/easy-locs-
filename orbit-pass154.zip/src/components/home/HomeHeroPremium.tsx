import React from "react";

export default function HomeHeroPremium() {
  return (
    <section className="rounded-3xl border bg-gradient-to-br from-card to-card/70 p-5 shadow-lg backdrop-blur">
      <div className="text-xs uppercase tracking-wide text-muted-foreground">Orbit</div>
      <h1 className="mt-2 text-2xl font-bold">Smart home, ultra fast actions</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Cleaner hierarchy, stronger CTA visibility, smoother mobile-first layout.
      </p>
      <div className="mt-4 flex gap-2">
        <button className="rounded-2xl bg-primary px-4 py-2 text-sm font-semibold text-white">Explore</button>
        <button className="rounded-2xl border px-4 py-2 text-sm font-semibold">Track</button>
      </div>
    </section>
  );
}
