import React from "react";

export default function HomeRailPremium({ title = "Trending near you" }: { title?: string }) {
  return (
    <section className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold text-white">{title}</h2>
        <button className="text-xs font-medium text-cyan-300">See all</button>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {[1,2,3,4].map((i) => (
          <button key={i} className="rounded-[22px] border border-white/10 bg-white/5 p-3 text-left shadow-lg backdrop-blur-xl transition-all active:scale-[0.985]">
            <div className="h-24 rounded-2xl bg-gradient-to-br from-cyan-400/15 to-violet-400/15" />
            <div className="mt-3 text-sm font-semibold text-white">Featured card {i}</div>
            <div className="mt-1 text-xs text-white/55">12 min · Premium layout</div>
          </button>
        ))}
      </div>
    </section>
  );
}
