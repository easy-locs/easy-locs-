import React from "react";

export default function PremiumHomeHero() {
  return (
    <section className="relative overflow-hidden rounded-[28px] border border-white/10 bg-[#07111f] p-5 shadow-2xl">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(34,211,238,0.12),transparent_34%),radial-gradient(circle_at_bottom_right,rgba(139,92,246,0.12),transparent_28%)]" />
      <div className="relative">
        <div className="inline-flex rounded-full border border-red-500/20 bg-red-500/10 px-3 py-1 text-[10px] font-semibold uppercase tracking-wide text-red-400">
          Live city layer
        </div>
        <h1 className="mt-3 text-3xl font-bold tracking-tight text-white">Everything around you, in one smart shell</h1>
        <p className="mt-2 max-w-xl text-sm text-white/65">
          Faster discovery, stronger CTA hierarchy, smoother premium home experience.
        </p>
        <div className="mt-4 flex gap-2">
          <button className="rounded-2xl bg-white px-4 py-2 text-sm font-semibold text-slate-900">Explore</button>
          <button className="rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-semibold text-white">Track</button>
        </div>
      </div>
    </section>
  );
}
