import React from "react";

export default function HomeQuickActionsPremium() {
  const items = ["Reorder", "Orders", "Nearby", "Deals"];
  return (
    <div className="grid grid-cols-2 gap-3">
      {items.map((label) => (
        <button
          key={label}
          className="rounded-2xl border bg-card/80 p-4 text-left shadow-sm transition-all active:scale-[0.98]"
        >
          <div className="text-sm font-semibold">{label}</div>
          <div className="mt-1 text-xs text-muted-foreground">Fast action</div>
        </button>
      ))}
    </div>
  );
}
