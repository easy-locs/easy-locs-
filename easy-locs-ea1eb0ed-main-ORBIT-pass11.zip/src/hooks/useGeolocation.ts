/**
 * useGeolocation — Reactive browser geolocation hook.
 * Auto-requests location on mount based on app preferences.
 * Keeps a light local cache so onboarding / radar can start with something usable.
 */
import { useState, useEffect, useCallback } from "react";
import { getAppPreferences } from "@/components/settings/AppPreferencesSection";

interface GeoState {
  lat: number | null;
  lng: number | null;
  loading: boolean;
  error: string | null;
  city: string | null;
}

interface CachedGeo {
  lat?: number;
  lng?: number;
  city?: string | null;
  at?: number;
}

const GEO_CACHE_KEY = "orbit:last-geo";
const GEO_CACHE_TTL_MS = 1000 * 60 * 30; // 30 minutes

function readCachedGeo(): Pick<GeoState, "lat" | "lng" | "city"> {
  try {
    const raw = localStorage.getItem(GEO_CACHE_KEY);
    if (!raw) return { lat: null, lng: null, city: null };
    const parsed = JSON.parse(raw) as CachedGeo;
    if (parsed.at && Date.now() - parsed.at > GEO_CACHE_TTL_MS) {
      localStorage.removeItem(GEO_CACHE_KEY);
      return { lat: null, lng: null, city: null };
    }
    return {
      lat: typeof parsed.lat === "number" ? parsed.lat : null,
      lng: typeof parsed.lng === "number" ? parsed.lng : null,
      city: typeof parsed.city === "string" ? parsed.city : null,
    };
  } catch {
    return { lat: null, lng: null, city: null };
  }
}

function cacheGeo(lat: number, lng: number, city?: string | null) {
  try {
    localStorage.setItem(GEO_CACHE_KEY, JSON.stringify({ lat, lng, city: city || null, at: Date.now() }));
  } catch {
    // no-op
  }
}

async function reverseDetectCity(lat: number, lng: number): Promise<string | null> {
  try {
    const res = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}`,
      {
        headers: { "Accept-Language": navigator.language || "en" },
        signal: AbortSignal.timeout(5000),
      }
    );
    if (!res.ok) return null;
    const data = (await res.json()) as { address?: Record<string, string> };
    return data.address?.city || data.address?.town || data.address?.village || data.address?.county || null;
  } catch {
    return null;
  }
}

export function useGeolocation() {
  const cached = readCachedGeo();

  const [state, setState] = useState<GeoState>({
    lat: cached.lat,
    lng: cached.lng,
    loading: false,
    error: null,
    city: cached.city,
  });

  const requestLocation = useCallback(() => {
    if (!("geolocation" in navigator)) {
      setState((s) => ({ ...s, error: "Geolocation not supported" }));
      return;
    }

    setState((s) => ({ ...s, loading: true, error: null }));

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const nextLat = pos.coords.latitude;
        const nextLng = pos.coords.longitude;
        const nextCity = await reverseDetectCity(nextLat, nextLng);
        cacheGeo(nextLat, nextLng, nextCity);
        setState({
          lat: nextLat,
          lng: nextLng,
          loading: false,
          error: null,
          city: nextCity,
        });
      },
      (err) => {
        const fallback = readCachedGeo();
        const denied = err.code === 1;

        setState((s) => ({
          ...s,
          lat: fallback.lat ?? s.lat,
          lng: fallback.lng ?? s.lng,
          city: fallback.city ?? s.city,
          loading: false,
          error: denied ? "Location permission denied" : "Could not get location",
        }));
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 }
    );
  }, []);

  useEffect(() => {
    const prefs = getAppPreferences();
    if (!prefs.autoLocation) return;

    if (!("permissions" in navigator)) {
      requestLocation();
      return;
    }

    let permRef: PermissionStatus | null = null;

    navigator.permissions
      .query({ name: "geolocation" as PermissionName })
      .then((perm) => {
        permRef = perm;

        if (perm.state !== "denied") {
          requestLocation();
        } else {
          const fallback = readCachedGeo();
          setState((s) => ({
            ...s,
            lat: fallback.lat ?? s.lat,
            lng: fallback.lng ?? s.lng,
            city: fallback.city ?? s.city,
            error: "Location permission denied",
            loading: false,
          }));
        }

        perm.onchange = () => {
          if (perm.state === "granted") requestLocation();
        };
      })
      .catch(() => requestLocation());

    return () => {
      if (permRef) permRef.onchange = null;
    };
  }, [requestLocation]);

  return { ...state, requestLocation };
}
