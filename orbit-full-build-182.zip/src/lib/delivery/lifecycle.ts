export type DeliveryMissionStatus =
  | "created"
  | "bidding"
  | "driver_selected"
  | "escrow_locked"
  | "picked_up"
  | "in_transit"
  | "proof_submitted"
  | "released"
  | "cancelled";

export type DeliveryProof = {
  photoTaken: boolean;
  photoUrl?: string;
  signatureCaptured: boolean;
  signatureData?: string;
  qrScanned: boolean;
  qrCode?: string;
  geoLat: number | null;
  geoLng: number | null;
  geoAccuracy: number | null;
  recipientName?: string;
  notes?: string;
  deliveredAt?: string;
};

export function canReleaseEscrow(proof: DeliveryProof) {
  return !!(
    proof.photoTaken &&
    proof.signatureCaptured &&
    proof.geoLat !== null &&
    proof.deliveredAt
  );
}
