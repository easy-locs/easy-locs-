import React from "react";
import HeatZones from "@/components/radar/HeatZones";
import DriverPulseLayer from "@/components/radar/DriverPulseLayer";
import OrbitCard from "@/components/ui/OrbitCard";
import type { RadarDriver, RadarOrder } from "@/types/radar";
import { buildHeatmapPoints } from "@/lib/radar/heatmap";

export default function DeliveryRadarMap({ drivers, orders }: { drivers: RadarDriver[]; orders: RadarOrder[] }) {
  const heat = buildHeatmapPoints(orders);

  return (
    <div className="space-y-4">
      <OrbitCard className="relative overflow-hidden p-5 md:p-6">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(34,211,238,0.12),transparent_35%),radial-gradient(circle_at_top_right,rgba(139,92,246,0.16),transparent_30%)]" />
        <div className="relative">
          <div className="text-[11px] uppercase tracking-[0.22em] text-cyan-300/80">Delivery radar</div>
          <div className="mt-2 text-2xl font-bold text-white">Snap-map feel, premium mission visibility</div>
          <div className="mt-2 text-sm text-white/60">Canvas-style rendering is recommended in the main repo. This scaffold exposes the data, layering and premium UI structure.</div>
          <div className="mt-4 grid gap-3 md:grid-cols-3">
            <div className="rounded-3xl border border-white/10 bg-white/5 p-4 text-center">
              <div className="text-[10px] uppercase tracking-[0.18em] text-white/45">Drivers</div>
              <div className="mt-1 text-2xl font-bold text-cyan-300">{drivers.length}</div>
            </div>
            <div className="rounded-3xl border border-white/10 bg-white/5 p-4 text-center">
              <div className="text-[10px] uppercase tracking-[0.18em] text-white/45">Orders</div>
              <div className="mt-1 text-2xl font-bold text-fuchsia-300">{orders.length}</div>
            </div>
            <div className="rounded-3xl border border-white/10 bg-white/5 p-4 text-center">
              <div className="text-[10px] uppercase tracking-[0.18em] text-white/45">Hot zones</div>
              <div className="mt-1 text-2xl font-bold text-emerald-300">{heat.length}</div>
            </div>
          </div>
        </div>
      </OrbitCard>
      <div className="grid gap-4 lg:grid-cols-[1.3fr,1fr]">
        <HeatZones points={heat} />
        <DriverPulseLayer drivers={drivers} />
      </div>
    </div>
  );
}
