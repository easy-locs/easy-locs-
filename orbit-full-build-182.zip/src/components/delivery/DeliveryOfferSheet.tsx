import React from "react";
import OrbitCard from "@/components/ui/OrbitCard";
import type { DeliveryOffer } from "@/lib/delivery/pricing";
import { computeDeliveryPrice } from "@/lib/delivery/pricing";

export default function DeliveryOfferSheet({ offers }: { offers: DeliveryOffer[] }) {
  return (
    <OrbitCard className="p-4">
      <div className="text-sm font-semibold text-white">Delivery offers</div>
      <div className="mt-3 space-y-2">
        {offers.map((offer) => {
          const price = computeDeliveryPrice({
            distanceKm: 8,
            packageClass: "medium",
            offer,
          });

          return (
            <div key={offer.id} className="rounded-2xl border border-white/10 bg-white/5 p-3">
              <div className="flex items-center justify-between">
                <div className="text-sm font-semibold text-white">Driver {offer.driverId}</div>
                <div className="text-xs text-fuchsia-300">{offer.mode}</div>
              </div>
              <div className="mt-1 text-xs text-white/60">ETA {offer.etaMin ?? 0} min</div>
              <div className="mt-2 text-lg font-bold text-white">AED {price}</div>
            </div>
          );
        })}
      </div>
    </OrbitCard>
  );
}
