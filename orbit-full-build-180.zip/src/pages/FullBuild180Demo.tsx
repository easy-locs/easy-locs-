import React from "react";
import GrowthHero from "@/components/growth/GrowthHero";
import ReferralCards from "@/components/growth/ReferralCards";

export default function FullBuild180Demo() {
  return (
    <main className="min-h-screen bg-[#030712] p-4">
      <div className="mx-auto max-w-3xl space-y-4">
        <GrowthHero />
        <ReferralCards />
      </div>
    </main>
  );
}
