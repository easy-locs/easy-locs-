import React from "react";

export default function GrowthHero() {
  return (
    <section className="rounded-[28px] border border-fuchsia-400/15 bg-[#07111f] p-5 shadow-2xl">
      <div className="text-[11px] font-semibold uppercase tracking-wide text-fuchsia-300/80">Growth live</div>
      <div className="mt-2 text-2xl font-bold text-white">Referrals, invites and viral loops</div>
      <div className="mt-1 text-sm text-white/55">Premium growth layer to turn users into repeat customers and promoters.</div>
      <button className="mt-4 rounded-2xl bg-white px-4 py-2 text-sm font-semibold text-slate-900">Invite now</button>
    </section>
  );
}
