import { useCallback, useEffect, useMemo, useState } from "react";
import { useLocation } from "react-router-dom";
import { AlertTriangle, Bug, ChevronDown, ChevronUp, History, RefreshCw, XCircle } from "lucide-react";
import { summarizeAudit, type A11yIssue } from "@/lib/a11y-audit";
import { A11Y_AUDIT_EVENT, readA11yHistory, runA11yAudit, type A11yAuditSnapshot } from "@/lib/a11y-dev";

const STORAGE_KEY = "orbit:a11y-panel-open";

function groupByRule(issues: A11yIssue[]) {
  return issues.reduce<Record<string, A11yIssue[]>>((acc, issue) => {
    if (!acc[issue.rule]) acc[issue.rule] = [];
    acc[issue.rule].push(issue);
    return acc;
  }, {});
}

export default function DevA11yPanel() {
  const location = useLocation();
  const [open, setOpen] = useState(() => {
    if (typeof window === "undefined") return false;
    return window.localStorage.getItem(STORAGE_KEY) === "1";
  });
  const [issues, setIssues] = useState<A11yIssue[]>([]);
  const [auditedAt, setAuditedAt] = useState<string>("");
  const [history, setHistory] = useState<A11yAuditSnapshot[]>(() => (typeof window === "undefined" ? [] : readA11yHistory()));

  const applySnapshot = useCallback((snapshot: A11yAuditSnapshot) => {
    setIssues(snapshot.issues);
    setAuditedAt(new Date(snapshot.auditedAt).toLocaleTimeString());
    setHistory(readA11yHistory());
  }, []);

  const runAudit = useCallback(() => {
    if (typeof window === "undefined") return;
    const snapshot = runA11yAudit(location.pathname, { logToConsole: true, persist: true });
    applySnapshot(snapshot);
  }, [applySnapshot, location.pathname]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(STORAGE_KEY, open ? "1" : "0");
  }, [open]);

  useEffect(() => {
    const onAudit = (event: Event) => {
      const detail = (event as CustomEvent<A11yAuditSnapshot>).detail;
      if (!detail || detail.pathname !== location.pathname) return;
      applySnapshot(detail);
    };

    window.addEventListener(A11Y_AUDIT_EVENT, onAudit as EventListener);
    const latest = readA11yHistory().find((item) => item.pathname === location.pathname);
    if (latest) applySnapshot(latest);

    return () => window.removeEventListener(A11Y_AUDIT_EVENT, onAudit as EventListener);
  }, [applySnapshot, location.pathname]);

  const summary = useMemo(() => summarizeAudit(issues), [issues]);
  const grouped = useMemo(() => groupByRule(issues), [issues]);

  if (!import.meta.env.DEV) return null;

  return (
    <aside
      aria-label="Accessibility audit panel"
      className="fixed bottom-4 right-4 z-[9999] w-[min(92vw,420px)] rounded-2xl border bg-background/95 shadow-2xl backdrop-blur"
    >
      <div className="flex items-center gap-3 border-b px-4 py-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-muted">
          <Bug className="h-4 w-4" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold">A11y audit</div>
          <div className="text-xs text-muted-foreground">{location.pathname} • {auditedAt || "pending"}</div>
        </div>
        <button
          type="button"
          onClick={runAudit}
          className="inline-flex h-9 w-9 items-center justify-center rounded-md border hover:bg-muted"
          aria-label="Run accessibility audit again"
        >
          <RefreshCw className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={() => setOpen((prev) => !prev)}
          className="inline-flex h-9 w-9 items-center justify-center rounded-md border hover:bg-muted"
          aria-expanded={open}
          aria-controls="dev-a11y-panel-content"
          aria-label={open ? "Collapse accessibility audit panel" : "Expand accessibility audit panel"}
        >
          {open ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
        </button>
      </div>

      <div className="grid grid-cols-4 gap-2 px-4 py-3 text-center text-xs">
        <div className="rounded-lg border p-2">
          <div className="text-[11px] uppercase text-muted-foreground">Score</div>
          <div className="text-lg font-bold">{summary.score}</div>
        </div>
        <div className="rounded-lg border p-2">
          <div className="text-[11px] uppercase text-muted-foreground">Errors</div>
          <div className="text-lg font-bold">{summary.errors}</div>
        </div>
        <div className="rounded-lg border p-2">
          <div className="text-[11px] uppercase text-muted-foreground">Warnings</div>
          <div className="text-lg font-bold">{summary.warnings}</div>
        </div>
        <div className="rounded-lg border p-2">
          <div className="text-[11px] uppercase text-muted-foreground">Info</div>
          <div className="text-lg font-bold">{summary.info}</div>
        </div>
      </div>

      {open && (
        <div id="dev-a11y-panel-content" className="max-h-[50vh] space-y-3 overflow-auto border-t px-4 py-3">
          <section className="rounded-xl border p-3">
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold">
              <History className="h-4 w-4" /> Recent routes
            </div>
            {history.length === 0 ? (
              <div className="text-xs text-muted-foreground">No audit history yet.</div>
            ) : (
              <div className="space-y-2">
                {history.slice(0, 5).map((entry) => (
                  <div key={`${entry.pathname}-${entry.auditedAt}`} className="flex items-center justify-between gap-3 rounded-lg border bg-muted/20 px-2 py-1.5 text-xs">
                    <div className="min-w-0">
                      <div className="truncate font-medium">{entry.pathname}</div>
                      <div className="text-muted-foreground">{new Date(entry.auditedAt).toLocaleTimeString()}</div>
                    </div>
                    <div className="shrink-0 rounded-md border px-2 py-1 font-semibold">{entry.summary.score}</div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {issues.length === 0 ? (
            <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 text-sm">
              No accessibility issues detected by the quick audit.
            </div>
          ) : (
            Object.entries(grouped).map(([rule, ruleIssues]) => (
              <section key={rule} className="rounded-xl border p-3">
                <div className="mb-2 flex items-center justify-between gap-2">
                  <div className="text-sm font-semibold">{rule}</div>
                  <div className="text-xs text-muted-foreground">{ruleIssues.length} issue(s)</div>
                </div>
                <div className="space-y-2">
                  {ruleIssues.slice(0, 6).map((issue, index) => (
                    <div key={`${rule}-${index}`} className="rounded-lg border bg-muted/30 p-2 text-xs">
                      <div className="mb-1 flex items-center gap-2 font-medium">
                        {issue.severity === "error" ? (
                          <XCircle className="h-3.5 w-3.5 shrink-0" />
                        ) : (
                          <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                        )}
                        <span>{issue.message}</span>
                      </div>
                      <div className="font-mono text-[11px] text-muted-foreground">{issue.element}</div>
                    </div>
                  ))}
                  {ruleIssues.length > 6 && (
                    <div className="text-xs text-muted-foreground">
                      +{ruleIssues.length - 6} more issue(s) not shown
                    </div>
                  )}
                </div>
              </section>
            ))
          )}
        </div>
      )}
    </aside>
  );
}
