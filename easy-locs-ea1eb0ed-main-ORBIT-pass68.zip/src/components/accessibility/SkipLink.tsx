export default function SkipLink() {
  return (
    <a href="#main-content" className="skip-link sr-only focus:not-sr-only">
      Skip to main content
    </a>
  );
}
