import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { scheduleA11yAudit } from "@/lib/a11y-dev";

export default function A11yRouteAudit() {
  const location = useLocation();

  useEffect(() => {
    if (!import.meta.env.DEV) return;
    return scheduleA11yAudit(location.pathname, {
      delayMs: 220,
      logToConsole: true,
      persist: true,
    });
  }, [location.pathname]);

  return null;
}
