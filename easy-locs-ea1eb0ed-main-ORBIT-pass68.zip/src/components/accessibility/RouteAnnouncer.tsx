import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";

function prettifyPathname(pathname: string): string {
  if (pathname === "/") return "Home";
  return pathname
    .split("/")
    .filter(Boolean)
    .map((segment) => segment.replace(/[-_]/g, " "))
    .map((segment) => segment.charAt(0).toUpperCase() + segment.slice(1))
    .join(" — ");
}

export default function RouteAnnouncer() {
  const location = useLocation();
  const [announcement, setAnnouncement] = useState("");

  useEffect(() => {
    const pageLabel = document.title?.trim() || prettifyPathname(location.pathname);
    const id = window.setTimeout(() => {
      setAnnouncement(`Navigated to ${pageLabel}`);
    }, 50);

    return () => window.clearTimeout(id);
  }, [location.pathname]);

  return (
    <div aria-live="polite" aria-atomic="true" className="sr-only" role="status">
      {announcement}
    </div>
  );
}
