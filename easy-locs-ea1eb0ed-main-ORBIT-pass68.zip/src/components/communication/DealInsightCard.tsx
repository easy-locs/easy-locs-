import { TrendingUp, Sparkles, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useDealInsight } from "@/hooks/useDealInsight";

type DealLike = {
  id: string;
  status?: string | null;
  current_offer_currency?: string | null;
  current_offer_amount?: number | null;
  counter_offer_amount?: number | null;
  accepted_amount?: number | null;
  negotiation_round?: number | null;
  offer_expires_at?: string | null;
};

type DealEventLike = {
  id?: string;
  event_type?: string;
  data_json?: any;
  created_at?: string;
};

interface DealInsightCardProps {
  deal: DealLike;
  events: DealEventLike[];
  onUseSuggestedPrice?: (amount: number) => void;
}

function fmtAmount(value: number | null | undefined, currency?: string | null) {
  if (value == null) return "—";
  try {
    return new Intl.NumberFormat(undefined, {
      style: "currency",
      currency: currency || "EUR",
      maximumFractionDigits: 0,
    }).format(value);
  } catch {
    return `${value} ${currency || "EUR"}`;
  }
}

export default function DealInsightCard({ deal, events, onUseSuggestedPrice }: DealInsightCardProps) {
  const { insight, isLoading } = useDealInsight(deal, events);

  if (!deal?.id || ["completed", "cancelled"].includes(String(deal.status || ""))) return null;

  return (
    <div className="mx-3 my-2 rounded-xl border border-accent/20 bg-accent/5 p-3 space-y-3 overflow-hidden">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-accent" />
            <p className="text-xs font-semibold text-foreground">Smart Deal Insight</p>
          </div>
          <p className="mt-1 text-[11px] text-muted-foreground leading-relaxed break-words">
            {insight?.explanation || "Smart negotiation guidance is being prepared for this deal."}
          </p>
        </div>
        <Badge variant="outline" className="text-[10px] shrink-0 gap-1 border-accent/30 text-accent">
          <ShieldCheck className="h-3 w-3" /> v1
        </Badge>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        <div className="rounded-lg bg-background/70 border border-border/40 p-2.5">
          <p className="text-[10px] text-muted-foreground">Suggested compromise</p>
          <p className="text-sm font-semibold text-foreground mt-1 break-words">
            {isLoading ? "Computing…" : fmtAmount(insight?.suggested_price, deal.current_offer_currency)}
          </p>
        </div>
        <div className="rounded-lg bg-background/70 border border-border/40 p-2.5">
          <p className="text-[10px] text-muted-foreground">Suggested range</p>
          <p className="text-sm font-semibold text-foreground mt-1 break-words">
            {isLoading
              ? "Computing…"
              : `${fmtAmount(insight?.suggested_min, deal.current_offer_currency)} — ${fmtAmount(insight?.suggested_max, deal.current_offer_currency)}`}
          </p>
        </div>
        <div className="rounded-lg bg-background/70 border border-border/40 p-2.5">
          <p className="text-[10px] text-muted-foreground">Deal probability</p>
          <div className="mt-1 flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-emerald-500" />
            <p className="text-sm font-semibold text-foreground">{isLoading ? "…" : `${insight?.probability_score ?? 50}%`}</p>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Button
          type="button"
          size="sm"
          className="h-11 px-4 rounded-lg text-xs"
          disabled={!insight?.suggested_price || !onUseSuggestedPrice}
          onClick={() => {
            if (insight?.suggested_price != null) onUseSuggestedPrice?.(insight.suggested_price);
          }}
        >
          Use suggested price
        </Button>
        <Badge variant="secondary" className="text-[10px]">Scoped insight</Badge>
      </div>
    </div>
  );
}
