/**
 * ThreadActionsMenu — Conversation-level actions (archive, mute, block, report).
 */
import { useState } from "react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  MoreVertical, Archive, BellOff, Bell, Ban, Flag,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n";
import { platformBus } from "@/lib/shared/platform-bus";

interface Props {
  userId: string;
  contextId: string;
  /** The other user's sender_id (for block/report) */
  otherUserId?: string;
  isMuted: boolean;
  isArchived: boolean;
  onPrefsChanged: (muted: boolean, archived: boolean) => void;
}

export default function ThreadActionsMenu({
  userId, contextId, otherUserId, isMuted, isArchived, onPrefsChanged,
}: Props) {
  const { t } = useI18n();
  const [reportOpen, setReportOpen] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const [busyAction, setBusyAction] = useState<null | "mute" | "archive" | "block" | "report">(null);

  const upsertPref = async (muted: boolean, archived: boolean) => {
    const { error } = await supabase.from("conversation_preferences").upsert({
      user_id: userId,
      context_id: contextId,
      muted,
      archived,
      updated_at: new Date().toISOString(),
    } as any, { onConflict: "user_id,context_id" });
    if (error) throw error;
    onPrefsChanged(muted, archived);
    platformBus.emit("orbit:notification_created", { action: archived ? "archive" : "preference_update", contextId }, "orbit", { userId });
  };

  const handleMuteToggle = async () => {
    if (busyAction) return;
    const newMuted = !isMuted;
    setBusyAction("mute");
    try {
      await upsertPref(newMuted, isArchived);
      toast.success(newMuted ? (t("orbit.muted") || "Conversation muted") : (t("orbit.unmuted") || "Conversation unmuted"));
    } catch (error: any) {
      toast.error(error?.message || (t("common.error") || "Error"));
    } finally {
      setBusyAction(null);
    }
  };

  const handleArchiveToggle = async () => {
    if (busyAction) return;
    const newArchived = !isArchived;
    setBusyAction("archive");
    try {
      await upsertPref(isMuted, newArchived);
      toast.success(newArchived ? (t("orbit.archived") || "Conversation archived") : (t("orbit.unarchived") || "Conversation unarchived"));
    } catch (error: any) {
      toast.error(error?.message || (t("common.error") || "Error"));
    } finally {
      setBusyAction(null);
    }
  };

  const handleBlock = async () => {
    if (!otherUserId || busyAction) return;
    setBusyAction("block");
    const { error } = await supabase.from("blocked_users").upsert({
      blocker_id: userId,
      blocked_id: otherUserId,
    } as any, { onConflict: "blocker_id,blocked_id" });
    setBusyAction(null);
    if (error) {
      toast.error(error.message || (t("common.error") || "Error"));
      return;
    }
    platformBus.emit("orbit:notification_created", { action: "block", contextId }, "orbit", { userId });
    toast.success(t("orbit.user_blocked") || "User blocked");
  };

  const handleReport = async () => {
    if (!otherUserId || !reportReason.trim() || busyAction) return;
    setBusyAction("report");
    const { error } = await supabase.from("user_reports").insert({
      reporter_id: userId,
      reported_user_id: otherUserId,
      reason: reportReason.trim(),
      context_id: contextId,
    } as any);
    setBusyAction(null);
    if (error) {
      toast.error(error.message || (t("common.error") || "Error"));
      return;
    }
    setReportOpen(false);
    setReportReason("");
    platformBus.emit("orbit:notification_created", { action: "report", contextId }, "orbit", { userId });
    toast.success(t("orbit.report_submitted") || "Report submitted");
  };

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon" className="h-8 w-8" disabled={!!busyAction}>
            <MoreVertical className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuItem onClick={handleMuteToggle} className="gap-2 text-xs" disabled={!!busyAction}>
            {isMuted ? <Bell className="h-3.5 w-3.5" /> : <BellOff className="h-3.5 w-3.5" />}
            {isMuted ? (t("orbit.unmute") || "Unmute") : (t("orbit.mute") || "Mute conversation")}
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleArchiveToggle} className="gap-2 text-xs" disabled={!!busyAction}>
            <Archive className="h-3.5 w-3.5" />
            {isArchived ? (t("orbit.unarchive") || "Unarchive") : (t("orbit.archive") || "Archive")}
          </DropdownMenuItem>
          {otherUserId && (
            <>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleBlock} className="gap-2 text-xs text-destructive" disabled={!!busyAction}>
                <Ban className="h-3.5 w-3.5" /> {t("orbit.block_user") || "Block user"}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setReportOpen(true)} className="gap-2 text-xs text-destructive" disabled={!!busyAction}>
                <Flag className="h-3.5 w-3.5" /> {t("orbit.report_user") || "Report user"}
              </DropdownMenuItem>
            </>
          )}
        </DropdownMenuContent>
      </DropdownMenu>

      <Dialog open={reportOpen} onOpenChange={setReportOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-base">{t("orbit.report_user") || "Report User"}</DialogTitle>
          </DialogHeader>
          <textarea
            value={reportReason}
            onChange={(e) => setReportReason(e.target.value)}
            placeholder={t("orbit.describe_issue") || "Describe the issue..."}
            className="w-full bg-muted/50 border border-border rounded-lg px-3 py-2 text-sm min-h-[80px] focus:outline-none focus:ring-2 focus:ring-ring"
          />
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setReportOpen(false)} disabled={busyAction === "report"}>{t("common.cancel") || "Cancel"}</Button>
            <Button size="sm" onClick={handleReport} disabled={busyAction === "report" || !reportReason.trim()}>
              {busyAction === "report" ? (t("common.sending") || "Sending...") : (t("orbit.submit_report") || "Submit Report")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
