/**
 * OrbitQRScanner — real camera QR scanner for wallet payments.
 * Uses BarcodeDetector when available, jsQR fallback otherwise.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { Camera, CameraOff, QrCode, RotateCcw, Check, Image as ImageIcon, ScanLine } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { decodeQRPayload } from "@/lib/orbit-payments/qr-security";
import type { QRPayload } from "@/lib/orbit-payments/types";

interface OrbitQRScannerProps {
  onDetected: (payload: QRPayload) => void;
}

function hasBarcodeDetector(): boolean {
  return typeof window !== "undefined" && "BarcodeDetector" in window;
}

export default function OrbitQRScanner({ onDetected }: OrbitQRScannerProps) {
  const [active, setActive] = useState(false);
  const [cameraReady, setCameraReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [facing, setFacing] = useState<"environment" | "user">("environment");
  const [lastSnapshot, setLastSnapshot] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scanIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const stopCamera = useCallback(() => {
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current);
      scanIntervalRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setActive(false);
    setCameraReady(false);
  }, []);

  const parseRaw = useCallback((raw: string): QRPayload | null => {
    const trimmed = raw.trim();
    if (!trimmed) return null;
    if (/^https?:\/\//i.test(trimmed)) {
      try {
        const url = new URL(trimmed);
        const qrParam = url.searchParams.get("qr");
        if (qrParam) return decodeQRPayload(qrParam);
      } catch {}
    }
    return decodeQRPayload(trimmed);
  }, []);

  const handleFound = useCallback((raw: string) => {
    const payload = parseRaw(raw);
    if (!payload) return;
    toast.success("QR payment detected");
    stopCamera();
    onDetected(payload);
  }, [parseRaw, stopCamera, onDetected]);

  const startCamera = useCallback(async () => {
    stopCamera();
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: facing }, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      streamRef.current = stream;
      setActive(true);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setCameraReady(true);

      if (hasBarcodeDetector()) {
        const detector = new (window as any).BarcodeDetector({ formats: ["qr_code"] });
        scanIntervalRef.current = setInterval(async () => {
          const video = videoRef.current;
          if (!video || video.readyState < 2) return;
          try {
            const codes = await detector.detect(video);
            if (codes?.length && codes[0].rawValue) handleFound(codes[0].rawValue);
          } catch {}
        }, 250);
      } else {
        const jsQRModule = await import("jsqr");
        const jsQR = jsQRModule.default;
        scanIntervalRef.current = setInterval(() => {
          const video = videoRef.current;
          const canvas = canvasRef.current;
          if (!video || !canvas || video.readyState < 2) return;
          const ctx = canvas.getContext("2d", { willReadFrequently: true });
          if (!ctx) return;
          const w = video.videoWidth || 640;
          const h = video.videoHeight || 640;
          canvas.width = w;
          canvas.height = h;
          ctx.drawImage(video, 0, 0, w, h);
          const image = ctx.getImageData(0, 0, w, h);
          const result = jsQR(image.data, image.width, image.height, { inversionAttempts: "attemptBoth" });
          if (result?.data) handleFound(result.data);
        }, 220);
      }
    } catch (err: any) {
      console.error("[wallet-scan] camera failed", err);
      setError(err?.message || "Camera access failed");
      toast.error("Unable to open camera for QR scanning");
      stopCamera();
    }
  }, [facing, stopCamera, handleFound]);

  const flipCamera = useCallback(async () => {
    setFacing((prev) => prev === "environment" ? "user" : "environment");
  }, []);

  useEffect(() => {
    if (!active) return;
    void startCamera();
  }, [facing]);

  useEffect(() => () => stopCamera(), [stopCamera]);

  const takeSnapshot = useCallback(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.readyState < 2) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const w = video.videoWidth || 640;
    const h = video.videoHeight || 640;
    canvas.width = w;
    canvas.height = h;
    ctx.drawImage(video, 0, 0, w, h);
    setLastSnapshot(canvas.toDataURL("image/png"));
    toast.success("Camera snapshot captured");
  }, []);

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-border bg-card p-4 space-y-3">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-sm font-semibold text-foreground">Wallet QR Scanner</p>
            <p className="text-xs text-muted-foreground">Open camera, scan QR, verify camera and snapshot.</p>
          </div>
          <div className="flex items-center gap-2 text-xs">
            {cameraReady ? <span className="inline-flex items-center gap-1 text-green-600"><Check className="h-3.5 w-3.5" /> Camera ready</span> : <span className="text-muted-foreground">Idle</span>}
          </div>
        </div>

        <div className="relative overflow-hidden rounded-2xl bg-black aspect-square">
          {active ? (
            <>
              <video ref={videoRef} className="h-full w-full object-cover" playsInline muted />
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                <div className="h-52 w-52 rounded-3xl border-2 border-white/70 shadow-[0_0_0_9999px_rgba(0,0,0,0.35)]" />
              </div>
              <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-2">
                <Button type="button" size="sm" variant="secondary" onClick={takeSnapshot}><ImageIcon className="mr-2 h-4 w-4" /> Snapshot</Button>
                <Button type="button" size="sm" variant="secondary" onClick={flipCamera}><RotateCcw className="mr-2 h-4 w-4" /> Flip</Button>
                <Button type="button" size="sm" variant="destructive" onClick={stopCamera}><CameraOff className="mr-2 h-4 w-4" /> Stop</Button>
              </div>
            </>
          ) : (
            <div className="flex h-full w-full flex-col items-center justify-center gap-3 p-6 text-center">
              <div className="rounded-full bg-white/10 p-4"><QrCode className="h-10 w-10 text-white/80" /></div>
              <div>
                <p className="text-sm font-medium text-white">Open camera to scan payment QR</p>
                <p className="text-xs text-white/60">Professional scanner with QR detection and camera snapshot.</p>
              </div>
              <Button type="button" onClick={() => void startCamera()}><Camera className="mr-2 h-4 w-4" /> Open camera</Button>
            </div>
          )}
        </div>

        {error && <p className="text-xs text-destructive">{error}</p>}
        <div className="rounded-xl border border-border/60 bg-muted/30 p-3 text-xs text-muted-foreground">
          <div className="flex items-center gap-2 font-medium text-foreground"><ScanLine className="h-3.5 w-3.5" /> Camera tools</div>
          <ul className="mt-2 space-y-1">
            <li>• QR payment scanning</li>
            <li>• Camera open/close verification</li>
            <li>• Front / back camera flip</li>
            <li>• Snapshot capture for diagnostics</li>
          </ul>
        </div>
        {lastSnapshot && (
          <div className="space-y-2">
            <p className="text-xs font-medium text-foreground">Last camera snapshot</p>
            <img src={lastSnapshot} alt="Camera snapshot" className="w-full rounded-xl border border-border object-cover" />
          </div>
        )}
      </div>
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}
