/**
 * LiveEcosystemMap — Premium Leaflet map rendering the living ecosystem.
 * Each entity category gets a unique animated marker.
 * Features: pulse animations, category-colored markers, popup cards, live updates.
 */
import { useEffect, useRef, useCallback, useMemo } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { EcosystemEntity, EcosystemCategory } from "@/hooks/useEcosystemRadar";

const CATEGORY_STYLE: Record<EcosystemCategory, { emoji: string; color: string; borderColor: string }> = {
  agent:              { emoji: "🧑‍💼", color: "#8b5cf6", borderColor: "#a78bfa" },
  technician:         { emoji: "🔧",   color: "#f59e0b", borderColor: "#fbbf24" },
  delivery:           { emoji: "📦",   color: "#22c55e", borderColor: "#4ade80" },
  visit:              { emoji: "🏠",   color: "#06b6d4", borderColor: "#22d3ee" },
  intervention:       { emoji: "🛠️",   color: "#ef4444", borderColor: "#f87171" },
  available_property: { emoji: "✅",   color: "#22c55e", borderColor: "#4ade80" },
  releasing_soon:     { emoji: "📅",   color: "#f59e0b", borderColor: "#fbbf24" },
  scheduled_visit:    { emoji: "🗓️",   color: "#8b5cf6", borderColor: "#a78bfa" },
  renovation:         { emoji: "🏗️",   color: "#f59e0b", borderColor: "#fbbf24" },
  back_on_market:     { emoji: "🔄",   color: "#22c55e", borderColor: "#4ade80" },
  service:            { emoji: "💼",   color: "#06b6d4", borderColor: "#22d3ee" },
  concierge:          { emoji: "🛎️",   color: "#8b5cf6", borderColor: "#a78bfa" },
  person:             { emoji: "👤",   color: "#64748b", borderColor: "#94a3b8" },
};

interface Props {
  lat: number;
  lng: number;
  radius: number;
  entities: EcosystemEntity[];
  onSelect?: (entity: EcosystemEntity) => void;
}

export default function LiveEcosystemMap({ lat, lng, radius, entities, onSelect }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.LayerGroup | null>(null);
  const mappedEntities = useMemo(() => entities.filter((e) => e.lat != null && e.lng != null), [entities]);
  const [followUser, setFollowUser] = useState(false);

  // Initialize map once
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: [lat, lng],
      zoom: getZoomForRadius(radius),
      zoomControl: false,
      attributionControl: false,
    });

    L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
      maxZoom: 19,
    }).addTo(map);

    L.control.zoom({ position: "bottomright" }).addTo(map);

    markersRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
      markersRef.current = null;
    };
  }, []);

  // Update view when center/radius changes
  useEffect(() => {
    if (!mapRef.current) return;
    mapRef.current.setView([lat, lng], getZoomForRadius(radius), { animate: true });
  }, [lat, lng, radius]);
  // Ensure Leaflet recalculates size when the panel becomes visible or data changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const t1 = window.setTimeout(() => map.invalidateSize(), 0);
    const t2 = window.setTimeout(() => map.invalidateSize(), 250);
    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    };
  }, [lat, lng, radius, entities.length]);

  useEffect(() => {
    const el = containerRef.current;
    const map = mapRef.current;
    if (!el || !map || typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(() => {
      map.invalidateSize();
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // Render markers
  const renderMarkers = useCallback(() => {
    const map = mapRef.current;
    const group = markersRef.current;
    if (!map || !group) return;

    group.clearLayers();

    // User position (pulsing cyan dot)
    const userIcon = L.divIcon({
      className: "",
      html: `
        <div style="position:relative;width:20px;height:20px;">
          <div style="position:absolute;inset:0;border-radius:50%;background:#06b6d4;border:3px solid white;box-shadow:0 0 20px rgba(6,182,212,0.6);z-index:2;"></div>
          <div style="position:absolute;inset:-8px;border-radius:50%;border:2px solid #06b6d4;opacity:0.4;animation:ecosystemPulse 2s ease-out infinite;"></div>
        </div>`,
      iconSize: [20, 20],
      iconAnchor: [10, 10],
    });
    L.marker([lat, lng], { icon: userIcon, zIndexOffset: 2000 })
      .addTo(group)
      .bindPopup('<span style="font-weight:600;">📍 You are here</span>');

    // Radius circle
    L.circle([lat, lng], {
      radius: radius * 1000,
      color: "#06b6d4",
      fillColor: "#06b6d4",
      fillOpacity: 0.03,
      weight: 1,
      opacity: 0.2,
      dashArray: "6 4",
    }).addTo(group);

    // Entity markers
    entities.forEach((entity) => {
      if (entity.lat == null || entity.lng == null) return;
      const style = CATEGORY_STYLE[entity.category] || CATEGORY_STYLE.person;
      const isOnline = entity.online;
      const isActive = ["active", "available", "en_route", "nearby", "arrived", "in_progress"].includes(String(entity.status || ""));

      const icon = L.divIcon({
        className: "",
        html: `
          <div style="position:relative;width:36px;height:36px;cursor:pointer;">
            <div style="
              width:36px;height:36px;border-radius:10px;
              background:${style.color}18;
              border:2px solid ${style.borderColor}90;
              display:flex;align-items:center;justify-content:center;
              font-size:16px;
              box-shadow:0 2px 12px ${style.color}40;
              transition:transform 0.2s;
            ">${style.emoji}</div>
            ${isOnline ? `<div style="position:absolute;top:-2px;right:-2px;width:10px;height:10px;border-radius:50%;background:#22c55e;border:2px solid #0f172a;"></div>` : ""}
            ${isActive ? `<div style="position:absolute;inset:-4px;border-radius:12px;border:2px solid ${style.color};opacity:0.5;animation:ecosystemPulse 1.5s ease-out infinite;"></div>` : ""}
          </div>`,
        iconSize: [36, 36],
        iconAnchor: [18, 18],
      });

      const priceStr = entity.price && entity.price > 0
        ? `<br/><span style="font-weight:700;color:${style.color};">${entity.price > 1000 ? `${(entity.price / 1000).toFixed(0)}k` : entity.price} ${entity.currency || "EUR"}</span>`
        : "";
      const distStr = entity.distance_km < 1
        ? `${Math.round(entity.distance_km * 1000)}m`
        : `${entity.distance_km.toFixed(1)}km`;

      const marker = L.marker([entity.lat, entity.lng], { icon, zIndexOffset: isActive ? 900 : 500 })
        .addTo(group)
        .bindPopup(`
          <div style="min-width:160px;">
            <div style="font-weight:700;font-size:13px;margin-bottom:2px;">${style.emoji} ${entity.title}</div>
            ${entity.subtitle ? `<div style="font-size:11px;opacity:0.7;margin-bottom:4px;">${entity.subtitle}</div>` : ""}
            <div style="font-size:10px;opacity:0.5;">${distStr} away</div>
            ${priceStr}
          </div>
        `);

      if (onSelect) {
        marker.on("click", () => onSelect(entity));
      }
    });
  }, [lat, lng, radius, entities, onSelect]);

  useEffect(() => {
    renderMarkers();
  }, [renderMarkers]);


  useEffect(() => {
    const map = mapRef.current;
    if (!map || !followUser) return;
    map.setView([lat, lng], Math.max(getZoomForRadius(radius), 13), { animate: true });
  }, [followUser, lat, lng, radius]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const pts: [number, number][] = [[lat, lng]];
    entities.slice(0, 100).forEach((entity) => {
      if (entity.lat != null && entity.lng != null) pts.push([entity.lat, entity.lng]);
    });
    if (pts.length > 1) {
      const bounds = L.latLngBounds(pts);
      map.fitBounds(bounds, { padding: [32, 32], maxZoom: getZoomForRadius(radius) });
    }
  }, [lat, lng, radius, entities]);

  return (
    <>
      <div className="relative w-full h-full min-h-[420px]">
        <div ref={containerRef} className="w-full h-full min-h-[420px] rounded-2xl overflow-hidden" style={{ zIndex: 1, minHeight: 420 }} />

        <div className="absolute top-3 right-3 z-[1001] flex flex-col gap-2">
          <button
            onClick={() => {
              const map = mapRef.current;
              if (!map) return;
              const pts = [[lat, lng], ...mappedEntities.map((e) => [e.lat as number, e.lng as number] as [number, number])];
              if (pts.length > 1) map.fitBounds(L.latLngBounds(pts), { padding: [32, 32], maxZoom: getZoomForRadius(radius) });
              else map.setView([lat, lng], getZoomForRadius(radius), { animate: true });
            }}
            className="px-2.5 py-1.5 rounded-lg text-[10px] font-medium backdrop-blur-md"
            style={{ background: 'hsl(var(--hud-bg) / 0.9)', color: 'hsl(var(--hud-cyan))', border: '1px solid hsl(var(--hud-cyan) / 0.2)' }}
          >
            Fit all
          </button>
          <button
            onClick={() => setFollowUser((v) => !v)}
            className="px-2.5 py-1.5 rounded-lg text-[10px] font-medium backdrop-blur-md"
            style={{ background: followUser ? 'hsl(var(--hud-success) / 0.18)' : 'hsl(var(--hud-bg) / 0.9)', color: followUser ? 'hsl(var(--hud-success))' : 'hsl(var(--hud-text-dim))', border: '1px solid hsl(var(--hud-border) / 0.2)' }}
          >
            {followUser ? 'Following' : 'Follow me'}
          </button>
          <div className="px-2.5 py-1.5 rounded-lg text-[10px] font-medium backdrop-blur-md"
            style={{ background: 'hsl(var(--hud-bg) / 0.9)', color: 'hsl(var(--hud-text-dim))', border: '1px solid hsl(var(--hud-border) / 0.15)' }}
          >
            {mappedEntities.length} mapped / {entities.length} total
          </div>
        </div>

        {mappedEntities.length === 0 && (
          <div className="absolute inset-0 z-[1000] flex items-center justify-center pointer-events-none">
            <div className="max-w-[320px] px-4 py-3 rounded-xl backdrop-blur-md text-center"
              style={{ background: 'hsl(var(--hud-bg) / 0.88)', color: 'hsl(var(--hud-text-dim))', border: '1px solid hsl(var(--hud-border) / 0.15)' }}>
              <div className="text-sm font-semibold" style={{ color: 'hsl(var(--hud-text))' }}>No live coordinates available</div>
              <div className="text-[11px] mt-1 leading-relaxed">Orbit Radar map only displays entities with real coordinates. Use list view for the full ecosystem.</div>
            </div>
          </div>
        )}
      </div>

      <style>{`
        @keyframes ecosystemPulse {
          0% { transform: scale(1); opacity: 0.5; }
          100% { transform: scale(2.2); opacity: 0; }
        }
      `}</style>
    </>
  );
}

function getZoomForRadius(km: number): number {
  if (km <= 5) return 14;
  if (km <= 10) return 13;
  if (km <= 25) return 11;
  if (km <= 50) return 10;
  if (km <= 100) return 9;
  if (km <= 200) return 8;
  return 7;
}
