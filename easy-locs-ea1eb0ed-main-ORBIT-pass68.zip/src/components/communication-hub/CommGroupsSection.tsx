/**
 * CommGroupsSection — Real group management with create, list, chat, members.
 */
import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import {
  UsersRound, Plus, Search, ArrowLeft, Send,
  UserPlus, LogOut, Trash2, Crown, Users, Radio, Megaphone, Shield, Pin, PinOff,
} from "lucide-react";
import { format, isToday, isYesterday } from "date-fns";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { haptic } from "@/lib/haptics";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import {
  OrbitCommunityKind,
  OrbitCommunityVisibility,
  communityKindLabel,
  communityVisibilityLabel,
  communityPostRuleLabel,
  encodeOrbitCommunityDescription,
  parseOrbitCommunityDescription,
  updateOrbitCommunityDescription,
  canCommunityRoleInvite,
  canCommunityRolePost,
  buildCommunityStorefrontLinks,
  buildCommunityWalletPath,
  computeOrbitCommunitySummary,
  getOrbitCommunityReadState,
  setOrbitCommunityReadAt,
  countOrbitCommunityUnread,
} from "@/lib/orbit-community-core";
import { getSecurityConfig } from "@/lib/app-security";
import { platformBus } from "@/lib/shared/platform-bus";

interface Group {
  id: string;
  name: string;
  description: string | null;
  photo_url: string | null;
  created_by: string;
  created_at: string;
  member_count?: number;
  last_message?: string;
  last_message_at?: string;
  kind?: OrbitCommunityKind;
  visibility?: OrbitCommunityVisibility;
}

interface GroupMember {
  id: string;
  user_id: string;
  role: "owner" | "admin" | "member" | "viewer" | string;
  joined_at: string;
  profile_name?: string;
}

interface GroupMessage {
  id: string;
  sender_id: string;
  content: string;
  created_at: string;
  sender_name?: string;
}

function getInitials(name: string): string {
  return name.split(" ").slice(0, 2).map(w => w[0]).join("").toUpperCase();
}

function formatMsgTime(d: string): string {
  const date = new Date(d);
  if (isToday(date)) return format(date, "HH:mm");
  if (isYesterday(date)) return "Yesterday";
  return format(date, "dd/MM");
}

export default function CommGroupsSection() {
  const { user, orgId } = useAuth();
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [viewMode, setViewMode] = useState<"all" | OrbitCommunityKind>("all");
  const [securityConfig, setSecurityConfig] = useState(getSecurityConfig());
  const [newGroup, setNewGroup] = useState({
    name: "",
    description: "",
    kind: "group" as OrbitCommunityKind,
    visibility: "private" as OrbitCommunityVisibility,
    linkedStoreId: "",
  });
  const [creating, setCreating] = useState(false);

  // Chat state
  const [activeGroup, setActiveGroup] = useState<Group | null>(null);
  const [messages, setMessages] = useState<GroupMessage[]>([]);
  const [members, setMembers] = useState<GroupMember[]>([]);
  const [msgInput, setMsgInput] = useState("");
  const [showMembers, setShowMembers] = useState(false);
  const [showAddMember, setShowAddMember] = useState(false);
  const [addMemberEmail, setAddMemberEmail] = useState("");
  const [channelView, setChannelView] = useState<"timeline" | "broadcast">("timeline");
  const [readState, setReadState] = useState(() => getOrbitCommunityReadState(user?.id));
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const loadGroups = useCallback(async () => {
    if (!user?.id) return;
    setLoading(true);
    const { data } = await supabase
      .from("groups")
      .select("*")
      .order("updated_at", { ascending: false });
    
    if (data) {
      // Get member counts and last messages
      const enriched = await Promise.all(data.map(async (g: any) => {
        const { count } = await supabase
          .from("group_members")
          .select("*", { count: "exact", head: true })
          .eq("group_id", g.id);
        
        const { data: lastMsg } = await supabase
          .from("group_messages")
          .select("content, created_at")
          .eq("group_id", g.id)
          .order("created_at", { ascending: false })
          .limit(1);
        
        const meta = parseOrbitCommunityDescription(g.description);
        return {
          ...g,
          description: meta.plainDescription,
          kind: meta.kind,
          visibility: meta.visibility,
          member_count: count || 0,
          last_message: lastMsg?.[0]?.content || null,
          last_message_at: lastMsg?.[0]?.created_at || g.created_at,
        };
      }));
      setGroups(enriched);
    }
    setLoading(false);
  }, [user?.id]);

  useEffect(() => { loadGroups(); }, [loadGroups]);

  useEffect(() => {
    const syncSecurity = () => setSecurityConfig(getSecurityConfig());
    window.addEventListener("orbit:security-changed", syncSecurity as EventListener);
    window.addEventListener("storage", syncSecurity);
    return () => {
      window.removeEventListener("orbit:security-changed", syncSecurity as EventListener);
      window.removeEventListener("storage", syncSecurity);
    };
  }, []);

  useEffect(() => {
    setReadState(getOrbitCommunityReadState(user?.id));
    const syncReadState = () => setReadState(getOrbitCommunityReadState(user?.id));
    window.addEventListener("storage", syncReadState);
    window.addEventListener("orbit:community-read-state-changed", syncReadState as EventListener);
    return () => {
      window.removeEventListener("storage", syncReadState);
      window.removeEventListener("orbit:community-read-state-changed", syncReadState as EventListener);
    };
  }, [user?.id]);


  const markGroupRead = useCallback((groupId: string, iso?: string | null) => {
    if (!user?.id || !groupId) return;
    setReadState(setOrbitCommunityReadAt(user.id, groupId, iso || new Date().toISOString()));
  }, [user?.id]);

  const handleCreate = async () => {
    if (!user?.id || !orgId || !newGroup.name.trim()) return;
    setCreating(true);
    const { data, error } = await supabase.from("groups").insert({
      org_id: orgId,
      name: newGroup.name.trim(),
      description: encodeOrbitCommunityDescription(newGroup.description.trim() || null, newGroup.kind, newGroup.visibility, { linkedStoreId: newGroup.linkedStoreId.trim() || null }),
      created_by: user.id,
    } as any).select().single();
    
    if (error || !data) {
      toast.error("Failed to create group");
      setCreating(false);
      return;
    }
    
    // Add creator as admin
    await supabase.from("group_members").insert({
      group_id: (data as any).id,
      user_id: user.id,
      role: "owner",
    } as any);
    
    haptic("success");
    toast.success("Group created");
    platformBus.emit("orbit:thread_created", { kind: newGroup.kind, groupId: (data as any).id, visibility: newGroup.visibility }, "orbit", { userId: user.id, orgId });
    setShowCreate(false);
    setNewGroup({ name: "", description: "", kind: "group", visibility: "private", linkedStoreId: "" });
    setCreating(false);
    loadGroups();
  };

  const openGroupChat = async (group: Group) => {
    setActiveGroup(group);
    haptic("light");
    
    // Load messages
    const { data: msgs } = await supabase
      .from("group_messages")
      .select("*")
      .eq("group_id", group.id)
      .order("created_at", { ascending: true })
      .limit(200);
    setMessages((msgs as GroupMessage[]) || []);
    
    // Load members
    const { data: mems } = await supabase
      .from("group_members")
      .select("*")
      .eq("group_id", group.id);
    setMembers((mems as GroupMember[]) || []);
    
    const latestSeenAt = (msgs as GroupMessage[] | null)?.at?.(-1)?.created_at || group.last_message_at || new Date().toISOString();
    markGroupRead(group.id, latestSeenAt);
    setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }), 100);
  };

  const sendMessage = async () => {
    if (!msgInput.trim() || !activeGroup || !user?.id) return;
    const content = msgInput.trim();
    setMsgInput("");
    haptic("light");
    
    const { data, error } = await supabase.from("group_messages").insert({
      group_id: activeGroup.id,
      sender_id: user.id,
      content,
    } as any).select().single();
    
    if (!error && data) {
      setMessages(prev => [...prev, data as GroupMessage]);
      // Update group timestamp
      await supabase.from("groups").update({ updated_at: new Date().toISOString() } as any).eq("id", activeGroup.id);
      platformBus.emit("orbit:message_sent", { groupId: activeGroup.id, communityKind: activeMeta?.kind || "group", isBroadcast: activeMeta?.kind === "channel", contentType: "text" }, "orbit", { userId: user.id, orgId });
      if (activeMeta?.kind === "channel") {
        platformBus.emit("orbit:notification_created", { source: "orbit_community", groupId: activeGroup.id, event: "channel_post" }, "orbit", { userId: user.id, orgId });
      }
      setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
    }
  };

  const handleAddMember = async () => {
    if (!addMemberEmail.trim() || !activeGroup) return;
    // Look up user by email in profiles
    const { data: profile } = await supabase
      .from("profiles")
      .select("id")
      .eq("email", addMemberEmail.trim().toLowerCase())
      .single();
    
    if (!profile) {
      toast.error("User not found");
      return;
    }
    
    const { error } = await supabase.from("group_members").insert({
      group_id: activeGroup.id,
      user_id: profile.id,
      role: activeMeta?.kind === "channel" ? "viewer" : "member",
    } as any);
    
    if (error) {
      toast.error(error.message.includes("duplicate") ? "Already a member" : "Failed to add member");
      return;
    }
    
    haptic("success");
    toast.success("Member added");
    setAddMemberEmail("");
    setShowAddMember(false);
    // Reload members
    const { data: mems } = await supabase.from("group_members").select("*").eq("group_id", activeGroup.id);
    setMembers((mems as GroupMember[]) || []);
  };

  const leaveGroup = async () => {
    if (!activeGroup || !user?.id) return;
    const { error } = await supabase.from("group_members").delete().eq("group_id", activeGroup.id).eq("user_id", user.id);
    if (error) { toast.error("Failed to leave group"); return; }
    haptic("medium");
    toast.success("Left group");
    setActiveGroup(null);
    loadGroups();
  };

  const removeMember = async (memberId: string) => {
    if (!activeGroup) return;
    const { error } = await supabase.from("group_members").delete().eq("id", memberId);
    if (error) { toast.error("Failed to remove member"); return; }
    haptic("light");
    toast.success("Member removed");
    const { data: mems } = await supabase.from("group_members").select("*").eq("group_id", activeGroup.id);
    setMembers((mems as GroupMember[]) || []);
  };

  const activeMeta = activeGroup ? parseOrbitCommunityDescription(activeGroup.description) : null;
  const myMember = members.find(m => m.user_id === user?.id) || null;
  const getGroupUnread = useCallback((group: Group) => {
    const lastAt = group.last_message_at ? +new Date(group.last_message_at) : 0;
    const readAt = readState[group.id] ? +new Date(readState[group.id]) : 0;
    return lastAt > readAt;
  }, [readState]);
  const communityLinks = activeMeta ? buildCommunityStorefrontLinks(activeMeta.linkedStoreId) : null;
  const communitySummary = computeOrbitCommunitySummary(activeMeta);
  const communityWalletPath = activeMeta ? buildCommunityWalletPath(activeMeta.linkedStoreId, { source: activeMeta.kind === "channel" ? "orbit_channel" : "orbit_community" }) : null;
  const ghostMessagesHidden = securityConfig.ghost_elite_enabled && securityConfig.ghost_hide_messages;
  const ghostProfileHidden = securityConfig.ghost_elite_enabled && securityConfig.ghost_hide_profile;
  const isAdmin = members.some(m => m.user_id === user?.id && (m.role === "admin" || m.role === "owner"));
  const canSendInActive = activeMeta ? canCommunityRolePost(activeMeta.kind, myMember?.role) : true;
  const canInviteInActive = activeMeta ? canCommunityRoleInvite(activeMeta.kind, myMember?.role) : true;
  const pinnedMessage = activeMeta?.pinnedMessageId ? messages.find(msg => msg.id === activeMeta.pinnedMessageId) || null : null;


  const pinMessage = async (msg: GroupMessage) => {
    if (!activeGroup || !isAdmin) return;
    const nextDescription = updateOrbitCommunityDescription(activeGroup.description, {
      pinnedMessageId: msg.id,
      pinnedMessagePreview: msg.content.slice(0, 140),
    });
    const { error } = await supabase.from("groups").update({ description: nextDescription } as any).eq("id", activeGroup.id);
    if (error) {
      toast.error("Failed to pin post");
      return;
    }
    const updated = { ...activeGroup, description: nextDescription };
    setActiveGroup(updated);
    setGroups(prev => prev.map(g => g.id === activeGroup.id ? { ...g, description: nextDescription } : g));
    platformBus.emit("orbit:notification_created", { source: "orbit_community", groupId: activeGroup.id, event: "pin", messageId: msg.id }, "orbit", { userId: user?.id, orgId });
    toast.success("Pinned for this community");
  };

  const unpinMessage = async () => {
    if (!activeGroup || !isAdmin) return;
    const nextDescription = updateOrbitCommunityDescription(activeGroup.description, {
      pinnedMessageId: null,
      pinnedMessagePreview: null,
    });
    const { error } = await supabase.from("groups").update({ description: nextDescription } as any).eq("id", activeGroup.id);
    if (error) {
      toast.error("Failed to unpin post");
      return;
    }
    const updated = { ...activeGroup, description: nextDescription };
    setActiveGroup(updated);
    setGroups(prev => prev.map(g => g.id === activeGroup.id ? { ...g, description: nextDescription } : g));
    platformBus.emit("orbit:notification_created", { source: "orbit_community", groupId: activeGroup.id, event: "unpin" }, "orbit", { userId: user?.id, orgId });
    toast.success("Pinned post removed");
  };
  // Realtime subscription for active group
  useEffect(() => {
    if (!activeGroup) return;
    const channel = supabase
      .channel(`group-${activeGroup.id}`)
      .on("postgres_changes", {
        event: "INSERT",
        schema: "public",
        table: "group_messages",
        filter: `group_id=eq.${activeGroup.id}`,
      }, (payload) => {
        const msg = payload.new as GroupMessage;
        setGroups(prev => prev.map(g => g.id === activeGroup.id ? { ...g, last_message: msg.content, last_message_at: msg.created_at } : g));
        if (msg.sender_id !== user?.id) {
          setMessages(prev => [...prev, msg]);
          if (document.visibilityState === "visible") {
            markGroupRead(activeGroup.id, msg.created_at);
          }
          setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
        } else {
          markGroupRead(activeGroup.id, msg.created_at);
        }
      })
      .subscribe();
    
    return () => { supabase.removeChannel(channel); };
  }, [activeGroup?.id, user?.id, markGroupRead]);

  useEffect(() => {
    setChannelView(activeMeta?.kind === "channel" ? "broadcast" : "timeline");
  }, [activeMeta?.kind, activeGroup?.id]);

  useEffect(() => {
    if (!activeGroup) return;
    const markVisibleRead = () => {
      if (document.visibilityState === "visible") {
        markGroupRead(activeGroup.id, activeGroup.last_message_at || new Date().toISOString());
      }
    };
    document.addEventListener("visibilitychange", markVisibleRead);
    window.addEventListener("focus", markVisibleRead);
    return () => {
      document.removeEventListener("visibilitychange", markVisibleRead);
      window.removeEventListener("focus", markVisibleRead);
    };
  }, [activeGroup?.id, activeGroup?.last_message_at, markGroupRead]);

  const broadcastMessages = useMemo(() => {
    if (activeMeta?.kind !== "channel") return [] as GroupMessage[];
    const adminIds = new Set(members.filter(m => m.role === "owner" || m.role === "admin").map(m => m.user_id));
    return messages.filter(msg => adminIds.has(msg.sender_id)).slice().sort((a, b) => +new Date(b.created_at) - +new Date(a.created_at));
  }, [activeMeta?.kind, members, messages]);

  const communityCounts = useMemo(() => ({
    all: groups.length,
    group: groups.filter(g => (g.kind || "group") === "group").length,
    channel: groups.filter(g => (g.kind || "group") === "channel").length,
    community: groups.filter(g => (g.kind || "group") === "community").length,
    linked: groups.filter(g => parseOrbitCommunityDescription(g.description).linkedStoreId).length,
    publicCount: groups.filter(g => parseOrbitCommunityDescription(g.description).visibility === "public").length,
    unread: countOrbitCommunityUnread(groups, readState),
  }), [groups, readState]);

  const filtered = groups.filter(g => {
    const matchesView = viewMode === "all" ? true : (g.kind || "group") === viewMode;
    if (!matchesView) return false;
    if (!search) return true;
    return [g.name, g.description || "", communityKindLabel(g.kind || "group")]
      .join(" ")
      .toLowerCase()
      .includes(search.toLowerCase());
  });

  const markAllVisibleRead = useCallback(() => {
    const nowIso = new Date().toISOString();
    filtered.forEach(group => {
      const targetIso = group.last_message_at || nowIso;
      setOrbitCommunityReadAt(user?.id, group.id, targetIso);
    });
    setReadState(getOrbitCommunityReadState(user?.id));
    toast.success("Community inbox marked as read");
  }, [filtered, user?.id]);

  // ═══ Group Chat View ═══
  if (activeGroup) {
    return (
      <div className="flex-1 flex flex-col min-h-0" style={{ background: "hsl(var(--hud-bg))" }}>
        {/* Chat header */}
        <div className="flex items-center gap-3 px-3 py-2.5 shrink-0" style={{ borderBottom: "1px solid hsl(var(--hud-border) / 0.08)" }}>
          <button onClick={() => { setActiveGroup(null); haptic("light"); }} className="p-1.5 rounded-full hover:bg-[hsl(var(--hud-surface)/0.5)]">
            <ArrowLeft className="h-5 w-5" style={{ color: "hsl(var(--hud-text))" }} />
          </button>
          <div
            className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold shrink-0"
            style={{ background: "hsl(var(--hud-cyan) / 0.12)", color: "hsl(var(--hud-cyan))" }}
          >
            {getInitials(activeGroup.name)}
          </div>
          <div className="flex-1 min-w-0">
            <span className="text-sm font-semibold block leading-tight break-words line-clamp-2" style={{ color: "hsl(var(--hud-text))" }}>
              {activeGroup.name}
            </span>
            <span className="text-[10px]" style={{ color: "hsl(var(--hud-text-dim) / 0.5)" }}>
              {members.length} members • {activeMeta ? communityKindLabel(activeMeta.kind) : "Group"} • {activeMeta ? communityPostRuleLabel(activeMeta.kind) : "Open conversation"}
            </span>
          </div>
          <button
            onClick={() => setShowMembers(true)}
            className="p-2 rounded-full"
            style={{ color: "hsl(var(--hud-cyan))" }}
          >
            <Users className="h-4.5 w-4.5" />
          </button>
        </div>

        {communityLinks && (
          <div className="px-3 py-2 flex flex-wrap gap-2 shrink-0" style={{ borderBottom: "1px solid hsl(var(--hud-border) / 0.06)" }}>
            <button onClick={() => navigate(communityLinks.storePage)} className="px-2.5 py-1 rounded-full text-[11px] font-medium" style={{ background: "hsl(var(--hud-cyan) / 0.12)", color: "hsl(var(--hud-cyan))" }}>Open store</button>
            <button onClick={() => navigate(communityLinks.videoHub)} className="px-2.5 py-1 rounded-full text-[11px] font-medium" style={{ background: "hsl(var(--hud-surface))", color: "hsl(var(--hud-text-dim) / 0.8)" }}>Store videos</button>
            <button onClick={() => navigate(communityLinks.liveHub)} className="px-2.5 py-1 rounded-full text-[11px] font-medium" style={{ background: "hsl(var(--hud-surface))", color: "hsl(var(--hud-text-dim) / 0.8)" }}>Live hub</button>
            {communityWalletPath && <button onClick={() => navigate(communityWalletPath)} className="px-2.5 py-1 rounded-full text-[11px] font-medium" style={{ background: "hsl(var(--hud-cyan) / 0.12)", color: "hsl(var(--hud-cyan))" }}>Pay in Wallet</button>}
          </div>
        )}


        <div className="px-3 py-2 flex flex-wrap gap-2 shrink-0" style={{ borderBottom: "1px solid hsl(var(--hud-border) / 0.06)" }}>
          <span className="px-2 py-1 rounded-full text-[10px] font-medium" style={{ background: "hsl(var(--hud-surface))", color: "hsl(var(--hud-text-dim) / 0.8)" }}>
            {communitySummary.isBroadcastOnly ? "Broadcast only" : "Interactive"}
          </span>
          {communitySummary.hasPinnedPost && (
            <span className="px-2 py-1 rounded-full text-[10px] font-medium" style={{ background: "hsl(var(--hud-cyan) / 0.10)", color: "hsl(var(--hud-cyan))" }}>
              Pinned update
            </span>
          )}
          {communitySummary.hasLinkedStore && (
            <span className="px-2 py-1 rounded-full text-[10px] font-medium" style={{ background: "hsl(var(--hud-success) / 0.10)", color: "hsl(var(--hud-success))" }}>
              Store linked
            </span>
          )}
          {communitySummary.commerceReady && (
            <span className="px-2 py-1 rounded-full text-[10px] font-medium" style={{ background: "hsl(var(--hud-warning) / 0.10)", color: "hsl(var(--hud-warning))" }}>
              Commerce ready
            </span>
          )}
        </div>
        {ghostMessagesHidden && (
          <div className="px-3 py-2 shrink-0 text-[11px]" style={{ background: "hsl(var(--hud-warning) / 0.08)", color: "hsl(var(--hud-warning))", borderBottom: "1px solid hsl(var(--hud-warning) / 0.12)" }}>Ghost Elite is masking community messages on this device.</div>
        )}

        {activeMeta?.kind === "channel" && (
          <div className="px-3 py-2 flex items-center gap-2 shrink-0" style={{ borderBottom: "1px solid hsl(var(--hud-border) / 0.06)" }}>
            <button onClick={() => setChannelView("broadcast")} className="px-2.5 py-1 rounded-full text-[11px] font-medium" style={{ background: channelView === "broadcast" ? "hsl(var(--hud-cyan) / 0.12)" : "hsl(var(--hud-surface))", color: channelView === "broadcast" ? "hsl(var(--hud-cyan))" : "hsl(var(--hud-text-dim) / 0.8)" }}>Broadcast feed</button>
            <button onClick={() => setChannelView("timeline")} className="px-2.5 py-1 rounded-full text-[11px] font-medium" style={{ background: channelView === "timeline" ? "hsl(var(--hud-cyan) / 0.12)" : "hsl(var(--hud-surface))", color: channelView === "timeline" ? "hsl(var(--hud-cyan))" : "hsl(var(--hud-text-dim) / 0.8)" }}>Message timeline</button>
            <span className="text-[10px] ml-auto" style={{ color: "hsl(var(--hud-text-dim) / 0.5)" }}>{broadcastMessages.length} broadcasts</span>
          </div>
        )}

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-3 py-3 space-y-2">
          {pinnedMessage && (
            <div className="px-3 py-2 rounded-2xl flex items-start gap-2" style={{ background: "hsl(var(--hud-cyan) / 0.08)", border: "1px solid hsl(var(--hud-cyan) / 0.18)" }}>
              <Pin className="h-3.5 w-3.5 mt-0.5" style={{ color: "hsl(var(--hud-cyan))" }} />
              <div className="flex-1 min-w-0">
                <span className="text-[10px] font-semibold block" style={{ color: "hsl(var(--hud-cyan))" }}>Pinned update</span>
                <span className="text-[12px] leading-tight break-words line-clamp-2" style={{ color: "hsl(var(--hud-text))" }}>
                  {ghostMessagesHidden ? "Pinned message hidden by Ghost Elite" : (pinnedMessage.content || activeMeta?.pinnedMessagePreview || "Pinned message")}
                </span>
              </div>
              {isAdmin && (
                <button onClick={unpinMessage} className="p-1.5 rounded-full hover:bg-[hsl(var(--hud-surface)/0.5)]">
                  <PinOff className="h-3.5 w-3.5" style={{ color: "hsl(var(--hud-danger))" }} />
                </button>
              )}
            </div>
          )}
          {(channelView === "broadcast" ? broadcastMessages.length === 0 : messages.length === 0) && (
            <div className="text-center py-12">
              <UsersRound className="h-8 w-8 mx-auto mb-2" style={{ color: "hsl(var(--hud-text-dim) / 0.15)" }} />
              <p className="text-xs" style={{ color: "hsl(var(--hud-text-dim) / 0.4)" }}>{activeMeta?.kind === "channel" ? (channelView === "broadcast" ? "No broadcasts yet" : "Broadcast your first update") : "Start the conversation"}</p>
            </div>
          )}
          {(channelView === "broadcast" ? broadcastMessages : messages).map(msg => {
            const isMine = msg.sender_id === user?.id;
            return (
              <div key={msg.id} className={`flex ${isMine ? "justify-end" : "justify-start"}`}>
                <div
                  className="max-w-[75%] px-3 py-2 rounded-2xl text-[13px]"
                  style={{
                    background: isMine ? "hsl(var(--hud-cyan) / 0.15)" : "hsl(var(--hud-surface))",
                    color: "hsl(var(--hud-text))",
                    borderBottomRightRadius: isMine ? 6 : undefined,
                    borderBottomLeftRadius: !isMine ? 6 : undefined,
                  }}
                >
                  {!isMine && (
                    <span className="text-[10px] font-semibold block mb-0.5" style={{ color: "hsl(var(--hud-cyan) / 0.7)" }}>
                      {ghostProfileHidden ? "Hidden member" : msg.sender_id.slice(0, 8)}
                    </span>
                  )}
                  {activeMeta?.kind === "channel" && (channelView === "broadcast" || (myMember && (myMember.role === "admin" || myMember.role === "owner"))) && (
                    <span className="text-[9px] inline-flex items-center gap-1 mb-1 px-1.5 py-0.5 rounded-full" style={{ background: "hsl(var(--hud-cyan) / 0.10)", color: "hsl(var(--hud-cyan))" }}>
                      <Megaphone className="h-2.5 w-2.5" /> Broadcast
                    </span>
                  )}
                  <p>{ghostMessagesHidden ? "Message hidden by Ghost Elite" : msg.content}</p>
                  <div className="mt-1 flex items-center justify-end gap-1.5">
                    {isAdmin && (
                      <button
                        onClick={() => pinMessage(msg)}
                        className="text-[9px] inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full"
                        style={{ background: "hsl(var(--hud-bg) / 0.35)", color: "hsl(var(--hud-cyan) / 0.85)" }}
                      >
                        <Pin className="h-2.5 w-2.5" /> Pin
                      </button>
                    )}
                    <span className="text-[9px] block text-right" style={{ color: "hsl(var(--hud-text-dim) / 0.35)" }}>
                      {format(new Date(msg.created_at), "HH:mm")}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Composer */}
        <div className="px-3 py-2 shrink-0" style={{ borderTop: "1px solid hsl(var(--hud-border) / 0.06)" }}>
          {!canSendInActive && (
            <div className="mb-2 px-3 py-2 rounded-xl text-[11px] flex items-center gap-2" style={{ background: "hsl(var(--hud-warning) / 0.08)", color: "hsl(var(--hud-warning))" }}>
              <Megaphone className="h-3.5 w-3.5" /> {activeMeta?.kind === "channel" ? "Only channel admins can post updates." : "Your current role cannot publish here."}
            </div>
          )}
          <div className="flex items-center gap-2">
            <Input
              value={msgInput}
              onChange={e => setMsgInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && !e.shiftKey && canSendInActive && sendMessage()}
              placeholder={activeMeta?.kind === "channel" ? "Broadcast update..." : "Message..."}
              disabled={!canSendInActive || ghostMessagesHidden}
              className="flex-1 h-10 text-sm border-0 rounded-full px-4 disabled:opacity-50"
              style={{ background: "hsl(var(--hud-surface))", color: "hsl(var(--hud-text))" }}
            />
            <button
              onClick={sendMessage}
              disabled={!msgInput.trim() || !canSendInActive || ghostMessagesHidden}
              className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 disabled:opacity-30"
              style={{ background: "hsl(var(--hud-cyan))" }}
            >
              <Send className="h-4 w-4" style={{ color: "hsl(var(--hud-bg))" }} />
            </button>
          </div>
        </div>

        {/* Members sheet */}
        <Dialog open={showMembers} onOpenChange={setShowMembers}>
          <DialogContent style={{ background: "hsl(var(--hud-bg))", borderColor: "hsl(var(--hud-border) / 0.15)" }}>
            <DialogHeader>
              <DialogTitle style={{ color: "hsl(var(--hud-text))" }}>Members ({members.length})</DialogTitle>
            </DialogHeader>
            <div className="space-y-1 max-h-60 overflow-y-auto">
              {members.map(m => (
                <div key={m.id} className="flex items-center gap-3 px-2 py-2 rounded-lg">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-bold"
                    style={{ background: "hsl(var(--hud-cyan) / 0.1)", color: "hsl(var(--hud-cyan))" }}>
                    {m.user_id.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="text-sm block leading-tight break-words line-clamp-2" style={{ color: "hsl(var(--hud-text))" }}>
                      {m.user_id === user?.id ? "You" : (ghostProfileHidden ? "Hidden member" : m.user_id.slice(0, 8))}
                    </span>
                    {(m.role === "admin" || m.role === "owner") && (
                      <span className="text-[10px] flex items-center gap-1" style={{ color: "hsl(var(--hud-cyan) / 0.7)" }}>
                        <Crown className="h-2.5 w-2.5" /> {m.role === "owner" ? "Owner" : "Admin"}
                      </span>
                    )}
                    {m.role === "viewer" && (
                      <span className="text-[10px] flex items-center gap-1" style={{ color: "hsl(var(--hud-text-dim) / 0.5)" }}>
                        <Radio className="h-2.5 w-2.5" /> Viewer
                      </span>
                    )}
                  </div>
                  {isAdmin && m.user_id !== user?.id && (
                    <button onClick={() => removeMember(m.id)} className="p-1.5 rounded-full hover:bg-[hsl(var(--hud-surface)/0.5)]">
                      <Trash2 className="h-3.5 w-3.5" style={{ color: "hsl(var(--hud-danger))" }} />
                    </button>
                  )}
                </div>
              ))}
            </div>
            <div className="flex gap-2 pt-2">
              {canInviteInActive && (
                <Button
                  size="sm"
                  className="flex-1 gap-1.5"
                  style={{ background: "hsl(var(--hud-cyan))", color: "hsl(var(--hud-bg))" }}
                  onClick={() => { setShowMembers(false); setShowAddMember(true); }}
                >
                  <UserPlus className="h-3.5 w-3.5" /> Add Member
                </Button>
              )}
              <Button
                size="sm"
                variant="ghost"
                className="gap-1.5"
                style={{ color: "hsl(var(--hud-danger))" }}
                onClick={leaveGroup}
              >
                <LogOut className="h-3.5 w-3.5" /> Leave
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Add member dialog */}
        <Dialog open={showAddMember} onOpenChange={setShowAddMember}>
          <DialogContent style={{ background: "hsl(var(--hud-bg))", borderColor: "hsl(var(--hud-border) / 0.15)" }}>
            <DialogHeader>
              <DialogTitle style={{ color: "hsl(var(--hud-text))" }}>Add Member</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div>
                <Label className="text-xs" style={{ color: "hsl(var(--hud-text-dim))" }}>User email</Label>
                <Input
                  value={addMemberEmail}
                  onChange={e => setAddMemberEmail(e.target.value)}
                  placeholder="user@example.com"
                  className="mt-1 border-0"
                  style={{ background: "hsl(var(--hud-surface))", color: "hsl(var(--hud-text))" }}
                />
              </div>
              <Button
                className="w-full"
                disabled={!addMemberEmail.trim()}
                onClick={handleAddMember}
                style={{ background: "hsl(var(--hud-cyan))", color: "hsl(var(--hud-bg))" }}
              >
                Add Member
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  // ═══ Group List View ═══
  return (
    <div className="flex-1 flex flex-col min-h-0" style={{ background: "hsl(var(--hud-bg))" }}>
      <div className="px-4 pt-4 pb-2 shrink-0">
        <div className="flex items-center justify-between mb-3 gap-3">
          <div className="min-w-0">
            <h2 className="text-lg font-bold" style={{ color: "hsl(var(--hud-text))" }}>Orbit Communities</h2>
            <p className="text-[11px]" style={{ color: "hsl(var(--hud-text-dim) / 0.55)" }}>
              {communityCounts.unread} unread community updates
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {communityCounts.unread > 0 && (
              <Button
                size="sm"
                variant="ghost"
                className="h-8 gap-1.5 text-xs"
                style={{ color: "hsl(var(--hud-warning))" }}
                onClick={markAllVisibleRead}
              >
                Mark all read
              </Button>
            )}
            <Button
              size="sm"
              variant="ghost"
              className="h-8 gap-1.5 text-xs"
              style={{ color: "hsl(var(--hud-cyan))" }}
              onClick={() => setShowCreate(true)}
            >
              <Plus className="h-4 w-4" />
              Create
            </Button>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-3">
          <span className="px-2.5 py-1 rounded-full text-[10px] font-medium" style={{ background: "hsl(var(--hud-surface))", color: "hsl(var(--hud-text-dim) / 0.75)" }}>All {communityCounts.all}</span>
          <span className="px-2.5 py-1 rounded-full text-[10px] font-medium" style={{ background: "hsl(var(--hud-cyan) / 0.10)", color: "hsl(var(--hud-cyan))" }}>Channels {communityCounts.channel}</span>
          <span className="px-2.5 py-1 rounded-full text-[10px] font-medium" style={{ background: "hsl(var(--hud-success) / 0.10)", color: "hsl(var(--hud-success))" }}>Store linked {communityCounts.linked}</span>
          <span className="px-2.5 py-1 rounded-full text-[10px] font-medium" style={{ background: "hsl(var(--hud-warning) / 0.10)", color: "hsl(var(--hud-warning))" }}>Public {communityCounts.publicCount}</span>
          <span className="px-2.5 py-1 rounded-full text-[10px] font-medium" style={{ background: "hsl(var(--hud-danger) / 0.10)", color: "hsl(var(--hud-danger))" }}>Unread {communityCounts.unread}</span>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1 mb-3">
          {[
            { id: "all", label: "All", icon: UsersRound },
            { id: "group", label: "Groups", icon: Users },
            { id: "channel", label: "Channels", icon: Radio },
            { id: "community", label: "Communities", icon: Shield },
          ].map((item) => {
            const Icon = item.icon;
            const active = viewMode === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setViewMode(item.id as any)}
                className="px-3 py-1.5 rounded-full text-[11px] font-medium flex items-center gap-1.5 shrink-0"
                style={{
                  background: active ? "hsl(var(--hud-cyan) / 0.12)" : "hsl(var(--hud-surface))",
                  color: active ? "hsl(var(--hud-cyan))" : "hsl(var(--hud-text-dim) / 0.7)",
                  border: `1px solid ${active ? "hsl(var(--hud-cyan) / 0.25)" : "hsl(var(--hud-border) / 0.08)"}`,
                }}
              >
                <Icon className="h-3.5 w-3.5" /> {item.label}
              </button>
            );
          })}
        </div>
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4" style={{ color: "hsl(var(--hud-text-dim) / 0.4)" }} />
          <Input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search groups..."
            className="pl-9 h-9 text-sm border-0"
            style={{ background: "hsl(var(--hud-surface))", color: "hsl(var(--hud-text))" }}
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <div className="w-6 h-6 border-2 rounded-full animate-spin" style={{ borderColor: "hsl(var(--hud-cyan) / 0.3)", borderTopColor: "hsl(var(--hud-cyan))" }} />
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center px-6">
            <UsersRound className="h-10 w-10 mb-3" style={{ color: "hsl(var(--hud-text-dim) / 0.2)" }} />
            <p className="text-sm" style={{ color: "hsl(var(--hud-text-dim) / 0.5)" }}>
              {search ? "No groups found" : "No groups yet"}
            </p>
            <Button
              size="sm"
              variant="ghost"
              className="mt-3 gap-1.5"
              style={{ color: "hsl(var(--hud-cyan))" }}
              onClick={() => setShowCreate(true)}
            >
              <Plus className="h-4 w-4" />
              Create your first group
            </Button>
          </div>
        ) : (
          <div className="divide-y" style={{ borderColor: "hsl(var(--hud-border) / 0.06)" }}>
            {filtered.map(group => (
              <button
                key={group.id}
                onClick={() => openGroupChat(group)}
                className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-[hsl(var(--hud-surface)/0.3)] transition-colors text-left"
              >
                <div
                  className="w-11 h-11 rounded-full flex items-center justify-center text-sm font-bold shrink-0"
                  style={{ background: "hsl(var(--hud-cyan) / 0.1)", color: "hsl(var(--hud-cyan))" }}
                >
                  {getInitials(group.name)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-semibold leading-tight break-words line-clamp-2" style={{ color: "hsl(var(--hud-text))" }}>
                      {group.name}
                    </span>
                    <div className="flex items-center gap-1 shrink-0 ml-2">
                      {getGroupUnread(group) && (
                        <span className="px-1.5 py-0.5 rounded-full text-[9px] font-semibold" style={{ background: "hsl(var(--hud-cyan) / 0.14)", color: "hsl(var(--hud-cyan))" }}>
                          New
                        </span>
                      )}
                      <span className="text-[10px]" style={{ color: "hsl(var(--hud-text-dim) / 0.4)" }}>
                        {group.last_message_at ? formatMsgTime(group.last_message_at) : ""}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[11px] leading-tight break-words line-clamp-2" style={{ color: "hsl(var(--hud-text-dim) / 0.5)" }}>
                      {ghostMessagesHidden ? "Message hidden by Ghost Elite" : (group.last_message || group.description || ((group.kind || "group") === "channel" ? "No broadcasts yet" : "No messages yet"))}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <span className="text-[10px]" style={{ color: "hsl(var(--hud-text-dim) / 0.35)" }}>
                      {group.member_count} members
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full" style={{ background: "hsl(var(--hud-cyan) / 0.08)", color: "hsl(var(--hud-cyan))" }}>
                      {communityKindLabel(group.kind || "group")}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full" style={{ background: "hsl(var(--hud-surface))", color: "hsl(var(--hud-text-dim) / 0.65)" }}>
                      {communityVisibilityLabel(group.visibility || "private")}
                    </span>
                    {parseOrbitCommunityDescription(group.description).linkedStoreId && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded-full" style={{ background: "hsl(var(--hud-warning) / 0.08)", color: "hsl(var(--hud-warning))" }}>Store linked</span>
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Create Group Dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent style={{ background: "hsl(var(--hud-bg))", borderColor: "hsl(var(--hud-border) / 0.15)" }}>
          <DialogHeader>
            <DialogTitle style={{ color: "hsl(var(--hud-text))" }}>Create Orbit Space</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label className="text-xs" style={{ color: "hsl(var(--hud-text-dim))" }}>Space name *</Label>
              <Input
                value={newGroup.name}
                onChange={e => setNewGroup(p => ({ ...p, name: e.target.value }))}
                placeholder={newGroup.kind === "channel" ? "e.g. Seller Broadcast" : newGroup.kind === "community" ? "e.g. Dubai Hosts Community" : "e.g. Property Team"}
                className="mt-1 border-0"
                style={{ background: "hsl(var(--hud-surface))", color: "hsl(var(--hud-text))" }}
              />
            </div>
            <div>
              <Label className="text-xs" style={{ color: "hsl(var(--hud-text-dim))" }}>Description</Label>
              <Input
                value={newGroup.description}
                onChange={e => setNewGroup(p => ({ ...p, description: e.target.value }))}
                placeholder={newGroup.kind === "channel" ? "Broadcast updates for followers" : newGroup.kind === "community" ? "Shared space with members and admins" : "What's this group about?"}
                className="mt-1 border-0"
                style={{ background: "hsl(var(--hud-surface))", color: "hsl(var(--hud-text))" }}
              />
            </div>
            <div>
              <Label className="text-xs block mb-2" style={{ color: "hsl(var(--hud-text-dim))" }}>Type</Label>
              <div className="flex gap-2 flex-wrap">
                {([
                  ["group", "Group"],
                  ["channel", "Channel"],
                  ["community", "Community"],
                ] as const).map(([kind, label]) => (
                  <button
                    key={kind}
                    type="button"
                    onClick={() => setNewGroup((p) => ({ ...p, kind }))}
                    className="px-3 py-1.5 rounded-full text-[11px] font-medium"
                    style={{
                      background: newGroup.kind === kind ? "hsl(var(--hud-cyan) / 0.12)" : "hsl(var(--hud-surface))",
                      color: newGroup.kind === kind ? "hsl(var(--hud-cyan))" : "hsl(var(--hud-text-dim) / 0.7)",
                    }}
                  >{label}</button>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-xs block mb-2" style={{ color: "hsl(var(--hud-text-dim))" }}>Visibility</Label>
              <div className="flex gap-2 flex-wrap">
                {([
                  ["private", "Private"],
                  ["public", "Public"],
                ] as const).map(([visibility, label]) => (
                  <button
                    key={visibility}
                    type="button"
                    onClick={() => setNewGroup((p) => ({ ...p, visibility }))}
                    className="px-3 py-1.5 rounded-full text-[11px] font-medium"
                    style={{
                      background: newGroup.visibility === visibility ? "hsl(var(--hud-cyan) / 0.12)" : "hsl(var(--hud-surface))",
                      color: newGroup.visibility === visibility ? "hsl(var(--hud-cyan))" : "hsl(var(--hud-text-dim) / 0.7)",
                    }}
                  >{label}</button>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-xs" style={{ color: "hsl(var(--hud-text-dim))" }}>Linked store ID (optional)</Label>
              <Input
                value={newGroup.linkedStoreId}
                onChange={e => setNewGroup(p => ({ ...p, linkedStoreId: e.target.value }))}
                placeholder="store slug or provider id"
                className="mt-1 border-0"
                style={{ background: "hsl(var(--hud-surface))", color: "hsl(var(--hud-text))" }}
              />
            </div>
            <Button
              className="w-full"
              disabled={!newGroup.name.trim() || creating}
              onClick={handleCreate}
              style={{ background: "hsl(var(--hud-cyan))", color: "hsl(var(--hud-bg))" }}
            >
              {creating ? "Creating..." : `Create ${communityKindLabel(newGroup.kind)}`}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
