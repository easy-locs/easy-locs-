/**
 * CommCallsSection — Call history with single direction icon per entry.
 * Uses HUD tokens. Functional redial. Swipe-to-delete.
 */
import { useState, useEffect, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useCall } from "@/components/call/CallProvider";
import {
  Phone, PhoneMissed, Video, Search, ArrowDownLeft, ArrowUpRight,
} from "lucide-react";
import { format, isToday, isYesterday } from "date-fns";
import { Input } from "@/components/ui/input";
import { haptic } from "@/lib/haptics";
import { toast } from "sonner";
import SwipeableCallItem from "./SwipeableCallItem";
import { getSecurityConfig } from "@/lib/app-security";
import { getSecureCallReadiness } from "@/lib/orbit-secure-session";
import { Badge } from "@/components/ui/badge";
import { platformBus } from "@/lib/shared/platform-bus";
import OrbitPermissionsDiag from "@/components/orbit/OrbitPermissionsDiag";
import { Button } from "@/components/ui/button";

type CallFilter = "all" | "missed" | "incoming" | "outgoing";

interface CallLog {
  id: string;
  caller_id: string;
  callee_org_id: string;
  status: string;
  is_video: boolean;
  duration_seconds: number | null;
  created_at: string;
  context_label: string | null;
  context_type: string;
  context_id: string | null;
  thread_id: string | null;
  org_name?: string;
}

function formatCallTime(dateStr: string): string {
  const d = new Date(dateStr);
  if (isToday(d)) return format(d, "HH:mm");
  if (isYesterday(d)) return "Yesterday";
  return format(d, "dd/MM");
}

function formatDuration(s: number | null): string {
  if (!s) return "";
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return sec > 0 ? `${m}m ${sec}s` : `${m}m`;
}

export default function CommCallsSection() {
  const { user } = useAuth();
  const { startCall, isInCall, isStartingCall } = useCall();
  const [calls, setCalls] = useState<CallLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<CallFilter>("all");
  const [search, setSearch] = useState("");
  const [showCameraTools, setShowCameraTools] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [cameraShot, setCameraShot] = useState<string | null>(null);
  const [realtimeConnected, setRealtimeConnected] = useState(false);
  const cameraVideoRef = useRef<HTMLVideoElement | null>(null);
  const cameraCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const securityCfg = getSecurityConfig();
  const secureCall = getSecureCallReadiness();

  const loadCalls = useCallback(async () => {
    if (!user?.id) return;
    setLoading(true);

    const { data: callData } = await supabase
      .from("call_logs")
      .select("id, caller_id, callee_org_id, status, is_video, duration_seconds, created_at, context_label, context_type, context_id, thread_id")
      .order("created_at", { ascending: false })
      .limit(100);

    if (!callData || callData.length === 0) {
      setCalls([]);
      setLoading(false);
      return;
    }

    const orgIds = [...new Set(callData.map(c => c.callee_org_id))];
    const { data: orgs } = await supabase
      .from("orgs")
      .select("id, name")
      .in("id", orgIds);

    const orgMap = new Map((orgs || []).map(o => [o.id, o.name]));

    const enriched: CallLog[] = callData.map(c => ({
      ...c,
      org_name: orgMap.get(c.callee_org_id) || undefined,
    }));

    setCalls(enriched);
    setLoading(false);
  }, [user?.id]);

  useEffect(() => { loadCalls(); }, [loadCalls]);

  useEffect(() => {
    if (!user?.id) return;
    const channel = supabase
      .channel(`comm-calls-${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "call_logs" }, () => {
        void loadCalls();
      })
      .subscribe((status) => {
        setRealtimeConnected(status === "SUBSCRIBED");
      });

    const onFocus = () => { void loadCalls(); };
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onFocus);

    const unsubs = [
      platformBus.on("orbit:call_started", () => { void loadCalls(); }),
      platformBus.on("orbit:call_accepted", () => { void loadCalls(); }),
      platformBus.on("orbit:call_declined", () => { void loadCalls(); }),
      platformBus.on("orbit:call_missed", () => { void loadCalls(); }),
      platformBus.on("orbit:call_closed", () => { void loadCalls(); }),
    ];

    return () => {
      supabase.removeChannel(channel);
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("visibilitychange", onFocus);
      unsubs.forEach((fn) => fn());
    };
  }, [user?.id, loadCalls]);

  const handleRedial = useCallback(async (call: CallLog) => {
    if (isInCall || isStartingCall) {
      toast.info("Call already in progress");
      return;
    }

    haptic("medium");
    const peerName = call.org_name || call.context_label || "Contact";

    if (securityCfg.comm_safe_access_mode) {
      toast.info(call.is_video ? "Safe access video channel" : "Safe access encrypted call");
    }
    await startCall({
      orgId: call.callee_org_id,
      threadId: call.thread_id || undefined,
      contextType: call.context_type,
      contextId: call.context_id || undefined,
      contextLabel: call.context_label || undefined,
      peerName,
      isVideo: call.is_video,
    });
    platformBus.emit("orbit:call_started", {
      peerName,
      mode: call.is_video ? "video" : "voice",
      encrypted: securityCfg.comm_encrypted_calls,
      safeAccess: securityCfg.comm_safe_access_mode,
    }, "orbit", { userId: user?.id });
  }, [startCall, isInCall, isStartingCall, securityCfg, user?.id]);

  const filtered = calls.filter(c => {
    if (filter === "missed" && c.status !== "missed") return false;
    if (filter === "incoming" && c.caller_id === user?.id) return false;
    if (filter === "outgoing" && c.caller_id !== user?.id) return false;
    if (search) {
      const q = search.toLowerCase();
      const searchable = [c.context_label, c.org_name].filter(Boolean).join(" ").toLowerCase();
      return searchable.includes(q);
    }
    return true;
  });

  const filters: { id: CallFilter; label: string }[] = [
    { id: "all", label: "All" },
    { id: "missed", label: "Missed" },
    { id: "incoming", label: "In" },
    { id: "outgoing", label: "Out" },
  ];

  const missedCount = calls.filter(c => c.status === "missed").length;

  /** Single unified call icon with direction arrow overlay */
  const getCallIcon = (call: CallLog) => {
    const isOutgoing = call.caller_id === user?.id;
    const isMissed = call.status === "missed";
    const isVideoCall = call.is_video;

    // Choose color
    const color = isMissed
      ? "hsl(var(--hud-danger))"
      : isOutgoing
        ? "hsl(var(--hud-cyan))"
        : "hsl(var(--hud-success))";

    // Single icon: Phone or Video
    const MainIcon = isVideoCall ? Video : Phone;

    // Direction arrow overlay
    const ArrowIcon = isMissed
      ? PhoneMissed
      : isOutgoing
        ? ArrowUpRight
        : ArrowDownLeft;

    return (
      <div className="relative">
        <MainIcon className="h-4.5 w-4.5" style={{ color, width: 18, height: 18 }} />
        <div
          className="absolute -bottom-0.5 -right-0.5 rounded-full flex items-center justify-center"
          style={{
            width: 12,
            height: 12,
            background: "hsl(var(--hud-bg))",
            border: `1.5px solid ${color}`,
          }}
        >
          <ArrowIcon style={{ width: 7, height: 7, color }} />
        </div>
      </div>
    );
  };


  const stopCameraTest = useCallback(() => {
    if (cameraStreamRef.current) {
      cameraStreamRef.current.getTracks().forEach((t) => t.stop());
      cameraStreamRef.current = null;
    }
    setCameraActive(false);
  }, []);

  const startCameraTest = useCallback(async () => {
    stopCameraTest();
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      cameraStreamRef.current = stream;
      setCameraActive(true);
      if (cameraVideoRef.current) {
        cameraVideoRef.current.srcObject = stream;
        await cameraVideoRef.current.play();
      }
      toast.success("Camera opened successfully");
    } catch (err: any) {
      setCameraError(err?.message || "Unable to open camera");
      toast.error("Camera could not be opened");
      stopCameraTest();
    }
  }, [stopCameraTest]);

  const captureCameraShot = useCallback(() => {
    const video = cameraVideoRef.current;
    const canvas = cameraCanvasRef.current;
    if (!video || !canvas || video.readyState < 2) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const w = video.videoWidth || 640;
    const h = video.videoHeight || 480;
    canvas.width = w;
    canvas.height = h;
    ctx.drawImage(video, 0, 0, w, h);
    setCameraShot(canvas.toDataURL("image/png"));
    toast.success("Photo captured from camera");
  }, []);

  useEffect(() => () => stopCameraTest(), [stopCameraTest]);

  const getDisplayLabel = (call: CallLog) => {
    const parts: string[] = [];
    if (call.org_name) parts.push(call.org_name);
    if (call.context_label && call.context_label !== call.org_name) parts.push(call.context_label);
    if (parts.length > 0) return parts;
    return [call.caller_id === user?.id ? "Outgoing call" : "Incoming call"];
  };

  return (
    <div className="flex-1 flex flex-col min-h-0" style={{ background: "hsl(var(--hud-bg))" }}>
      {/* Header */}
      <div className="px-4 pt-4 pb-2 shrink-0">
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <h2 className="text-lg font-bold" style={{ color: "hsl(var(--hud-text))" }}>Calls</h2>
          <Badge variant="outline" className="text-[10px]">{realtimeConnected ? "Realtime on" : "Realtime off"}</Badge>
          {securityCfg.comm_encrypted_calls && <Badge variant="outline" className="text-[10px]">Encrypted calls</Badge>}
          {securityCfg.comm_safe_access_mode && <Badge variant="outline" className="text-[10px]">Safe access</Badge>}
          {securityCfg.comm_signal_style_mode && <Badge variant="outline" className="text-[10px]">Signal-style</Badge>}
          {securityCfg.comm_secure_voice_notes && <Badge variant="outline" className="text-[10px]">Secure voice</Badge>}
        </div>
        <div className="mb-3 rounded-2xl border border-[hsl(var(--hud-border)/0.12)] bg-[hsl(var(--hud-surface)/0.45)] p-3">
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <Badge variant="secondary" className="text-[10px]">Secure call {secureCall.level}</Badge>
            {secureCall.profileMasked && <Badge variant="outline" className="text-[10px]">Ghost profile mask</Badge>}
          </div>
          <p className="text-[11px] leading-relaxed" style={{ color: "hsl(var(--hud-text-dim) / 0.72)" }}>{secureCall.summary}</p>
        </div>

        {/* Search */}
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4" style={{ color: "hsl(var(--hud-text-dim) / 0.4)" }} />
          <Input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search..."
            className="pl-9 h-9 text-sm border-0"
            style={{
              background: "hsl(var(--hud-surface))",
              color: "hsl(var(--hud-text))",
            }}
          />
        </div>

        <div className="mb-3 rounded-2xl border border-[hsl(var(--hud-border)/0.12)] bg-[hsl(var(--hud-surface)/0.55)] p-3 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div>
              <p className="text-xs font-semibold" style={{ color: "hsl(var(--hud-text))" }}>Camera & encrypted call tools</p>
              <p className="text-[10px]" style={{ color: "hsl(var(--hud-text-dim) / 0.65)" }}>Verify camera, snapshot, mic/cam permissions and secure call readiness.</p>
            </div>
            <Button type="button" size="sm" variant="outline" onClick={() => setShowCameraTools((v) => !v)}>{showCameraTools ? "Hide" : "Open"}</Button>
          </div>
          {showCameraTools && (
            <div className="space-y-3">
              <OrbitPermissionsDiag />
              <div className="rounded-xl overflow-hidden bg-black/90 aspect-video">
                {cameraActive ? <video ref={cameraVideoRef} className="h-full w-full object-cover" playsInline muted /> : <div className="flex h-full items-center justify-center text-center px-4"><p className="text-xs text-white/70">Open camera to verify encrypted call camera access and capture a photo test.</p></div>}
              </div>
              <div className="flex flex-wrap gap-2">
                <Button type="button" size="sm" onClick={() => void startCameraTest()}>Open camera</Button>
                <Button type="button" size="sm" variant="outline" onClick={captureCameraShot} disabled={!cameraActive}>Take photo</Button>
                <Button type="button" size="sm" variant="outline" onClick={stopCameraTest} disabled={!cameraActive}>Stop</Button>
              </div>
              {cameraError && <p className="text-[11px] text-red-500">{cameraError}</p>}
              {cameraShot && <img src={cameraShot} alt="Camera test" className="w-full rounded-xl border border-[hsl(var(--hud-border)/0.12)]" />}
              <canvas ref={cameraCanvasRef} className="hidden" />
            </div>
          )}
        </div>

        {/* Filters */}
        <div className="flex gap-2">
          {filters.map(f => (
            <button
              key={f.id}
              onClick={() => { haptic("selection"); setFilter(f.id); }}
              className="px-3 py-1.5 rounded-full text-xs font-medium transition-all"
              style={{
                background: filter === f.id ? "hsl(var(--hud-cyan) / 0.12)" : "hsl(var(--hud-surface) / 0.5)",
                color: filter === f.id ? "hsl(var(--hud-cyan))" : "hsl(var(--hud-text-dim) / 0.6)",
                border: `1px solid ${filter === f.id ? "hsl(var(--hud-cyan) / 0.2)" : "transparent"}`,
              }}
            >
              {f.label}
              {f.id === "missed" && missedCount > 0 && (
                <span className="ml-1 text-[10px] font-bold" style={{ color: "hsl(var(--hud-danger))" }}>
                  {missedCount}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Call list */}
      <div className="flex-1 overflow-y-auto px-2">
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <div className="w-6 h-6 border-2 rounded-full animate-spin" style={{ borderColor: "hsl(var(--hud-cyan) / 0.3)", borderTopColor: "hsl(var(--hud-cyan))" }} />
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <Phone className="h-10 w-10 mb-3" style={{ color: "hsl(var(--hud-text-dim) / 0.2)" }} />
            <p className="text-sm" style={{ color: "hsl(var(--hud-text-dim) / 0.5)" }}>
              {filter === "missed" ? "No missed calls" : "No calls yet"}
            </p>
            <p className="text-xs mt-1" style={{ color: "hsl(var(--hud-text-dim) / 0.3)" }}>
              Start a call from any conversation
            </p>
          </div>
        ) : (
          <div className="divide-y" style={{ borderColor: "hsl(var(--hud-border) / 0.06)" }}>
            {filtered.map(call => {
              const labels = getDisplayLabel(call);
              const primaryLabel = labels[0];
              const secondaryLabel = labels.length > 1 ? labels[1] : null;

              const handleDeleteCall = async () => {
                const { error } = await supabase.from("call_logs").delete().eq("id", call.id);
                if (error) { toast.error("Failed to delete call"); return; }
                setCalls(prev => prev.filter(c => c.id !== call.id));
                toast.success("Call deleted");
              };

              return (
                <SwipeableCallItem key={call.id} onDelete={handleDeleteCall}>
                  <button
                    type="button"
                    onClick={() => void handleRedial(call)}
                    disabled={isInCall || isStartingCall}
                    className="w-full flex items-center gap-3 px-3 py-3 transition-colors text-left disabled:opacity-60"
                    style={{ background: "hsl(var(--hud-bg))" }}
                    onMouseEnter={e => (e.currentTarget.style.background = "hsl(var(--hud-surface) / 0.3)")}
                    onMouseLeave={e => (e.currentTarget.style.background = "hsl(var(--hud-bg))")}
                  >
                    {/* Single unified icon */}
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center shrink-0"
                      style={{
                        background: call.status === "missed"
                          ? "hsl(var(--hud-danger) / 0.08)"
                          : "hsl(var(--hud-surface))",
                      }}
                    >
                      {getCallIcon(call)}
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <span
                        className="text-sm font-medium block leading-tight break-words line-clamp-2"
                        style={{
                          color: call.status === "missed" ? "hsl(var(--hud-danger))" : "hsl(var(--hud-text))",
                        }}
                      >
                        {primaryLabel}
                      </span>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        {secondaryLabel && (
                          <span className="text-[11px] max-w-[180px] leading-tight break-words line-clamp-2" style={{ color: "hsl(var(--hud-cyan) / 0.7)" }}>
                            {secondaryLabel}
                          </span>
                        )}
                        {secondaryLabel && <span className="text-[11px]" style={{ color: "hsl(var(--hud-text-dim) / 0.25)" }}>·</span>}
                        <span className="text-[11px]" style={{ color: "hsl(var(--hud-text-dim) / 0.5)" }}>
                          {call.status === "ended" ? formatDuration(call.duration_seconds) : call.status}
                        </span>
                      </div>
                    </div>

                    {/* Time */}
                    <span className="text-[11px] tabular-nums shrink-0" style={{ color: "hsl(var(--hud-text-dim) / 0.4)" }}>
                      {formatCallTime(call.created_at)}
                    </span>
                  </button>
                </SwipeableCallItem>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
