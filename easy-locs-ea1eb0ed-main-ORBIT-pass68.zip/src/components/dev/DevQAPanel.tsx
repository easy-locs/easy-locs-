import { useState } from "react";
import { Gauge, RefreshCw } from "lucide-react";
import { runSmartQA, type QAReport } from "@/lib/smart-qa";

export default function DevQAPanel() {
  const [report, setReport] = useState<QAReport | null>(null);

  const run = () => setReport(runSmartQA());

  if (!import.meta.env.DEV) return null;

  return (
    <aside className="fixed top-20 right-4 z-[9998] w-[min(92vw,340px)] rounded-2xl border bg-background/95 shadow-2xl backdrop-blur">
      <div className="flex items-center gap-3 border-b px-4 py-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-muted">
          <Gauge className="h-4 w-4" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold">Smart QA</div>
          <div className="text-xs text-muted-foreground">Global platform quality score</div>
        </div>
        <button
          type="button"
          onClick={run}
          className="inline-flex h-9 w-9 items-center justify-center rounded-md border hover:bg-muted"
          aria-label="Run smart QA"
        >
          <RefreshCw className="h-4 w-4" />
        </button>
      </div>

      <div className="space-y-3 px-4 py-3 text-sm">
        <div className="rounded-xl border p-3 text-center">
          <div className="text-[11px] uppercase text-muted-foreground">Global score</div>
          <div className="text-3xl font-bold">{report?.score ?? "--"}</div>
          {report && <div className="mt-1 text-xs text-muted-foreground">Inspector issues: {report.inspectorIssues}</div>}
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="rounded-lg border p-2">Accessibility <span className="float-right font-semibold">{report?.metrics.accessibility ?? "--"}</span></div>
          <div className="rounded-lg border p-2">Performance <span className="float-right font-semibold">{report?.metrics.performance ?? "--"}</span></div>
          <div className="rounded-lg border p-2">SEO <span className="float-right font-semibold">{report?.metrics.seo ?? "--"}</span></div>
          <div className="rounded-lg border p-2">Security <span className="float-right font-semibold">{report?.metrics.security ?? "--"}</span></div>
        </div>
      </div>
    </aside>
  );
}
