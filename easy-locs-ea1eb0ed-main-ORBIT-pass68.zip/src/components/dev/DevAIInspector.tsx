import { useMemo, useState } from "react";
import { Bot, RefreshCw, Wand2 } from "lucide-react";
import { runAIInspector, type AIInspectionReport } from "@/lib/ai-inspector";
import { applySafeAutoFixes, type AutoFixResult } from "@/lib/ai-autofix";

export default function DevAIInspector() {
  const [report, setReport] = useState<AIInspectionReport | null>(null);
  const [fixResult, setFixResult] = useState<AutoFixResult | null>(null);

  const run = () => {
    setReport(runAIInspector());
    setFixResult(null);
  };

  const applyFixes = () => {
    const latest = runAIInspector();
    setReport(latest);
    setFixResult(applySafeAutoFixes(latest));
    setReport(runAIInspector());
  };

  const topIssues = useMemo(() => report?.issues.slice(0, 6) ?? [], [report]);

  if (!import.meta.env.DEV) return null;

  return (
    <aside className="fixed bottom-4 left-4 z-[9999] w-[min(92vw,420px)] rounded-2xl border bg-background/95 shadow-2xl backdrop-blur">
      <div className="flex items-center gap-3 border-b px-4 py-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-muted">
          <Bot className="h-4 w-4" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold">AI Inspector</div>
          <div className="text-xs text-muted-foreground">Scan UX, SEO, a11y, performance, security</div>
        </div>
        <button
          type="button"
          onClick={run}
          className="inline-flex h-9 w-9 items-center justify-center rounded-md border hover:bg-muted"
          aria-label="Run AI inspector"
        >
          <RefreshCw className="h-4 w-4" />
        </button>
      </div>

      <div className="space-y-3 px-4 py-3 text-sm">
        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <div className="rounded-lg border p-2">
            <div className="text-[11px] uppercase text-muted-foreground">Score</div>
            <div className="text-lg font-bold">{report?.score ?? "--"}</div>
          </div>
          <div className="rounded-lg border p-2">
            <div className="text-[11px] uppercase text-muted-foreground">Issues</div>
            <div className="text-lg font-bold">{report?.summary.total ?? 0}</div>
          </div>
          <div className="rounded-lg border p-2">
            <div className="text-[11px] uppercase text-muted-foreground">High</div>
            <div className="text-lg font-bold">{report?.summary.bySeverity.high ?? 0}</div>
          </div>
        </div>

        <div className="flex gap-2">
          <button type="button" onClick={run} className="flex-1 rounded-md border px-3 py-2 hover:bg-muted">
            Run inspection
          </button>
          <button type="button" onClick={applyFixes} className="flex-1 rounded-md border px-3 py-2 hover:bg-muted">
            <span className="inline-flex items-center gap-2"><Wand2 className="h-4 w-4" /> Apply safe fixes</span>
          </button>
        </div>

        {fixResult && (
          <div className="rounded-xl border bg-muted/20 p-3 text-xs">
            <div className="font-semibold">Auto-fix result</div>
            <div className="mt-1 text-muted-foreground">Applied {fixResult.applied} change(s){fixResult.skipped ? ` • skipped ${fixResult.skipped}` : ""}</div>
            {fixResult.changes.length > 0 && (
              <ul className="mt-2 space-y-1">
                {fixResult.changes.slice(0, 4).map((change) => (
                  <li key={change}>• {change}</li>
                ))}
              </ul>
            )}
          </div>
        )}

        {report && topIssues.length > 0 ? (
          <div className="space-y-2">
            {topIssues.map((issue, index) => (
              <div key={`${issue.rule}-${index}`} className="rounded-xl border bg-muted/20 p-3 text-xs">
                <div className="flex items-center justify-between gap-2">
                  <div className="font-semibold uppercase tracking-wide">{issue.type}</div>
                  <div className="rounded-md border px-2 py-0.5">{issue.severity}</div>
                </div>
                <div className="mt-1 font-medium">{issue.message}</div>
                {issue.suggestion && <div className="mt-1 text-muted-foreground">Fix: {issue.suggestion}</div>}
              </div>
            ))}
          </div>
        ) : report ? (
          <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs">
            No issues detected by the AI inspector.
          </div>
        ) : null}
      </div>
    </aside>
  );
}
