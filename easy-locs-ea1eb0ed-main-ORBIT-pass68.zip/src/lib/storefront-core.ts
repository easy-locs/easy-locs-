export type StorefrontVisibility = "public" | "private" | "unlisted";

export type StorefrontMediaItem = {
  url: string;
  kind: "image" | "video";
  source: "profile" | "service";
  title?: string;
};

export function detectMediaKind(url: string | null | undefined): "image" | "video" {
  const value = (url || "").toLowerCase();
  if (/(\.mp4|\.webm|\.mov|\.m4v)(\?|$)/.test(value)) return "video";
  if (value.includes("video")) return "video";
  return "image";
}

export function getStorefrontVisibility(profile: Record<string, any> | null | undefined): StorefrontVisibility {
  const raw = String(
    profile?.storefront_visibility ||
    profile?.visibility ||
    (profile?.private_storefront ? "private" : "public") ||
    "public",
  ).toLowerCase();

  if (raw === "private") return "private";
  if (raw === "unlisted" || raw === "members_only") return "unlisted";
  return "public";
}

export function collectStorefrontMedia(profile: Record<string, any> | null | undefined, services: any[]): StorefrontMediaItem[] {
  const items: StorefrontMediaItem[] = [];
  const seen = new Set<string>();

  const push = (url: string | null | undefined, source: StorefrontMediaItem["source"], title?: string) => {
    if (!url || seen.has(url)) return;
    seen.add(url);
    items.push({ url, kind: detectMediaKind(url), source, title });
  };

  push(profile?.cover_photo_url, "profile", profile?.display_name || profile?.company_name || "Storefront");
  push(profile?.avatar_url, "profile", profile?.display_name || profile?.company_name || "Storefront");
  push(profile?.featured_video_url, "profile", profile?.display_name || profile?.company_name || "Featured video");

  for (const service of services || []) {
    const media = Array.isArray(service?.photo_urls) ? service.photo_urls : [];
    for (const url of media) push(url, "service", service?.title || "Service");
    push(service?.photo_url, "service", service?.title || "Service");
    push(service?.video_url, "service", service?.title || "Service");
  }

  return items;
}



export type DetectionLike = { city?: string | null; country?: string | null } | null | undefined;

export type SellerSignalSummary = {
  visibility: StorefrontVisibility;
  serviceCount: number;
  mediaCount: number;
  videoCount: number;
  featuredVideo: boolean;
  commerceReady: boolean;
  localBoost: boolean;
};

export function isLocalToDetection(
  entry: { city?: string | null; country?: string | null } | null | undefined,
  detection?: DetectionLike,
) {
  if (!entry || !detection) return false;
  const cityOk = detection.city && entry.city && entry.city.toLowerCase() == detection.city.toLowerCase();
  const countryOk = detection.country && entry.country && entry.country.toLowerCase() === detection.country.toLowerCase();
  return Boolean(cityOk || countryOk);
}

export function computeSellerSignalSummary(
  profile: Record<string, any> | null | undefined,
  services: any[] = [],
  detection?: DetectionLike,
): SellerSignalSummary {
  const visibility = getStorefrontVisibility(profile);
  const media = collectStorefrontMedia(profile, services);
  const videoCount = media.filter((item) => item.kind === "video").length;
  const serviceCount = Array.isArray(services) ? services.length : 0;
  return {
    visibility,
    serviceCount,
    mediaCount: media.length,
    videoCount,
    featuredVideo: !!profile?.featured_video_url,
    commerceReady: visibility === "public" && serviceCount > 0,
    localBoost: isLocalToDetection({ city: profile?.city, country: profile?.country }, detection),
  };
}

export function rankFeedEntries<T extends {
  city?: string | null;
  country?: string | null;
  visibility?: StorefrontVisibility;
  category?: string | null;
  source?: string | null;
  price?: number | null;
}>(entries: T[], detection?: DetectionLike) {
  return [...entries].sort((a, b) => scoreEntry(b, detection) - scoreEntry(a, detection));
}

function scoreEntry(
  entry: { city?: string | null; country?: string | null; visibility?: StorefrontVisibility; category?: string | null; source?: string | null; price?: number | null },
  detection?: DetectionLike,
) {
  let score = 0;
  if (isLocalToDetection(entry, detection)) score += 50;
  if (entry.visibility === "public") score += 20;
  if (entry.category === "commerce") score += 15;
  if (entry.source === "service") score += 10;
  if (typeof entry.price === "number" && Number.isFinite(entry.price) && entry.price > 0) score += 5;
  return score;
}

export function buildOrbitContactPath(params: {
  sellerName?: string | null;
  storeSlug?: string | null;
  providerId?: string | null;
  context?: string | null;
  source?: string | null;
}) {
  const search = new URLSearchParams();
  if (params.sellerName) search.set("search", params.sellerName);
  if (params.storeSlug) search.set("store", params.storeSlug);
  if (params.providerId) search.set("providerId", params.providerId);
  if (params.context) search.set("context", params.context);
  if (params.source) search.set("source", params.source);
  return `/dashboard/communication?section=chats&${search.toString()}`;
}

export function buildWalletContactPath(params: {
  sellerName?: string | null;
  providerId?: string | null;
  storeSlug?: string | null;
  mode?: "send" | "receive";
  amount?: number | null;
  currency?: string | null;
  source?: string | null;
}) {
  const search = new URLSearchParams();
  const mode = params.mode || "send";
  search.set("action", mode);
  search.set("view", mode);
  if (params.providerId) search.set("recipientId", params.providerId);
  if (params.sellerName) search.set("recipientName", params.sellerName);
  if (params.storeSlug) search.set("store", params.storeSlug);
  if (params.amount != null && Number.isFinite(Number(params.amount)) && Number(params.amount) > 0) {
    search.set("amount", String(params.amount));
  }
  if (params.currency) search.set("currency", params.currency);
  if (params.source) search.set("source", params.source);
  return `/dashboard/wallet?${search.toString()}`;
}

export function buildVideoHubPath(params: {
  storeSlug?: string | null;
  providerId?: string | null;
  sellerName?: string | null;
  mode?: "all" | "commerce" | "local";
  visibility?: "all" | "public" | "private";
  source?: string | null;
}) {
  const search = new URLSearchParams();
  if (params.mode) search.set("mode", params.mode);
  if (params.storeSlug) search.set("store", params.storeSlug);
  if (params.providerId) search.set("providerId", params.providerId);
  if (params.sellerName) search.set("search", params.sellerName);
  if (params.visibility && params.visibility !== "all") search.set("visibility", params.visibility);
  if (params.source) search.set("source", params.source);
  return `/dashboard/video-hub?${search.toString()}`;
}

export function canExposeStorefrontPricing(visibility: StorefrontVisibility) {
  return visibility === "public";
}

export function buildStorefrontAccessLabel(visibility: StorefrontVisibility) {
  return visibility === "public" ? "pay" : "request_access";
}


export function buildLiveCommercePath(params: {
  storeSlug?: string | null;
  providerId?: string | null;
  sellerName?: string | null;
  mode?: "all" | "commerce" | "local";
  visibility?: "all" | "public" | "private";
  source?: string | null;
}) {
  const search = new URLSearchParams();
  if (params.mode) search.set("mode", params.mode);
  if (params.storeSlug) search.set("store", params.storeSlug);
  if (params.providerId) search.set("providerId", params.providerId);
  if (params.sellerName) search.set("search", params.sellerName);
  if (params.visibility && params.visibility !== "all") search.set("visibility", params.visibility);
  if (params.source) search.set("source", params.source);
  return `/dashboard/live-hub?${search.toString()}`;
}
