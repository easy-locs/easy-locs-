import { getSecurityConfig, shouldHideWalletSensitiveData, shouldMaskSensitiveArea } from "@/lib/app-security";

export type OrbitSecureProfile = {
  encryptedCalls: boolean;
  secureVoice: boolean;
  signalStyle: boolean;
  safeAccess: boolean;
  ghostEnabled: boolean;
  walletMasked: boolean;
  messagesMasked: boolean;
  locationMasked: boolean;
  profileMasked: boolean;
  commerceLocked: boolean;
};

export function getOrbitSecureProfile(): OrbitSecureProfile {
  const cfg = getSecurityConfig();
  const walletMasked = shouldHideWalletSensitiveData();
  return {
    encryptedCalls: !!cfg.comm_encrypted_calls,
    secureVoice: !!cfg.comm_secure_voice_notes,
    signalStyle: !!cfg.comm_signal_style_mode,
    safeAccess: !!cfg.comm_safe_access_mode,
    ghostEnabled: !!cfg.ghost_elite_enabled,
    walletMasked,
    messagesMasked: shouldMaskSensitiveArea("messages"),
    locationMasked: shouldMaskSensitiveArea("location"),
    profileMasked: shouldMaskSensitiveArea("profile"),
    commerceLocked: walletMasked || (cfg.ghost_elite_enabled && cfg.ghost_hide_profile),
  };
}

export function getSecureCallReadiness() {
  const profile = getOrbitSecureProfile();
  return {
    ...profile,
    level: profile.encryptedCalls && profile.signalStyle ? "hardened" : profile.encryptedCalls ? "encrypted" : "basic",
    canPlaceSecureCall: profile.encryptedCalls && !profile.profileMasked,
    summary: profile.encryptedCalls
      ? profile.safeAccess
        ? "Encrypted calling with safe access active"
        : "Encrypted calling active"
      : "Calling active without encrypted enforcement",
  } as const;
}

export function getSecureCommerceReadiness() {
  const profile = getOrbitSecureProfile();
  return {
    ...profile,
    canExposePricing: !profile.walletMasked,
    canOpenWallet: !profile.commerceLocked,
    summary: profile.commerceLocked
      ? "Ghost Elite is limiting pricing and wallet exposure"
      : profile.safeAccess
        ? "Secure commerce path with safe access and wallet protection"
        : "Standard commerce path connected to Orbit and Wallet",
  } as const;
}


export function getSecureMediaReadiness() {
  const profile = getOrbitSecureProfile();
  const encryptedMediaReady = profile.signalStyle || profile.secureVoice;
  return {
    ...profile,
    encryptedMediaReady,
    canOpenSensitiveMedia: !profile.messagesMasked && !profile.profileMasked,
    summary: encryptedMediaReady
      ? profile.safeAccess
        ? "Secure media path with safe access active"
        : "Secure media path active"
      : "Media is available without strict encrypted enforcement",
  } as const;
}
