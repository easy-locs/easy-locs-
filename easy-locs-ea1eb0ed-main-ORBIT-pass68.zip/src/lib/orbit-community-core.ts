export type OrbitCommunityKind = 'group' | 'channel' | 'community';
export type OrbitCommunityVisibility = 'public' | 'private';
export type OrbitCommunityRole = 'owner' | 'admin' | 'member' | 'viewer';

const PREFIX = '[orbit-meta]';

export interface OrbitCommunityMeta {
  kind: OrbitCommunityKind;
  visibility: OrbitCommunityVisibility;
  plainDescription: string | null;
  pinnedMessageId?: string | null;
  pinnedMessagePreview?: string | null;
  linkedStoreId?: string | null;
}

export function encodeOrbitCommunityDescription(
  description: string | null | undefined,
  kind: OrbitCommunityKind,
  visibility: OrbitCommunityVisibility,
  extras?: Partial<Omit<OrbitCommunityMeta, 'kind' | 'visibility' | 'plainDescription'>>,
): string {
  const clean = (description || '').trim();
  const payload = {
    kind,
    visibility,
    d: clean || null,
    pinnedMessageId: extras?.pinnedMessageId ?? null,
    pinnedMessagePreview: extras?.pinnedMessagePreview ?? null,
    linkedStoreId: extras?.linkedStoreId ?? null,
  };
  return `${PREFIX}${JSON.stringify(payload)}`;
}

export function parseOrbitCommunityDescription(description: string | null | undefined): OrbitCommunityMeta {
  const raw = (description || '').trim();
  if (!raw.startsWith(PREFIX)) {
    return {
      kind: 'group',
      visibility: 'private',
      plainDescription: raw || null,
      pinnedMessageId: null,
      pinnedMessagePreview: null,
      linkedStoreId: null,
    };
  }
  try {
    const parsed = JSON.parse(raw.slice(PREFIX.length));
    return {
      kind: parsed.kind === 'channel' || parsed.kind === 'community' ? parsed.kind : 'group',
      visibility: parsed.visibility === 'public' ? 'public' : 'private',
      plainDescription: typeof parsed.d === 'string' ? parsed.d : null,
      pinnedMessageId: typeof parsed.pinnedMessageId === 'string' ? parsed.pinnedMessageId : null,
      pinnedMessagePreview: typeof parsed.pinnedMessagePreview === 'string' ? parsed.pinnedMessagePreview : null,
      linkedStoreId: typeof parsed.linkedStoreId === 'string' ? parsed.linkedStoreId : null,
    };
  } catch {
    return {
      kind: 'group',
      visibility: 'private',
      plainDescription: raw || null,
      pinnedMessageId: null,
      pinnedMessagePreview: null,
      linkedStoreId: null,
    };
  }
}

export function updateOrbitCommunityDescription(
  currentDescription: string | null | undefined,
  updates: Partial<OrbitCommunityMeta>,
): string {
  const current = parseOrbitCommunityDescription(currentDescription);
  return encodeOrbitCommunityDescription(
    updates.plainDescription ?? current.plainDescription,
    updates.kind ?? current.kind,
    updates.visibility ?? current.visibility,
    {
      pinnedMessageId: updates.pinnedMessageId ?? current.pinnedMessageId ?? null,
      pinnedMessagePreview: updates.pinnedMessagePreview ?? current.pinnedMessagePreview ?? null,
      linkedStoreId: updates.linkedStoreId ?? current.linkedStoreId ?? null,
    },
  );
}

export function communityKindLabel(kind: OrbitCommunityKind): string {
  if (kind === 'channel') return 'Channel';
  if (kind === 'community') return 'Community';
  return 'Group';
}

export function communityVisibilityLabel(visibility: OrbitCommunityVisibility): string {
  return visibility === 'public' ? 'Public' : 'Private';
}

export function communityPostRuleLabel(kind: OrbitCommunityKind): string {
  if (kind === 'channel') return 'Admin broadcast';
  if (kind === 'community') return 'Members can post';
  return 'Open conversation';
}

export function canCommunityRolePost(kind: OrbitCommunityKind, role: OrbitCommunityRole | null | undefined): boolean {
  const safeRole = role || 'viewer';
  if (kind === 'channel') return safeRole === 'owner' || safeRole === 'admin';
  return safeRole !== 'viewer';
}

export function canCommunityRoleInvite(kind: OrbitCommunityKind, role: OrbitCommunityRole | null | undefined): boolean {
  const safeRole = role || 'viewer';
  if (kind === 'channel') return safeRole === 'owner' || safeRole === 'admin';
  if (kind === 'community') return safeRole === 'owner' || safeRole === 'admin' || safeRole === 'member';
  return safeRole !== 'viewer';
}


export interface OrbitCommunityStorefrontLinks {
  storePage: string;
  videoHub: string;
  liveHub: string;
}

export function buildCommunityStorefrontLinks(linkedStoreId: string | null | undefined): OrbitCommunityStorefrontLinks | null {
  const storeId = (linkedStoreId || '').trim();
  if (!storeId) return null;
  const encoded = encodeURIComponent(storeId);
  return {
    storePage: `/store/${encoded}`,
    videoHub: `/dashboard/video-hub?store=${encoded}&source=orbit_community`,
    liveHub: `/dashboard/live-hub?store=${encoded}&source=orbit_community`,
  };
}


export interface OrbitCommunitySummary {
  hasPinnedPost: boolean;
  hasLinkedStore: boolean;
  isBroadcastOnly: boolean;
  commerceReady: boolean;
}

export function computeOrbitCommunitySummary(meta: OrbitCommunityMeta | null | undefined): OrbitCommunitySummary {
  const safe = meta || parseOrbitCommunityDescription(null);
  return {
    hasPinnedPost: Boolean(safe.pinnedMessageId),
    hasLinkedStore: Boolean((safe.linkedStoreId || '').trim()),
    isBroadcastOnly: safe.kind === 'channel',
    commerceReady: Boolean((safe.linkedStoreId || '').trim()) && (safe.kind === 'channel' || safe.kind === 'community'),
  };
}

export function buildCommunityWalletPath(
  linkedStoreId: string | null | undefined,
  opts?: { amount?: number | null; currency?: string | null; source?: string | null }
): string | null {
  const storeId = (linkedStoreId || '').trim();
  if (!storeId) return null;
  const params = new URLSearchParams();
  params.set('view', 'send');
  params.set('store', storeId);
  params.set('source', opts?.source || 'orbit_community');
  if (typeof opts?.amount === 'number' && Number.isFinite(opts.amount) && opts.amount > 0) {
    params.set('amount', String(opts.amount));
  }
  if (opts?.currency) {
    params.set('currency', opts.currency);
  }
  return `/dashboard/wallet?${params.toString()}`;
}


export interface OrbitCommunityReadState {
  [groupId: string]: string;
}

const READ_STATE_PREFIX = 'orbit-community-read-state:';

export function getOrbitCommunityReadState(userId: string | null | undefined): OrbitCommunityReadState {
  const safeUserId = (userId || '').trim();
  if (!safeUserId || typeof window === 'undefined') return {};
  try {
    const raw = window.localStorage.getItem(`${READ_STATE_PREFIX}${safeUserId}`);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

export function setOrbitCommunityReadAt(userId: string | null | undefined, groupId: string, iso: string): OrbitCommunityReadState {
  const safeUserId = (userId || '').trim();
  const safeGroupId = (groupId || '').trim();
  if (!safeUserId || !safeGroupId || typeof window === 'undefined') return {};
  const next = {
    ...getOrbitCommunityReadState(safeUserId),
    [safeGroupId]: iso,
  };
  try {
    window.localStorage.setItem(`${READ_STATE_PREFIX}${safeUserId}`, JSON.stringify(next));
    window.dispatchEvent(new CustomEvent('orbit:community-read-state-changed', { detail: { userId: safeUserId, groupId: safeGroupId, iso } }));
  } catch {
    // ignore storage failures
  }
  return next;
}

export function countOrbitCommunityUnread(
  groups: Array<{ id: string; last_message_at?: string | null }>,
  readState: OrbitCommunityReadState,
): number {
  return groups.reduce((acc, group) => {
    const lastAt = group.last_message_at ? +new Date(group.last_message_at) : 0;
    const readAt = readState[group.id] ? +new Date(readState[group.id]) : 0;
    return acc + (lastAt > readAt ? 1 : 0);
  }, 0);
}
