import type { AIInspectionReport } from "@/lib/ai-inspector";

export interface AutoFixResult {
  applied: number;
  skipped: number;
  changes: string[];
}

function safeText(value: string | null | undefined, fallback: string): string {
  const trimmed = value?.trim();
  return trimmed ? trimmed.slice(0, 120) : fallback;
}

export function applySafeAutoFixes(report?: AIInspectionReport | null): AutoFixResult {
  if (typeof document === "undefined") {
    return { applied: 0, skipped: 0, changes: [] };
  }

  const changes: string[] = [];
  let applied = 0;
  let skipped = 0;

  const imgs = Array.from(document.querySelectorAll<HTMLImageElement>("img:not([alt])"));
  for (const img of imgs) {
    const alt = safeText(img.getAttribute("data-alt") ?? img.getAttribute("title") ?? img.getAttribute("aria-label"), "Decorative image");
    img.setAttribute("alt", alt);
    applied += 1;
    changes.push(`Added alt text to image: ${alt}`);
  }

  const anchors = Array.from(document.querySelectorAll<HTMLAnchorElement>('a[target="_blank"]'));
  for (const anchor of anchors) {
    const rel = anchor.getAttribute("rel") ?? "";
    if (!/(^|\s)noopener(\s|$)/.test(rel) || !/(^|\s)noreferrer(\s|$)/.test(rel)) {
      const next = new Set(rel.split(/\s+/).filter(Boolean));
      next.add("noopener");
      next.add("noreferrer");
      anchor.setAttribute("rel", Array.from(next).join(" "));
      applied += 1;
      changes.push(`Hardened target=_blank link: ${anchor.getAttribute("href") ?? ""}`);
    }
  }

  const lazyImages = Array.from(document.querySelectorAll<HTMLImageElement>("img")).filter(
    (img, index) => index > 1 && !img.hasAttribute("loading"),
  );
  for (const img of lazyImages) {
    img.setAttribute("loading", "lazy");
    applied += 1;
    changes.push(`Enabled lazy loading for image: ${img.getAttribute("src") ?? ""}`);
  }

  const namelessButtons = Array.from(document.querySelectorAll<HTMLButtonElement>("button")).filter(
    (button) => !button.textContent?.trim() && !button.getAttribute("aria-label") && !button.getAttribute("aria-labelledby"),
  );
  for (const button of namelessButtons) {
    button.setAttribute("aria-label", safeText(button.getAttribute("title") ?? button.getAttribute("name"), "Button action"));
    applied += 1;
    changes.push("Added aria-label to unlabeled button");
  }

  const formButtons = Array.from(document.querySelectorAll<HTMLButtonElement>("form button:not([type])"));
  for (const button of formButtons) {
    button.setAttribute("type", "button");
    applied += 1;
    changes.push(`Set safe button type for form button: ${safeText(button.textContent, "button")}`);
  }

  if (report && report.issues.length > 0 && changes.length === 0) {
    skipped = report.issues.length;
  }

  return { applied, skipped, changes };
}
