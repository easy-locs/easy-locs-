import { supabase } from "@/integrations/supabase/client";

export type DealInsightRecord = {
  id?: string;
  deal_id: string;
  suggested_price: number | null;
  suggested_min: number | null;
  suggested_max: number | null;
  probability_score: number;
  market_reference?: number | null;
  algorithm_version?: string;
  explanation?: string | null;
  created_at?: string;
  updated_at?: string;
};

type DealLike = {
  id: string;
  current_offer_amount?: number | null;
  counter_offer_amount?: number | null;
  accepted_amount?: number | null;
  negotiation_round?: number | null;
  offer_expires_at?: string | null;
};

type DealEventLike = {
  id?: string;
  event_type?: string;
  data_json?: any;
  created_at?: string;
};

function roundAmount(value: number): number {
  return Math.round(value);
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function pctDiff(a: number, b: number): number {
  const base = Math.max(Math.abs(a), Math.abs(b), 1);
  return Math.abs(a - b) / base;
}

export function computeDealInsight(deal: DealLike, events: DealEventLike[] = []): DealInsightRecord {
  const current = deal.current_offer_amount ?? null;
  const counter = deal.counter_offer_amount ?? null;

  let suggestedPrice: number | null = null;
  let suggestedMin: number | null = null;
  let suggestedMax: number | null = null;

  if (current != null && counter != null) {
    suggestedPrice = roundAmount((current + counter) / 2);
    suggestedMin = Math.min(current, counter);
    suggestedMax = Math.max(current, counter);
  } else if (current != null) {
    suggestedPrice = roundAmount(current);
    suggestedMin = current;
    suggestedMax = current;
  } else if (counter != null) {
    suggestedPrice = roundAmount(counter);
    suggestedMin = counter;
    suggestedMax = counter;
  }

  let probability = 50;
  const explanations: string[] = [];

  if (current != null && counter != null) {
    const diff = pctDiff(current, counter);
    if (diff <= 0.05) {
      probability += 25;
      explanations.push("Buyer and seller are close in price.");
    } else if (diff <= 0.1) {
      probability += 15;
      explanations.push("Buyer and seller are within a workable negotiation range.");
    } else {
      explanations.push("Large pricing gap reduces closing probability.");
    }
  } else if (suggestedPrice != null) {
    explanations.push("Only one side has made a price move so far.");
  } else {
    explanations.push("Negotiation has started but no priced offer exists yet.");
  }

  const round = deal.negotiation_round ?? 0;
  if (round > 0 && round <= 2) {
    probability += 10;
    explanations.push("Early negotiation stage with strong agreement potential.");
  } else if (round >= 5) {
    probability -= 10;
    explanations.push("Extended negotiation rounds may reduce deal momentum.");
  }

  if (deal.offer_expires_at) {
    const expiresInMs = new Date(deal.offer_expires_at).getTime() - Date.now();
    if (expiresInMs > 0 && expiresInMs <= 24 * 60 * 60 * 1000) {
      probability += 5;
      explanations.push("Offer deadline may accelerate a decision within 24 hours.");
    }
  }

  const smartSuggestionEvents = events.filter((ev) => ev.event_type === "smart_suggestion").length;
  if (smartSuggestionEvents >= 2 && probability > 60) {
    probability -= 5;
    explanations.push("Multiple automated suggestions indicate negotiation friction.");
  }

  probability = clamp(Math.round(probability), 5, 95);

  return {
    deal_id: deal.id,
    suggested_price: suggestedPrice,
    suggested_min: suggestedMin,
    suggested_max: suggestedMax,
    probability_score: probability,
    algorithm_version: "v1",
    explanation: explanations.join(" "),
  };
}

function insightChangedSignificantly(previous: Partial<DealInsightRecord> | null, next: DealInsightRecord): boolean {
  if (!previous) return true;
  const prevPrice = previous.suggested_price ?? null;
  const nextPrice = next.suggested_price ?? null;
  const prevProbability = previous.probability_score ?? null;
  const nextProbability = next.probability_score;
  return prevPrice !== nextPrice || Math.abs((prevProbability ?? 0) - nextProbability) >= 5;
}

export async function syncDealInsight(deal: DealLike, events: DealEventLike[] = []): Promise<DealInsightRecord> {
  const insight = computeDealInsight(deal, events);

  const { data: previous, error: previousError } = await supabase
    .from("deal_insights")
    .select("*")
    .eq("deal_id", deal.id)
    .maybeSingle();
  if (previousError) throw previousError;

  const { error: upsertError } = await supabase
    .from("deal_insights")
    .upsert({ ...insight, updated_at: new Date().toISOString() } as any, { onConflict: "deal_id" });

  if (upsertError) throw upsertError;

  if (insightChangedSignificantly(previous as any, insight)) {
    const latestSuggestionSignature = `${insight.suggested_price ?? "na"}:${insight.probability_score}`;
    const hasRecentDuplicate = events.some((event) => {
      if (event.event_type !== "smart_suggestion") return false;
      const metadata = (event.data_json || {}) as Record<string, any>;
      return `${metadata.suggested_price ?? "na"}:${metadata.probability_score}` === latestSuggestionSignature;
    });

    if (!hasRecentDuplicate) {
      await supabase.from("deal_events").insert({
        deal_id: deal.id,
        event_type: "smart_suggestion",
        data_json: {
          event_type: "smart_suggestion",
          suggested_price: insight.suggested_price,
          probability_score: insight.probability_score,
          explanation: insight.explanation,
          suggested_min: insight.suggested_min,
          suggested_max: insight.suggested_max,
          algorithm_version: insight.algorithm_version || "v1",
        },
      } as any);
    }
  }

  return insight;
}
