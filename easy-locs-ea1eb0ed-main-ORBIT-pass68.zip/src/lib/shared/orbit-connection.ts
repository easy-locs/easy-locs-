import { supabase } from "@/integrations/supabase/client";
import { platformBus } from "@/lib/shared/platform-bus";

export interface RequestGatewayOptions extends RequestInit {
  timeoutMs?: number;
  retries?: number;
  query?: Record<string, string | number | boolean | undefined | null>;
  emitType?: string;
}

export interface RequestGatewayErrorShape {
  code: string;
  message: string;
  status?: number;
  retryable?: boolean;
}

export class RequestGatewayError extends Error {
  code: string;
  status?: number;
  retryable: boolean;

  constructor(shape: RequestGatewayErrorShape) {
    super(shape.message);
    this.name = "RequestGatewayError";
    this.code = shape.code;
    this.status = shape.status;
    this.retryable = !!shape.retryable;
  }
}

function buildUrl(base: string, query?: RequestGatewayOptions["query"]) {
  if (!query) return base;
  const url = new URL(base);
  Object.entries(query).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      url.searchParams.set(key, String(value));
    }
  });
  return url.toString();
}

function normalizeError(error: unknown): RequestGatewayError {
  if (error instanceof RequestGatewayError) return error;
  if (error instanceof DOMException && error.name === "AbortError") {
    return new RequestGatewayError({ code: "TIMEOUT", message: "Request timed out", retryable: true });
  }
  if (navigator.onLine === false) {
    return new RequestGatewayError({ code: "OFFLINE", message: "You appear to be offline", retryable: true });
  }
  return new RequestGatewayError({
    code: "REQUEST_FAILED",
    message: error instanceof Error ? error.message : "Request failed",
  });
}

function shouldRetry(error: RequestGatewayError) {
  return error.retryable || error.status === 429 || (typeof error.status === "number" && error.status >= 500);
}

function extractErrorMessage(payload: unknown, fallback: string) {
  if (payload && typeof payload === "object") {
    const asRecord = payload as Record<string, unknown>;
    if (typeof asRecord.message === "string") return asRecord.message;
    if (asRecord.error && typeof asRecord.error === "object") {
      const errorObj = asRecord.error as Record<string, unknown>;
      if (typeof errorObj.message === "string") return errorObj.message;
    }
  }
  if (typeof payload === "string" && payload.trim()) return payload;
  return fallback;
}

export async function requestJson<T = unknown>(url: string, options: RequestGatewayOptions = {}): Promise<T> {
  const { timeoutMs = 12000, retries = 1, query, emitType, headers, ...rest } = options;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const session = (await supabase.auth.getSession()).data.session;

  if (emitType) {
    platformBus.emit("system:sync_started", { type: emitType, url }, "system", { userId: session?.user?.id });
  }

  try {
    const response = await fetch(buildUrl(url, query), {
      ...rest,
      headers: {
        ...(rest.body !== undefined ? { "Content-Type": "application/json" } : {}),
        ...(session?.access_token ? { Authorization: `Bearer ${session.access_token}` } : {}),
        ...(import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ? { apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY } : {}),
        ...(headers || {}),
      },
      signal: controller.signal,
    });

    const contentType = response.headers.get("content-type") || "";
    const payload = contentType.includes("application/json")
      ? await response.json().catch(() => ({}))
      : await response.text().catch(() => "");

    if (!response.ok) {
      throw new RequestGatewayError({
        code: `HTTP_${response.status}`,
        message: extractErrorMessage(payload, `HTTP ${response.status}`),
        status: response.status,
        retryable: response.status === 429 || response.status >= 500,
      });
    }

    if (emitType) {
      platformBus.emit("system:sync_completed", { type: emitType, ok: true }, "system", {
        userId: session?.user?.id,
      });
    }
    return payload as T;
  } catch (error) {
    const normalized = normalizeError(error);
    if (retries > 0 && shouldRetry(normalized)) {
      return requestJson<T>(url, { ...options, retries: retries - 1, timeoutMs: Math.round(timeoutMs * 1.25) });
    }
    if (emitType) {
      platformBus.emit(
        "system:sync_completed",
        { type: emitType, ok: false, error: normalized.message, code: normalized.code },
        "system",
        { userId: session?.user?.id },
      );
    }
    throw normalized;
  } finally {
    clearTimeout(timer);
  }
}

export async function invokeEdge<T = unknown>(fnName: string, body?: unknown, method: "GET" | "POST" = "POST"): Promise<T> {
  const base = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/${fnName}`;
  return requestJson<T>(base, {
    method,
    body: method === "POST" ? JSON.stringify(body ?? {}) : undefined,
    emitType: `edge:${fnName}:${method.toLowerCase()}`,
  });
}

export function bridgeAsync<T>(promise: Promise<T>, type: string) {
  return promise
    .then((data) => {
      platformBus.emit("system:sync_completed", { type, ok: true }, "system");
      return data;
    })
    .catch((error) => {
      const normalized = normalizeError(error);
      console.error(`[orbit-connection] ${type} failed`, normalized);
      platformBus.emit("system:sync_completed", { type, ok: false, error: normalized.message, code: normalized.code }, "system");
      throw normalized;
    });
}
