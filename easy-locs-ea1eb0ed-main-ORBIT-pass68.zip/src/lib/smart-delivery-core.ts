export type DeliveryPricingMode = 'fixed' | 'progressive' | 'auto';
export type DeliveryPackageSize = 'small' | 'standard' | 'large' | 'bulky';

export interface DeliveryJobCore {
  id?: string;
  order_id?: string | null;
  pickup_lat: number | null;
  pickup_lng: number | null;
  dropoff_lat: number | null;
  dropoff_lng: number | null;
  price?: number | null;
  pricing_mode?: DeliveryPricingMode | null;
  package_size?: DeliveryPackageSize | null;
  package_weight_kg?: number | null;
  requires_two_person_lift?: boolean | null;
  is_fragile?: boolean | null;
  seller_amount?: number | null;
  platform_fee?: number | null;
  driver_amount?: number | null;
  status?: string | null;
  accepted_at?: string | null;
  picked_up_at?: string | null;
  delivered_at?: string | null;
}

export interface DeliveryOfferCore {
  offered_price: number;
  driver_id?: string | null;
  status?: string | null;
}

export interface DeliveryEscrowSplit {
  sellerAmount: number;
  driverAmount: number;
  platformFee: number;
  totalHeld: number;
}

const PACKAGE_MULTIPLIER: Record<DeliveryPackageSize, number> = {
  small: 0.9,
  standard: 1,
  large: 1.3,
  bulky: 1.75,
};

export function isBigParcel(size?: DeliveryPackageSize | null, weightKg?: number | null, requiresTwoPersonLift?: boolean | null) {
  return size === 'large' || size === 'bulky' || (weightKg ?? 0) >= 15 || !!requiresTwoPersonLift;
}

export function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function estimateDeliveryDistanceKm(job: DeliveryJobCore): number | null {
  if ([job.pickup_lat, job.pickup_lng, job.dropoff_lat, job.dropoff_lng].some((v) => typeof v !== 'number')) return null;
  return haversineKm(job.pickup_lat!, job.pickup_lng!, job.dropoff_lat!, job.dropoff_lng!);
}

export function computeSuggestedDeliveryPrice(job: DeliveryJobCore): number {
  const distance = estimateDeliveryDistanceKm(job) ?? 0;
  const size = job.package_size ?? 'standard';
  const base = 5;
  const distancePrice = Math.max(0, distance) * 1.35;
  const weightExtra = Math.max(0, (job.package_weight_kg ?? 0) - 5) * 0.25;
  const fragileExtra = job.is_fragile ? 1.5 : 0;
  const twoPersonExtra = job.requires_two_person_lift ? 4 : 0;
  const raw = (base + distancePrice + weightExtra + fragileExtra + twoPersonExtra) * PACKAGE_MULTIPLIER[size];
  return Math.max(4, Math.round(raw * 100) / 100);
}

export function computeEscrowSplit(totalAmount: number, deliveryFee: number, platformFeeRate = 0.08): DeliveryEscrowSplit {
  const held = Math.max(0, totalAmount);
  const driverAmount = Math.max(0, deliveryFee);
  const platformFee = Math.round(held * platformFeeRate * 100) / 100;
  const sellerAmount = Math.max(0, Math.round((held - driverAmount - platformFee) * 100) / 100);
  return {
    sellerAmount,
    driverAmount,
    platformFee,
    totalHeld: Math.round(held * 100) / 100,
  };
}

export function buildDeliveryConfirmationCode(seed?: string | null) {
  const raw = (seed || cryptoRandom()).replace(/[^a-zA-Z0-9]/g, '');
  return raw.slice(0, 4).toUpperCase().padEnd(4, '7');
}

function cryptoRandom() {
  try {
    const arr = new Uint32Array(1);
    crypto.getRandomValues(arr);
    return String(arr[0]);
  } catch {
    return String(Date.now());
  }
}

export function computeDeliveryJobSummary(job: DeliveryJobCore) {
  const suggestedPrice = computeSuggestedDeliveryPrice(job);
  const distanceKm = estimateDeliveryDistanceKm(job);
  const parcelLabel = isBigParcel(job.package_size, job.package_weight_kg, job.requires_two_person_lift)
    ? 'Large parcel'
    : 'Standard parcel';
  const fragileLabel = job.is_fragile ? 'Fragile' : null;
  return {
    distanceKm,
    suggestedPrice,
    parcelLabel,
    fragileLabel,
    isBigParcel: isBigParcel(job.package_size, job.package_weight_kg, job.requires_two_person_lift),
  };
}

export function rankDeliveryOffer(offer: DeliveryOfferCore, suggestedPrice: number) {
  const ratio = suggestedPrice > 0 ? Math.abs((offer.offered_price - suggestedPrice) / suggestedPrice) : 0;
  const score = Math.max(5, 95 - Math.round(ratio * 100));
  return score;
}
