import { runAIInspector } from "@/lib/ai-inspector";
import { auditPage, summarizeAudit } from "@/lib/a11y-audit";

export interface QAMetrics {
  accessibility: number;
  performance: number;
  seo: number;
  security: number;
}

export interface QAReport {
  metrics: QAMetrics;
  score: number;
  inspectorIssues: number;
}

function clampScore(score: number) {
  return Math.max(0, Math.min(100, Math.round(score)));
}

export function computeQAScore(metrics: QAMetrics): QAReport {
  const score =
    metrics.accessibility * 0.35 +
    metrics.performance * 0.3 +
    metrics.seo * 0.2 +
    metrics.security * 0.15;

  return {
    metrics: {
      accessibility: clampScore(metrics.accessibility),
      performance: clampScore(metrics.performance),
      seo: clampScore(metrics.seo),
      security: clampScore(metrics.security),
    },
    score: clampScore(score),
    inspectorIssues: 0,
  };
}

export function runSmartQA(): QAReport {
  if (typeof document === "undefined") {
    return computeQAScore({ accessibility: 100, performance: 100, seo: 100, security: 100 });
  }

  const a11ySummary = summarizeAudit(auditPage());
  const inspector = runAIInspector();
  const performancePenalty = inspector.issues.filter((issue) => issue.type === "performance").length * 6;
  const seoPenalty = inspector.issues.filter((issue) => issue.type === "seo").length * 5;
  const securityPenalty = inspector.issues.filter((issue) => issue.type === "security").length * 7;

  const report = computeQAScore({
    accessibility: a11ySummary.score,
    performance: 100 - performancePenalty,
    seo: 100 - seoPenalty,
    security: 100 - securityPenalty,
  });

  return {
    ...report,
    inspectorIssues: inspector.issues.length,
  };
}
