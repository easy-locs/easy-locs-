import { platformBus } from '@/lib/shared/platform-bus';
import { invokeEdge } from '@/lib/shared/orbit-connection';

export type BankConnectRequest = {
  countryCode?: string;
  regionHint?: 'us_ca' | 'europe_uk' | 'global';
};

export type BankConnectionAction = 'list' | 'connect' | 'complete' | 'sync_accounts';
export type BankPaymentAction = 'create_payment_intent' | 'confirm_payment_intent' | 'sync_wallet';
export type BankPayoutAction = 'request_payout' | 'list';

function normalizeCurrency(currency?: string | null) {
  return (currency || 'EUR').toUpperCase();
}

function normalizeAmount(amount?: number | null) {
  return typeof amount === 'number' && Number.isFinite(amount) ? Math.max(0, Number(amount.toFixed(2))) : 0;
}

async function invoke<T = unknown>(fn: string, body?: Record<string, unknown>) {
  return invokeEdge<T>(fn, body, 'POST');
}

export async function listBankConnections() {
  return invoke('bank-connections', { action: 'list' });
}

export async function connectBankAccount(input: BankConnectRequest) {
  return invoke('bank-connections', { action: 'connect', ...input });
}

export async function completeBankConnection(connectionId: string) {
  const data = await invoke('bank-connections', { action: 'complete', connectionId });
  platformBus.emit('wallet:balance_updated', { connectionId, source: 'bank_complete' }, 'wallet');
  return data;
}

export async function syncBankAccounts(connectionId: string) {
  const data = await invoke('bank-connections', { action: 'sync_accounts', connectionId });
  platformBus.emit('wallet:balance_updated', { connectionId, source: 'bank_sync_accounts' }, 'wallet');
  return data;
}

export async function createPayByBankIntent(payload: {
  provider?: 'plaid' | 'yapily' | 'saltedge' | 'stripe';
  bankConnectionId?: string;
  bankAccountId?: string;
  amount: number;
  currency: string;
}) {
  return invoke('bank-payments', { action: 'create_payment_intent', ...payload, amount: normalizeAmount(payload.amount), currency: normalizeCurrency(payload.currency) });
}

export async function confirmPayByBankIntent(intentId: string, status?: string) {
  const data = await invoke('bank-payments', { action: 'confirm_payment_intent', intentId, status });
  platformBus.emit('wallet:payment_completed', { intentId, status: status || 'confirmed', source: 'bank_intent' }, 'wallet');
  return data;
}

export async function syncWalletFromBankIntent(intentId: string) {
  const data = await invoke('bank-payments', { action: 'sync_wallet', intentId });
  platformBus.emit('wallet:balance_updated', { intentId, source: 'bank_sync_wallet' }, 'wallet');
  return data;
}

export async function requestBankPayout(payload: {
  provider?: 'plaid' | 'yapily' | 'saltedge' | 'stripe';
  bankConnectionId?: string;
  bankAccountId?: string;
  amount: number;
  currency: string;
  destination?: string;
}) {
  const data = await invoke('bank-payouts', { action: 'request_payout', ...payload, amount: normalizeAmount(payload.amount), currency: normalizeCurrency(payload.currency) });
  platformBus.emit('orbit:notification_created', { source: 'bank_payout', amount: normalizeAmount(payload.amount), currency: normalizeCurrency(payload.currency) }, 'wallet');
  return data;
}

export async function syncBankJobs(connectionId?: string) {
  return invoke('bank-sync-jobs', { connectionId });
}
