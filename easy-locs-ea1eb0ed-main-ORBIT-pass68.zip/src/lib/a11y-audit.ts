export type RGB = [number, number, number];

function clampByte(value: number): number {
  return Math.max(0, Math.min(255, Math.round(value)));
}

function normalizeHue(h: number): number {
  const mod = h % 360;
  return mod < 0 ? mod + 360 : mod;
}

/** Parse basic CSS colors used in tests and audits: #rgb, #rrggbb, rgb(), rgba(), hsl(), hsla() */
export function parseColor(input: string): RGB | null {
  const color = input?.trim().toLowerCase();
  if (!color) return null;

  const hex3 = color.match(/^#([0-9a-f]{3})$/i);
  if (hex3) {
    const [r, g, b] = hex3[1].split("").map((ch) => parseInt(ch + ch, 16));
    return [r, g, b];
  }

  const hex6 = color.match(/^#([0-9a-f]{6})$/i);
  if (hex6) {
    return [0, 2, 4].map((idx) => parseInt(hex6[1].slice(idx, idx + 2), 16)) as RGB;
  }

  const rgb = color.match(/^rgba?\((.+)\)$/i);
  if (rgb) {
    const parts = rgb[1].split(",").map((part) => part.trim());
    if (parts.length < 3) return null;
    const channels = parts.slice(0, 3).map((part) => {
      if (part.endsWith("%")) {
        const pct = Number.parseFloat(part.slice(0, -1));
        if (!Number.isFinite(pct)) return NaN;
        return clampByte((pct / 100) * 255);
      }
      const num = Number.parseFloat(part);
      return Number.isFinite(num) ? clampByte(num) : NaN;
    });
    if (channels.some(Number.isNaN)) return null;
    return channels as RGB;
  }

  const hsl = color.match(/^hsla?\((.+)\)$/i);
  if (hsl) {
    const parts = hsl[1].split(",").map((part) => part.trim().replace(/%$/, ""));
    if (parts.length < 3) return null;
    const h = Number.parseFloat(parts[0]);
    const s = Number.parseFloat(parts[1]);
    const l = Number.parseFloat(parts[2]);
    if (![h, s, l].every(Number.isFinite)) return null;
    return hslToRgb(h, s, l);
  }

  return null;
}

/** Convert HSL values using CSS-style ranges: h 0-360, s 0-100, l 0-100 */
export function hslToRgb(h: number, s: number, l: number): RGB {
  const hue = normalizeHue(h) / 360;
  const sat = Math.max(0, Math.min(100, s)) / 100;
  const light = Math.max(0, Math.min(100, l)) / 100;

  if (sat === 0) {
    const gray = clampByte(light * 255);
    return [gray, gray, gray];
  }

  const q = light < 0.5 ? light * (1 + sat) : light + sat - light * sat;
  const p = 2 * light - q;

  const hueToRgb = (t: number) => {
    let temp = t;
    if (temp < 0) temp += 1;
    if (temp > 1) temp -= 1;
    if (temp < 1 / 6) return p + (q - p) * 6 * temp;
    if (temp < 1 / 2) return q;
    if (temp < 2 / 3) return p + (q - p) * (2 / 3 - temp) * 6;
    return p;
  };

  return [
    clampByte(hueToRgb(hue + 1 / 3) * 255),
    clampByte(hueToRgb(hue) * 255),
    clampByte(hueToRgb(hue - 1 / 3) * 255),
  ];
}

export function relativeLuminance(r: number, g: number, b: number): number {
  const [rs, gs, bs] = [r, g, b].map((c) => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
}

/** WCAG contrast ratio between two colors */
export function contrastRatio(color1: string, color2: string): number | null {
  const c1 = parseColor(color1);
  const c2 = parseColor(color2);
  if (!c1 || !c2) return null;
  const l1 = relativeLuminance(...c1);
  const l2 = relativeLuminance(...c2);
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

/** Check if contrast meets WCAG AA */
export function meetsWCAG_AA(color1: string, color2: string, isLargeText = false): boolean {
  const ratio = contrastRatio(color1, color2);
  if (ratio === null) return false;
  return isLargeText ? ratio >= 3.0 : ratio >= 4.5;
}

/** Check if contrast meets WCAG AAA */
export function meetsWCAG_AAA(color1: string, color2: string, isLargeText = false): boolean {
  const ratio = contrastRatio(color1, color2);
  if (ratio === null) return false;
  return isLargeText ? ratio >= 4.5 : ratio >= 7.0;
}

/* ─── Keyboard Navigation ─── */

/** ARIA-standard keyboard keys for interactive patterns */
export const KEYS = {
  ENTER: "Enter",
  SPACE: " ",
  ESCAPE: "Escape",
  TAB: "Tab",
  ARROW_UP: "ArrowUp",
  ARROW_DOWN: "ArrowDown",
  ARROW_LEFT: "ArrowLeft",
  ARROW_RIGHT: "ArrowRight",
  HOME: "Home",
  END: "End",
} as const;

/** Create keyboard handler for common ARIA patterns */
export function createArrowKeyHandler(
  items: HTMLElement[],
  options: {
    orientation?: "horizontal" | "vertical" | "both";
    loop?: boolean;
    onSelect?: (el: HTMLElement, index: number) => void;
  } = {},
) {
  const { orientation = "vertical", loop = true, onSelect } = options;

  return (e: KeyboardEvent) => {
    const currentIndex = items.indexOf(e.target as HTMLElement);
    if (currentIndex === -1 || items.length === 0) return;

    let nextIndex = currentIndex;
    const isVertical = orientation === "vertical" || orientation === "both";
    const isHorizontal = orientation === "horizontal" || orientation === "both";

    if (e.key === KEYS.ARROW_DOWN && isVertical) {
      nextIndex = currentIndex + 1;
    } else if (e.key === KEYS.ARROW_UP && isVertical) {
      nextIndex = currentIndex - 1;
    } else if (e.key === KEYS.ARROW_RIGHT && isHorizontal) {
      nextIndex = currentIndex + 1;
    } else if (e.key === KEYS.ARROW_LEFT && isHorizontal) {
      nextIndex = currentIndex - 1;
    } else if (e.key === KEYS.HOME) {
      nextIndex = 0;
    } else if (e.key === KEYS.END) {
      nextIndex = items.length - 1;
    } else if ((e.key === KEYS.ENTER || e.key === KEYS.SPACE) && onSelect) {
      e.preventDefault();
      onSelect(items[currentIndex], currentIndex);
      return;
    } else {
      return;
    }

    e.preventDefault();
    if (loop) {
      nextIndex = ((nextIndex % items.length) + items.length) % items.length;
    } else {
      nextIndex = Math.max(0, Math.min(nextIndex, items.length - 1));
    }
    items[nextIndex]?.focus();
  };
}

/* ─── ARIA Validation ─── */

export interface A11yIssue {
  element: string;
  rule: string;
  severity: "error" | "warning" | "info";
  message: string;
}

function describeElement(el: Element): string {
  const tag = el.tagName.toLowerCase();
  const id = el.getAttribute("id");
  const className = el.getAttribute("class");
  const attrs = [id ? `#${id}` : "", className ? `.${className.split(/\s+/).filter(Boolean).join(".")}` : ""]
    .filter(Boolean)
    .join("");
  return `<${tag}${attrs}>`;
}

function findLabelForInput(id: string): HTMLLabelElement | null {
  const labels = Array.from(document.querySelectorAll("label[for]")) as HTMLLabelElement[];
  return labels.find((label) => label.getAttribute("for") === id) ?? null;
}

/** Quick DOM audit — call in dev mode only */
export function auditPage(): A11yIssue[] {
  if (typeof document === "undefined") return [];
  const issues: A11yIssue[] = [];

  document.querySelectorAll("img").forEach((img) => {
    if (!img.hasAttribute("alt")) {
      issues.push({
        element: describeElement(img),
        rule: "img-alt",
        severity: "error",
        message: "Image missing alt attribute",
      });
    }
  });

  document.querySelectorAll("button, a[href]").forEach((el) => {
    const labelledBy = el.getAttribute("aria-labelledby");
    const ariaLabel = el.getAttribute("aria-label")?.trim();
    const text = el.textContent?.trim();
    const hasLabelledBy = labelledBy ? Boolean(document.getElementById(labelledBy)) : false;
    if (!ariaLabel && !hasLabelledBy && !text) {
      issues.push({
        element: describeElement(el),
        rule: "accessible-name",
        severity: "error",
        message: "Interactive element has no accessible name",
      });
    }
  });

  document.querySelectorAll("input, select, textarea").forEach((el) => {
    const input = el as HTMLInputElement;
    if (input.type === "hidden") return;
    const labelledBy = input.getAttribute("aria-labelledby");
    const hasLabel = Boolean(
      input.getAttribute("aria-label") ||
        (labelledBy && document.getElementById(labelledBy)) ||
        (input.id && findLabelForInput(input.id)) ||
        input.closest("label"),
    );
    if (!hasLabel) {
      issues.push({
        element: `<${el.tagName.toLowerCase()} type=\"${input.type || "text"}\">`,
        rule: "label",
        severity: "error",
        message: "Form input missing associated label",
      });
    }
  });

  const h1s = document.querySelectorAll("h1");
  if (h1s.length === 0) {
    issues.push({
      element: "document",
      rule: "heading-h1",
      severity: "warning",
      message: "Page has no H1 heading",
    });
  } else if (h1s.length > 1) {
    issues.push({
      element: "document",
      rule: "heading-h1",
      severity: "warning",
      message: `Page has ${h1s.length} H1 headings (should be 1)`,
    });
  }

  const headings = Array.from(document.querySelectorAll("h1, h2, h3, h4, h5, h6"));
  for (let i = 1; i < headings.length; i += 1) {
    const prevLevel = Number.parseInt(headings[i - 1].tagName[1], 10);
    const currLevel = Number.parseInt(headings[i].tagName[1], 10);
    if (currLevel > prevLevel + 1) {
      issues.push({
        element: `<${headings[i].tagName.toLowerCase()}>`,
        rule: "heading-order",
        severity: "warning",
        message: `Heading skips level: h${prevLevel} → h${currLevel}`,
      });
    }
  }

  document.querySelectorAll("button, a[href], [role='button']").forEach((el) => {
    const rect = (el as HTMLElement).getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0 && (rect.width < 44 || rect.height < 44)) {
      issues.push({
        element: `${describeElement(el)} (${Math.round(rect.width)}x${Math.round(rect.height)})`,
        rule: "touch-target",
        severity: "warning",
        message: "Touch target smaller than 44x44px",
      });
    }
  });

  if (!document.documentElement.getAttribute("lang")) {
    issues.push({
      element: "<html>",
      rule: "html-lang",
      severity: "error",
      message: "HTML element missing lang attribute",
    });
  }

  return issues;
}

/** Count issues by severity */
export function summarizeAudit(issues: A11yIssue[]): {
  errors: number;
  warnings: number;
  info: number;
  score: number;
} {
  const errors = issues.filter((i) => i.severity === "error").length;
  const warnings = issues.filter((i) => i.severity === "warning").length;
  const info = issues.filter((i) => i.severity === "info").length;
  const score = Math.max(0, 100 - errors * 10 - warnings * 3 - info);
  return { errors, warnings, info, score };
}

/* ─── Focus Management ─── */

const FOCUSABLE_SELECTOR = [
  'a[href]',
  'button:not([disabled])',
  'textarea:not([disabled])',
  'input:not([disabled]):not([type="hidden"])',
  'select:not([disabled])',
  '[tabindex]:not([tabindex="-1"])',
].join(', ');

/** Get all focusable elements within a container */
export function getFocusableElements(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter((el) => {
    if (el.hasAttribute("hidden")) return false;
    if (el.getAttribute("aria-hidden") === "true") return false;
    return true;
  });
}

/** Restore focus to a specific element (e.g., after modal close) */
export function restoreFocus(element: HTMLElement | null) {
  if (element && typeof element.focus === "function") {
    requestAnimationFrame(() => element.focus());
  }
}

/** Generate a unique ID for ARIA relationships */
let idCounter = 0;
export function generateAriaId(prefix = "a11y"): string {
  idCounter += 1;
  return `${prefix}-${idCounter}-${Date.now().toString(36)}`;
}
