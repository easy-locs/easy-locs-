import { supabase } from "@/integrations/supabase/client";

export type SupportThreadStatus = "received" | "processing" | "replied" | "failed" | "human_review";

export interface SupportEmailThread {
  id: string;
  subject: string;
  customer_email: string;
  customer_name: string | null;
  language: string;
  status: SupportThreadStatus;
  last_message_at: string;
  last_error: string | null;
}

export interface SupportEmailMessage {
  id: string;
  thread_id: string;
  direction: "inbound" | "outbound";
  from_email: string;
  to_email: string;
  subject: string;
  text_body: string | null;
  status: SupportThreadStatus;
  sent_by_ai: boolean;
  created_at: string;
}

export async function listSupportThreads() {
  const { data, error } = await supabase
    .from("email_threads" as never)
    .select("id,subject,customer_email,customer_name,language,status,last_message_at,last_error")
    .order("last_message_at", { ascending: false });
  if (error) throw error;
  return (data || []) as unknown as SupportEmailThread[];
}

export async function getSupportThreadMessages(threadId: string) {
  const { data, error } = await supabase
    .from("email_messages" as never)
    .select("id,thread_id,direction,from_email,to_email,subject,text_body,status,sent_by_ai,created_at")
    .eq("thread_id", threadId)
    .order("created_at", { ascending: true });
  if (error) throw error;
  return (data || []) as unknown as SupportEmailMessage[];
}

export async function sendSupportHumanReply(payload: { threadId: string; replyText: string; aiReplyId?: string | null; subject?: string; action?: "send" | "draft" | "approve_ai"; }) {
  const { data, error } = await supabase.functions.invoke("support-email-reply", { body: payload });
  if (error) throw error;
  return data as { success: boolean; data?: { threadId: string; status: SupportThreadStatus; messageId?: string }; error?: { code: string; message: string } };
}
