import { auditPage, summarizeAudit, type A11yIssue } from "@/lib/a11y-audit";

export const A11Y_AUDIT_EVENT = "orbit:a11y-audit";
export const A11Y_AUDIT_HISTORY_KEY = "orbit:a11y-history";
const MAX_HISTORY = 10;

export interface A11yAuditSnapshot {
  pathname: string;
  title: string;
  auditedAt: string;
  issues: A11yIssue[];
  summary: ReturnType<typeof summarizeAudit>;
}

function getPageTitle(pathname: string) {
  return document.title?.trim() || pathname || "/";
}

export function createA11ySnapshot(pathname: string): A11yAuditSnapshot {
  const issues = auditPage();
  return {
    pathname,
    title: getPageTitle(pathname),
    auditedAt: new Date().toISOString(),
    issues,
    summary: summarizeAudit(issues),
  };
}

export function logA11ySnapshot(snapshot: A11yAuditSnapshot) {
  const { pathname, title, summary, issues } = snapshot;
  console.groupCollapsed(
    `[A11Y] ${pathname} • score ${summary.score} • ${summary.errors} error(s), ${summary.warnings} warning(s)`,
  );
  console.log("Title:", title);
  console.log("Summary:", summary);
  if (issues.length > 0) console.table(issues);
  console.groupEnd();
}

export function dispatchA11ySnapshot(snapshot: A11yAuditSnapshot) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent<A11yAuditSnapshot>(A11Y_AUDIT_EVENT, { detail: snapshot }));
}

export function readA11yHistory(): A11yAuditSnapshot[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(A11Y_AUDIT_HISTORY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as A11yAuditSnapshot[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function writeA11yHistory(snapshot: A11yAuditSnapshot): A11yAuditSnapshot[] {
  if (typeof window === "undefined") return [snapshot];
  const next = [snapshot, ...readA11yHistory().filter((item) => item.pathname !== snapshot.pathname)].slice(0, MAX_HISTORY);
  window.localStorage.setItem(A11Y_AUDIT_HISTORY_KEY, JSON.stringify(next));
  return next;
}

export function runA11yAudit(pathname: string, options?: { logToConsole?: boolean; persist?: boolean }) {
  const snapshot = createA11ySnapshot(pathname);
  if (options?.persist !== false) writeA11yHistory(snapshot);
  if (options?.logToConsole) logA11ySnapshot(snapshot);
  dispatchA11ySnapshot(snapshot);
  return snapshot;
}

export function scheduleA11yAudit(
  pathname: string,
  options?: { delayMs?: number; logToConsole?: boolean; persist?: boolean },
) {
  if (typeof window === "undefined") return () => {};
  const delayMs = options?.delayMs ?? 180;
  let timeoutId = 0;
  let frameId = 0;

  timeoutId = window.setTimeout(() => {
    frameId = window.requestAnimationFrame(() => {
      runA11yAudit(pathname, {
        logToConsole: options?.logToConsole,
        persist: options?.persist,
      });
    });
  }, delayMs);

  return () => {
    window.clearTimeout(timeoutId);
    if (frameId) window.cancelAnimationFrame(frameId);
  };
}
