import { auditPage, summarizeAudit, type A11yIssue } from "@/lib/a11y-audit";

export type AIInspectionType = "performance" | "a11y" | "seo" | "security" | "ux";
export type AIInspectionSeverity = "low" | "medium" | "high";

export interface AIInspectionIssue {
  type: AIInspectionType;
  severity: AIInspectionSeverity;
  rule: string;
  message: string;
  element?: string;
  suggestion?: string;
}

export interface AIInspectionSummary {
  total: number;
  byType: Record<AIInspectionType, number>;
  bySeverity: Record<AIInspectionSeverity, number>;
}

export interface AIInspectionReport {
  issues: AIInspectionIssue[];
  score: number;
  summary: AIInspectionSummary;
}

function pushIssue(issues: AIInspectionIssue[], issue: AIInspectionIssue) {
  issues.push(issue);
}

function mapA11yIssue(issue: A11yIssue): AIInspectionIssue {
  return {
    type: "a11y",
    severity: issue.severity === "error" ? "high" : issue.severity === "warning" ? "medium" : "low",
    rule: issue.rule,
    message: issue.message,
    element: issue.element,
    suggestion:
      issue.rule === "img-alt"
        ? "Add descriptive alt text, or alt=\"\" for decorative images."
        : issue.rule === "accessible-name"
          ? "Add visible text or aria-label / aria-labelledby to the interactive element."
          : issue.rule === "label"
            ? "Associate the field with a <label>, aria-label, or aria-labelledby."
            : issue.rule === "touch-target"
              ? "Increase the interactive hit area to at least 44x44px."
              : issue.rule === "html-lang"
                ? "Set <html lang=\"…\"> to the page language."
                : "Adjust the markup to satisfy the reported accessibility rule.",
  };
}

export function runAIInspector(): AIInspectionReport {
  const issues: AIInspectionIssue[] = [];

  if (typeof document !== "undefined") {
    for (const issue of auditPage()) {
      pushIssue(issues, mapA11yIssue(issue));
    }

    const title = document.querySelector("title")?.textContent?.trim() ?? "";
    if (!title) {
      pushIssue(issues, {
        type: "seo",
        severity: "high",
        rule: "title",
        message: "Document is missing a <title>.",
        element: "<head>",
        suggestion: "Add a unique page title that describes the page intent and target keywords.",
      });
    } else if (title.length < 20) {
      pushIssue(issues, {
        type: "seo",
        severity: "medium",
        rule: "title-length",
        message: "Page title is very short.",
        element: "<title>",
        suggestion: "Use a clearer title of roughly 20–60 characters when possible.",
      });
    }

    const metaDescription = document.querySelector('meta[name="description"]')?.getAttribute("content")?.trim() ?? "";
    if (!metaDescription) {
      pushIssue(issues, {
        type: "seo",
        severity: "medium",
        rule: "meta-description",
        message: "Page is missing a meta description.",
        element: "<head>",
        suggestion: "Add a concise meta description for better previews and search snippets.",
      });
    }

    const canonicalLinks = Array.from(document.querySelectorAll('link[rel="canonical"]'));
    if (canonicalLinks.length === 0) {
      pushIssue(issues, {
        type: "seo",
        severity: "low",
        rule: "canonical",
        message: "Page does not declare a canonical URL.",
        element: "<head>",
        suggestion: "Add a canonical link to reduce duplicate-indexing issues.",
      });
    } else if (canonicalLinks.length > 1) {
      pushIssue(issues, {
        type: "seo",
        severity: "medium",
        rule: "canonical-multiple",
        message: "Page has multiple canonical URLs.",
        element: "<head>",
        suggestion: "Keep exactly one canonical link element per page.",
      });
    }

    const blankTextLinks = Array.from(document.querySelectorAll<HTMLAnchorElement>('a[href]')).filter(
      (anchor) => !anchor.textContent?.trim() && !anchor.getAttribute("aria-label") && !anchor.getAttribute("aria-labelledby"),
    );
    for (const anchor of blankTextLinks) {
      pushIssue(issues, {
        type: "seo",
        severity: "medium",
        rule: "link-text",
        message: "Link does not expose descriptive text.",
        element: `<a href=\"${anchor.getAttribute("href") ?? ""}\">`,
        suggestion: "Provide visible link text or an accessible label.",
      });
    }

    const externalBlankLinks = Array.from(document.querySelectorAll<HTMLAnchorElement>('a[target="_blank"]')).filter(
      (anchor) => !/(^|\s)(noopener|noreferrer)(\s|$)/.test(anchor.getAttribute("rel") ?? ""),
    );
    for (const anchor of externalBlankLinks) {
      pushIssue(issues, {
        type: "security",
        severity: "medium",
        rule: "target-blank-rel",
        message: "External link opens in a new tab without rel=\"noopener noreferrer\".",
        element: `<a href=\"${anchor.getAttribute("href") ?? ""}\">`,
        suggestion: "Add rel=\"noopener noreferrer\" to reduce reverse-tabnabbing risk.",
      });
    }

    const formsWithRiskyButtons = Array.from(document.querySelectorAll("form button")).filter(
      (button) => !button.getAttribute("type"),
    );
    for (const button of formsWithRiskyButtons) {
      pushIssue(issues, {
        type: "ux",
        severity: "medium",
        rule: "button-type",
        message: "Button inside a form has no explicit type.",
        element: `<button>${button.textContent?.trim() ?? ""}</button>`,
        suggestion: "Set type=\"button\" or type=\"submit\" explicitly to avoid accidental submissions.",
      });
    }

    const largeImageCount = document.querySelectorAll("img").length;
    if (largeImageCount > 24) {
      pushIssue(issues, {
        type: "performance",
        severity: "medium",
        rule: "image-density",
        message: `Page contains ${largeImageCount} images, which may slow rendering on mobile.`,
        element: "document",
        suggestion: "Use responsive sizes, lazy loading, and limit non-critical images above the fold.",
      });
    }

    const lazyCandidates = Array.from(document.querySelectorAll<HTMLImageElement>("img")).filter(
      (img, index) => index > 1 && !img.hasAttribute("loading"),
    );
    for (const img of lazyCandidates.slice(0, 8)) {
      pushIssue(issues, {
        type: "performance",
        severity: "low",
        rule: "image-lazy",
        message: "Below-the-fold image is missing loading=\"lazy\".",
        element: `<img src=\"${img.getAttribute("src") ?? ""}\">`,
        suggestion: "Set loading=\"lazy\" on non-critical images.",
      });
    }
  }

  const a11ySummary = summarizeAudit(
    issues
      .filter((issue) => issue.type === "a11y")
      .map(
        (issue) =>
          ({
            rule: issue.rule,
            message: issue.message,
            element: issue.element ?? "document",
            severity: issue.severity === "high" ? "error" : issue.severity === "medium" ? "warning" : "info",
          }) satisfies A11yIssue,
      ),
  );

  const byType: Record<AIInspectionType, number> = {
    a11y: 0,
    performance: 0,
    seo: 0,
    security: 0,
    ux: 0,
  };
  const bySeverity: Record<AIInspectionSeverity, number> = {
    low: 0,
    medium: 0,
    high: 0,
  };

  for (const issue of issues) {
    byType[issue.type] += 1;
    bySeverity[issue.severity] += 1;
  }

  const penalty = bySeverity.high * 8 + bySeverity.medium * 4 + bySeverity.low * 2;
  const score = Math.max(0, Math.min(100, Math.round((a11ySummary.score * 0.45 + (100 - penalty) * 0.55))));

  return {
    issues,
    score,
    summary: {
      total: issues.length,
      byType,
      bySeverity,
    },
  };
}
