import { useEffect, useMemo, useRef } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useRealtimeSubscription } from "@/hooks/useRealtimeSubscription";
import { computeDealInsight, syncDealInsight, type DealInsightRecord } from "@/lib/deal-insight";

type DealLike = {
  id: string;
  current_offer_amount?: number | null;
  counter_offer_amount?: number | null;
  accepted_amount?: number | null;
  negotiation_round?: number | null;
  offer_expires_at?: string | null;
  status?: string | null;
};

type DealEventLike = {
  id?: string;
  event_type?: string;
  data_json?: any;
  created_at?: string;
};

export function useDealInsight(deal?: DealLike | null, events: DealEventLike[] = []) {
  const dealId = deal?.id;
  const queryClient = useQueryClient();
  const syncSignatureRef = useRef<string | null>(null);

  useRealtimeSubscription({
    table: "deal_insights",
    channelName: `deal-insights-${dealId || "none"}`,
    filter: dealId ? `deal_id=eq.${dealId}` : undefined,
    queryKeys: dealId ? [["deal_insight", dealId] as any] : undefined,
    enabled: !!dealId,
  });

  const query = useQuery({
    queryKey: ["deal_insight", dealId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("deal_insights")
        .select("*")
        .eq("deal_id", dealId!)
        .maybeSingle();
      if (error) throw error;
      return (data as DealInsightRecord | null) ?? null;
    },
    enabled: !!dealId,
  });

  const fallbackInsight = useMemo(() => {
    if (!dealId || !deal) return null;
    return computeDealInsight(deal, events);
  }, [deal, dealId, events]);

  useEffect(() => {
    if (!dealId || !deal) return;
    if (["completed", "cancelled"].includes(String(deal.status || ""))) return;

    const signature = JSON.stringify({
      id: dealId,
      current_offer_amount: deal.current_offer_amount ?? null,
      counter_offer_amount: deal.counter_offer_amount ?? null,
      accepted_amount: deal.accepted_amount ?? null,
      negotiation_round: deal.negotiation_round ?? null,
      offer_expires_at: deal.offer_expires_at ?? null,
      events: events.map((event) => ({
        id: event.id,
        event_type: event.event_type,
        created_at: event.created_at,
      })),
    });

    if (syncSignatureRef.current === signature) return;
    syncSignatureRef.current = signature;

    let cancelled = false;
    void syncDealInsight(deal, events)
      .then(() => {
        if (!cancelled) queryClient.invalidateQueries({ queryKey: ["deal_insight", dealId] });
      })
      .catch(() => {
        if (!cancelled) syncSignatureRef.current = null;
      });

    return () => {
      cancelled = true;
    };
  }, [deal, dealId, events, queryClient]);

  return {
    ...query,
    insight: query.data ?? fallbackInsight,
  };
}
