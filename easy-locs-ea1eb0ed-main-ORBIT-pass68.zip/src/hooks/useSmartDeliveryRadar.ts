import { useEffect, useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { platformBus } from '@/lib/platform-bus';
import {
  buildDeliveryConfirmationCode,
  computeDeliveryJobSummary,
  computeEscrowSplit,
  haversineKm,
  type DeliveryJobCore,
  type DeliveryPricingMode,
} from '@/lib/smart-delivery-core';

export interface DeliveryJobRecord extends DeliveryJobCore {
  id: string;
  seller_id?: string | null;
  buyer_id?: string | null;
  driver_id?: string | null;
  radius_km?: number | null;
  confirmation_code?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface DeliveryEscrowRecord {
  id: string;
  order_id: string;
  seller_amount: number;
  driver_amount: number;
  platform_fee: number;
  status: string;
  released_at?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface DeliveryJobView extends DeliveryJobRecord {
  summary: ReturnType<typeof computeDeliveryJobSummary>;
  escrow?: DeliveryEscrowRecord | null;
}

interface DriverPosition {
  lat: number;
  lng: number;
}

export function useSmartDeliveryRadar(radiusKm = 5) {
  const qc = useQueryClient();
  const [driverPosition, setDriverPosition] = useState<DriverPosition | null>(null);

  useEffect(() => {
    if (!navigator.geolocation) return;
    const watcher = navigator.geolocation.watchPosition(
      (pos) => {
        setDriverPosition({ lat: pos.coords.latitude, lng: pos.coords.longitude });
      },
      () => {
        // keep silent fallback when browser blocks location
      },
      { enableHighAccuracy: true, maximumAge: 20_000, timeout: 12_000 },
    );
    return () => navigator.geolocation.clearWatch(watcher);
  }, []);

  const jobsQuery = useQuery({
    queryKey: ['delivery_jobs', radiusKm],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('delivery_jobs' as any)
        .select('*')
        .in('status', ['open', 'accepted', 'on_route_to_pickup', 'picked_up', 'on_route_to_dropoff', 'delivered'] as any)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return (data ?? []) as DeliveryJobRecord[];
    },
  });

  const escrowQuery = useQuery({
    queryKey: ['delivery_escrow'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('escrow_payments' as any)
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return (data ?? []) as DeliveryEscrowRecord[];
    },
  });

  useEffect(() => {
    const channel = supabase
      .channel('delivery-jobs-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'delivery_jobs' }, () => {
        qc.invalidateQueries({ queryKey: ['delivery_jobs'] });
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'escrow_payments' }, () => {
        qc.invalidateQueries({ queryKey: ['delivery_escrow'] });
      })
      .subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [qc]);

  const createJob = useMutation({
    mutationFn: async (
      input: Omit<DeliveryJobRecord, 'id' | 'status' | 'created_at' | 'updated_at' | 'confirmation_code'>
        & { total_amount?: number; platform_fee_rate?: number; pricing_mode?: DeliveryPricingMode },
    ) => {
      const summary = computeDeliveryJobSummary(input);
      const price = input.price ?? summary.suggestedPrice;
      const confirmationCode = buildDeliveryConfirmationCode(input.order_id ?? input.seller_id ?? null);

      platformBus.emit('system:sync_started', { area: 'delivery_job_create' }, 'delivery');

      const { data: job, error } = await supabase.rpc('create_delivery_job_secure' as any, {
        _order_id: input.order_id ?? null,
        _buyer_id: input.buyer_id ?? null,
        _seller_id: input.seller_id ?? null,
        _total_amount: input.total_amount ?? price,
        _pickup_lat: input.pickup_lat ?? null,
        _pickup_lng: input.pickup_lng ?? null,
        _dropoff_lat: input.dropoff_lat ?? null,
        _dropoff_lng: input.dropoff_lng ?? null,
        _price: price,
        _pricing_mode: input.pricing_mode ?? 'fixed',
        _radius_km: input.radius_km ?? radiusKm,
        _package_size: input.package_size ?? 'standard',
        _package_weight_kg: input.package_weight_kg ?? null,
        _requires_two_person_lift: input.requires_two_person_lift ?? false,
        _is_fragile: input.is_fragile ?? false,
        _confirmation_code: confirmationCode,
        _platform_fee_rate: input.platform_fee_rate ?? 0.08,
      } as any);
      if (error) throw error;

      platformBus.emit('orbit:notification_created', { source: 'delivery_job', status: 'open', deliveryJobId: (job as any).id }, 'delivery');
      platformBus.emit('system:sync_completed', { area: 'delivery_job_create', ok: true }, 'delivery');
      return job as DeliveryJobRecord;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['delivery_jobs'] });
      qc.invalidateQueries({ queryKey: ['delivery_escrow'] });
    },
  });

  const acceptJob = useMutation({
    mutationFn: async ({ jobId, offeredPrice }: { jobId: string; driverId?: string; offeredPrice?: number }) => {
      platformBus.emit('system:sync_started', { area: 'delivery_accept' }, 'delivery');

      const { data, error } = await supabase.rpc('accept_delivery_job_secure' as any, {
        _job_id: jobId,
        _offered_price: offeredPrice ?? null,
        _platform_fee_rate: 0.08,
      } as any);
      if (error) throw error;

      platformBus.emit('tracking:started', { deliveryJobId: jobId }, 'delivery');
      platformBus.emit('orbit:notification_created', { source: 'delivery_job', status: 'accepted', deliveryJobId: jobId }, 'delivery');
      platformBus.emit('system:sync_completed', { area: 'delivery_accept', ok: true }, 'delivery');
      return data as DeliveryJobRecord;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['delivery_jobs'] });
      qc.invalidateQueries({ queryKey: ['delivery_escrow'] });
    },
  });

  const updateStatus = useMutation({
    mutationFn: async ({ jobId, status }: { jobId: string; status: DeliveryJobRecord['status'] }) => {
      const now = new Date().toISOString();
      const patch: Record<string, any> = { status, updated_at: now };
      if (status === 'picked_up') patch.picked_up_at = now;
      if (status === 'delivered') patch.delivered_at = now;
      const { data, error } = await supabase.from('delivery_jobs' as any).update(patch as any).eq('id', jobId).select('*').single();
      if (error) throw error;
      platformBus.emit('tracking:position_updated', { deliveryJobId: jobId, status }, 'delivery');
      platformBus.emit('system:sync_completed', { area: 'delivery_status', ok: true }, 'delivery');
      return data as DeliveryJobRecord;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['delivery_jobs'] }),
  });

  const confirmDelivery = useMutation({
    mutationFn: async ({ jobId, code }: { jobId: string; code?: string }) => {
      const { data: job, error } = await supabase.rpc('confirm_delivery_job_secure' as any, {
        _job_id: jobId,
        _buyer_code: code?.trim() || null,
      } as any);
      if (error) throw error;
      platformBus.emit('wallet:payment_completed', { source: 'delivery_escrow_release', orderId: (job as any)?.order_id, deliveryJobId: jobId }, 'delivery');
      platformBus.emit('system:sync_completed', { area: 'delivery_confirm', ok: true }, 'delivery');
      return job as DeliveryJobRecord;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['delivery_jobs'] });
      qc.invalidateQueries({ queryKey: ['delivery_escrow'] });
    },
  });

  const jobs = useMemo<DeliveryJobView[]>(() => {
    const escrowByOrder = new Map((escrowQuery.data ?? []).map((row) => [row.order_id, row]));
    return (jobsQuery.data ?? []).map((job) => ({
      ...job,
      summary: computeDeliveryJobSummary(job),
      escrow: job.order_id ? escrowByOrder.get(job.order_id) ?? null : null,
    }));
  }, [escrowQuery.data, jobsQuery.data]);

  const openJobs = jobs.filter((job) => {
    if (job.status !== 'open') return false;
    if (!driverPosition || typeof job.pickup_lat !== 'number' || typeof job.pickup_lng !== 'number') return true;
    const maxDistanceKm = job.radius_km ?? radiusKm;
    return haversineKm(driverPosition.lat, driverPosition.lng, job.pickup_lat, job.pickup_lng) <= maxDistanceKm;
  });

  const activeJobs = jobs.filter((job) => job.status && !['open', 'confirmed', 'cancelled'].includes(job.status));

  return {
    jobs,
    openJobs,
    activeJobs,
    isLoading: jobsQuery.isLoading || escrowQuery.isLoading,
    driverPosition,
    createJob,
    acceptJob,
    updateStatus,
    confirmDelivery,
  };
}
