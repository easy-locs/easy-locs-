import { useMemo, useState } from "react";
import { groupOrbitResults, runOrbitSearch } from "@/lib/orbit-search";

export function useOrbitSearch(initialQuery = "") {
  const [query, setQuery] = useState(initialQuery);
  const results = useMemo(() => runOrbitSearch(query), [query]);
  const grouped = useMemo(() => groupOrbitResults(results), [results]);

  return {
    query,
    setQuery,
    results,
    grouped,
    hasResults: results.length > 0,
  };
}
