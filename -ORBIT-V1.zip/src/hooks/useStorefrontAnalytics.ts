import { useMemo } from "react";
import { buildAnalyticsSnapshot, buildPerformanceCards, estimateTopInsight } from "@/lib/storefront-analytics";

export function useStorefrontAnalytics(storefrontId?: string | null) {
  const snapshot = useMemo(() => buildAnalyticsSnapshot({ storefrontId: storefrontId || "demo-storefront" }), [storefrontId]);
  const cards = useMemo(() => buildPerformanceCards(snapshot), [snapshot]);
  const topInsight = useMemo(() => estimateTopInsight(snapshot), [snapshot]);

  return {
    snapshot,
    cards,
    topInsight,
    loading: false,
  };
}
