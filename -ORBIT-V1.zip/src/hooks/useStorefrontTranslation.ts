import { useMemo, useState } from "react";
import {
  buildStorefrontTranslationSuggestions,
  buildStorefrontTranslationSummary,
  resolveTranslatedCatalogItem,
  resolveTranslatedField,
  type CatalogTranslationBundle,
  type StorefrontTranslationBundle,
  type SupportedStorefrontLanguage,
} from "@/lib/storefront-translation";

interface UseStorefrontTranslationOptions {
  storefront: StorefrontTranslationBundle;
  catalog?: CatalogTranslationBundle[];
  initialLanguage?: SupportedStorefrontLanguage;
}

export function useStorefrontTranslation(options: UseStorefrontTranslationOptions) {
  const [language, setLanguage] = useState<SupportedStorefrontLanguage>(options.initialLanguage || options.storefront.language || "en");

  const suggestions = useMemo(() => buildStorefrontTranslationSuggestions(options.storefront), [options.storefront]);
  const summary = useMemo(() => buildStorefrontTranslationSummary(options.storefront), [options.storefront]);

  const translatedStorefront = useMemo(() => ({
    ...options.storefront,
    shopName: resolveTranslatedField(options.storefront.shopName, options.storefront.translations, "shopName", language),
    description: resolveTranslatedField(options.storefront.description, options.storefront.translations, "description", language),
  }), [language, options.storefront]);

  const translatedCatalog = useMemo(() => (
    (options.catalog || []).map((item) => resolveTranslatedCatalogItem(item, language))
  ), [language, options.catalog]);

  return {
    language,
    setLanguage,
    suggestions,
    summary,
    translatedStorefront,
    translatedCatalog,
  };
}

export default useStorefrontTranslation;
