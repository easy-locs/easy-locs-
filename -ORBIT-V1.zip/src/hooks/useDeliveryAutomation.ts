import { useEffect, useMemo, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { buildAutomationSnapshot } from "@/lib/delivery-automation";
import { emitDeliveryAutomationEvents } from "@/services/delivery-events";
import { useDeliveryTimeline } from "@/hooks/useDeliveryTimeline";

function normaliseJobStatus(status: string): string {
  if (["nearby", "arrived"].includes(status)) return "in_transit";
  if (status === "en_route") return "picked_up";
  if (status === "accepted") return "accepted";
  if (status === "delivered") return "delivered";
  if (status === "confirmed") return "confirmed";
  if (status === "released") return "released";
  return status;
}

export function useDeliveryAutomation(jobId?: string | null) {
  const qc = useQueryClient();
  const { job, tracking, driver, steps, nextAction, isLoading } = useDeliveryTimeline(jobId);

  const snapshot = useMemo(() => buildAutomationSnapshot(job, tracking.session), [job, tracking.session]);
  const emittedRef = useRef<string | null>(null);

  useEffect(() => {
    if (!jobId) return;
    const signature = `${jobId}:${snapshot.derivedStatus}:${snapshot.autoReleaseReady}`;
    if (emittedRef.current === signature) return;
    emittedRef.current = signature;
    emitDeliveryAutomationEvents(jobId, snapshot);
  }, [jobId, snapshot]);

  const applyAutomation = useMutation({
    mutationFn: async () => {
      if (!jobId || !job) throw new Error("No delivery job selected.");
      const now = new Date().toISOString();
      const nextJobStatus = normaliseJobStatus(snapshot.derivedStatus);

      if (job.status !== nextJobStatus && !["released", "confirmed"].includes(job.status ?? "")) {
        const patch: Record<string, any> = { status: nextJobStatus, updated_at: now };
        if (nextJobStatus === "picked_up") patch.picked_up_at = now;
        if (nextJobStatus === "delivered") patch.delivered_at = now;

        const { error: jobError } = await supabase
          .from("delivery_jobs" as any)
          .update(patch as any)
          .eq("id", jobId);
        if (jobError) throw jobError;
      }

      if (tracking.trackingId) {
        const trackingStatus =
          snapshot.derivedStatus === "delivered" ? "completed" :
          snapshot.derivedStatus === "arrived" ? "arrived" :
          snapshot.derivedStatus === "nearby" ? "nearby" : "en_route";

        const { error: trackingError } = await supabase
          .from("live_trackings" as any)
          .update({
            status: trackingStatus,
            eta_minutes: snapshot.etaMinutes,
            updated_at: now,
          } as any)
          .eq("id", tracking.trackingId);
        if (trackingError) throw trackingError;
      }

      if (snapshot.autoReleaseReady && job.escrow?.status !== "released") {
        await supabase
          .from("escrow_payments" as any)
          .update({ status: "released", released_at: now, updated_at: now } as any)
          .eq("order_id", job.order_id ?? "");
      }

      return { appliedAt: now, status: snapshot.derivedStatus };
    },
    onSuccess: async () => {
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["delivery_jobs"] }),
        qc.invalidateQueries({ queryKey: ["delivery_timeline_job", jobId] }),
        qc.invalidateQueries({ queryKey: ["delivery_escrow"] }),
      ]);
    },
  });

  return {
    job,
    driver,
    steps,
    tracking,
    nextAction,
    snapshot,
    isLoading,
    applyAutomation,
  };
}
