import { useMemo } from "react";
import { useOrbitLaunchReadiness } from "@/hooks/useOrbitLaunchReadiness";
import { buildOrbitHardeningReport } from "@/lib/orbit-hardening";
import type { MockStorefront } from "@/lib/storefront-directory";

export function useOrbitHealth(storefront: MockStorefront | null | undefined) {
  const readiness = useOrbitLaunchReadiness(storefront ?? undefined);
  const hardening = useMemo(() => buildOrbitHardeningReport(readiness), [readiness]);

  return {
    readiness,
    hardening,
    launchReady: hardening.criticalCount === 0 && readiness.score >= 80,
  };
}
