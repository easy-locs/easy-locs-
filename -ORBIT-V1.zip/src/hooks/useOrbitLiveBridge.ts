import { useMemo } from "react";
import { buildOrbitLiveBridgeReport, DEFAULT_ORBIT_MODULE_CONNECTIONS, type OrbitModuleConnection } from "@/lib/orbit-live-bridge";

export function useOrbitLiveBridge(overrides?: OrbitModuleConnection[]) {
  return useMemo(() => buildOrbitLiveBridgeReport(overrides || DEFAULT_ORBIT_MODULE_CONNECTIONS), [overrides]);
}
