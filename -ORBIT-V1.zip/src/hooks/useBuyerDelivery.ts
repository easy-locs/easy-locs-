import { useMemo } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useSmartDeliveryRadar, type DeliveryJobView } from "@/hooks/useSmartDeliveryRadar";

export interface BuyerDeliverySupportTicket {
  id: string;
  title: string;
  status: "open" | "in_review" | "resolved";
  createdAt: string;
}

export interface BuyerDeliverySummary {
  total: number;
  active: number;
  awaitingCode: number;
  released: number;
}

const demoBuyerJobs: DeliveryJobView[] = [
  {
    id: "buyer-demo-live",
    order_id: "order-buyer-live",
    seller_id: "seller-demo",
    buyer_id: "buyer-demo",
    driver_id: "driver-demo",
    status: "in_transit",
    pickup_lat: 25.2048,
    pickup_lng: 55.2708,
    dropoff_lat: 25.0802,
    dropoff_lng: 55.1401,
    radius_km: 5,
    price: 29,
    package_size: "standard",
    package_weight_kg: 2,
    requires_two_person_lift: false,
    is_fragile: false,
    pricing_mode: "fixed",
    confirmation_code: "4821",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    summary: {
      distanceKm: 17.5,
      suggestedPrice: 29,
      parcelLabel: "Standard parcel",
      fragileLabel: null,
      isBigParcel: false,
    },
    escrow: {
      id: "escrow-buyer-live",
      order_id: "order-buyer-live",
      seller_amount: 76,
      driver_amount: 21,
      platform_fee: 8,
      status: "held",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  },
  {
    id: "buyer-demo-done",
    order_id: "order-buyer-done",
    seller_id: "seller-demo",
    buyer_id: "buyer-demo",
    driver_id: "driver-demo-2",
    status: "released",
    pickup_lat: 25.226,
    pickup_lng: 55.291,
    dropoff_lat: 25.193,
    dropoff_lng: 55.247,
    radius_km: 5,
    price: 24,
    package_size: "small",
    package_weight_kg: 1,
    requires_two_person_lift: false,
    is_fragile: true,
    pricing_mode: "fixed",
    confirmation_code: "1812",
    created_at: new Date(Date.now() - 86400000).toISOString(),
    updated_at: new Date(Date.now() - 86400000).toISOString(),
    summary: {
      distanceKm: 5.8,
      suggestedPrice: 24,
      parcelLabel: "Small parcel",
      fragileLabel: "Fragile",
      isBigParcel: false,
    },
    escrow: {
      id: "escrow-buyer-done",
      order_id: "order-buyer-done",
      seller_amount: 70,
      driver_amount: 17,
      platform_fee: 7,
      status: "released",
      released_at: new Date(Date.now() - 82000000).toISOString(),
      created_at: new Date(Date.now() - 86400000).toISOString(),
      updated_at: new Date(Date.now() - 82000000).toISOString(),
    },
  },
];

const demoTickets: BuyerDeliverySupportTicket[] = [
  { id: "ticket-1", title: "Driver is running late", status: "in_review", createdAt: new Date().toISOString() },
  { id: "ticket-2", title: "Confirm refund for damaged packaging", status: "resolved", createdAt: new Date(Date.now() - 86400000).toISOString() },
];

export function buildBuyerDeliverySummary(jobs: DeliveryJobView[]): BuyerDeliverySummary {
  return {
    total: jobs.length,
    active: jobs.filter((job) => ["accepted", "picked_up", "in_transit", "on_route_to_pickup", "on_route_to_dropoff", "delivered"].includes(job.status)).length,
    awaitingCode: jobs.filter((job) => ["delivered", "confirmed"].includes(job.status) || Boolean(job.confirmation_code && !["released", "cancelled"].includes(job.status))).length,
    released: jobs.filter((job) => job.status === "released" || job.escrow?.status === "released").length,
  };
}

export function buildBuyerNextStep(job: DeliveryJobView): string {
  switch (job.status) {
    case "open":
      return "Seller is preparing your delivery.";
    case "accepted":
    case "on_route_to_pickup":
      return "Driver assigned. Get ready for pickup confirmation.";
    case "picked_up":
    case "in_transit":
    case "on_route_to_dropoff":
      return "Track the driver live and keep your delivery code ready.";
    case "delivered":
    case "confirmed":
      return "Enter your delivery code to release payment safely.";
    case "released":
      return "Delivery complete. You can rate the driver or request support.";
    case "failed_delivery":
      return "Delivery failed. Review support options or reschedule.";
    case "dispute":
      return "Support is reviewing this delivery issue.";
    default:
      return "Follow the next guided step from your dashboard.";
  }
}

export function useBuyerDelivery(buyerId?: string | null) {
  const radar = useSmartDeliveryRadar(8);
  const qc = useQueryClient();

  const jobs = useMemo(() => {
    const filtered = (radar.jobs ?? []).filter((job) => !buyerId || job.buyer_id === buyerId);
    return filtered.length ? filtered : demoBuyerJobs;
  }, [buyerId, radar.jobs]);

  const summary = useMemo(() => buildBuyerDeliverySummary(jobs), [jobs]);

  const saveRating = useMutation({
    mutationFn: async (input: { jobId: string; rating: number; note?: string }) => ({
      ...input,
      savedAt: new Date().toISOString(),
    }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["delivery_jobs"] });
    },
  });

  const createSupportTicket = useMutation({
    mutationFn: async (title: string) => ({
      id: `local-${Date.now()}`,
      title,
      status: "open" as const,
      createdAt: new Date().toISOString(),
    }),
  });

  return {
    jobs,
    activeJob: jobs.find((job) => ["accepted", "picked_up", "in_transit", "on_route_to_dropoff", "delivered", "confirmed"].includes(job.status)) ?? jobs[0] ?? null,
    summary,
    supportTickets: demoTickets,
    confirmDelivery: radar.confirmDelivery,
    saveRating,
    createSupportTicket,
    isLoading: radar.isLoading,
    refetch: async () => {
      await qc.invalidateQueries({ queryKey: ["delivery_jobs"] });
    },
  };
}
