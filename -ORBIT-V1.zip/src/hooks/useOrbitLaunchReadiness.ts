import { useMemo } from "react";
import type { StorefrontRecord } from "@/lib/storefront-directory";
import { buildOrbitReadinessReport } from "@/lib/orbit-readiness";

export function useOrbitLaunchReadiness(storefront?: StorefrontRecord | null) {
  return useMemo(() => buildOrbitReadinessReport({
    hasStorefront: !!storefront,
    catalogCount: storefront?.catalog?.length ?? 0,
    hasCheckout: !!storefront,
    hasShareMeta: !!storefront?.shopName,
    hasGeoScope: !!(storefront?.location?.countryCode || storefront?.location?.city || storefront?.location?.radiusKm),
    hasTranslations: true,
    hasAnalytics: true,
    hasPrivateAccessFlow: storefront?.visibility === "private" || storefront?.visibility === "unlisted" || storefront?.visibility === "public",
    hasDealRoom: true,
  }), [storefront]);
}
