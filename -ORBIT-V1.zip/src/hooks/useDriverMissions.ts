import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface DriverMissionItem {
  id: string;
  order_id?: string | null;
  status: string;
  price: number;
  package_size?: string | null;
  created_at?: string | null;
  accepted_at?: string | null;
  delivered_at?: string | null;
  pickup_lat?: number | null;
  pickup_lng?: number | null;
  dropoff_lat?: number | null;
  dropoff_lng?: number | null;
}

export interface DriverEarningItem {
  id: string;
  amount: number;
  currency: string;
  status: string;
  created_at?: string | null;
}

const demoMissions: DriverMissionItem[] = [
  { id: "demo-open", status: "accepted", price: 24, package_size: "standard", created_at: new Date().toISOString(), accepted_at: new Date().toISOString(), pickup_lat: 25.2048, pickup_lng: 55.2708, dropoff_lat: 25.089, dropoff_lng: 55.148 },
  { id: "demo-finished", status: "delivered", price: 31, package_size: "large", created_at: new Date(Date.now() - 86400000).toISOString(), delivered_at: new Date(Date.now() - 86000000).toISOString(), pickup_lat: 25.225, pickup_lng: 55.29, dropoff_lat: 25.19, dropoff_lng: 55.26 },
  { id: "demo-held", status: "confirmed", price: 18, package_size: "small", created_at: new Date(Date.now() - 172800000).toISOString(), delivered_at: new Date(Date.now() - 171000000).toISOString(), pickup_lat: 25.18, pickup_lng: 55.24, dropoff_lat: 25.23, dropoff_lng: 55.31 },
];

const demoEarnings: DriverEarningItem[] = [
  { id: "earn-1", amount: 31, currency: "AED", status: "released", created_at: new Date(Date.now() - 86000000).toISOString() },
  { id: "earn-2", amount: 18, currency: "AED", status: "pending", created_at: new Date(Date.now() - 171000000).toISOString() },
  { id: "earn-3", amount: 22, currency: "AED", status: "released", created_at: new Date(Date.now() - 250000000).toISOString() },
];

export function useDriverMissions(userId?: string | null, driverProfileId?: string | null) {
  const missionsQuery = useQuery({
    queryKey: ["driver_missions", userId],
    enabled: Boolean(userId),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("delivery_jobs" as any)
        .select("id, order_id, status, price, package_size, created_at, accepted_at, delivered_at, pickup_lat, pickup_lng, dropoff_lat, dropoff_lng")
        .eq("driver_id", userId as string)
        .order("created_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      return ((data as DriverMissionItem[] | null) ?? []).length ? (data as DriverMissionItem[]) : demoMissions;
    },
  });

  const earningsQuery = useQuery({
    queryKey: ["driver_earnings", driverProfileId],
    enabled: Boolean(driverProfileId),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("driver_earnings" as any)
        .select("id, amount, currency, status, created_at")
        .eq("driver_id", driverProfileId as string)
        .order("created_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      return ((data as DriverEarningItem[] | null) ?? []).length ? (data as DriverEarningItem[]) : demoEarnings;
    },
  });

  const summary = useMemo(() => {
    const missions = missionsQuery.data ?? demoMissions;
    const earnings = earningsQuery.data ?? demoEarnings;
    const totalEarnings = earnings.reduce((sum, item) => sum + Number(item.amount || 0), 0);
    const pendingEarnings = earnings.filter((item) => item.status !== "released").reduce((sum, item) => sum + Number(item.amount || 0), 0);
    const completed = missions.filter((m) => ["delivered", "confirmed", "released"].includes(m.status)).length;
    const active = missions.filter((m) => ["accepted", "picked_up", "in_transit"].includes(m.status)).length;
    return { totalEarnings, pendingEarnings, completed, active, missionsCount: missions.length };
  }, [missionsQuery.data, earningsQuery.data]);

  return {
    missions: missionsQuery.data ?? demoMissions,
    earnings: earningsQuery.data ?? demoEarnings,
    summary,
    isLoading: missionsQuery.isLoading || earningsQuery.isLoading,
    refetch: async () => {
      await Promise.all([missionsQuery.refetch(), earningsQuery.refetch()]);
    },
  };
}
