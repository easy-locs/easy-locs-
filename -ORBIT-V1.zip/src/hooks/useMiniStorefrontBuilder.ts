import { useMemo, useState } from "react";
import {
  type MiniActivitySuggestion,
  type SupportedLocale,
  buildSmartStorefrontSummary,
  suggestMiniActivityFromText,
} from "@/lib/orbit-taxonomy";

export interface StorefrontDraft {
  storefrontName: string;
  companyName: string;
  locale: SupportedLocale;
  description: string;
  activities: MiniActivitySuggestion[];
}

export function useMiniStorefrontBuilder(initial?: Partial<StorefrontDraft>) {
  const [draft, setDraft] = useState<StorefrontDraft>({
    storefrontName: initial?.storefrontName ?? "My Orbit Store",
    companyName: initial?.companyName ?? "",
    locale: initial?.locale ?? "en",
    description: initial?.description ?? "",
    activities: initial?.activities ?? [],
  });
  const [inputText, setInputText] = useState("");

  const addActivityFromText = (rawText?: string) => {
    const source = (rawText ?? inputText).trim();
    if (!source) return null;
    const suggestion = suggestMiniActivityFromText(source);
    setDraft(prev => ({
      ...prev,
      activities: [...prev.activities, suggestion],
      description: prev.description || source,
    }));
    setInputText("");
    return suggestion;
  };

  const removeActivity = (index: number) => {
    setDraft(prev => ({
      ...prev,
      activities: prev.activities.filter((_, currentIndex) => currentIndex !== index),
    }));
  };

  const updateActivityName = (index: number, name: string) => {
    setDraft(prev => ({
      ...prev,
      activities: prev.activities.map((activity, currentIndex) => currentIndex === index ? { ...activity, name } : activity),
    }));
  };

  const storefrontSummary = useMemo(() => buildSmartStorefrontSummary({
    shopName: draft.storefrontName,
    activities: draft.activities,
    locale: draft.locale,
  }), [draft.activities, draft.locale, draft.storefrontName]);

  return {
    draft,
    setDraft,
    inputText,
    setInputText,
    addActivityFromText,
    removeActivity,
    updateActivityName,
    storefrontSummary,
  };
}
