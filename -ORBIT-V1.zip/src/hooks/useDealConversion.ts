import { useMemo, useState } from "react";
import { getDealConversionTargets, type DealConversionInput } from "@/lib/deal-conversion";
import { convertDealToOrderBundle } from "@/lib/deal-conversion-binding";

export function useDealConversion(input: DealConversionInput) {
  const [converted, setConverted] = useState<any | null>(null);
  const [converting, setConverting] = useState(false);
  const preview = useMemo(() => ({
    targets: getDealConversionTargets(input),
    acceptedAmount: input.acceptedAmount ?? 0,
  }), [input]);

  const convert = async () => {
    setConverting(true);
    try {
      const result = await convertDealToOrderBundle(input);
      setConverted(result);
      return result;
    } finally {
      setConverting(false);
    }
  };

  return {
    preview,
    result: converted,
    converting,
    convert,
    reset: () => setConverted(null),
  };
}
