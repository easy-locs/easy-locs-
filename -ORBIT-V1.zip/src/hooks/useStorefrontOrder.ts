import { useCallback, useEffect, useMemo, useState } from "react";
import type { CatalogEntryDraft } from "@/lib/public-shop";
import {
  addEntryToCart,
  buildOrderConversionTargets,
  buildUnifiedOrderDraft,
  canCheckoutCart,
  emptyCart,
  setCartItemQuantity,
  summarizeCart,
  type OrderFulfillmentMode,
  type OrderPaymentMode,
} from "@/lib/storefront-order-engine";

function storageKey(slug: string) {
  return `orbit:shop-cart:${slug}`;
}

export function useStorefrontOrder(slug: string, currency = "AED") {
  const [note, setNote] = useState("");
  const [paymentMode, setPaymentMode] = useState<OrderPaymentMode>("card");
  const [fulfillmentMode, setFulfillmentMode] = useState<OrderFulfillmentMode>("delivery");
  const [cart, setCart] = useState(() => emptyCart(slug, currency));

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const raw = window.localStorage.getItem(storageKey(slug));
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed?.slug === slug && Array.isArray(parsed?.items)) {
          setCart(parsed);
        }
      }
    } catch {
      // ignore malformed storage
    }
  }, [slug]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(storageKey(slug), JSON.stringify(cart));
  }, [slug, cart]);

  const addToCart = useCallback((entry: CatalogEntryDraft, quantity = 1) => {
    setCart((prev) => addEntryToCart(prev.slug === slug ? prev : emptyCart(slug, currency), entry, quantity));
  }, [slug, currency]);

  const updateQuantity = useCallback((entryId: string, quantity: number) => {
    setCart((prev) => setCartItemQuantity(prev, entryId, quantity));
  }, []);

  const clearCart = useCallback(() => {
    setCart(emptyCart(slug, currency));
  }, [slug, currency]);

  const summary = useMemo(() => summarizeCart(cart), [cart]);
  const orderDraft = useMemo(() => buildUnifiedOrderDraft(cart, { note, paymentMode, fulfillmentMode }), [cart, note, paymentMode, fulfillmentMode]);
  const checkoutReady = useMemo(() => canCheckoutCart(cart), [cart]);
  const conversionTargets = useMemo(() => buildOrderConversionTargets(orderDraft), [orderDraft]);

  return {
    cart,
    summary,
    note,
    setNote,
    paymentMode,
    setPaymentMode,
    fulfillmentMode,
    setFulfillmentMode,
    orderDraft,
    checkoutReady,
    conversionTargets,
    addToCart,
    updateQuantity,
    clearCart,
  };
}
