import { useEffect, useMemo, useState } from "react";
import type { ShopLocationScope } from "@/lib/public-shop";
import { evaluateGeoAvailability, type ViewerGeoContext } from "@/lib/shop-geo-scope";

const STORAGE_KEY = "orbit.viewer.geo-scope";

export function useShopGeoScope(shopScope?: ShopLocationScope | null) {
  const [viewer, setViewer] = useState<ViewerGeoContext>(() => {
    if (typeof window === "undefined") return { countryCode: "AE", city: "Dubai" };
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : { countryCode: inferCountryCode(), city: undefined };
    } catch {
      return { countryCode: inferCountryCode(), city: undefined };
    }
  });
  const [locating, setLocating] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(viewer));
  }, [viewer]);

  const availability = useMemo(() => evaluateGeoAvailability(shopScope, viewer), [shopScope, viewer]);

  const updateViewer = (patch: Partial<ViewerGeoContext>) => {
    setViewer((prev) => ({ ...prev, ...patch }));
  };

  const detectLocation = async () => {
    if (typeof navigator === "undefined" || !navigator.geolocation) return false;
    setLocating(true);
    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) =>
        navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true, timeout: 10000 })
      );
      setViewer((prev) => ({
        ...prev,
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
      }));
      return true;
    } catch {
      return false;
    } finally {
      setLocating(false);
    }
  };

  return {
    viewer,
    updateViewer,
    detectLocation,
    locating,
    availability,
  };
}

function inferCountryCode() {
  if (typeof navigator === "undefined") return "AE";
  const lang = navigator.language?.toLowerCase() || "en";
  if (lang.includes("fr")) return "FR";
  if (lang.includes("es")) return "ES";
  if (lang.includes("zh")) return "CN";
  if (lang.includes("ar")) return "AE";
  return "US";
}
