import { useCallback, useState } from "react";
import type { UnifiedOrderDraft } from "@/lib/storefront-order-engine";
import { createStorefrontOrderBundle, type StorefrontOrderBundle } from "@/lib/storefront-order-binding";

export function useStorefrontOrderBinding() {
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<StorefrontOrderBundle | null>(null);
  const [error, setError] = useState<string | null>(null);

  const submitOrder = useCallback(async (input: {
    storefrontId?: string | null;
    storefrontSlug: string;
    draft: UnifiedOrderDraft;
    customerId?: string | null;
    dealRoomId?: string | null;
  }) => {
    setSubmitting(true);
    setError(null);
    try {
      const bundle = await createStorefrontOrderBundle(input);
      setResult(bundle);
      return bundle;
    } catch (err: any) {
      const message = err?.message || "Unable to create order bundle.";
      setError(message);
      throw err;
    } finally {
      setSubmitting(false);
    }
  }, []);

  return {
    submitting,
    result,
    error,
    submitOrder,
    reset: () => {
      setResult(null);
      setError(null);
    },
  };
}
