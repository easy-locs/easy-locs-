import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useDeliveryTracking } from "@/hooks/useDeliveryTracking";
import { buildBuyerNextStep } from "@/hooks/useBuyerDelivery";
import type { DeliveryJobView } from "@/hooks/useSmartDeliveryRadar";

export interface DeliveryDriverCardInfo {
  id: string;
  label: string;
  vehicle: string;
  status: string;
  rating: number;
  phone?: string | null;
  etaMinutes?: number | null;
}

export interface DeliveryTimelineStepView {
  key: string;
  label: string;
  status: "done" | "current" | "pending" | "issue";
  timestamp?: string | null;
  hint?: string;
}

const STATUS_LABELS: Record<string, string> = {
  open: "Order created",
  accepted: "Driver assigned",
  on_route_to_pickup: "Driver heading to pickup",
  picked_up: "Package picked up",
  in_transit: "On the way",
  on_route_to_dropoff: "Driver heading to customer",
  delivered: "Delivered",
  confirmed: "Buyer confirmed",
  released: "Money released",
  failed_delivery: "Delivery failed",
  dispute: "Dispute opened",
  cancelled: "Cancelled",
};

const FLOW = ["open", "accepted", "picked_up", "in_transit", "delivered", "confirmed", "released"] as const;

export function buildDeliveryTimelineSteps(job: Partial<DeliveryJobView>, trackingStatus?: string | null): DeliveryTimelineStepView[] {
  if (["failed_delivery", "dispute", "cancelled"].includes(job.status ?? "")) {
    return [
      { key: "open", label: STATUS_LABELS.open, status: "done", timestamp: job.created_at ?? null },
      { key: job.status ?? "issue", label: STATUS_LABELS[job.status ?? ""] ?? "Issue", status: "issue", timestamp: job.updated_at ?? null },
      { key: "resolve", label: "Resolve the issue", status: "current", hint: "Use support, refund, or reschedule." },
    ];
  }

  const status = (job.status ?? "open") as string;
  const currentIndex = Math.max(0, FLOW.indexOf((FLOW as readonly string[]).includes(status) ? status : "open"));
  const steps = FLOW.map((step, index) => {
    const timestamp =
      step === "open" ? job.created_at :
      step === "accepted" ? ((job as any).accepted_at ?? null) :
      step === "picked_up" ? ((job as any).picked_up_at ?? null) :
      step === "delivered" ? ((job as any).delivered_at ?? null) :
      step === "released" ? ((job.escrow as any)?.released_at ?? null) :
      job.updated_at ?? null;

    return {
      key: step,
      label: STATUS_LABELS[step] ?? step,
      status: index < currentIndex ? "done" : index === currentIndex ? "current" : "pending",
      timestamp,
      hint:
        step === "in_transit" && trackingStatus ? `GPS status: ${trackingStatus.replace(/_/g, " ")}` :
        step === "confirmed" ? "Buyer shares the code only after receiving the parcel." : undefined,
    } satisfies DeliveryTimelineStepView;
  });

  return steps;
}

export function useDeliveryTimeline(jobId?: string | null) {
  const tracking = useDeliveryTracking(jobId);

  const jobQuery = useQuery({
    queryKey: ["delivery_timeline_job", jobId],
    enabled: Boolean(jobId),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("delivery_jobs" as any)
        .select("*")
        .eq("id", jobId as string)
        .maybeSingle();
      if (error) throw error;
      return (data as DeliveryJobView | null) ?? null;
    },
  });

  const driverQuery = useQuery({
    queryKey: ["delivery_timeline_driver", jobQuery.data?.driver_id],
    enabled: Boolean(jobQuery.data?.driver_id),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("drivers" as any)
        .select("id, user_id, vehicle_type, status, reliability_score")
        .eq("user_id", jobQuery.data?.driver_id as string)
        .maybeSingle();
      if (error) throw error;
      return data as any;
    },
  });

  const steps = useMemo(
    () => buildDeliveryTimelineSteps(jobQuery.data ?? {}, tracking.session?.status ?? null),
    [jobQuery.data, tracking.session?.status],
  );

  const driver = useMemo<DeliveryDriverCardInfo | null>(() => {
    if (!jobQuery.data?.driver_id) return null;
    const row = driverQuery.data;
    return {
      id: row?.id ?? jobQuery.data.driver_id,
      label: row?.user_id ?? `Driver ${jobQuery.data.driver_id.slice(0, 8)}`,
      vehicle: row?.vehicle_type ?? "bike",
      status: row?.status ?? (jobQuery.data.status === "open" ? "waiting" : "active"),
      rating: Math.round(Number(row?.reliability_score ?? 0.94) * 50) / 10,
      etaMinutes: tracking.session?.eta_minutes ?? null,
    };
  }, [driverQuery.data, jobQuery.data, tracking.session?.eta_minutes]);

  return {
    job: jobQuery.data,
    driver,
    steps,
    tracking,
    nextAction: jobQuery.data ? buildBuyerNextStep(jobQuery.data) : "Delivery updates will appear here.",
    isLoading: jobQuery.isLoading || driverQuery.isLoading || tracking.loading,
  };
}
