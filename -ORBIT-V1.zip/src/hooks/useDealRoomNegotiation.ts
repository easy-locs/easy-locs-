import { useMemo, useState } from "react";

export type DealRoomState = "pending" | "negotiating" | "accepted" | "expired" | "cancelled";

export interface DealMessage {
  id: string;
  author: "creator" | "target";
  body: string;
  createdAt: string;
}

export interface DealOffer {
  currentOfferAmount?: number;
  counterOfferAmount?: number;
  acceptedAmount?: number;
  negotiationRound: number;
  offerExpiresAt?: string;
}

export function useDealRoomNegotiation(seed?: Partial<DealOffer & { state: DealRoomState }>) {
  const [state, setState] = useState<DealRoomState>(seed?.state ?? "pending");
  const [offer, setOffer] = useState<DealOffer>({
    currentOfferAmount: seed?.currentOfferAmount,
    counterOfferAmount: seed?.counterOfferAmount,
    acceptedAmount: seed?.acceptedAmount,
    negotiationRound: seed?.negotiationRound ?? 0,
    offerExpiresAt: seed?.offerExpiresAt,
  });
  const [messages, setMessages] = useState<DealMessage[]>([]);

  const sendOffer = (amount: number, body: string, author: DealMessage["author"]) => {
    const nextRound = offer.negotiationRound + 1;
    setOffer(prev => ({
      ...prev,
      currentOfferAmount: author === "creator" ? amount : prev.currentOfferAmount,
      counterOfferAmount: author === "target" ? amount : prev.counterOfferAmount,
      negotiationRound: nextRound,
      offerExpiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    }));
    setState("negotiating");
    setMessages(prev => [...prev, { id: `${Date.now()}-${prev.length}`, author, body, createdAt: new Date().toISOString() }]);
  };

  const acceptDeal = (amount: number) => {
    setOffer(prev => ({ ...prev, acceptedAmount: amount }));
    setState("accepted");
  };

  const rejectDeal = () => setState("cancelled");
  const expireDeal = () => setState("expired");

  const expiresInText = useMemo(() => {
    if (!offer.offerExpiresAt) return null;
    const diff = new Date(offer.offerExpiresAt).getTime() - Date.now();
    if (diff <= 0) return "Expired";
    const hours = Math.ceil(diff / (60 * 60 * 1000));
    return `${hours}h left`;
  }, [offer.offerExpiresAt]);

  return {
    state,
    offer,
    messages,
    sendOffer,
    acceptDeal,
    rejectDeal,
    expireDeal,
    expiresInText,
  };
}
