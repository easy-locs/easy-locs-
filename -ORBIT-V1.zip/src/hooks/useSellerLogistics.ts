import { useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useSmartDeliveryRadar, type DeliveryJobView } from "@/hooks/useSmartDeliveryRadar";

export interface SellerDeliveryDraft {
  buyerId?: string | null;
  pickupLat: number;
  pickupLng: number;
  dropoffLat: number;
  dropoffLng: number;
  packageSize: "small" | "standard" | "large";
  packageWeightKg?: number | null;
  fragile?: boolean;
  twoPersonLift?: boolean;
  radiusKm?: number;
  price?: number;
}

export interface SellerLogisticsSummary {
  total: number;
  actionNeeded: number;
  live: number;
  delivered: number;
  released: number;
  openValueAed: number;
}

export interface SellerDriverOption {
  id: string;
  label: string;
  status: string;
  vehicle: string;
  reliability: number;
}

const demoJobs: DeliveryJobView[] = [
  {
    id: "seller-demo-open",
    seller_id: "demo-seller",
    buyer_id: "demo-buyer",
    order_id: "order-demo-open",
    status: "open",
    pickup_lat: 25.2048,
    pickup_lng: 55.2708,
    dropoff_lat: 25.0802,
    dropoff_lng: 55.1401,
    radius_km: 5,
    price: 28,
    package_size: "standard",
    package_weight_kg: 2,
    requires_two_person_lift: false,
    is_fragile: false,
    pricing_mode: "fixed",
    summary: {
      distanceKm: 17.67,
      suggestedPrice: 28,
      parcelLabel: 'Standard parcel',
      fragileLabel: null,
      isBigParcel: false,
    },
    escrow: { id: "escrow-demo-open", order_id: "order-demo-open", seller_amount: 72, driver_amount: 20, platform_fee: 8, status: "held" },
  },
  {
    id: "seller-demo-live",
    seller_id: "demo-seller",
    buyer_id: "demo-buyer",
    driver_id: "driver-live",
    order_id: "order-demo-live",
    status: "in_transit",
    pickup_lat: 25.2104,
    pickup_lng: 55.2799,
    dropoff_lat: 25.1977,
    dropoff_lng: 55.2741,
    radius_km: 5,
    price: 24,
    package_size: "small",
    package_weight_kg: 1,
    requires_two_person_lift: false,
    is_fragile: true,
    pricing_mode: "fixed",
    summary: {
      distanceKm: 2.6,
      suggestedPrice: 24,
      parcelLabel: 'Standard parcel',
      fragileLabel: 'Fragile',
      isBigParcel: false,
    },
    escrow: { id: "escrow-demo-live", order_id: "order-demo-live", seller_amount: 70, driver_amount: 18, platform_fee: 6, status: "held" },
  },
  {
    id: "seller-demo-done",
    seller_id: "demo-seller",
    buyer_id: "demo-buyer",
    driver_id: "driver-done",
    order_id: "order-demo-done",
    status: "released",
    pickup_lat: 25.22,
    pickup_lng: 55.31,
    dropoff_lat: 25.19,
    dropoff_lng: 55.24,
    radius_km: 5,
    price: 31,
    package_size: "large",
    package_weight_kg: 8,
    requires_two_person_lift: true,
    is_fragile: false,
    pricing_mode: "fixed",
    summary: {
      distanceKm: 8.2,
      suggestedPrice: 31,
      parcelLabel: 'Large parcel',
      fragileLabel: null,
      isBigParcel: true,
    },
    escrow: { id: "escrow-demo-done", order_id: "order-demo-done", seller_amount: 90, driver_amount: 28, platform_fee: 8, status: "released", released_at: new Date().toISOString() },
  },
];

export function buildSellerSummary(jobs: DeliveryJobView[]): SellerLogisticsSummary {
  const actionNeeded = jobs.filter((job) => ["open", "failed_delivery", "dispute"].includes(job.status)).length;
  const live = jobs.filter((job) => ["accepted", "picked_up", "in_transit", "on_route_to_pickup", "on_route_to_dropoff"].includes(job.status)).length;
  const delivered = jobs.filter((job) => ["delivered", "confirmed"].includes(job.status)).length;
  const released = jobs.filter((job) => ["released"].includes(job.status) || job.escrow?.status === "released").length;
  const openValueAed = jobs
    .filter((job) => !["released", "cancelled"].includes(job.status))
    .reduce((sum, job) => sum + Number(job.price ?? 0), 0);

  return {
    total: jobs.length,
    actionNeeded,
    live,
    delivered,
    released,
    openValueAed,
  };
}

export function useSellerLogistics(sellerId?: string | null) {
  const qc = useQueryClient();
  const radar = useSmartDeliveryRadar(8);

  const sellerJobs = useMemo(() => {
    const filtered = (radar.jobs ?? []).filter((job) => !sellerId || job.seller_id === sellerId);
    return filtered.length ? filtered : demoJobs;
  }, [radar.jobs, sellerId]);

  const summary = useMemo(() => buildSellerSummary(sellerJobs), [sellerJobs]);

  const driversQuery = useQuery({
    queryKey: ["seller_driver_options"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("drivers" as any)
        .select("id, status, vehicle_type, reliability_score, user_id")
        .in("status", ["online", "paused", "busy"] as any)
        .order("reliability_score", { ascending: false })
        .limit(12);
      if (error) throw error;
      const rows = ((data as any[]) ?? []).map((row) => ({
        id: row.id,
        label: row.user_id ?? row.id,
        status: row.status,
        vehicle: row.vehicle_type,
        reliability: Number(row.reliability_score ?? 0),
      })) as SellerDriverOption[];
      return rows.length ? rows : [
        { id: "driver-fast", label: "Fast rider", status: "online", vehicle: "bike", reliability: 0.96 },
        { id: "driver-safe", label: "Safe courier", status: "online", vehicle: "car", reliability: 0.93 },
        { id: "driver-heavy", label: "Heavy cargo", status: "busy", vehicle: "van", reliability: 0.91 },
      ];
    },
  });

  const createDelivery = useMutation({
    mutationFn: async (draft: SellerDeliveryDraft) => {
      if (!sellerId) throw new Error("sellerId is required");
      return radar.createJob.mutateAsync({
        seller_id: sellerId,
        buyer_id: draft.buyerId ?? null,
        pickup_lat: draft.pickupLat,
        pickup_lng: draft.pickupLng,
        dropoff_lat: draft.dropoffLat,
        dropoff_lng: draft.dropoffLng,
        package_size: draft.packageSize,
        package_weight_kg: draft.packageWeightKg ?? null,
        requires_two_person_lift: draft.twoPersonLift ?? false,
        is_fragile: draft.fragile ?? false,
        radius_km: draft.radiusKm ?? 5,
        price: draft.price,
        total_amount: draft.price,
      });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["delivery_jobs"] }),
  });

  const assignDriver = useMutation({
    mutationFn: async ({ jobId, driverId }: { jobId: string; driverId: string }) => {
      const now = new Date().toISOString();
      const { data, error } = await supabase
        .from("delivery_jobs" as any)
        .update({
          driver_id: driverId,
          status: "accepted",
          accepted_at: now,
          updated_at: now,
        } as any)
        .eq("id", jobId)
        .select("*")
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["delivery_jobs"] }),
  });

  const markIssue = useMutation({
    mutationFn: async ({ jobId, issue }: { jobId: string; issue: "cancelled" | "dispute" | "failed_delivery" }) => {
      const { data, error } = await supabase
        .from("delivery_jobs" as any)
        .update({ status: issue, updated_at: new Date().toISOString() } as any)
        .eq("id", jobId)
        .select("*")
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["delivery_jobs"] }),
  });

  return {
    jobs: sellerJobs,
    summary,
    drivers: driversQuery.data ?? [],
    isLoading: radar.isLoading || driversQuery.isLoading,
    createDelivery,
    assignDriver,
    markIssue,
    refetch: async () => {
      await Promise.all([qc.invalidateQueries({ queryKey: ['delivery_jobs'] }), driversQuery.refetch()]);
    },
  };
}
