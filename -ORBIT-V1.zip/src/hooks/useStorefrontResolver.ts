import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { evaluateShopAccess, type ShopAccessDecision } from "@/lib/shop-access";
import { shouldTreatAsStorefront, type StorefrontRecord } from "@/lib/storefront-directory";
import { acceptStorefrontInviteToken, fetchStorefrontBySlug, fetchStorefrontInviteByToken } from "@/lib/storefront-supabase";

export function useStorefrontResolver(slug?: string) {
  const [searchParams] = useSearchParams();
  const [storefront, setStorefront] = useState<StorefrontRecord | null>(null);
  const [loading, setLoading] = useState(false);
  const [inviteAccepted, setInviteAccepted] = useState(false);
  const [acceptingInvite, setAcceptingInvite] = useState(false);
  const inviteToken = searchParams.get("invite");
  const direct = !!slug;

  useEffect(() => {
    let cancelled = false;
    setLoading(true);

    (async () => {
      const shop = await fetchStorefrontBySlug(slug);
      if (!cancelled) {
        setStorefront(shop);
        setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [slug]);

  const [invite, setInvite] = useState<any | null>(null);

  useEffect(() => {
    let cancelled = false;
    if (!inviteToken) {
      setInvite(null);
      return;
    }

    (async () => {
      const loaded = await fetchStorefrontInviteByToken(inviteToken);
      if (!cancelled) setInvite(loaded);
    })();

    return () => {
      cancelled = true;
    };
  }, [inviteToken]);

  const accessDecision: ShopAccessDecision | null = useMemo(() => {
    if (!storefront) return null;
    return evaluateShopAccess({
      visibility: storefront.visibility,
      hasDirectLink: direct,
      scheduledAt: storefront.scheduledAt,
      invite,
      role: "anonymous",
    });
  }, [storefront, direct, invite]);

  const acceptInvite = async () => {
    if (!inviteToken) return false;
    setAcceptingInvite(true);
    try {
      await acceptStorefrontInviteToken(inviteToken);
      setInviteAccepted(true);
      setInvite((prev: any) => ({ ...(prev || {}), status: "accepted" }));
      return true;
    } catch {
      return false;
    } finally {
      setAcceptingInvite(false);
    }
  };

  return {
    slug,
    storefront,
    inviteToken,
    loading,
    acceptingInvite,
    inviteAccepted,
    isStorefrontCandidate: shouldTreatAsStorefront(slug),
    accessDecision,
    acceptInvite,
  };
}
