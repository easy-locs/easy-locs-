import { useMemo, useState } from "react";
import { buildInviteLink, createShopInvite, evaluateShopAccess, type ShopAccessContext, type ShopInviteDraft } from "@/lib/shop-access";

export function useShopAccessControl(context: ShopAccessContext & { shopSlug: string }) {
  const [invites, setInvites] = useState<ShopInviteDraft[]>([]);
  const decision = useMemo(() => evaluateShopAccess(context), [context]);

  const addInvite = (email: string, role: ShopInviteDraft["role"] = "viewer") => {
    const next = createShopInvite(email, role);
    setInvites((prev) => [next, ...prev.filter((item) => item.email !== next.email)]);
    return next;
  };

  const acceptInvite = (inviteId: string) => {
    setInvites((prev) => prev.map((item) => item.id === inviteId ? { ...item, status: "accepted" } : item));
  };

  const revokeInvite = (inviteId: string) => {
    setInvites((prev) => prev.map((item) => item.id === inviteId ? { ...item, status: "revoked" } : item));
  };

  const getInviteLink = (inviteId: string) => buildInviteLink(typeof window !== "undefined" ? window.location.origin : "https://orbit.local", context.shopSlug, inviteId);

  return {
    decision,
    invites,
    addInvite,
    acceptInvite,
    revokeInvite,
    getInviteLink,
  };
}
