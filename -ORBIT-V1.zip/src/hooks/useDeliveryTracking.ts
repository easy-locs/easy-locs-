import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { findActiveTracking, useTrackingViewer } from "@/hooks/useLiveTracking";
import { useAuth } from "@/contexts/AuthContext";

interface DeliveryTrackingSession {
  id: string;
  status: string;
  current_lat: number | null;
  current_lng: number | null;
  destination_lat: number | null;
  destination_lng: number | null;
  eta_minutes?: number | null;
  updated_at?: string | null;
  speed_kmh?: number | null;
  heading?: number | null;
}

export function useDeliveryTracking(jobId?: string | null) {
  const [trackingId, setTrackingId] = useState<string | null>(null);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    if (!jobId) {
      setTrackingId(null);
      return;
    }

    let cancelled = false;
    setSearching(true);

    (async () => {
      const id = await findActiveTracking("delivery", jobId);
      if (!cancelled) {
        setTrackingId(id);
        setSearching(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [jobId]);

  const { tracking } = useTrackingViewer(trackingId);

  return {
    trackingId,
    session: (tracking as DeliveryTrackingSession | null) ?? null,
    loading: searching,
    hasTracking: Boolean(trackingId),
  };
}

export function useDeliveryTrackerStart() {
  const { user, orgId } = useAuth();
  const [starting, setStarting] = useState(false);

  const startTracking = useCallback(async (opts: {
    jobId: string;
    destinationLat?: number | null;
    destinationLng?: number | null;
    destinationLabel?: string | null;
    viewerUserId?: string | null;
  }) => {
    if (!user?.id || !orgId) {
      throw new Error("You must be signed in with an organisation to start tracking.");
    }

    setStarting(true);
    try {
      const existing = await findActiveTracking("delivery", opts.jobId);
      if (existing) return existing;

      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        if (!("geolocation" in navigator)) {
          reject(new Error("Geolocation is not available in this browser."));
          return;
        }
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 5000,
        });
      });

      const { data, error } = await supabase
        .from("live_trackings" as any)
        .insert({
          org_id: orgId,
          tracker_user_id: user.id,
          viewer_user_id: opts.viewerUserId ?? null,
          context_type: "delivery",
          context_id: opts.jobId,
          context_label: opts.destinationLabel ?? "Delivery",
          destination_lat: opts.destinationLat ?? null,
          destination_lng: opts.destinationLng ?? null,
          destination_label: opts.destinationLabel ?? null,
          origin_lat: position.coords.latitude,
          origin_lng: position.coords.longitude,
          current_lat: position.coords.latitude,
          current_lng: position.coords.longitude,
          status: "en_route",
          started_at: new Date().toISOString(),
          last_position_at: new Date().toISOString(),
          metadata_json: {
            context_type: "delivery",
            context_id: opts.jobId,
            started_by: user.id,
          },
        } as any)
        .select("id")
        .single();

      if (error) throw error;
      return (data as { id: string } | null)?.id ?? null;
    } finally {
      setStarting(false);
    }
  }, [orgId, user?.id]);

  return { startTracking, starting };
}
