import { useMemo } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useSellerLogistics } from "@/hooks/useSellerLogistics";
import { useDriverMissions } from "@/hooks/useDriverMissions";
import { useDriverStatus } from "@/hooks/useDriverStatus";
import { useBuyerDelivery } from "@/hooks/useBuyerDelivery";
import type { DeliveryJobView } from "@/hooks/useSmartDeliveryRadar";

export interface DeliveryTimelineStep {
  key: string;
  label: string;
  state: "done" | "active" | "upcoming" | "issue";
}

export interface DeliveryCommandItem {
  id: string;
  orderId: string;
  status: string;
  priceAed: number;
  packageLabel: string;
  ownerView: "seller" | "driver" | "buyer";
  nextAction: string;
  health: "good" | "watch" | "issue";
  timeline: DeliveryTimelineStep[];
}

export interface DeliveryCommandSummary {
  total: number;
  live: number;
  attention: number;
  completed: number;
  releasedValueAed: number;
}

const ORDERED_STATUSES = [
  "open",
  "accepted",
  "picked_up",
  "in_transit",
  "delivered",
  "confirmed",
  "released",
] as const;

const STATUS_LABELS: Record<string, string> = {
  open: "New order",
  accepted: "Driver assigned",
  picked_up: "Picked up",
  in_transit: "On the way",
  delivered: "Delivered",
  confirmed: "Buyer confirmed",
  released: "Money released",
  failed_delivery: "Delivery failed",
  dispute: "Dispute",
  cancelled: "Cancelled",
};

export function buildUnifiedNextAction(status: string, ownerView: DeliveryCommandItem["ownerView"]): string {
  switch (status) {
    case "open":
      return ownerView === "seller" ? "Assign a driver or use best available." : "Wait for seller assignment.";
    case "accepted":
      return ownerView === "driver" ? "Start pickup." : "Driver is heading to pickup.";
    case "picked_up":
      return ownerView === "driver" ? "Start delivery route." : "Watch live movement.";
    case "in_transit":
    case "on_route_to_dropoff":
      return ownerView === "buyer" ? "Keep delivery code ready." : "Track arrival and prepare confirmation.";
    case "delivered":
      return ownerView === "buyer" ? "Enter delivery code to confirm." : "Wait for buyer confirmation.";
    case "confirmed":
      return "Release and close the delivery.";
    case "released":
      return "Delivery complete. Review history or rating.";
    case "failed_delivery":
      return "Resolve failure or reschedule delivery.";
    case "dispute":
      return "Open support review and freeze changes.";
    case "cancelled":
      return "Delivery closed. Create a new mission if needed.";
    default:
      return "Review the latest status and take the guided next step.";
  }
}

export function buildDeliveryTimeline(status: string): DeliveryTimelineStep[] {
  if (["failed_delivery", "dispute", "cancelled"].includes(status)) {
    return [
      { key: "open", label: "New order", state: "done" },
      { key: status, label: STATUS_LABELS[status] ?? status, state: "issue" },
      { key: "recovery", label: "Resolve issue", state: "active" },
    ];
  }

  const currentIndex = Math.max(0, ORDERED_STATUSES.indexOf(status as (typeof ORDERED_STATUSES)[number]));
  return ORDERED_STATUSES.map((step, index) => ({
    key: step,
    label: STATUS_LABELS[step] ?? step,
    state: index < currentIndex ? "done" : index === currentIndex ? "active" : "upcoming",
  }));
}

export function summarizeDeliveryCommandCenter(items: DeliveryCommandItem[]): DeliveryCommandSummary {
  return {
    total: items.length,
    live: items.filter((item) => ["accepted", "picked_up", "in_transit", "on_route_to_dropoff", "delivered"].includes(item.status)).length,
    attention: items.filter((item) => ["open", "failed_delivery", "dispute"].includes(item.status)).length,
    completed: items.filter((item) => ["released", "confirmed"].includes(item.status)).length,
    releasedValueAed: items
      .filter((item) => item.status === "released")
      .reduce((sum, item) => sum + item.priceAed, 0),
  };
}

function inferOwnerView(job: DeliveryJobView, currentUserId?: string | null): DeliveryCommandItem["ownerView"] {
  if (currentUserId && job.driver_id === currentUserId) return "driver";
  if (currentUserId && job.buyer_id === currentUserId) return "buyer";
  return "seller";
}

function inferHealth(status: string): DeliveryCommandItem["health"] {
  if (["failed_delivery", "dispute", "cancelled"].includes(status)) return "issue";
  if (["open", "delivered", "confirmed"].includes(status)) return "watch";
  return "good";
}

export function mapJobToCommandItem(job: DeliveryJobView, currentUserId?: string | null): DeliveryCommandItem {
  const ownerView = inferOwnerView(job, currentUserId);
  return {
    id: job.id,
    orderId: job.order_id ?? job.id,
    status: job.status,
    priceAed: Number(job.price ?? 0),
    packageLabel: job.summary?.parcelLabel ?? "Delivery parcel",
    ownerView,
    nextAction: buildUnifiedNextAction(job.status, ownerView),
    health: inferHealth(job.status),
    timeline: buildDeliveryTimeline(job.status),
  };
}

export function useDeliveryCommandCenter() {
  const { user } = useAuth();
  const seller = useSellerLogistics(user?.id);
  const driverStatus = useDriverStatus(user?.id);
  const driver = useDriverMissions(user?.id, driverStatus.driver?.id);
  const buyer = useBuyerDelivery(user?.id);

  const sourceJobs = useMemo(() => {
    const combined = [...(seller.jobs ?? []), ...(buyer.jobs ?? [])];
    const deduped = new Map<string, DeliveryJobView>();
    combined.forEach((job) => deduped.set(job.id, job));
    return Array.from(deduped.values());
  }, [buyer.jobs, seller.jobs]);

  const items = useMemo(() => sourceJobs.map((job) => mapJobToCommandItem(job, user?.id)), [sourceJobs, user?.id]);
  const summary = useMemo(() => summarizeDeliveryCommandCenter(items), [items]);

  const weakestItem = useMemo(
    () => items.find((item) => item.health === "issue") ?? items.find((item) => item.health === "watch") ?? items[0] ?? null,
    [items],
  );

  return {
    items,
    summary,
    weakestItem,
    seller,
    buyer,
    driver,
    driverStatus: driverStatus.driver,
    isLoading: seller.isLoading || buyer.isLoading || driver.isLoading,
  };
}
