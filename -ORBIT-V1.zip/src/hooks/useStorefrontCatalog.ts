import { useMemo, useState } from "react";
import type { CatalogEntryDraft } from "@/lib/public-shop";
import {
  filterCatalogEntries,
  listCatalogCategories,
  summarizeCatalog,
  type StorefrontCatalogFilter,
} from "@/lib/storefront-catalog";

export function useStorefrontCatalog(entries: CatalogEntryDraft[]) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<StorefrontCatalogFilter>("all");
  const [category, setCategory] = useState("");

  const categories = useMemo(() => listCatalogCategories(entries), [entries]);
  const filteredEntries = useMemo(() => filterCatalogEntries(entries, { filter, query, category }), [entries, filter, query, category]);
  const summary = useMemo(() => summarizeCatalog(entries), [entries]);

  return {
    query,
    setQuery,
    filter,
    setFilter,
    category,
    setCategory,
    categories,
    filteredEntries,
    summary,
    resetFilters: () => {
      setQuery("");
      setFilter("all");
      setCategory("");
    },
  };
}
