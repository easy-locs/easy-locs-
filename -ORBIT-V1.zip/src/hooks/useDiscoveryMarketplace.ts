import { useMemo, useState } from "react";
import { DISCOVERY_MOCK_ITEMS, filterDiscoveryItems, groupDiscoveryItems } from "@/lib/discovery-marketplace";

export function useDiscoveryMarketplace(initial?: { countryCode?: string; city?: string; query?: string }) {
  const [countryCode, setCountryCode] = useState(initial?.countryCode || "");
  const [city, setCity] = useState(initial?.city || "");
  const [query, setQuery] = useState(initial?.query || "");

  const filtered = useMemo(
    () => filterDiscoveryItems(DISCOVERY_MOCK_ITEMS, { countryCode: countryCode || undefined, city: city || undefined, query }),
    [countryCode, city, query],
  );

  const grouped = useMemo(() => groupDiscoveryItems(filtered), [filtered]);

  return {
    countryCode,
    city,
    query,
    setCountryCode,
    setCity,
    setQuery,
    items: filtered,
    grouped,
  };
}
