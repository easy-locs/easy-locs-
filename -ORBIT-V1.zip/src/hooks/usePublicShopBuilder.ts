import { useMemo, useState } from "react";
import { addActivityToShop, buildShopPreviewMeta, buildShopShareTargets, createShopDraft, normalizeShopSlug, type PublicShopDraft, type ShopVisibility } from "@/lib/public-shop";

export function usePublicShopBuilder(initial?: Partial<PublicShopDraft>) {
  const [draft, setDraft] = useState<PublicShopDraft>(createShopDraft(initial));
  const [activityInput, setActivityInput] = useState("");

  const addActivity = (text?: string) => {
    const source = (text ?? activityInput).trim();
    if (!source) return null;
    setDraft(prev => {
      const next = addActivityToShop(prev, source);
      return {
        ...next,
        slug: prev.slug || normalizeShopSlug(next.shopName),
      };
    });
    setActivityInput("");
    return source;
  };

  const setVisibility = (visibility: ShopVisibility) => setDraft(prev => ({ ...prev, visibility }));

  const shareTargets = useMemo(() => buildShopShareTargets(typeof window !== "undefined" ? window.location.origin : "https://orbit.local", draft), [draft]);
  const previewMeta = useMemo(() => buildShopPreviewMeta(draft), [draft]);

  return {
    draft,
    setDraft,
    activityInput,
    setActivityInput,
    addActivity,
    setVisibility,
    shareTargets,
    previewMeta,
  };
}
