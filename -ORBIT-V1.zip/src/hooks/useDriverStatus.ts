import { useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { platformBus } from "@/lib/platform-bus";
import type { DriverAvailabilityStatus, DriverVehicleType } from "@/lib/delivery-dispatch";

export interface DriverStatusRecord {
  id: string;
  user_id: string;
  status: DriverAvailabilityStatus;
  vehicle_type: DriverVehicleType;
  lat?: number | null;
  lng?: number | null;
  reliability_score?: number | null;
  acceptance_rate?: number | null;
  average_pickup_minutes?: number | null;
  completed_jobs?: number | null;
  last_active?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
}

async function fetchOrCreateDriverProfile(userId: string): Promise<DriverStatusRecord> {
  const { data: existing, error: fetchError } = await supabase
    .from("drivers" as any)
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();

  if (fetchError) throw fetchError;
  if (existing) return existing as DriverStatusRecord;

  const { data: created, error: insertError } = await supabase
    .from("drivers" as any)
    .insert({ user_id: userId, status: "offline", vehicle_type: "bike", reliability_score: 0.8 } as any)
    .select("*")
    .single();

  if (insertError) throw insertError;
  return created as DriverStatusRecord;
}

export function useDriverStatus(userId?: string | null) {
  const qc = useQueryClient();

  const driverQuery = useQuery({
    queryKey: ["driver_status", userId],
    enabled: Boolean(userId),
    queryFn: async () => fetchOrCreateDriverProfile(userId as string),
  });

  useEffect(() => {
    if (!userId || !driverQuery.data?.id) return;
    const channel = supabase
      .channel(`driver-status-${driverQuery.data.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "drivers", filter: `id=eq.${driverQuery.data.id}` }, () => {
        qc.invalidateQueries({ queryKey: ["driver_status", userId] });
      })
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [userId, driverQuery.data?.id, qc]);

  const updateStatus = useMutation({
    mutationFn: async ({ status, lat, lng, vehicleType }: { status: DriverAvailabilityStatus; lat?: number; lng?: number; vehicleType?: DriverVehicleType }) => {
      if (!userId) throw new Error("userId is required");
      const current = driverQuery.data ?? await fetchOrCreateDriverProfile(userId);
      platformBus.emit("system:sync_started", { area: "driver_status", userId, status }, "delivery");
      const { data, error } = await supabase
        .from("drivers" as any)
        .update({
          status,
          lat: lat ?? current.lat ?? null,
          lng: lng ?? current.lng ?? null,
          vehicle_type: vehicleType ?? current.vehicle_type,
          last_active: new Date().toISOString(),
        } as any)
        .eq("id", current.id)
        .select("*")
        .single();
      if (error) throw error;
      platformBus.emit("system:sync_completed", { area: "driver_status", ok: true, userId, status }, "delivery");
      return data as DriverStatusRecord;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["driver_status", userId] }),
  });

  const updateLocation = useMutation({
    mutationFn: async ({ lat, lng }: { lat: number; lng: number }) => {
      if (!userId) throw new Error("userId is required");
      const current = driverQuery.data ?? await fetchOrCreateDriverProfile(userId);
      const { data, error } = await supabase
        .from("drivers" as any)
        .update({ lat, lng, last_active: new Date().toISOString() } as any)
        .eq("id", current.id)
        .select("*")
        .single();
      if (error) throw error;
      platformBus.emit("tracking:position_updated", { userId, lat, lng }, "delivery");
      return data as DriverStatusRecord;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["driver_status", userId] }),
  });

  return {
    driver: driverQuery.data,
    isLoading: driverQuery.isLoading,
    refetch: driverQuery.refetch,
    updateStatus,
    updateLocation,
  };
}
