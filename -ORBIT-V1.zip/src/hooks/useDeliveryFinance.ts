import { useMemo } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useSmartDeliveryRadar, type DeliveryJobView } from "@/hooks/useSmartDeliveryRadar";

export interface DeliveryFinanceSummary {
  held: number;
  released: number;
  disputed: number;
  refunds: number;
  heldValueAed: number;
  releasedValueAed: number;
}

export interface DeliveryFinanceItem {
  jobId: string;
  orderId: string;
  status: string;
  escrowStatus: string;
  sellerAmount: number;
  driverAmount: number;
  platformFee: number;
  grossAmount: number;
  moneyNextStep: string;
  risk: "low" | "watch" | "high";
}

export interface DeliveryDisputeDraft {
  jobId: string;
  reason: string;
  requestedAction: "refund" | "partial_refund" | "review";
}

const demoFinanceJobs: DeliveryJobView[] = [
  {
    id: "finance-demo-held",
    order_id: "order-finance-held",
    seller_id: "seller-demo",
    buyer_id: "buyer-demo",
    driver_id: "driver-demo",
    status: "confirmed",
    pickup_lat: 25.2048,
    pickup_lng: 55.2708,
    dropoff_lat: 25.193,
    dropoff_lng: 55.274,
    radius_km: 5,
    price: 120,
    package_size: "standard",
    package_weight_kg: 2,
    requires_two_person_lift: false,
    is_fragile: false,
    pricing_mode: "fixed",
    summary: {
      distanceKm: 3.2,
      suggestedPrice: 120,
      parcelLabel: "Standard parcel",
      fragileLabel: null,
      isBigParcel: false,
    },
    escrow: {
      id: "escrow-finance-held",
      order_id: "order-finance-held",
      seller_amount: 88,
      driver_amount: 22,
      platform_fee: 10,
      status: "held",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  },
  {
    id: "finance-demo-dispute",
    order_id: "order-finance-dispute",
    seller_id: "seller-demo",
    buyer_id: "buyer-demo",
    driver_id: "driver-demo",
    status: "dispute",
    pickup_lat: 25.21,
    pickup_lng: 55.28,
    dropoff_lat: 25.18,
    dropoff_lng: 55.25,
    radius_km: 5,
    price: 85,
    package_size: "small",
    package_weight_kg: 1,
    requires_two_person_lift: false,
    is_fragile: true,
    pricing_mode: "fixed",
    summary: {
      distanceKm: 5.9,
      suggestedPrice: 85,
      parcelLabel: "Small parcel",
      fragileLabel: "Fragile",
      isBigParcel: false,
    },
    escrow: {
      id: "escrow-finance-dispute",
      order_id: "order-finance-dispute",
      seller_amount: 60,
      driver_amount: 18,
      platform_fee: 7,
      status: "held",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  },
  {
    id: "finance-demo-released",
    order_id: "order-finance-released",
    seller_id: "seller-demo",
    buyer_id: "buyer-demo",
    driver_id: "driver-demo",
    status: "released",
    pickup_lat: 25.24,
    pickup_lng: 55.31,
    dropoff_lat: 25.19,
    dropoff_lng: 55.27,
    radius_km: 5,
    price: 99,
    package_size: "large",
    package_weight_kg: 7,
    requires_two_person_lift: true,
    is_fragile: false,
    pricing_mode: "fixed",
    summary: {
      distanceKm: 9.1,
      suggestedPrice: 99,
      parcelLabel: "Large parcel",
      fragileLabel: null,
      isBigParcel: true,
    },
    escrow: {
      id: "escrow-finance-released",
      order_id: "order-finance-released",
      seller_amount: 72,
      driver_amount: 19,
      platform_fee: 8,
      status: "released",
      released_at: new Date().toISOString(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  },
];

export function buildFinanceSummary(jobs: DeliveryJobView[]): DeliveryFinanceSummary {
  const heldJobs = jobs.filter((job) => job.escrow?.status === "held");
  const releasedJobs = jobs.filter((job) => job.escrow?.status === "released" || job.status === "released");
  const disputedJobs = jobs.filter((job) => job.status === "dispute");
  const refundJobs = jobs.filter((job) => ["refund", "partial_refund"].includes(job.status));

  return {
    held: heldJobs.length,
    released: releasedJobs.length,
    disputed: disputedJobs.length,
    refunds: refundJobs.length,
    heldValueAed: heldJobs.reduce((sum, job) => sum + Number(job.price ?? 0), 0),
    releasedValueAed: releasedJobs.reduce((sum, job) => sum + Number(job.price ?? 0), 0),
  };
}

export function buildMoneyNextStep(job: DeliveryJobView): string {
  if (job.status === "dispute") return "Freeze the case, review proof, then decide refund or release.";
  if (job.status === "failed_delivery") return "Do not release money yet. Decide retry, refund, or cancel.";
  if (job.status === "confirmed" && job.escrow?.status === "held") return "Ready for release. Check proof, then release payout.";
  if (job.status === "released" || job.escrow?.status === "released") return "Money already released. Nothing blocked.";
  if (["refund", "partial_refund"].includes(job.status)) return "Refund flow already started. Keep all parties informed.";
  if (["delivered"].includes(job.status)) return "Wait for buyer confirmation code before releasing money.";
  return "Hold funds until delivery reaches the next verified step.";
}

export function mapJobToFinanceItem(job: DeliveryJobView): DeliveryFinanceItem {
  const sellerAmount = Number(job.escrow?.seller_amount ?? 0);
  const driverAmount = Number(job.escrow?.driver_amount ?? 0);
  const platformFee = Number(job.escrow?.platform_fee ?? 0);
  const grossAmount = Number(job.price ?? sellerAmount + driverAmount + platformFee);
  const risk: DeliveryFinanceItem["risk"] = job.status === "dispute" || job.status === "failed_delivery"
    ? "high"
    : job.status === "confirmed" || job.status === "delivered"
      ? "watch"
      : "low";

  return {
    jobId: job.id,
    orderId: job.order_id ?? job.id,
    status: job.status,
    escrowStatus: job.escrow?.status ?? "unknown",
    sellerAmount,
    driverAmount,
    platformFee,
    grossAmount,
    moneyNextStep: buildMoneyNextStep(job),
    risk,
  };
}

export function useDeliveryFinance() {
  const radar = useSmartDeliveryRadar(8);
  const qc = useQueryClient();

  const jobs = useMemo(() => (radar.jobs?.length ? radar.jobs : demoFinanceJobs), [radar.jobs]);
  const items = useMemo(() => jobs.map(mapJobToFinanceItem), [jobs]);
  const summary = useMemo(() => buildFinanceSummary(jobs), [jobs]);
  const priorityItem = useMemo(
    () => items.find((item) => item.risk === "high") ?? items.find((item) => item.risk === "watch") ?? items[0] ?? null,
    [items],
  );

  const releaseFunds = useMutation({
    mutationFn: async (jobId: string) => {
      const job = jobs.find((entry) => entry.id === jobId);
      if (!job) throw new Error("Delivery not found");
      if (job.status === "dispute") throw new Error("Resolve dispute before releasing money.");
      if (!job.order_id) throw new Error("Order is missing for this delivery.");

      const now = new Date().toISOString();
      const { error: escrowError } = await supabase
        .from("escrow_payments" as any)
        .update({ status: "released", released_at: now, updated_at: now } as any)
        .eq("order_id", job.order_id);
      if (escrowError) throw escrowError;

      const { error: jobError } = await supabase
        .from("delivery_jobs" as any)
        .update({ status: "released", updated_at: now } as any)
        .eq("id", jobId);
      if (jobError) throw jobError;

      return { jobId, releasedAt: now };
    },
    onSuccess: async () => {
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["delivery_jobs"] }),
        qc.invalidateQueries({ queryKey: ["delivery_escrow"] }),
      ]);
    },
  });

  const createDispute = useMutation({
    mutationFn: async ({ jobId, reason, requestedAction }: DeliveryDisputeDraft) => {
      const now = new Date().toISOString();
      const { error } = await supabase
        .from("delivery_jobs" as any)
        .update({
          status: requestedAction === "review" ? "dispute" : requestedAction,
          updated_at: now,
        } as any)
        .eq("id", jobId);
      if (error) throw error;
      return { jobId, reason, requestedAction, createdAt: now };
    },
    onSuccess: async () => {
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["delivery_jobs"] }),
        qc.invalidateQueries({ queryKey: ["delivery_escrow"] }),
      ]);
    },
  });

  return {
    jobs,
    items,
    summary,
    priorityItem,
    isLoading: radar.isLoading,
    releaseFunds,
    createDispute,
    refetch: async () => {
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["delivery_jobs"] }),
        qc.invalidateQueries({ queryKey: ["delivery_escrow"] }),
      ]);
    },
  };
}
