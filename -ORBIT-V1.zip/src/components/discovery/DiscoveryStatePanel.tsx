interface Props {
  trending: number;
  nearby: number;
  topRated: number;
  smartPicks: number;
}

export default function DiscoveryStatePanel({ trending, nearby, topRated, smartPicks }: Props) {
  const cards = [
    { label: "Trending", value: trending, hint: "What is getting attention now" },
    { label: "Nearby", value: nearby, hint: "Useful around the viewer location" },
    { label: "Top rated", value: topRated, hint: "Strong quality signals" },
    { label: "Smart picks", value: smartPicks, hint: "Mixed future-facing suggestions" },
  ];

  return (
    <section className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
      {cards.map((card) => (
        <div key={card.label} className="rounded-2xl border border-border bg-card p-4 shadow-sm">
          <div className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">{card.label}</div>
          <div className="mt-2 text-2xl font-semibold tracking-tight">{card.value}</div>
          <div className="mt-1 text-sm text-muted-foreground">{card.hint}</div>
        </div>
      ))}
    </section>
  );
}
