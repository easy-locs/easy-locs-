import type { DiscoveryCardItem } from "@/lib/discovery-marketplace";
import { Link } from "react-router-dom";

export default function DiscoverySmartCard({ item }: { item: DiscoveryCardItem }) {
  return (
    <Link
      to={item.href}
      className="flex min-h-[170px] flex-col justify-between rounded-3xl border border-border bg-card p-4 shadow-sm transition hover:border-primary/40 hover:bg-primary/5"
    >
      <div>
        <div className="text-[10px] font-semibold uppercase tracking-[0.25em] text-muted-foreground">{item.kind}</div>
        <div className="mt-2 text-lg font-semibold leading-tight">{item.title}</div>
        <div className="mt-2 text-sm text-muted-foreground">{item.subtitle}</div>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
        {item.rating != null && <span className="rounded-full bg-muted px-2 py-1">⭐ {item.rating.toFixed(1)}</span>}
        {item.distanceKm != null && <span className="rounded-full bg-muted px-2 py-1">📍 {item.distanceKm.toFixed(1)} km</span>}
        {item.city && <span className="rounded-full bg-muted px-2 py-1">{item.city}</span>}
      </div>
    </Link>
  );
}
