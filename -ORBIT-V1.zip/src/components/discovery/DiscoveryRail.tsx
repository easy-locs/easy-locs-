import type { DiscoveryCardItem } from "@/lib/discovery-marketplace";
import DiscoverySmartCard from "./DiscoverySmartCard";

export default function DiscoveryRail({ title, subtitle, items }: { title: string; subtitle: string; items: DiscoveryCardItem[] }) {
  if (!items.length) return null;

  return (
    <section className="space-y-3">
      <div>
        <div className="text-lg font-semibold tracking-tight">{title}</div>
        <div className="text-sm text-muted-foreground">{subtitle}</div>
      </div>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {items.map((item) => (
          <DiscoverySmartCard key={item.id} item={item} />
        ))}
      </div>
    </section>
  );
}
