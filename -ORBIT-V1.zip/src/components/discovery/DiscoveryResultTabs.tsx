import { Link } from "react-router-dom";
import type { OrbitSearchResult } from "@/lib/orbit-search";

interface GroupedResults {
  all: OrbitSearchResult[];
  shops: OrbitSearchResult[];
  catalog: OrbitSearchResult[];
  services: OrbitSearchResult[];
  jobs: OrbitSearchResult[];
  property: OrbitSearchResult[];
}

interface Props {
  grouped: GroupedResults;
}

function ResultBlock({ title, items }: { title: string; items: OrbitSearchResult[] }) {
  if (!items.length) return null;

  return (
    <section className="rounded-3xl border border-border bg-card p-5 shadow-sm">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h2 className="text-lg font-semibold">{title}</h2>
        <span className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">{items.length}</span>
      </div>
      <div className="grid gap-3">
        {items.map((item) => (
          <Link key={item.id} to={item.href} className="rounded-2xl border border-border bg-background/70 p-4 transition hover:border-primary/40 hover:bg-primary/5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="font-medium">{item.title}</div>
                {item.subtitle && <div className="text-xs text-muted-foreground">{item.subtitle}</div>}
              </div>
              <span className="rounded-full border border-border px-2 py-1 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{item.type}</span>
            </div>
            {item.description && <div className="mt-2 text-sm text-muted-foreground">{item.description}</div>}
            {!!item.tags?.length && (
              <div className="mt-3 flex flex-wrap gap-2">
                {item.tags.slice(0, 4).map((tag) => (
                  <span key={`${item.id}-${tag}`} className="rounded-full border border-border px-2 py-1 text-[11px] text-muted-foreground">{tag}</span>
                ))}
              </div>
            )}
          </Link>
        ))}
      </div>
    </section>
  );
}

export default function DiscoveryResultTabs({ grouped }: Props) {
  return (
    <div className="grid gap-6">
      <ResultBlock title="Top results" items={grouped.all.slice(0, 8)} />
      <div className="grid gap-6 lg:grid-cols-2">
        <ResultBlock title="Shops" items={grouped.shops} />
        <ResultBlock title="Products & catalog" items={grouped.catalog} />
        <ResultBlock title="Services" items={grouped.services} />
        <ResultBlock title="Jobs" items={grouped.jobs} />
      </div>
      <ResultBlock title="Property" items={grouped.property} />
    </div>
  );
}
