interface Props {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export default function UnifiedSearchBar({ value, onChange, placeholder = "Search shops, products, services, jobs, property..." }: Props) {
  return (
    <div className="rounded-3xl border border-border bg-card p-4 shadow-sm">
      <div className="text-xs font-semibold uppercase tracking-[0.25em] text-muted-foreground">ORBIT Search</div>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="mt-3 w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none ring-0 placeholder:text-muted-foreground"
      />
      <div className="mt-3 flex flex-wrap gap-2 text-xs text-muted-foreground">
        {['pizza', 'hotel', 'plumber', 'delivery job', 'holiday rental'].map((hint) => (
          <button key={hint} type="button" onClick={() => onChange(hint)} className="rounded-full border border-border px-3 py-1 hover:bg-muted">
            {hint}
          </button>
        ))}
      </div>
    </div>
  );
}
