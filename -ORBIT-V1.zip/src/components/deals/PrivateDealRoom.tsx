import { useState } from "react";
import { useDealRoomNegotiation } from "@/hooks/useDealRoomNegotiation";
import DealConversionCard from "@/components/deals/DealConversionCard";

export default function PrivateDealRoom({ dealId }: { dealId: string }) {
  const { state, offer, messages, sendOffer, acceptDeal, rejectDeal, expiresInText } = useDealRoomNegotiation();
  const [amount, setAmount] = useState("");
  const [message, setMessage] = useState("");

  const numericAmount = Number(amount);

  return (
    <div className="space-y-6 rounded-2xl border border-border bg-card p-5 shadow-sm">
      <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
        <div>
          <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Private deal room</div>
          <h1 className="text-2xl font-semibold tracking-tight">Deal #{dealId}</h1>
          <p className="text-sm text-muted-foreground">Negotiate privately, exchange counter-offers, then convert the accepted deal into an order, invoice, delivery or payment.</p>
        </div>
        <div className="rounded-xl border border-border px-3 py-2 text-sm">
          <div className="font-medium">State: {state}</div>
          {expiresInText && <div className="text-muted-foreground">{expiresInText}</div>}
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <div className="rounded-xl bg-muted/50 p-3 text-sm"><div className="text-xs uppercase text-muted-foreground">Offer</div><div className="font-medium">{offer.currentOfferAmount ?? "—"}</div></div>
        <div className="rounded-xl bg-muted/50 p-3 text-sm"><div className="text-xs uppercase text-muted-foreground">Counter</div><div className="font-medium">{offer.counterOfferAmount ?? "—"}</div></div>
        <div className="rounded-xl bg-muted/50 p-3 text-sm"><div className="text-xs uppercase text-muted-foreground">Accepted</div><div className="font-medium">{offer.acceptedAmount ?? "—"}</div></div>
        <div className="rounded-xl bg-muted/50 p-3 text-sm"><div className="text-xs uppercase text-muted-foreground">Round</div><div className="font-medium">{offer.negotiationRound}</div></div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <div className="space-y-3">
          <div className="text-sm font-medium">Messages</div>
          <div className="space-y-2 rounded-2xl border border-border p-4">
            {!messages.length ? <div className="text-sm text-muted-foreground">No messages yet. Send the first offer.</div> : messages.map(item => (
              <div key={item.id} className="rounded-xl bg-muted/50 p-3 text-sm">
                <div className="font-medium">{item.author}</div>
                <div className="text-muted-foreground">{item.body}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-3 rounded-2xl border border-border p-4">
          <div className="text-sm font-medium">Make an offer</div>
          <input value={amount} onChange={(e) => setAmount(e.target.value)} type="number" className="w-full rounded-xl border border-input bg-background px-3 py-2" placeholder="135" />
          <textarea value={message} onChange={(e) => setMessage(e.target.value)} className="min-h-28 w-full rounded-xl border border-input bg-background px-3 py-2" placeholder="Add terms, timing, attachment note or payment condition" />
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={() => numericAmount > 0 && sendOffer(numericAmount, message || `Offer ${numericAmount}`, "creator")} className="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">Send offer</button>
            <button type="button" onClick={() => numericAmount > 0 && sendOffer(numericAmount, message || `Counter ${numericAmount}`, "target")} className="rounded-xl border border-border px-4 py-2 text-sm font-medium">Counter offer</button>
            <button type="button" onClick={() => acceptDeal(numericAmount || offer.counterOfferAmount || offer.currentOfferAmount || 0)} className="rounded-xl border border-border px-4 py-2 text-sm font-medium">Accept deal</button>
            <button type="button" onClick={rejectDeal} className="rounded-xl border border-destructive/30 px-4 py-2 text-sm font-medium text-destructive">Reject</button>
          </div>
        </div>
      </div>
      <DealConversionCard
        dealId={dealId}
        acceptedAmount={offer.acceptedAmount}
        requiresDelivery
        title={`Deal #${dealId}`}
        storefrontSlug="deal-room"
      />

    </div>
  );
}
