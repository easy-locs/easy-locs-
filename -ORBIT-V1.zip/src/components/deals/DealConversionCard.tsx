import { useDealConversion } from "@/hooks/useDealConversion";

export default function DealConversionCard(props: Parameters<typeof useDealConversion>[0]) {
  const { preview, result, convert, reset, converting } = useDealConversion(props);

  return (
    <div className="space-y-4 rounded-2xl border border-border bg-card p-5 shadow-sm">
      <div>
        <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Deal conversion</div>
        <h3 className="text-lg font-semibold">Turn accepted deal into action</h3>
        <p className="text-sm text-muted-foreground">Keep the flow simple: accepted deal → order → invoice → payment → delivery when needed.</p>
      </div>

      <div className="rounded-xl bg-muted/50 p-4 text-sm">
        <div className="font-medium">Ready targets</div>
        <div className="mt-1 text-muted-foreground">{preview.targets.join(", ") || "No target yet"}</div>
        <div className="mt-2">Accepted amount: <span className="font-medium">{preview.acceptedAmount || "—"}</span></div>
      </div>

      {result ? (
        <div className="space-y-2 rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-4 text-sm">
          <div className="font-medium">Converted</div>
          <div className="text-muted-foreground">{result.summary}</div>
          <div className="grid gap-2 md:grid-cols-2">
            {result.orderId && <div>Order: <span className="font-medium">{result.orderId}</span></div>}
            {result.invoiceId && <div>Invoice: <span className="font-medium">{result.invoiceId}</span></div>}
            {result.paymentId && <div>Payment: <span className="font-medium">{result.paymentId}</span></div>}
            {result.deliveryJobId && <div>Delivery: <span className="font-medium">{result.deliveryJobId}</span></div>}
          </div>
          <div className="text-muted-foreground">Next route: {result.nextRoute}</div>
          <button type="button" onClick={reset} className="rounded-xl border border-border px-3 py-2">Reset</button>
        </div>
      ) : (
        <button type="button" onClick={() => void convert()} disabled={converting} className="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground disabled:opacity-60">{converting ? "Converting…" : "Convert accepted deal"}</button>
      )}
    </div>
  );
}
