import { useEffect, useMemo, useState } from "react";
import { Activity, Bot, ChevronDown, Gauge, RefreshCw, ShieldAlert } from "lucide-react";
import { useLocation } from "react-router-dom";
import {
  ORBIT_INSPECTOR_EVENT,
  readOrbitInspectorHistory,
  runOrbitInspector,
  type OrbitInspectorReport,
  type OrbitInspectorTopIssue,
} from "@/lib/orbit-inspector";
import { A11Y_AUDIT_EVENT, type A11yAuditSnapshot } from "@/lib/a11y-dev";

const OPEN_KEY = "orbit:inspector-open";

function severityTone(issue: OrbitInspectorTopIssue) {
  if (issue.severity === "high") return "border-destructive/40 bg-destructive/5 text-destructive";
  if (issue.severity === "medium") return "border-amber-500/40 bg-amber-500/5 text-amber-700 dark:text-amber-300";
  return "border-border bg-muted/40 text-foreground";
}

export default function DevOrbitInspector() {
  const location = useLocation();
  const [open, setOpen] = useState<boolean>(() => {
    if (typeof window === "undefined") return true;
    return window.localStorage.getItem(OPEN_KEY) !== "0";
  });
  const [report, setReport] = useState<OrbitInspectorReport | null>(null);
  const [history, setHistory] = useState<OrbitInspectorReport[]>(() => readOrbitInspectorHistory());

  useEffect(() => {
    if (!import.meta.env.DEV || typeof window === "undefined") return;

    const onInspector = (event: Event) => {
      const detail = (event as CustomEvent<OrbitInspectorReport>).detail;
      if (!detail) return;
      setReport(detail);
      setHistory(readOrbitInspectorHistory());
    };

    const onA11y = (_event: Event) => {
      window.requestAnimationFrame(() => {
        const next = runOrbitInspector(location.pathname);
        setReport(next);
        setHistory(readOrbitInspectorHistory());
      });
    };

    window.addEventListener(ORBIT_INSPECTOR_EVENT, onInspector as EventListener);
    window.addEventListener(A11Y_AUDIT_EVENT, onA11y as EventListener);

    if (!report) {
      const initial = runOrbitInspector(location.pathname);
      setReport(initial);
      setHistory(readOrbitInspectorHistory());
    }

    return () => {
      window.removeEventListener(ORBIT_INSPECTOR_EVENT, onInspector as EventListener);
      window.removeEventListener(A11Y_AUDIT_EVENT, onA11y as EventListener);
    };
  }, [location.pathname]);

  const topRoute = useMemo(() => {
    const routes = report?.routeHealth ?? [];
    return routes.length > 0 ? [...routes].sort((a, b) => a.score - b.score)[0] : null;
  }, [report]);

  if (!import.meta.env.DEV) return null;

  const toggle = () => {
    setOpen((prev) => {
      const next = !prev;
      if (typeof window !== "undefined") window.localStorage.setItem(OPEN_KEY, next ? "1" : "0");
      return next;
    });
  };

  const rerun = () => {
    const next = runOrbitInspector(location.pathname);
    setReport(next);
    setHistory(readOrbitInspectorHistory());
  };

  return (
    <aside className="fixed bottom-4 right-4 z-[9998] w-[min(96vw,420px)] rounded-2xl border bg-background/95 shadow-2xl backdrop-blur">
      <div className="flex items-center gap-3 border-b px-4 py-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted">
          <Bot className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold">ORBIT Inspector</div>
          <div className="text-xs text-muted-foreground">Unified QA + AI + route health</div>
        </div>
        <button
          type="button"
          onClick={rerun}
          className="inline-flex h-9 w-9 items-center justify-center rounded-md border hover:bg-muted"
          aria-label="Run ORBIT inspector"
        >
          <RefreshCw className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={toggle}
          className="inline-flex h-9 w-9 items-center justify-center rounded-md border hover:bg-muted"
          aria-label={open ? "Collapse ORBIT inspector" : "Expand ORBIT inspector"}
          aria-expanded={open}
        >
          <ChevronDown className={`h-4 w-4 transition-transform ${open ? "rotate-180" : ""}`} />
        </button>
      </div>

      {open && (
        <div className="space-y-4 px-4 py-4 text-sm">
          <section className="grid grid-cols-2 gap-3">
            <div className="rounded-xl border p-3">
              <div className="flex items-center gap-2 text-xs uppercase text-muted-foreground">
                <Gauge className="h-3.5 w-3.5" /> Global score
              </div>
              <div className="mt-2 text-3xl font-bold">{report?.qa.score ?? "--"}</div>
              <div className="mt-1 text-xs text-muted-foreground">{report?.pathname ?? location.pathname}</div>
            </div>
            <div className="rounded-xl border p-3">
              <div className="flex items-center gap-2 text-xs uppercase text-muted-foreground">
                <ShieldAlert className="h-3.5 w-3.5" /> AI findings
              </div>
              <div className="mt-2 text-3xl font-bold">{report?.ai.summary.total ?? 0}</div>
              <div className="mt-1 text-xs text-muted-foreground">
                High {report?.ai.summary.bySeverity.high ?? 0} · Medium {report?.ai.summary.bySeverity.medium ?? 0}
              </div>
            </div>
          </section>

          <section className="grid grid-cols-4 gap-2 text-xs">
            <div className="rounded-lg border p-2">A11y <span className="float-right font-semibold">{report?.qa.metrics.accessibility ?? "--"}</span></div>
            <div className="rounded-lg border p-2">Perf <span className="float-right font-semibold">{report?.qa.metrics.performance ?? "--"}</span></div>
            <div className="rounded-lg border p-2">SEO <span className="float-right font-semibold">{report?.qa.metrics.seo ?? "--"}</span></div>
            <div className="rounded-lg border p-2">Sec <span className="float-right font-semibold">{report?.qa.metrics.security ?? "--"}</span></div>
          </section>

          <section className="rounded-xl border p-3">
            <div className="mb-2 flex items-center gap-2 text-sm font-medium">
              <Activity className="h-4 w-4" /> Top issues
            </div>
            {report?.topIssues?.length ? (
              <div className="space-y-2">
                {report.topIssues.slice(0, 5).map((issue) => (
                  <div key={issue.key} className={`rounded-lg border p-2 text-xs ${severityTone(issue)}`}>
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-medium">{issue.type} · {issue.severity}</span>
                      <span>x{issue.count}</span>
                    </div>
                    <div className="mt-1 leading-relaxed">{issue.message}</div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-xs text-muted-foreground">No issues detected on the current inspection.</div>
            )}
          </section>

          <section className="rounded-xl border p-3">
            <div className="mb-2 text-sm font-medium">Recent route health</div>
            <div className="space-y-2">
              {(report?.routeHealth ?? []).slice(0, 5).map((route) => (
                <div key={`${route.pathname}-${route.auditedAt}`} className="rounded-lg border p-2 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <span className="truncate font-medium">{route.pathname}</span>
                    <span className="font-semibold">{route.score}</span>
                  </div>
                  <div className="mt-1 text-muted-foreground">
                    {route.errors} error(s) · {route.warnings} warning(s)
                  </div>
                </div>
              ))}
              {!(report?.routeHealth?.length) && <div className="text-xs text-muted-foreground">Route audits will appear here as you navigate.</div>}
            </div>
            {topRoute && (
              <div className="mt-3 rounded-lg border border-amber-500/40 bg-amber-500/5 p-2 text-xs">
                Weakest route: <span className="font-medium">{topRoute.pathname}</span> · score {topRoute.score}
              </div>
            )}
          </section>

          <section className="rounded-xl border p-3">
            <div className="mb-2 text-sm font-medium">Inspector history</div>
            <div className="space-y-2">
              {history.slice(0, 4).map((item) => (
                <div key={`${item.pathname}-${item.generatedAt}`} className="rounded-lg border p-2 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <span className="truncate font-medium">{item.pathname}</span>
                    <span>{item.qa.score}</span>
                  </div>
                  <div className="mt-1 text-muted-foreground">
                    {new Date(item.generatedAt).toLocaleTimeString()} · {item.ai.summary.total} issue(s)
                  </div>
                </div>
              ))}
              {!history.length && <div className="text-xs text-muted-foreground">No saved inspector runs yet.</div>}
            </div>
          </section>
        </div>
      )}
    </aside>
  );
}
