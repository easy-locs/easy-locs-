import type { DeliveryJobView } from "@/hooks/useSmartDeliveryRadar";
import type { SellerDriverOption } from "@/hooks/useSellerLogistics";

interface DeliveryTrackerProps {
  jobs: DeliveryJobView[];
  drivers: SellerDriverOption[];
  onAssign: (jobId: string, driverId: string) => void;
  onCancel: (jobId: string) => void;
  onDispute: (jobId: string) => void;
  onFail: (jobId: string) => void;
  busy?: boolean;
}

function nextActionLabel(status: string) {
  if (status === "open") return "Assign a driver";
  if (["accepted", "picked_up", "in_transit", "on_route_to_pickup", "on_route_to_dropoff"].includes(status)) return "Track live delivery";
  if (["delivered", "confirmed"].includes(status)) return "Wait for release";
  if (status === "released") return "Completed";
  return "Needs attention";
}

export default function DeliveryTracker({ jobs, drivers, onAssign, onCancel, onDispute, onFail, busy = false }: DeliveryTrackerProps) {
  return (
    <section className="rounded-2xl border bg-card p-5 shadow-sm">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div>
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Step 2</p>
          <h2 className="text-xl font-semibold">Track deliveries</h2>
        </div>
        <span className="text-sm text-muted-foreground">{jobs.length} jobs</span>
      </div>

      <div className="space-y-4">
        {jobs.map((job) => (
          <article key={job.id} className="rounded-2xl border p-4">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="font-semibold">Delivery #{job.id.slice(0, 8)}</h3>
                  <span className="rounded-full border px-2 py-1 text-xs">{job.status}</span>
                  <span className="rounded-full border px-2 py-1 text-xs">{job.package_size ?? "standard"}</span>
                </div>
                <p className="mt-2 text-sm text-muted-foreground">{job.summary.parcelLabel} • {job.summary.distanceKm ?? "--"} km</p>
                <p className="mt-1 text-sm text-muted-foreground">Driver amount {Number(job.escrow?.driver_amount ?? 0).toFixed(0)} AED • Seller amount {Number(job.escrow?.seller_amount ?? 0).toFixed(0)} AED</p>
                <p className="mt-1 text-sm font-medium">Next step: {nextActionLabel(job.status)}</p>
              </div>

              <div className="min-w-[230px] space-y-2">
                {job.status === "open" ? (
                  <div className="space-y-2">
                    <select
                      className="w-full rounded-xl border bg-background px-3 py-2 text-sm"
                      defaultValue=""
                      onChange={(e) => e.target.value && onAssign(job.id, e.target.value)}
                      disabled={busy}
                    >
                      <option value="">Choose a driver</option>
                      {drivers.map((driver) => (
                        <option key={driver.id} value={driver.id}>{driver.label} • {driver.vehicle} • {Math.round(driver.reliability * 100)}%</option>
                      ))}
                    </select>
                    <button type="button" className="w-full rounded-xl bg-primary px-4 py-2 text-sm text-primary-foreground" onClick={() => drivers[0] && onAssign(job.id, drivers[0].id)} disabled={busy || !drivers[0]}>
                      Assign best available driver
                    </button>
                  </div>
                ) : null}

                <div className="grid grid-cols-2 gap-2 text-sm">
                  <button type="button" className="rounded-xl border px-3 py-2" onClick={() => onCancel(job.id)} disabled={busy}>Cancel</button>
                  <button type="button" className="rounded-xl border px-3 py-2" onClick={() => onDispute(job.id)} disabled={busy}>Dispute</button>
                  <button type="button" className="col-span-2 rounded-xl border px-3 py-2" onClick={() => onFail(job.id)} disabled={busy}>Mark failed delivery</button>
                </div>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
