import { useMemo, useState } from "react";
import type { SellerDeliveryDraft } from "@/hooks/useSellerLogistics";

interface DeliveryCreatorProps {
  onCreate: (draft: SellerDeliveryDraft) => void;
  isSubmitting?: boolean;
}

const starter = {
  pickupLat: "25.2048",
  pickupLng: "55.2708",
  dropoffLat: "25.0802",
  dropoffLng: "55.1401",
  packageSize: "standard",
  packageWeightKg: "2",
  radiusKm: "5",
  price: "28",
  fragile: false,
  twoPersonLift: false,
};

export default function DeliveryCreator({ onCreate, isSubmitting = false }: DeliveryCreatorProps) {
  const [form, setForm] = useState(starter);

  const helperText = useMemo(() => {
    if (form.packageSize === "small") return "Best for documents, drinks, and small food orders.";
    if (form.packageSize === "large") return "Use for boxes, bulk orders, or heavy restaurant loads.";
    return "Standard is the safest choice for most local deliveries.";
  }, [form.packageSize]);

  function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    onCreate({
      pickupLat: Number(form.pickupLat),
      pickupLng: Number(form.pickupLng),
      dropoffLat: Number(form.dropoffLat),
      dropoffLng: Number(form.dropoffLng),
      packageSize: form.packageSize as SellerDeliveryDraft["packageSize"],
      packageWeightKg: Number(form.packageWeightKg || 0),
      radiusKm: Number(form.radiusKm || 5),
      price: Number(form.price || 0),
      fragile: form.fragile,
      twoPersonLift: form.twoPersonLift,
    });
  }

  return (
    <section className="rounded-2xl border bg-card p-5 shadow-sm">
      <div className="mb-4">
        <p className="text-sm uppercase tracking-wide text-muted-foreground">Step 1</p>
        <h2 className="text-xl font-semibold">Create delivery</h2>
        <p className="mt-1 text-sm text-muted-foreground">Use the quick form below. It is designed for a beginner seller: pickup, dropoff, package, price.</p>
      </div>

      <form className="space-y-4" onSubmit={submit}>
        <div className="grid gap-3 md:grid-cols-2">
          <label className="space-y-1 text-sm">
            <span className="font-medium">Pickup latitude</span>
            <input className="w-full rounded-xl border bg-background px-3 py-2" value={form.pickupLat} onChange={(e) => setForm((v) => ({ ...v, pickupLat: e.target.value }))} />
          </label>
          <label className="space-y-1 text-sm">
            <span className="font-medium">Pickup longitude</span>
            <input className="w-full rounded-xl border bg-background px-3 py-2" value={form.pickupLng} onChange={(e) => setForm((v) => ({ ...v, pickupLng: e.target.value }))} />
          </label>
          <label className="space-y-1 text-sm">
            <span className="font-medium">Dropoff latitude</span>
            <input className="w-full rounded-xl border bg-background px-3 py-2" value={form.dropoffLat} onChange={(e) => setForm((v) => ({ ...v, dropoffLat: e.target.value }))} />
          </label>
          <label className="space-y-1 text-sm">
            <span className="font-medium">Dropoff longitude</span>
            <input className="w-full rounded-xl border bg-background px-3 py-2" value={form.dropoffLng} onChange={(e) => setForm((v) => ({ ...v, dropoffLng: e.target.value }))} />
          </label>
        </div>

        <div className="grid gap-3 md:grid-cols-4">
          <label className="space-y-1 text-sm md:col-span-2">
            <span className="font-medium">Package size</span>
            <select className="w-full rounded-xl border bg-background px-3 py-2" value={form.packageSize} onChange={(e) => setForm((v) => ({ ...v, packageSize: e.target.value }))}>
              <option value="small">Small</option>
              <option value="standard">Standard</option>
              <option value="large">Large</option>
            </select>
            <span className="block text-xs text-muted-foreground">{helperText}</span>
          </label>

          <label className="space-y-1 text-sm">
            <span className="font-medium">Weight (kg)</span>
            <input className="w-full rounded-xl border bg-background px-3 py-2" value={form.packageWeightKg} onChange={(e) => setForm((v) => ({ ...v, packageWeightKg: e.target.value }))} />
          </label>

          <label className="space-y-1 text-sm">
            <span className="font-medium">Price (AED)</span>
            <input className="w-full rounded-xl border bg-background px-3 py-2" value={form.price} onChange={(e) => setForm((v) => ({ ...v, price: e.target.value }))} />
          </label>
        </div>

        <div className="grid gap-3 md:grid-cols-3">
          <label className="space-y-1 text-sm">
            <span className="font-medium">Broadcast radius (km)</span>
            <input className="w-full rounded-xl border bg-background px-3 py-2" value={form.radiusKm} onChange={(e) => setForm((v) => ({ ...v, radiusKm: e.target.value }))} />
          </label>

          <label className="flex items-center gap-2 rounded-xl border px-3 py-2 text-sm">
            <input type="checkbox" checked={form.fragile} onChange={(e) => setForm((v) => ({ ...v, fragile: e.target.checked }))} />
            Fragile item
          </label>

          <label className="flex items-center gap-2 rounded-xl border px-3 py-2 text-sm">
            <input type="checkbox" checked={form.twoPersonLift} onChange={(e) => setForm((v) => ({ ...v, twoPersonLift: e.target.checked }))} />
            Needs two people
          </label>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button type="submit" className="rounded-xl bg-primary px-4 py-2 text-primary-foreground" disabled={isSubmitting}>
            {isSubmitting ? "Creating..." : "Create delivery"}
          </button>
          <p className="text-sm text-muted-foreground">Tip: start with standard + 5 km radius if you are not sure.</p>
        </div>
      </form>
    </section>
  );
}
