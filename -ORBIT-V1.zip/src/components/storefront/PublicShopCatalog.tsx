import type { CatalogEntryDraft } from "@/lib/public-shop";

export default function PublicShopCatalog({ entries, onAddToCart }: { entries: CatalogEntryDraft[]; onAddToCart?: (entry: CatalogEntryDraft) => void }) {
  if (!entries.length) {
    return <div className="rounded-xl border border-dashed border-border p-6 text-sm text-muted-foreground">No products or services yet.</div>;
  }

  return (
    <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
      {entries.map(entry => (
        <div key={entry.id} className="rounded-2xl border border-border p-4">
          <div className="mb-2 flex items-center justify-between gap-3">
            <div>
              <div className="text-sm font-semibold">{entry.name}</div>
              <div className="text-xs uppercase tracking-wide text-muted-foreground">{entry.kind}</div>
            </div>
            {entry.price != null && <div className="text-sm font-medium">{entry.price} {entry.currency}</div>}
          </div>
          {entry.description && <p className="text-sm text-muted-foreground">{entry.description}</p>}
          {onAddToCart ? (
            <button
              type="button"
              onClick={() => onAddToCart(entry)}
              className="mt-3 rounded-xl bg-primary px-3 py-2 text-sm font-medium text-primary-foreground"
            >
              Add to cart
            </button>
          ) : null}
        </div>
      ))}
    </div>
  );
}
