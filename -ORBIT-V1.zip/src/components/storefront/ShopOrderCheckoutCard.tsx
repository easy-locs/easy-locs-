import type { OrderFulfillmentMode, OrderPaymentMode, UnifiedOrderDraft } from "@/lib/storefront-order-engine";

interface Props {
  orderDraft: UnifiedOrderDraft;
  checkoutReady: boolean;
  onPaymentModeChange: (value: OrderPaymentMode) => void;
  onFulfillmentModeChange: (value: OrderFulfillmentMode) => void;
  onNoteChange: (value: string) => void;
  onCheckout: () => void;
}

export default function ShopOrderCheckoutCard({ orderDraft, checkoutReady, onPaymentModeChange, onFulfillmentModeChange, onNoteChange, onCheckout }: Props) {
  return (
    <div className="rounded-3xl border border-border bg-card p-5 shadow-sm">
      <div className="mb-4">
        <h3 className="text-lg font-semibold">Checkout</h3>
        <p className="text-sm text-muted-foreground">One simple flow: cart → payment → delivery when needed.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <label className="grid gap-2 text-sm">
          <span className="font-medium">Fulfillment</span>
          <select
            className="rounded-xl border border-border bg-background px-3 py-2"
            value={orderDraft.fulfillmentMode}
            onChange={(e) => onFulfillmentModeChange(e.target.value as OrderFulfillmentMode)}
          >
            <option value="delivery">Delivery</option>
            <option value="pickup">Pickup</option>
            <option value="digital">Digital</option>
          </select>
        </label>

        <label className="grid gap-2 text-sm">
          <span className="font-medium">Payment</span>
          <select
            className="rounded-xl border border-border bg-background px-3 py-2"
            value={orderDraft.paymentMode}
            onChange={(e) => onPaymentModeChange(e.target.value as OrderPaymentMode)}
          >
            <option value="card">Card</option>
            <option value="wallet">Wallet</option>
            <option value="cash">Cash</option>
            <option value="deal_room">Deal room</option>
          </select>
        </label>
      </div>

      <label className="mt-4 grid gap-2 text-sm">
        <span className="font-medium">Order note</span>
        <textarea
          className="min-h-[90px] rounded-2xl border border-border bg-background px-3 py-3"
          placeholder="Special request, address note, pickup instruction…"
          defaultValue={orderDraft.note || ""}
          onChange={(e) => onNoteChange(e.target.value)}
        />
      </label>

      <div className="mt-4 rounded-2xl bg-muted/50 p-4 text-sm">
        <div className="flex items-center justify-between"><span>Items</span><span>{orderDraft.itemCount}</span></div>
        <div className="mt-2 flex items-center justify-between"><span>Subtotal</span><span>{orderDraft.subtotal} {orderDraft.currency}</span></div>
        <div className="mt-2 flex items-center justify-between"><span>Delivery</span><span>{orderDraft.deliveryFee} {orderDraft.currency}</span></div>
        <div className="mt-3 flex items-center justify-between border-t border-border pt-3 text-base font-semibold"><span>Total</span><span>{orderDraft.total} {orderDraft.currency}</span></div>
      </div>

      <button
        type="button"
        disabled={!checkoutReady}
        onClick={onCheckout}
        className="mt-4 w-full rounded-2xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50"
      >
        Continue to order
      </button>
    </div>
  );
}
