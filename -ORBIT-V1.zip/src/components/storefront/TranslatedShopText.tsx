import type { SupportedStorefrontLanguage } from "@/lib/storefront-translation";

interface Props {
  title: string;
  description?: string;
  language: SupportedStorefrontLanguage;
}

export default function TranslatedShopText({ title, description, language }: Props) {
  const isRtl = language === "ar";
  return (
    <div dir={isRtl ? "rtl" : "ltr"} className="space-y-2">
      <h1 className="text-3xl font-semibold tracking-tight">{title}</h1>
      {description ? <p className="max-w-2xl text-sm text-muted-foreground">{description}</p> : null}
    </div>
  );
}
