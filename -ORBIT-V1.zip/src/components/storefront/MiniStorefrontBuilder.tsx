import { type ChangeEvent } from "react";
import { useMiniStorefrontBuilder } from "@/hooks/useMiniStorefrontBuilder";
import {
  ORBIT_VERTICALS,
  getCategoryLabel,
  getSubcategoryLabel,
  getVerticalLabel,
  type SupportedLocale,
} from "@/lib/orbit-taxonomy";

const LOCALE_OPTIONS: Array<{ value: SupportedLocale; label: string }> = [
  { value: "en", label: "English" },
  { value: "fr", label: "Français" },
  { value: "ar", label: "العربية" },
  { value: "es", label: "Español" },
  { value: "zh", label: "中文" },
];

export default function MiniStorefrontBuilder() {
  const {
    draft,
    setDraft,
    inputText,
    setInputText,
    addActivityFromText,
    removeActivity,
    updateActivityName,
    storefrontSummary,
  } = useMiniStorefrontBuilder({
    storefrontName: "Orbit Mini Store",
  });

  const handleTopField = (field: "storefrontName" | "companyName" | "description") => (event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const value = event.target.value;
    setDraft(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-border bg-card p-5 shadow-sm">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">Smart mini boutique</p>
            <h1 className="text-2xl font-semibold tracking-tight">One storefront, many activities, simple for beginners</h1>
            <p className="mt-1 text-sm text-muted-foreground">Create one clean business profile, then let each activity have its own name, category and presentation.</p>
            <p className="mt-2 text-xs text-muted-foreground">Global-ready: categories can be reviewed in English, French, Arabic, Spanish and Chinese.</p>
          </div>
          <div className="rounded-xl border border-primary/20 bg-primary/5 px-4 py-3 text-sm">
            <div className="font-medium">Smart summary</div>
            <div className="text-muted-foreground">{storefrontSummary}</div>
          </div>
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <div className="space-y-6 rounded-2xl border border-border bg-card p-5 shadow-sm">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="space-y-2 text-sm">
              <span className="font-medium">Storefront name</span>
              <input value={draft.storefrontName} onChange={handleTopField("storefrontName")} className="w-full rounded-xl border border-input bg-background px-3 py-2" placeholder="Orbit Super Store" />
            </label>
            <label className="space-y-2 text-sm">
              <span className="font-medium">Company name</span>
              <input value={draft.companyName} onChange={handleTopField("companyName")} className="w-full rounded-xl border border-input bg-background px-3 py-2" placeholder="Pizza Times One DMCC" />
            </label>
            <label className="space-y-2 text-sm md:col-span-2">
              <span className="font-medium">Default language</span>
              <select
                value={draft.locale}
                onChange={(event) => setDraft(prev => ({ ...prev, locale: event.target.value as SupportedLocale }))}
                className="w-full rounded-xl border border-input bg-background px-3 py-2"
              >
                {LOCALE_OPTIONS.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
              </select>
            </label>
            <label className="space-y-2 text-sm md:col-span-2">
              <span className="font-medium">Global description</span>
              <textarea value={draft.description} onChange={handleTopField("description")} className="min-h-24 w-full rounded-xl border border-input bg-background px-3 py-2" placeholder="Describe the company once. Each activity can then have its own smart suggestion." />
            </label>
          </div>

          <div className="rounded-2xl border border-dashed border-primary/25 bg-primary/5 p-4">
            <div className="mb-2 text-sm font-medium">Add one activity with AI suggestion</div>
            <p className="mb-3 text-sm text-muted-foreground">Example: “Go Pizza, wood fired pizza and pasta in JLT with delivery to Marina” or “Holiday apartment in Dubai Marina, daily and weekly stay”.</p>
            <textarea
              value={inputText}
              onChange={(event) => setInputText(event.target.value)}
              className="min-h-28 w-full rounded-xl border border-input bg-background px-3 py-2"
              placeholder="Describe what this activity sells or books..."
            />
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => addActivityFromText()}
                className="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
              >
                Suggest activity
              </button>
              <button
                type="button"
                onClick={() => {
                  addActivityFromText("Go Pizza, pizza and pasta delivery in JLT and Marina");
                  addActivityFromText("Orbit Stay, holiday apartment in Dubai Marina daily and weekly booking");
                }}
                className="rounded-xl border border-border px-4 py-2 text-sm font-medium"
              >
                Add demo set
              </button>
            </div>
          </div>
        </div>

        <aside className="rounded-2xl border border-border bg-card p-5 shadow-sm">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <div className="text-sm font-medium">Store universes</div>
              <div className="text-sm text-muted-foreground">Uniform, scrollable and translation-ready</div>
            </div>
            <div className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">{draft.activities.length} activities</div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {ORBIT_VERTICALS.map(vertical => (
              <div key={vertical.code} className="rounded-xl border border-border px-3 py-2 text-sm">
                <div>{vertical.icon} {vertical.labels[draft.locale]}</div>
              </div>
            ))}
          </div>
        </aside>
      </section>

      <section className="rounded-2xl border border-border bg-card p-5 shadow-sm">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Activities inside this mini boutique</h2>
            <p className="text-sm text-muted-foreground">Each activity keeps its own name while staying inside one clean storefront.</p>
          </div>
        </div>

        {!draft.activities.length ? (
          <div className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
            No activity yet. Add one description and let the smart suggestion organize the boutique.
          </div>
        ) : (
          <div className="space-y-4">
            {draft.activities.map((activity, index) => (
              <div key={`${activity.name}-${index}`} className="rounded-2xl border border-border p-4">
                <div className="grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
                  <div className="space-y-3">
                    <label className="space-y-2 text-sm">
                      <span className="font-medium">Activity name</span>
                      <input
                        value={activity.name}
                        onChange={(event) => updateActivityName(index, event.target.value)}
                        className="w-full rounded-xl border border-input bg-background px-3 py-2"
                      />
                    </label>
                    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                      <div className="rounded-xl bg-muted/50 p-3 text-sm">
                        <div className="text-xs uppercase tracking-wide text-muted-foreground">Vertical</div>
                        <div className="font-medium">{getVerticalLabel(activity.verticalCode, draft.locale)}</div>
                      </div>
                      <div className="rounded-xl bg-muted/50 p-3 text-sm">
                        <div className="text-xs uppercase tracking-wide text-muted-foreground">Category</div>
                        <div className="font-medium">{getCategoryLabel(activity.categoryCode, draft.locale)}</div>
                      </div>
                      <div className="rounded-xl bg-muted/50 p-3 text-sm">
                        <div className="text-xs uppercase tracking-wide text-muted-foreground">AI confidence</div>
                        <div className="font-medium">{Math.round(activity.confidence * 100)}%</div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <div className="mb-2 text-sm font-medium">Suggested subcategories</div>
                      <div className="flex flex-wrap gap-2">
                        {activity.subcategoryCodes.length ? activity.subcategoryCodes.map(code => (
                          <span key={code} className="rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                            {getSubcategoryLabel(code, draft.locale)}
                          </span>
                        )) : (
                          <span className="text-sm text-muted-foreground">No subcategory suggestion yet</span>
                        )}
                      </div>
                    </div>
                    <div>
                      <div className="mb-2 text-sm font-medium">Suggested tags</div>
                      <div className="flex flex-wrap gap-2">
                        {activity.suggestedTags.map(tag => (
                          <span key={tag} className="rounded-full border border-border px-3 py-1 text-xs">#{tag}</span>
                        ))}
                      </div>
                    </div>
                    <div className="rounded-2xl bg-muted/20 p-4">
                      <DynamicActivityAttributes
                        verticalCode={activity.verticalCode}
                        categoryCode={activity.categoryCode}
                        subcategoryCodes={activity.subcategoryCodes}
                        locale={draft.locale}
                      />
                    </div>
                    <div className="pt-1">
                      <button type="button" onClick={() => removeActivity(index)} className="rounded-xl border border-destructive/30 px-4 py-2 text-sm font-medium text-destructive">
                        Remove activity
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
