import { useMemo, useState } from "react";
import { buildTaxonomyExplorer, getCountryPreset, getTaxonomyStats, suggestBusinessStructure } from "@/lib/orbit-global-taxonomy";
import { getLocaleDisplayName, type SupportedLocale } from "@/lib/orbit-taxonomy";

const LOCALES: SupportedLocale[] = ["en", "fr", "ar", "es", "zh"];
const COUNTRY_CODES = ["AE", "FR", "ES", "CN", "US"];

export default function GlobalTaxonomyExplorer() {
  const [locale, setLocale] = useState<SupportedLocale>("en");
  const [countryCode, setCountryCode] = useState("AE");
  const [text, setText] = useState("Cloud kitchen for pizza, burgers and pasta in Dubai Marina with delivery");

  const explorer = useMemo(() => buildTaxonomyExplorer(locale), [locale]);
  const suggestion = useMemo(() => suggestBusinessStructure({ text, countryCode, locale }), [countryCode, locale, text]);
  const preset = getCountryPreset(countryCode);
  const stats = getTaxonomyStats();

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-border bg-card p-5 shadow-sm">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">Global taxonomy</p>
            <h1 className="text-2xl font-semibold tracking-tight">World-wide categories, simple for every business</h1>
            <p className="mt-1 text-sm text-muted-foreground">Browse verticals, local presets, and AI suggestions in the right language.</p>
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-5">
            <div className="rounded-xl border border-border px-3 py-2"><div className="font-semibold">{stats.verticals}</div><div className="text-muted-foreground">Verticals</div></div>
            <div className="rounded-xl border border-border px-3 py-2"><div className="font-semibold">{stats.categories}</div><div className="text-muted-foreground">Categories</div></div>
            <div className="rounded-xl border border-border px-3 py-2"><div className="font-semibold">{stats.subcategories}</div><div className="text-muted-foreground">Subcategories</div></div>
            <div className="rounded-xl border border-border px-3 py-2"><div className="font-semibold">{stats.expansionGroups}</div><div className="text-muted-foreground">World groups</div></div>
            <div className="rounded-xl border border-border px-3 py-2"><div className="font-semibold">{stats.countries}</div><div className="text-muted-foreground">Country presets</div></div>
          </div>
        </div>
      </section>

      <section className="grid gap-6 xl:grid-cols-[1fr_1.15fr]">
        <div className="space-y-4 rounded-2xl border border-border bg-card p-5 shadow-sm">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="space-y-2 text-sm">
              <span className="font-medium">Language</span>
              <select value={locale} onChange={(e) => setLocale(e.target.value as SupportedLocale)} className="w-full rounded-xl border border-input bg-background px-3 py-2">
                {LOCALES.map((item) => <option key={item} value={item}>{getLocaleDisplayName(item)}</option>)}
              </select>
            </label>
            <label className="space-y-2 text-sm">
              <span className="font-medium">Country preset</span>
              <select value={countryCode} onChange={(e) => setCountryCode(e.target.value)} className="w-full rounded-xl border border-input bg-background px-3 py-2">
                {COUNTRY_CODES.map((item) => <option key={item} value={item}>{item}</option>)}
              </select>
            </label>
          </div>

          <label className="space-y-2 text-sm">
            <span className="font-medium">Describe the business</span>
            <textarea value={text} onChange={(e) => setText(e.target.value)} rows={5} className="w-full rounded-2xl border border-input bg-background px-3 py-3" />
          </label>

          <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4">
            <div className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">AI suggestion</div>
            <div className="mt-2 text-lg font-semibold">{suggestion.verticalLabel} · {suggestion.categoryLabel}</div>
            <div className="mt-1 text-sm text-muted-foreground">Confidence {(suggestion.confidence * 100).toFixed(0)}% · language {getLocaleDisplayName(suggestion.locale)}</div>
            <div className="mt-3 flex flex-wrap gap-2">
              {suggestion.subcategories.map((item) => <span key={item.code} className="rounded-full border border-border px-3 py-1 text-xs">{item.label}</span>)}
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {suggestion.hints.map((hint) => <span key={hint} className="rounded-full bg-background px-3 py-1 text-xs text-muted-foreground">{hint}</span>)}
            </div>
          </div>

          {preset && (
            <div className="rounded-2xl border border-border bg-muted/20 p-4 text-sm">
              <div className="font-medium">{countryCode} preset</div>
              <div className="mt-1 text-muted-foreground">City hints: {preset.cityHints.join(", ")}</div>
              <div className="mt-2 flex flex-wrap gap-2">
                {preset.priorityVerticals.map((item) => <span key={item} className="rounded-full border border-border px-3 py-1 text-xs">{item}</span>)}
              </div>
            </div>
          )}
        </div>

        <div className="space-y-4">
          {explorer.map((group) => (
            <section key={group.verticalCode} className="rounded-2xl border border-border bg-card p-5 shadow-sm">
              <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                <div>
                  <div className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">{group.localeName}</div>
                  <h2 className="text-xl font-semibold">{group.verticalLabel}</h2>
                </div>
                <div className="flex flex-wrap gap-2">
                  {group.categories.map((category) => <span key={category.code} className="rounded-full bg-primary/5 px-3 py-1 text-xs font-medium text-primary">{category.label}</span>)}
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                {group.featuredSubcategories.map((subcategory) => (
                  <span key={subcategory.code} className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">
                    {subcategory.label}
                  </span>
                ))}
              </div>
            </section>
          ))}
        </div>
      </section>
    </div>
  );
}
