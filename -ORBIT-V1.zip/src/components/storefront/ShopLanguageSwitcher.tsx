import { buildLanguageLabel, STOREFRONT_LANGUAGES, type SupportedStorefrontLanguage } from "@/lib/storefront-translation";

interface Props {
  value: SupportedStorefrontLanguage;
  onChange: (language: SupportedStorefrontLanguage) => void;
}

export default function ShopLanguageSwitcher({ value, onChange }: Props) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4 shadow-sm">
      <div className="text-sm font-medium">Language</div>
      <div className="mt-3 flex flex-wrap gap-2">
        {STOREFRONT_LANGUAGES.map((language) => {
          const active = value === language;
          return (
            <button
              key={language}
              type="button"
              onClick={() => onChange(language)}
              className={`rounded-full px-3 py-1.5 text-xs font-medium transition ${active ? "bg-primary text-primary-foreground" : "border border-border bg-background text-foreground"}`}
            >
              {buildLanguageLabel(language)}
            </button>
          );
        })}
      </div>
    </div>
  );
}
