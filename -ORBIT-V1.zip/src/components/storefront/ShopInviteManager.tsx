import { useState } from "react";
import { summarizeAccessDecision } from "@/lib/shop-access";
import type { ReturnType } from "react";
import type { useShopAccessControl } from "@/hooks/useShopAccessControl";

type AccessController = ReturnType<typeof useShopAccessControl>;

export default function ShopInviteManager({ access }: { access: AccessController }) {
  const [email, setEmail] = useState("");

  return (
    <div className="space-y-4 rounded-2xl border border-border bg-card p-5 shadow-sm">
      <div>
        <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Private access</div>
        <h3 className="text-lg font-semibold">Invite flow</h3>
        <p className="text-sm text-muted-foreground">{summarizeAccessDecision(access.decision)}. Add invited buyers, VIP clients or resellers and share a protected direct link.</p>
      </div>

      <div className="flex flex-col gap-2 sm:flex-row">
        <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="client@example.com" className="flex-1 rounded-xl border border-input bg-background px-3 py-2 text-sm" />
        <button
          type="button"
          onClick={() => {
            if (!email.trim()) return;
            access.addInvite(email, "viewer");
            setEmail("");
          }}
          className="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
        >
          Add invite
        </button>
      </div>

      <div className="space-y-3">
        {access.invites.length === 0 ? (
          <div className="rounded-xl bg-muted/50 p-4 text-sm text-muted-foreground">No invites yet. Add one email to open a private or unlisted shop safely.</div>
        ) : access.invites.map((invite) => (
          <div key={invite.id} className="rounded-xl border border-border p-4 text-sm">
            <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
              <div>
                <div className="font-medium">{invite.email}</div>
                <div className="text-muted-foreground">{invite.role} · {invite.status} · expires {new Date(invite.expiresAt).toLocaleString()}</div>
                <div className="mt-1 break-all text-xs text-primary">{access.getInviteLink(invite.id)}</div>
              </div>
              <div className="flex gap-2">
                <button type="button" onClick={() => access.acceptInvite(invite.id)} className="rounded-xl border border-border px-3 py-2">Accept</button>
                <button type="button" onClick={() => access.revokeInvite(invite.id)} className="rounded-xl border border-border px-3 py-2">Revoke</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
