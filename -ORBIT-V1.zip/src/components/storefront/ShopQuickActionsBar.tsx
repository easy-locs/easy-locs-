import { Link } from "react-router-dom";

export default function ShopQuickActionsBar({ slug }: { slug: string }) {
  return (
    <div className="rounded-3xl border border-border bg-card p-4 shadow-sm">
      <div className="flex flex-wrap gap-2">
        <Link to={`/shop/${slug}/checkout`} className="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">Checkout</Link>
        <Link to={`/deal/demo-${slug}`} className="rounded-xl border border-border px-4 py-2 text-sm font-medium">Deal room</Link>
        <Link to="/discover" className="rounded-xl border border-border px-4 py-2 text-sm font-medium">Discover</Link>
        <Link to="/business/shop-share" className="rounded-xl border border-border px-4 py-2 text-sm font-medium">Share setup</Link>
        <Link to="/business/analytics" className="rounded-xl border border-border px-4 py-2 text-sm font-medium">Analytics</Link>
      </div>
    </div>
  );
}
