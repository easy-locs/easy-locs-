import type { ReactNode } from "react";
import { summarizeAccessDecision, type ShopAccessDecision } from "@/lib/shop-access";

interface Props {
  decision: ShopAccessDecision | null;
  shopName?: string;
  onRetryLabel?: string;
  onAcceptInvite?: (() => void | Promise<void>) | null;
  acceptingInvite?: boolean;
  inviteToken?: string | null;
  children: ReactNode;
}

export default function ShopAccessGate({
  decision,
  shopName,
  children,
  onRetryLabel = "Open with invite link",
  onAcceptInvite,
  acceptingInvite = false,
  inviteToken,
}: Props) {
  if (!decision) return <>{children}</>;
  if (decision.allowed && decision.canPreview) return <>{children}</>;

  return (
    <div className="mx-auto max-w-2xl rounded-3xl border border-border bg-card p-6 shadow-sm">
      <div className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">Shop access</div>
      <h1 className="text-2xl font-semibold tracking-tight">{shopName ?? "This shop"} is not open yet</h1>
      <p className="mt-2 text-sm text-muted-foreground">{summarizeAccessDecision(decision)}</p>
      <div className="mt-5 rounded-2xl bg-muted/50 p-4 text-sm text-muted-foreground">
        {decision.requiresInvite && "This storefront is private. Use an invite link or be added by the owner."}
        {decision.requiresLink && "This storefront is unlisted. Open it using the direct private link shared by the business."}
        {decision.reason === "scheduled_waiting" && "This storefront is scheduled and will open automatically at the configured time."}
        {decision.reason === "draft_blocked" && "This storefront is still a draft and is not visible to buyers."}
      </div>
      <div className="mt-5 flex flex-wrap gap-3">
        {decision.requiresInvite && inviteToken && onAcceptInvite ? (
          <button type="button" onClick={() => void onAcceptInvite()} className="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground" disabled={acceptingInvite}>
            {acceptingInvite ? "Accepting invite..." : "Accept invite"}
          </button>
        ) : (
          <button type="button" className="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">{onRetryLabel}</button>
        )}
        <a href="/business/shops" className="rounded-xl border border-border px-4 py-2 text-sm font-medium">Business control center</a>
      </div>
    </div>
  );
}
