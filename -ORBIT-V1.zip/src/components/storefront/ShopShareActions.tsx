import { QRCodeSVG } from "qrcode.react";
import type { ShareTargets } from "@/lib/public-shop";

export default function ShopShareActions({ share }: { share: ShareTargets }) {
  const openShare = async () => {
    if (typeof navigator !== "undefined" && navigator.share) {
      await navigator.share({ title: "Orbit shop", url: share.canonicalUrl });
      return;
    }
    await navigator.clipboard.writeText(share.canonicalUrl);
  };

  return (
    <div className="rounded-2xl border border-border p-4">
      <div className="mb-3 text-sm font-medium">Quick sharing</div>
      <div className="grid gap-4 md:grid-cols-[auto_1fr] md:items-start">
        <div className="rounded-xl border border-border bg-white p-2">
          <QRCodeSVG value={share.canonicalUrl} size={128} includeMargin />
        </div>
        <div className="space-y-3">
          <input readOnly value={share.canonicalUrl} className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm" />
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={openShare} className="rounded-xl bg-primary px-3 py-2 text-sm font-medium text-primary-foreground">Copy / share</button>
            <a href={share.whatsappUrl} target="_blank" rel="noopener noreferrer" className="rounded-xl border border-border px-3 py-2 text-sm">WhatsApp</a>
            <a href={share.telegramUrl} target="_blank" rel="noopener noreferrer" className="rounded-xl border border-border px-3 py-2 text-sm">Telegram</a>
            <a href={share.xUrl} target="_blank" rel="noopener noreferrer" className="rounded-xl border border-border px-3 py-2 text-sm">X</a>
            <a href={share.mailUrl} className="rounded-xl border border-border px-3 py-2 text-sm">Email</a>
          </div>
          <p className="text-xs text-muted-foreground">Shared links use the shop name, description and banner/logo preview from the public shop page.</p>
        </div>
      </div>
    </div>
  );
}
