import type { StorefrontCatalogFilter } from "@/lib/storefront-catalog";

interface Props {
  query: string;
  onQueryChange: (value: string) => void;
  filter: StorefrontCatalogFilter;
  onFilterChange: (value: StorefrontCatalogFilter) => void;
  category: string;
  onCategoryChange: (value: string) => void;
  categories: string[];
}

export default function ShopCatalogFilters({
  query,
  onQueryChange,
  filter,
  onFilterChange,
  category,
  onCategoryChange,
  categories,
}: Props) {
  return (
    <div className="grid gap-3 rounded-2xl border border-border bg-muted/30 p-4 md:grid-cols-[1fr_auto_auto]">
      <input
        value={query}
        onChange={(e) => onQueryChange(e.target.value)}
        placeholder="Search inside this shop"
        className="h-11 rounded-xl border border-border bg-background px-3 text-sm outline-none"
      />

      <div className="flex flex-wrap gap-2">
        {(["all", "product", "service"] as const).map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => onFilterChange(item)}
            className={`rounded-xl px-3 py-2 text-sm ${filter === item ? "bg-primary text-primary-foreground" : "border border-border bg-background"}`}
          >
            {item === "all" ? "All" : item === "product" ? "Products" : "Services"}
          </button>
        ))}
      </div>

      <select
        value={category}
        onChange={(e) => onCategoryChange(e.target.value)}
        className="h-11 rounded-xl border border-border bg-background px-3 text-sm outline-none"
      >
        <option value="">All categories</option>
        {categories.map((item) => (
          <option key={item} value={item}>{item}</option>
        ))}
      </select>
    </div>
  );
}
