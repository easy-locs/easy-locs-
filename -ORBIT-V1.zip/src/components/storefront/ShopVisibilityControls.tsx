import type { ShopVisibility } from "@/lib/public-shop";
import { getVisibilityLabel } from "@/lib/public-shop";

const OPTIONS: ShopVisibility[] = ["public", "unlisted", "private", "draft", "scheduled"];

export default function ShopVisibilityControls({
  value,
  onChange,
}: {
  value: ShopVisibility;
  onChange: (next: ShopVisibility) => void;
}) {
  return (
    <div className="space-y-2">
      <div className="text-sm font-medium">Shop visibility</div>
      <div className="grid grid-cols-2 gap-2 md:grid-cols-5">
        {OPTIONS.map(option => (
          <button
            key={option}
            type="button"
            onClick={() => onChange(option)}
            className={`rounded-xl border px-3 py-2 text-sm ${value === option ? "border-primary bg-primary/10 text-primary" : "border-border bg-background"}`}
          >
            {getVisibilityLabel(option)}
          </button>
        ))}
      </div>
      <p className="text-xs text-muted-foreground">Public = searchable. Unlisted = link only. Private = invite only. Draft = hidden. Scheduled = opens automatically.</p>
    </div>
  );
}
