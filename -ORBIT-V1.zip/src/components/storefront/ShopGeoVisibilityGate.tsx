import type { ShopLocationScope } from "@/lib/public-shop";
import { geoText } from "@/lib/shop-geo-scope";
import { useShopGeoScope } from "@/hooks/useShopGeoScope";

interface Props {
  scope: ShopLocationScope;
}

export default function ShopGeoVisibilityGate({ scope }: Props) {
  const { viewer, updateViewer, detectLocation, locating, availability } = useShopGeoScope(scope);

  return (
    <div className="rounded-3xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-sm font-medium">Geo access</div>
          <div className="mt-1 text-xs text-muted-foreground">Control shop visibility by country, region, city and service radius.</div>
        </div>
        <span className={`rounded-full px-3 py-1 text-xs font-medium ${availability.allowed ? "bg-emerald-500/10 text-emerald-600" : "bg-amber-500/10 text-amber-600"}`}>
          {availability.allowed ? "Visible here" : "Restricted"}
        </span>
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-2">
        <div className="rounded-2xl bg-muted/50 p-4 text-sm">
          <div className="font-medium">Shop scope</div>
          <div className="mt-1 text-muted-foreground">{geoText(scope) || "Worldwide"}</div>
        </div>
        <div className="rounded-2xl bg-muted/50 p-4 text-sm">
          <div className="font-medium">Viewer scope</div>
          <div className="mt-1 text-muted-foreground">{geoText(viewer) || "Not set"}</div>
        </div>
      </div>

      <div className="mt-4 rounded-2xl border border-border p-4 text-sm">
        <div className="font-medium">Smart result</div>
        <div className="mt-1 text-muted-foreground">{availability.summary}</div>
        {availability.distanceKm != null && (
          <div className="mt-1 text-xs text-muted-foreground">Distance: {availability.distanceKm.toFixed(1)} km</div>
        )}
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-3">
        <label className="grid gap-1 text-sm">
          <span className="text-muted-foreground">Country</span>
          <input value={viewer.countryCode ?? ""} onChange={(e) => updateViewer({ countryCode: e.target.value.toUpperCase() })} className="rounded-xl border border-border bg-background px-3 py-2" placeholder="AE" />
        </label>
        <label className="grid gap-1 text-sm">
          <span className="text-muted-foreground">Region</span>
          <input value={viewer.region ?? ""} onChange={(e) => updateViewer({ region: e.target.value })} className="rounded-xl border border-border bg-background px-3 py-2" placeholder="Dubai" />
        </label>
        <label className="grid gap-1 text-sm">
          <span className="text-muted-foreground">City</span>
          <input value={viewer.city ?? ""} onChange={(e) => updateViewer({ city: e.target.value })} className="rounded-xl border border-border bg-background px-3 py-2" placeholder="Dubai Marina" />
        </label>
      </div>

      <div className="mt-4 flex flex-wrap gap-3">
        <button type="button" onClick={() => void detectLocation()} className="rounded-xl border border-border px-4 py-2 text-sm font-medium">
          {locating ? "Detecting..." : "Use my GPS"}
        </button>
        <button type="button" onClick={() => updateViewer({ countryCode: undefined, region: undefined, city: undefined, latitude: undefined, longitude: undefined })} className="rounded-xl border border-border px-4 py-2 text-sm font-medium">
          Reset viewer scope
        </button>
      </div>
    </div>
  );
}
