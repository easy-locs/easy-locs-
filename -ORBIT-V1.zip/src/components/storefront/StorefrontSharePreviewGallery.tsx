import type { SharePreviewCard } from "@/lib/storefront-share-meta";

const CHANNELS = [
  { key: "whatsapp", label: "WhatsApp", note: "Large image + short description" },
  { key: "telegram", label: "Telegram", note: "Card preview from URL metadata" },
  { key: "x", label: "X", note: "Summary card / large image card" },
  { key: "email", label: "Email", note: "Title + description + direct link" },
];

export default function StorefrontSharePreviewGallery({ preview }: { preview: SharePreviewCard }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4 shadow-sm">
      <div className="mb-3 text-sm font-medium">Channel preview guide</div>
      <div className="grid gap-3 md:grid-cols-2">
        {CHANNELS.map((channel) => (
          <div key={channel.key} className="rounded-2xl border border-border bg-background/70 p-4">
            <div className="flex items-center justify-between gap-2">
              <div className="font-medium">{channel.label}</div>
              <span className="rounded-full bg-muted px-2 py-1 text-[10px] uppercase tracking-wide text-muted-foreground">preview</span>
            </div>
            <div className="mt-2 text-sm text-muted-foreground">{channel.note}</div>
            <div className="mt-3 rounded-xl border border-dashed border-border p-3">
              <div className="text-sm font-medium">{preview.title}</div>
              <div className="mt-1 line-clamp-2 text-xs text-muted-foreground">{preview.description}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
