import type { StorefrontCartState } from "@/lib/storefront-order-engine";

interface Props {
  cart: StorefrontCartState;
  currency: string;
  onUpdateQuantity: (entryId: string, quantity: number) => void;
  onClear: () => void;
}

export default function ShopCartDrawer({ cart, currency, onUpdateQuantity, onClear }: Props) {
  return (
    <div className="rounded-3xl border border-border bg-card p-5 shadow-sm">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div>
          <h3 className="text-lg font-semibold">Cart</h3>
          <p className="text-sm text-muted-foreground">Simple checkout basket for products and services.</p>
        </div>
        <button type="button" onClick={onClear} className="rounded-xl border border-border px-3 py-2 text-xs font-medium">
          Clear
        </button>
      </div>

      {cart.items.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-5 text-sm text-muted-foreground">Your cart is empty. Add products or services from the shop catalog.</div>
      ) : (
        <div className="space-y-3">
          {cart.items.map((item) => (
            <div key={item.entryId} className="rounded-2xl border border-border p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-medium">{item.entry.name}</div>
                  <div className="text-xs uppercase tracking-wide text-muted-foreground">{item.entry.kind}</div>
                  {item.entry.description ? <p className="mt-1 text-sm text-muted-foreground">{item.entry.description}</p> : null}
                </div>
                <div className="text-sm font-medium">{(item.entry.price ?? 0) * item.quantity} {item.entry.currency || currency}</div>
              </div>
              <div className="mt-3 flex items-center gap-2">
                <button type="button" onClick={() => onUpdateQuantity(item.entryId, item.quantity - 1)} className="rounded-lg border border-border px-3 py-1 text-sm">−</button>
                <div className="min-w-8 text-center text-sm font-medium">{item.quantity}</div>
                <button type="button" onClick={() => onUpdateQuantity(item.entryId, item.quantity + 1)} className="rounded-lg border border-border px-3 py-1 text-sm">+</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
