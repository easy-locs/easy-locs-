import { useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import ShopAccessBadge from "@/components/storefront/ShopAccessBadge";
import ShopShareActions from "@/components/storefront/ShopShareActions";
import PublicShopCatalog from "@/components/storefront/PublicShopCatalog";
import ShopSlugRegistryCard from "@/components/storefront/ShopSlugRegistryCard";
import ShopCatalogFilters from "@/components/storefront/ShopCatalogFilters";
import ShopGeoScopeCard from "@/components/storefront/ShopGeoScopeCard";
import ShopGeoVisibilityGate from "@/components/storefront/ShopGeoVisibilityGate";
import ShopQuickActionsBar from "@/components/storefront/ShopQuickActionsBar";
import ShopLanguageSwitcher from "@/components/storefront/ShopLanguageSwitcher";
import TranslatedShopText from "@/components/storefront/TranslatedShopText";
import type { ShopAccessDecision } from "@/lib/shop-access";
import { buildShopPreviewMeta, buildShopShareTargets, summarizeLocation } from "@/lib/public-shop";
import { applyStorefrontMetaTags, buildStorefrontMetaTags, buildStorefrontSharePreview } from "@/lib/storefront-share-meta";
import ShopMetaPreviewCard from "@/components/storefront/ShopMetaPreviewCard";
import StorefrontSharePreviewGallery from "@/components/storefront/StorefrontSharePreviewGallery";
import { getVisibilityHint, type StorefrontRecord } from "@/lib/storefront-directory";
import { buildShopMetadataPreview } from "@/lib/storefront-catalog";
import { useStorefrontCatalog } from "@/hooks/useStorefrontCatalog";
import { useStorefrontOrder } from "@/hooks/useStorefrontOrder";
import { useStorefrontTranslation } from "@/hooks/useStorefrontTranslation";

interface Props {
  storefront: StorefrontRecord;
  accessDecision: ShopAccessDecision;
}

export default function PublicShopPage({ storefront, accessDecision }: Props) {
  const share = buildShopShareTargets(typeof window !== "undefined" ? window.location.origin : "https://orbit.local", storefront);
  const catalog = useStorefrontCatalog(storefront.catalog);
  const preview = buildShopPreviewMeta(storefront);
  const sharePreview = useMemo(() => buildStorefrontSharePreview(storefront, preview), [storefront, preview]);
  const metaTags = useMemo(() => buildStorefrontMetaTags(storefront, share, preview), [storefront, share, preview]);
  const order = useStorefrontOrder(storefront.slug, storefront.catalog?.[0]?.currency || "AED");
  const translation = useStorefrontTranslation({
    storefront: {
      storefrontId: storefront.id,
      shopName: storefront.shopName,
      description: storefront.description,
      language: "en",
    },
    catalog: storefront.catalog.map((item) => ({ id: item.id, name: item.name, description: item.description })),
  });

  const translatedCatalogMap = new Map(translation.translatedCatalog.map((item) => [item.id, item]));
  const translatedStorefront = translation.translatedStorefront;
  const translatedCatalogEntries = catalog.filteredEntries.map((entry) => ({
    ...entry,
    name: translatedCatalogMap.get(entry.id)?.name || entry.name,
    description: translatedCatalogMap.get(entry.id)?.description || entry.description,
  }));

  const meta = buildShopMetadataPreview({
    shopName: translatedStorefront.shopName,
    description: translatedStorefront.description,
    city: storefront.location.city,
    countryCode: storefront.location.countryCode,
    catalogCount: storefront.catalog.length,
  });

  useEffect(() => {
    applyStorefrontMetaTags(metaTags);
  }, [metaTags]);

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-6 md:px-6">
      <section className="overflow-hidden rounded-3xl border border-border bg-card shadow-sm">
        <div className="bg-gradient-to-r from-primary/15 via-primary/5 to-transparent px-5 py-8 md:px-8">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
            <div className="space-y-3">
              <div className="text-xs font-semibold uppercase tracking-[0.25em] text-muted-foreground">Orbit shop</div>
              <div>
                <TranslatedShopText title={translatedStorefront.shopName} description={translatedStorefront.description} language={translation.language} />
              </div>
              <div className="flex flex-wrap gap-2">
                <span className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">{summarizeLocation(storefront.location)}</span>
                <span className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">{getVisibilityHint(storefront.visibility)}</span>
                <span className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">{catalog.summary.total} catalog entries</span>
              </div>
            </div>
            <div className="grid gap-3 sm:min-w-[300px]">
              <ShopAccessBadge decision={accessDecision} />
              <div className="rounded-2xl border border-primary/15 bg-primary/5 p-4 text-sm">
                <div className="font-medium">Fast order</div>
                <div className="mt-1 text-muted-foreground">Browse the catalog, choose a product or service, then convert directly into order, payment or delivery.</div>
                <div className="mt-2 text-xs text-muted-foreground">Cart: {order.summary.itemCount} item(s) · {order.summary.subtotal} {order.summary.currency}</div>
                <div className="mt-3 flex gap-2">
                  <Link to={`/shop/${storefront.slug}/checkout`} className="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">Order now</Link>
                  <a href={`/deal/demo-${storefront.slug}`} className="rounded-xl border border-border px-4 py-2 text-sm font-medium">Open deal room</a>
                </div>
              </div>
              <div className="rounded-2xl border border-border bg-background/70 p-4 text-sm">
                <div className="font-medium">Share preview</div>
                <div className="mt-1 text-muted-foreground">{preview.title}</div>
                <div className="mt-1 line-clamp-2 text-xs text-muted-foreground">{meta.description}</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <ShopQuickActionsBar slug={storefront.slug} />

      <section className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <div className="rounded-3xl border border-border bg-card p-5 shadow-sm">
          <div className="mb-4 flex items-center justify-between gap-3">
            <div>
              <h2 className="text-xl font-semibold">Catalog</h2>
              <p className="text-sm text-muted-foreground">Products and services shown inside the shared shop URL.</p>
            </div>
            <div className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">
              {catalog.summary.products} products · {catalog.summary.services} services
            </div>
          </div>

          <ShopCatalogFilters
            query={catalog.query}
            onQueryChange={catalog.setQuery}
            filter={catalog.filter}
            onFilterChange={catalog.setFilter}
            category={catalog.category}
            onCategoryChange={catalog.setCategory}
            categories={catalog.categories}
          />

          <div className="mt-4">
            <PublicShopCatalog entries={translatedCatalogEntries} onAddToCart={order.addToCart} />
          </div>
        </div>

        <div className="space-y-6">
          <ShopLanguageSwitcher value={translation.language} onChange={translation.setLanguage} />
          <ShopShareActions share={share} />
          <ShopMetaPreviewCard preview={sharePreview} />
          <StorefrontSharePreviewGallery preview={sharePreview} />
          <ShopGeoScopeCard scope={storefront.location} />
          <ShopGeoVisibilityGate scope={storefront.location} />
          <ShopSlugRegistryCard storefrontId={storefront.id} initialSlug={storefront.slug} visibility={storefront.visibility} />
          <div className="rounded-3xl border border-border bg-card p-5 shadow-sm">
            <div className="text-sm font-medium">Business structure</div>
            <div className="mt-3 space-y-3 text-sm">
              <div className="rounded-2xl bg-muted/50 p-4">
                <div className="font-medium">Owner</div>
                <div className="text-muted-foreground">{storefront.ownerName}</div>
              </div>
              <div className="rounded-2xl bg-muted/50 p-4">
                <div className="font-medium">Activities</div>
                <div className="mt-2 flex flex-wrap gap-2">
                  {storefront.activities.length > 0 ? storefront.activities.map((activity, index) => (
                    <span key={`${activity.name}-${index}`} className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">{activity.name}</span>
                  )) : <span className="text-muted-foreground">No activity labels yet</span>}
                </div>
              </div>
              <div className="rounded-2xl bg-muted/50 p-4">
                <div className="font-medium">Contact</div>
                <div className="text-muted-foreground">{storefront.phone}</div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
