import { useMemo, useState } from "react";
import { normalizeShopSlug } from "@/lib/public-shop";
import { registerShopSlug } from "@/lib/storefront-supabase";

interface Props {
  storefrontId: string;
  initialSlug: string;
  visibility?: string;
}

export default function ShopSlugRegistryCard({ storefrontId, initialSlug, visibility = "public" }: Props) {
  const [value, setValue] = useState(initialSlug);
  const [saved, setSaved] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const normalized = useMemo(() => normalizeShopSlug(value), [value]);

  const save = async () => {
    setSaving(true);
    try {
      const { data } = await registerShopSlug({ storefrontId, slug: normalized, visibility });
      setSaved(data?.slug ?? normalized);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="rounded-3xl border border-border bg-card p-5 shadow-sm">
      <div className="text-sm font-medium">Shop URL</div>
      <p className="mt-1 text-sm text-muted-foreground">Keep your shop link short, clean and easy to share worldwide.</p>
      <div className="mt-4 flex flex-col gap-3 sm:flex-row">
        <div className="flex-1 rounded-2xl border border-border bg-background px-4 py-3 text-sm">/shop/{normalized || "your-shop-slug"}</div>
        <input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="pizza-times-marina"
          className="flex-1 rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none"
        />
      </div>
      <div className="mt-4 flex items-center gap-3">
        <button type="button" onClick={() => void save()} className="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground" disabled={saving}>
          {saving ? "Saving..." : "Save slug"}
        </button>
        {saved ? <span className="text-xs text-muted-foreground">Saved: /shop/{saved}</span> : null}
      </div>
    </div>
  );
}
