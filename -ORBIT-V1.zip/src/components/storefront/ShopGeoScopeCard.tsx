import type { ShopLocationScope } from "@/lib/public-shop";

export default function ShopGeoScopeCard({ scope }: { scope: ShopLocationScope }) {
  const chips = [
    scope.countryCode ? `Country: ${scope.countryCode}` : null,
    scope.region ? `Region: ${scope.region}` : null,
    scope.city ? `City: ${scope.city}` : null,
    scope.radiusKm ? `Radius: ${scope.radiusKm} km` : null,
  ].filter(Boolean);

  return (
    <div className="rounded-3xl border border-border bg-card p-5 shadow-sm">
      <div className="text-sm font-medium">Geo scope</div>
      <div className="mt-1 text-sm text-muted-foreground">Worldwide-ready visibility with country, region, city and radius rules.</div>
      <div className="mt-3 flex flex-wrap gap-2">
        {chips.length ? chips.map((chip) => (
          <span key={chip} className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">{chip}</span>
        )) : <span className="text-sm text-muted-foreground">No geo scope configured.</span>}
      </div>
    </div>
  );
}
