import type { SharePreviewCard } from "@/lib/storefront-share-meta";

export default function ShopMetaPreviewCard({ preview }: { preview: SharePreviewCard }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4 shadow-sm">
      <div className="mb-3 text-sm font-medium">Share preview</div>
      <div className="overflow-hidden rounded-2xl border border-border bg-background">
        {preview.image ? (
          <div className="h-36 w-full bg-cover bg-center" style={{ backgroundImage: `url(${preview.image})` }} />
        ) : (
          <div className="flex h-24 items-center justify-center bg-muted text-sm text-muted-foreground">No preview image</div>
        )}
        <div className="space-y-2 p-4">
          <div>
            <div className="text-base font-semibold">{preview.title}</div>
            <div className="text-xs text-muted-foreground">/{preview.subtitle}</div>
          </div>
          <p className="text-sm text-muted-foreground">{preview.description}</p>
          <div className="flex flex-wrap gap-2">
            {preview.chips.map((chip) => (
              <span key={chip} className="rounded-full border border-border px-2.5 py-1 text-[11px] text-muted-foreground">{chip}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
