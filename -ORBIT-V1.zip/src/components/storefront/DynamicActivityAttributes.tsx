import { buildAttributePreviewMap } from "@/lib/orbit-category-seed";
import type { SupportedLocale } from "@/lib/orbit-taxonomy";

interface Props {
  verticalCode: string;
  categoryCode: string;
  subcategoryCodes: string[];
  locale?: SupportedLocale;
}

export default function DynamicActivityAttributes({ verticalCode, categoryCode, subcategoryCodes, locale = "en" }: Props) {
  const attributes = buildAttributePreviewMap({ verticalCode, categoryCode, subcategoryCodes, locale });

  if (!attributes.length) {
    return (
      <div className="rounded-2xl border border-dashed border-border bg-muted/30 p-4 text-sm text-muted-foreground">
        No dynamic attributes suggested yet for this activity.
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="text-sm font-medium">Suggested smart fields</div>
      <div className="grid gap-3 md:grid-cols-2">
        {attributes.map((attribute) => (
          <div key={attribute.code} className="rounded-2xl border border-border bg-background/70 p-3">
            <div className="flex items-center justify-between gap-3">
              <div className="font-medium text-sm">{attribute.label}</div>
              <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{attribute.type}</div>
            </div>
            <div className="mt-2 flex flex-wrap gap-2 text-[11px]">
              {attribute.required && <span className="rounded-full bg-destructive/10 px-2 py-1 text-destructive">required</span>}
              {attribute.filterable && <span className="rounded-full bg-primary/10 px-2 py-1 text-primary">filter</span>}
            </div>
            {!!attribute.options.length && (
              <div className="mt-3 flex flex-wrap gap-2">
                {attribute.options.slice(0, 6).map((option) => (
                  <span key={option} className="rounded-full border border-border px-2 py-1 text-[11px]">
                    {option.replace(/_/g, " ")}
                  </span>
                ))}
                {attribute.options.length > 6 && (
                  <span className="rounded-full border border-border px-2 py-1 text-[11px] text-muted-foreground">
                    +{attribute.options.length - 6} more
                  </span>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
