import { summarizeAccessDecision, type ShopAccessDecision } from "@/lib/shop-access";

export default function ShopAccessBadge({ decision }: { decision: ShopAccessDecision }) {
  return (
    <div className="rounded-xl border border-primary/20 bg-primary/5 px-4 py-3 text-sm">
      <div className="font-medium">Access</div>
      <div className="text-muted-foreground">{summarizeAccessDecision(decision)}</div>
      <div className="mt-1 text-xs text-muted-foreground">
        {decision.canOrder ? "Ordering enabled" : "Ordering blocked"}
        {decision.requiresInvite ? " · Invite needed" : ""}
        {decision.requiresLink ? " · Direct link needed" : ""}
      </div>
    </div>
  );
}
