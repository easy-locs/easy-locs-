import { useState } from "react";
import type { DeliveryFinanceItem } from "@/hooks/useDeliveryFinance";

interface DeliveryDisputePanelProps {
  item: DeliveryFinanceItem | null;
  busy?: boolean;
  onRelease: (jobId: string) => Promise<void>;
  onCreateDispute: (jobId: string, reason: string, action: "refund" | "partial_refund" | "review") => Promise<void>;
}

export default function DeliveryDisputePanel({ item, busy, onRelease, onCreateDispute }: DeliveryDisputePanelProps) {
  const [reason, setReason] = useState("Damaged parcel or wrong delivery proof");

  if (!item) {
    return (
      <section className="rounded-3xl border bg-card p-5 shadow-sm">
        <h2 className="text-xl font-semibold">Finance action</h2>
        <p className="mt-3 text-sm text-muted-foreground">Select a delivery from the money list to release funds or open a dispute.</p>
      </section>
    );
  }

  return (
    <section className="rounded-3xl border bg-card p-5 shadow-sm">
      <p className="text-sm uppercase tracking-wide text-muted-foreground">Money action</p>
      <h2 className="text-xl font-semibold">Simple finance controls</h2>
      <p className="mt-2 text-sm text-muted-foreground">Use this block when you need to answer one question fast: release the money, freeze the case, or refund part of the order.</p>

      <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-2xl border p-4">
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Seller</p>
          <p className="mt-2 font-medium">{item.sellerAmount.toFixed(0)} AED</p>
        </div>
        <div className="rounded-2xl border p-4">
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Driver</p>
          <p className="mt-2 font-medium">{item.driverAmount.toFixed(0)} AED</p>
        </div>
        <div className="rounded-2xl border p-4">
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Platform fee</p>
          <p className="mt-2 font-medium">{item.platformFee.toFixed(0)} AED</p>
        </div>
        <div className="rounded-2xl border p-4">
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Next step</p>
          <p className="mt-2 font-medium">{item.moneyNextStep}</p>
        </div>
      </div>

      <div className="mt-5 rounded-2xl border p-4">
        <label className="text-sm font-medium" htmlFor="dispute-reason">Reason</label>
        <textarea
          id="dispute-reason"
          value={reason}
          onChange={(event) => setReason(event.target.value)}
          className="mt-2 min-h-[96px] w-full rounded-xl border bg-background px-3 py-2 text-sm"
        />
        <p className="mt-2 text-xs text-muted-foreground">Keep it simple: what happened, what proof exists, and what decision is needed.</p>
      </div>

      <div className="mt-5 flex flex-wrap gap-3">
        <button
          type="button"
          disabled={busy || item.status === "dispute"}
          onClick={() => onRelease(item.jobId)}
          className="rounded-xl border px-4 py-2 text-sm font-medium transition hover:border-primary/50 disabled:opacity-50"
        >
          Release money now
        </button>
        <button
          type="button"
          disabled={busy}
          onClick={() => onCreateDispute(item.jobId, reason, "review")}
          className="rounded-xl border px-4 py-2 text-sm font-medium transition hover:border-primary/50 disabled:opacity-50"
        >
          Open dispute review
        </button>
        <button
          type="button"
          disabled={busy}
          onClick={() => onCreateDispute(item.jobId, reason, "partial_refund")}
          className="rounded-xl border px-4 py-2 text-sm font-medium transition hover:border-primary/50 disabled:opacity-50"
        >
          Partial refund
        </button>
        <button
          type="button"
          disabled={busy}
          onClick={() => onCreateDispute(item.jobId, reason, "refund")}
          className="rounded-xl border px-4 py-2 text-sm font-medium transition hover:border-primary/50 disabled:opacity-50"
        >
          Full refund
        </button>
      </div>
    </section>
  );
}
