import type { DeliveryFinanceItem } from "@/hooks/useDeliveryFinance";

interface DeliveryFinanceBoardProps {
  items: DeliveryFinanceItem[];
  selectedId?: string | null;
  onSelect: (jobId: string) => void;
}

const tones: Record<DeliveryFinanceItem["risk"], string> = {
  low: "border-emerald-500/30 bg-emerald-500/5",
  watch: "border-amber-500/30 bg-amber-500/5",
  high: "border-destructive/40 bg-destructive/5",
};

export default function DeliveryFinanceBoard({ items, selectedId, onSelect }: DeliveryFinanceBoardProps) {
  return (
    <section className="rounded-3xl border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Finance board</p>
          <h2 className="text-xl font-semibold">Money status in one simple list</h2>
        </div>
        <span className="text-xs text-muted-foreground">{items.length} deliveries</span>
      </div>

      <div className="mt-4 space-y-3">
        {items.map((item) => {
          const selected = item.jobId === selectedId;
          return (
            <button
              key={item.jobId}
              type="button"
              onClick={() => onSelect(item.jobId)}
              className={[
                "w-full rounded-2xl border p-4 text-left transition hover:border-primary/50",
                tones[item.risk],
                selected ? "ring-2 ring-primary/30" : "",
              ].join(" ")}
            >
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-semibold">#{item.orderId.slice(0, 8)}</p>
                  <p className="text-sm text-muted-foreground">{item.grossAmount.toFixed(0)} AED gross • seller {item.sellerAmount.toFixed(0)} • driver {item.driverAmount.toFixed(0)}</p>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span className="rounded-full border px-2 py-1 uppercase tracking-wide">{item.status}</span>
                  <span className="rounded-full border px-2 py-1 uppercase tracking-wide">{item.escrowStatus}</span>
                </div>
              </div>
              <p className="mt-3 text-sm">{item.moneyNextStep}</p>
            </button>
          );
        })}
      </div>
    </section>
  );
}
