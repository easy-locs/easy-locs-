import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { StorefrontAnalyticsSnapshot } from "@/lib/storefront-analytics";

export default function StorefrontConversionCard({ snapshot, insight }: { snapshot: StorefrontAnalyticsSnapshot; insight: string }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Conversion overview</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 text-sm">
        <div className="grid gap-2 md:grid-cols-3">
          <div className="rounded-lg border p-3">
            <div className="text-muted-foreground">Visitors</div>
            <div className="text-lg font-semibold">{snapshot.visitors.toLocaleString()}</div>
          </div>
          <div className="rounded-lg border p-3">
            <div className="text-muted-foreground">Orders</div>
            <div className="text-lg font-semibold">{snapshot.orders.toLocaleString()}</div>
          </div>
          <div className="rounded-lg border p-3">
            <div className="text-muted-foreground">Conversion</div>
            <div className="text-lg font-semibold">{snapshot.conversionRate.toFixed(1)}%</div>
          </div>
        </div>
        <div className="rounded-lg border border-dashed p-3 text-muted-foreground">Top insight: {insight}</div>
      </CardContent>
    </Card>
  );
}
