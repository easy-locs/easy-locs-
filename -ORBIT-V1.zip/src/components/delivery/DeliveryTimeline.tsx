import type { DeliveryTimelineStep } from "@/hooks/useDeliveryCommandCenter";

interface DeliveryTimelineProps {
  steps: DeliveryTimelineStep[];
}

export default function DeliveryTimeline({ steps }: DeliveryTimelineProps) {
  return (
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-7">
      {steps.map((step, index) => (
        <div key={`${step.key}-${index}`} className="rounded-2xl border p-3 text-sm">
          <div className="flex items-center gap-3">
            <div
              className={[
                "flex h-8 w-8 items-center justify-center rounded-full border text-xs font-semibold",
                step.state === "done" ? "bg-primary text-primary-foreground" : "",
                step.state === "active" ? "border-primary text-primary" : "",
                step.state === "issue" ? "border-destructive text-destructive" : "",
              ].join(" ")}
            >
              {index + 1}
            </div>
            <div>
              <p className="font-medium">{step.label}</p>
              <p className="text-xs text-muted-foreground capitalize">{step.state}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
