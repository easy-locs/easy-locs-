import type { DeliveryDriverCardInfo } from "@/hooks/useDeliveryTimeline";

interface DeliveryDriverCardProps {
  driver: DeliveryDriverCardInfo | null;
  onOpenTracking?: () => void;
}

export default function DeliveryDriverCard({ driver, onOpenTracking }: DeliveryDriverCardProps) {
  if (!driver) {
    return (
      <section className="rounded-2xl border bg-card p-4 shadow-sm">
        <p className="text-sm uppercase tracking-wide text-muted-foreground">Driver</p>
        <h3 className="mt-2 text-lg font-semibold">Waiting for assignment</h3>
        <p className="mt-2 text-sm text-muted-foreground">A driver card will appear here as soon as the mission is accepted.</p>
      </section>
    );
  }

  return (
    <section className="rounded-2xl border bg-card p-4 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Driver</p>
          <h3 className="mt-2 text-lg font-semibold">{driver.label}</h3>
          <p className="mt-1 text-sm text-muted-foreground">{driver.vehicle} • {driver.status} • {driver.rating.toFixed(1)} / 5</p>
        </div>
        {driver.etaMinutes != null ? <span className="rounded-full border px-3 py-1 text-xs">ETA {driver.etaMinutes} min</span> : null}
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl border bg-muted/30 p-3 text-sm">
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Call</p>
          <p className="mt-1 font-medium">{driver.phone ?? "In-app contact coming next"}</p>
        </div>
        <div className="rounded-xl border bg-muted/30 p-3 text-sm">
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Current ETA</p>
          <p className="mt-1 font-medium">{driver.etaMinutes != null ? `${driver.etaMinutes} min` : "Updating"}</p>
        </div>
      </div>

      {onOpenTracking ? (
        <button type="button" onClick={onOpenTracking} className="mt-4 rounded-xl border px-4 py-2 text-sm font-medium">
          Open GPS tracking
        </button>
      ) : null}
    </section>
  );
}
