import type { DeliveryCommandItem } from "@/hooks/useDeliveryCommandCenter";

interface DeliveryCommandBoardProps {
  items: DeliveryCommandItem[];
  selectedId?: string | null;
  onSelect: (id: string) => void;
}

const toneClasses: Record<DeliveryCommandItem["health"], string> = {
  good: "border-emerald-500/30 bg-emerald-500/5",
  watch: "border-amber-500/30 bg-amber-500/5",
  issue: "border-destructive/40 bg-destructive/5",
};

export default function DeliveryCommandBoard({ items, selectedId, onSelect }: DeliveryCommandBoardProps) {
  return (
    <section className="rounded-3xl border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Command board</p>
          <h2 className="text-xl font-semibold">One simple list for action</h2>
        </div>
        <span className="text-xs text-muted-foreground">{items.length} deliveries</span>
      </div>

      <div className="mt-4 space-y-3">
        {items.map((item) => {
          const selected = item.id === selectedId;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelect(item.id)}
              className={[
                "w-full rounded-2xl border p-4 text-left transition hover:border-primary/50",
                toneClasses[item.health],
                selected ? "ring-2 ring-primary/30" : "",
              ].join(" ")}
            >
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-semibold">#{item.orderId.slice(0, 8)}</p>
                  <p className="text-sm text-muted-foreground">{item.packageLabel} • {item.priceAed.toFixed(0)} AED</p>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span className="rounded-full border px-2 py-1 uppercase tracking-wide">{item.ownerView}</span>
                  <span className="rounded-full border px-2 py-1 uppercase tracking-wide">{item.status}</span>
                </div>
              </div>
              <p className="mt-3 text-sm">{item.nextAction}</p>
            </button>
          );
        })}
      </div>
    </section>
  );
}
