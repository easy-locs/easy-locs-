import LiveTrackingMap from "@/components/tracking/LiveTrackingMap";
import { useDeliveryTracking } from "@/hooks/useDeliveryTracking";

const STATUS_LABELS: Record<string, { label: string; emoji: string }> = {
  pending: { label: "Preparing", emoji: "⏳" },
  en_route: { label: "En route", emoji: "🚗" },
  nearby: { label: "Nearby", emoji: "📍" },
  arrived: { label: "Arrived", emoji: "✅" },
  completed: { label: "Completed", emoji: "🏁" },
};

interface DeliveryLiveTrackerProps {
  jobId: string;
  onClose?: () => void;
}

export default function DeliveryLiveTracker({ jobId, onClose }: DeliveryLiveTrackerProps) {
  const { session, loading, hasTracking, trackingId } = useDeliveryTracking(jobId);

  if (loading) {
    return <div className="rounded-2xl border bg-card p-4 text-sm text-muted-foreground">Searching for live tracking…</div>;
  }

  if (!hasTracking || !session || !trackingId) {
    return (
      <div className="rounded-2xl border bg-card p-4 shadow-sm">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="text-lg font-semibold">No active GPS tracking</h3>
            <p className="mt-2 text-sm text-muted-foreground">Tracking starts when the driver shares live location for this delivery.</p>
          </div>
          {onClose ? <button type="button" className="rounded-xl border px-3 py-2 text-sm" onClick={onClose}>Close</button> : null}
        </div>
      </div>
    );
  }

  const statusCfg = STATUS_LABELS[session.status] ?? STATUS_LABELS.pending;

  return (
    <section className="rounded-2xl border bg-card p-4 shadow-sm">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Live GPS tracking</p>
          <h3 className="mt-2 text-lg font-semibold">{statusCfg.emoji} {statusCfg.label}</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            {session.eta_minutes != null ? `ETA ${session.eta_minutes} min` : "ETA updates will appear here."}
          </p>
        </div>
        {onClose ? <button type="button" className="rounded-xl border px-3 py-2 text-sm" onClick={onClose}>Close</button> : null}
      </div>

      <LiveTrackingMap trackingId={trackingId} compact className="min-h-[320px]" />

      <div className="mt-4 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
        <span className="inline-flex items-center gap-2 rounded-full border px-3 py-1">
          <span className="h-2.5 w-2.5 rounded-full bg-primary animate-pulse" /> LIVE
        </span>
        {session.updated_at ? <span>Last update {new Date(session.updated_at).toLocaleTimeString()}</span> : null}
      </div>
    </section>
  );
}
