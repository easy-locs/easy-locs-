import type { DeliveryTimelineStepView } from "@/hooks/useDeliveryTimeline";

interface DeliveryStatusStepperProps {
  steps: DeliveryTimelineStepView[];
}

export default function DeliveryStatusStepper({ steps }: DeliveryStatusStepperProps) {
  return (
    <div className="space-y-3">
      {steps.map((step, index) => (
        <div key={`${step.key}-${index}`} className="flex gap-3">
          <div className="flex flex-col items-center">
            <div
              className={[
                "flex h-9 w-9 items-center justify-center rounded-full border text-xs font-semibold",
                step.status === "done" ? "border-primary bg-primary text-primary-foreground" : "",
                step.status === "current" ? "border-primary text-primary" : "",
                step.status === "issue" ? "border-destructive text-destructive" : "",
              ].join(" ")}
            >
              {step.status === "done" ? "✓" : index + 1}
            </div>
            {index < steps.length - 1 ? <div className="mt-2 h-8 w-px bg-border" /> : null}
          </div>
          <div className="pb-4">
            <p className="font-medium">{step.label}</p>
            <p className="text-xs uppercase tracking-wide text-muted-foreground">{step.status}</p>
            {step.timestamp ? (
              <p className="mt-1 text-xs text-muted-foreground">{new Date(step.timestamp).toLocaleString()}</p>
            ) : null}
            {step.hint ? <p className="mt-1 text-sm text-muted-foreground">{step.hint}</p> : null}
          </div>
        </div>
      ))}
    </div>
  );
}
