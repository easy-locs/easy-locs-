import { mapAutomationStatusLabel } from "@/lib/delivery-automation";
import { useDeliveryAutomation } from "@/hooks/useDeliveryAutomation";

interface DeliveryAutomationBadgeProps {
  jobId?: string | null;
  compact?: boolean;
}

export default function DeliveryAutomationBadge({ jobId, compact = false }: DeliveryAutomationBadgeProps) {
  const { snapshot, applyAutomation } = useDeliveryAutomation(jobId);

  if (!jobId) return null;

  return (
    <section className={`rounded-2xl border bg-card shadow-sm ${compact ? "p-3" : "p-4"}`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Automation</p>
          <h3 className="mt-1 text-base font-semibold">{mapAutomationStatusLabel(snapshot.derivedStatus)}</h3>
          <p className="mt-1 text-sm text-muted-foreground">{snapshot.suggestedAction}</p>
        </div>
        <button
          type="button"
          className="rounded-xl border px-3 py-2 text-sm font-medium"
          onClick={() => applyAutomation.mutate()}
          disabled={applyAutomation.isPending}
        >
          {applyAutomation.isPending ? "Applying…" : "Sync automation"}
        </button>
      </div>

      <div className="mt-3 flex flex-wrap gap-2 text-xs">
        {snapshot.etaMinutes != null ? <span className="rounded-full border px-3 py-1">ETA {snapshot.etaMinutes} min</span> : null}
        {snapshot.distanceMeters != null ? <span className="rounded-full border px-3 py-1">{Math.round(snapshot.distanceMeters)} m away</span> : null}
        {snapshot.shouldNotifyBuyer ? <span className="rounded-full border px-3 py-1">Notify buyer</span> : null}
        {snapshot.shouldNotifySeller ? <span className="rounded-full border px-3 py-1">Notify seller</span> : null}
        {snapshot.escrowReady ? <span className="rounded-full border px-3 py-1">Escrow ready</span> : null}
        {snapshot.autoReleaseReady ? <span className="rounded-full border px-3 py-1">Auto-release ready</span> : null}
      </div>
    </section>
  );
}
