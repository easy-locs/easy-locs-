import { useMemo } from "react";
import { haversineKm } from "@/lib/smart-delivery-core";

interface DeliveryMapProps {
  pickupLat?: number | null;
  pickupLng?: number | null;
  dropoffLat?: number | null;
  dropoffLng?: number | null;
  driverLat?: number | null;
  driverLng?: number | null;
  status?: string;
}

function buildProgress(status?: string) {
  switch (status) {
    case "accepted":
    case "on_route_to_pickup":
      return 20;
    case "picked_up":
      return 45;
    case "in_transit":
    case "on_route_to_dropoff":
      return 75;
    case "delivered":
    case "confirmed":
      return 92;
    case "released":
      return 100;
    default:
      return 10;
  }
}

export default function DeliveryMap({ pickupLat, pickupLng, dropoffLat, dropoffLng, driverLat, driverLng, status }: DeliveryMapProps) {
  const totalDistance = useMemo(() => {
    if ([pickupLat, pickupLng, dropoffLat, dropoffLng].every((value) => typeof value === "number")) {
      return haversineKm(pickupLat as number, pickupLng as number, dropoffLat as number, dropoffLng as number);
    }
    return 0;
  }, [dropoffLat, dropoffLng, pickupLat, pickupLng]);

  const driverGap = useMemo(() => {
    if ([driverLat, driverLng, dropoffLat, dropoffLng].every((value) => typeof value === "number")) {
      return haversineKm(driverLat as number, driverLng as number, dropoffLat as number, dropoffLng as number);
    }
    return null;
  }, [driverLat, driverLng, dropoffLat, dropoffLng]);

  const progress = buildProgress(status);

  return (
    <section className="rounded-2xl border bg-card p-4 shadow-sm">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold">Live delivery view</h2>
          <p className="text-sm text-muted-foreground">Simple map-style view for beginners. One glance shows where the order is.</p>
        </div>
        <span className="rounded-full border px-3 py-1 text-xs font-medium uppercase tracking-wide">{status ?? "pending"}</span>
      </div>

      <div className="mt-4 rounded-2xl border bg-muted/40 p-4">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>Pickup</span>
          <span>Driver</span>
          <span>Dropoff</span>
        </div>
        <div className="mt-3 relative">
          <div className="h-3 rounded-full bg-muted" />
          <div className="absolute left-0 top-0 h-3 rounded-full bg-primary transition-all" style={{ width: `${progress}%` }} />
          <div className="absolute left-0 top-1/2 h-5 w-5 -translate-y-1/2 rounded-full border-2 border-background bg-emerald-500" />
          <div className="absolute top-1/2 h-5 w-5 -translate-y-1/2 rounded-full border-2 border-background bg-primary transition-all" style={{ left: `calc(${progress}% - 10px)` }} />
          <div className="absolute right-0 top-1/2 h-5 w-5 -translate-y-1/2 rounded-full border-2 border-background bg-amber-500" />
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <div className="rounded-xl border bg-background p-3 text-sm">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Total route</p>
            <p className="mt-1 text-lg font-semibold">{totalDistance ? `${totalDistance.toFixed(1)} km` : "--"}</p>
          </div>
          <div className="rounded-xl border bg-background p-3 text-sm">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Driver to you</p>
            <p className="mt-1 text-lg font-semibold">{driverGap !== null ? `${driverGap.toFixed(1)} km` : "Live soon"}</p>
          </div>
          <div className="rounded-xl border bg-background p-3 text-sm">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">What to do</p>
            <p className="mt-1 text-sm font-medium">Keep your code ready and watch the final step.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
