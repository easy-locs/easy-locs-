import { useState } from "react";
import DeliveryDriverCard from "@/components/delivery/DeliveryDriverCard";
import DeliveryLiveTracker from "@/components/delivery/DeliveryLiveTracker";
import DeliveryAutomationBadge from "@/components/delivery/DeliveryAutomationBadge";
import DeliveryStatusStepper from "@/components/delivery/DeliveryStatusStepper";
import { useDeliveryTimeline } from "@/hooks/useDeliveryTimeline";

interface DeliveryTimelinePanelProps {
  jobId?: string | null;
  title?: string;
}

export default function DeliveryTimelinePanel({ jobId, title = "Delivery timeline" }: DeliveryTimelinePanelProps) {
  const [showTracking, setShowTracking] = useState(false);
  const { job, driver, steps, tracking, nextAction, isLoading } = useDeliveryTimeline(jobId);

  if (!jobId) {
    return (
      <section className="rounded-2xl border bg-card p-4 shadow-sm">
        <h3 className="text-lg font-semibold">{title}</h3>
        <p className="mt-2 text-sm text-muted-foreground">Select a delivery to see the timeline and driver details.</p>
      </section>
    );
  }

  return (
    <section className="space-y-4 rounded-2xl border bg-card p-4 shadow-sm">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-sm uppercase tracking-wide text-muted-foreground">{title}</p>
          <h3 className="mt-2 text-lg font-semibold">#{job?.order_id?.slice(0, 8) ?? jobId.slice(0, 8)}</h3>
          <p className="mt-1 text-sm text-muted-foreground">{nextAction}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {tracking.hasTracking ? (
            <button type="button" className="rounded-xl border px-4 py-2 text-sm font-medium" onClick={() => setShowTracking((value) => !value)}>
              {showTracking ? "Hide GPS" : "Open GPS"}
            </button>
          ) : null}
          {job?.status ? <span className="rounded-full border px-3 py-1 text-xs uppercase tracking-wide">{job.status}</span> : null}
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-[0.9fr_1.1fr]">
        <div className="space-y-4">
          <DeliveryDriverCard driver={driver} onOpenTracking={tracking.hasTracking ? () => setShowTracking(true) : undefined} />
          <DeliveryAutomationBadge jobId={jobId} compact />
        </div>
        <section className="rounded-2xl border p-4">
          <p className="text-sm uppercase tracking-wide text-muted-foreground">Progress</p>
          <div className="mt-4">
            <DeliveryStatusStepper steps={steps} />
          </div>
        </section>
      </div>

      {showTracking ? <DeliveryLiveTracker jobId={jobId} onClose={() => setShowTracking(false)} /> : null}
      {isLoading ? <p className="text-sm text-muted-foreground">Refreshing timeline…</p> : null}
    </section>
  );
}
