import { useMemo, useState } from "react";

interface DeliveryProofProps {
  onSubmitRating: (payload: { rating: number; note?: string }) => Promise<unknown> | void;
  onNeedHelp: (message: string) => Promise<unknown> | void;
  busy?: boolean;
}

export default function DeliveryProof({ onSubmitRating, onNeedHelp, busy }: DeliveryProofProps) {
  const [rating, setRating] = useState(5);
  const [note, setNote] = useState("");
  const [supportMessage, setSupportMessage] = useState("Driver late or package issue");
  const [photoName, setPhotoName] = useState<string | null>(null);

  const stars = useMemo(() => [1, 2, 3, 4, 5], []);

  return (
    <section className="rounded-2xl border bg-card p-4 shadow-sm">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold">Proof, rating & support</h2>
          <p className="text-sm text-muted-foreground">Simple post-delivery actions for non-technical users.</p>
        </div>
        <span className="rounded-full border px-3 py-1 text-xs">Beginner friendly</span>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border p-4">
          <h3 className="font-semibold">Upload proof photo</h3>
          <p className="mt-1 text-sm text-muted-foreground">Optional. Useful if the package arrived damaged or left at the door.</p>
          <label className="mt-4 flex cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed p-6 text-center text-sm text-muted-foreground">
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(event) => {
                const file = event.target.files?.[0] ?? null;
                setPhotoName(file?.name ?? null);
              }}
            />
            <span className="font-medium text-foreground">Choose delivery photo</span>
            <span className="mt-1">{photoName ?? "No file selected yet"}</span>
          </label>
        </div>

        <div className="rounded-2xl border p-4">
          <h3 className="font-semibold">Rate your driver</h3>
          <div className="mt-3 flex gap-2">
            {stars.map((star) => (
              <button
                key={star}
                type="button"
                className={`h-10 w-10 rounded-xl border text-lg ${star <= rating ? "bg-primary text-primary-foreground" : "bg-background"}`}
                onClick={() => setRating(star)}
              >
                ★
              </button>
            ))}
          </div>
          <textarea
            value={note}
            onChange={(event) => setNote(event.target.value)}
            placeholder="Short note about the delivery"
            className="mt-3 min-h-[100px] w-full rounded-xl border bg-background px-3 py-2 text-sm"
          />
          <button
            type="button"
            className="mt-3 rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
            disabled={busy}
            onClick={() => onSubmitRating({ rating, note: note.trim() || undefined })}
          >
            Save rating
          </button>
        </div>
      </div>

      <div className="mt-4 rounded-2xl border p-4">
        <h3 className="font-semibold">Need help?</h3>
        <p className="mt-1 text-sm text-muted-foreground">Open a simple support request in one line.</p>
        <div className="mt-3 flex flex-col gap-3 sm:flex-row">
          <input
            value={supportMessage}
            onChange={(event) => setSupportMessage(event.target.value)}
            className="w-full rounded-xl border bg-background px-3 py-2 text-sm"
            placeholder="Describe the issue"
          />
          <button
            type="button"
            className="rounded-xl border px-4 py-2 text-sm font-medium"
            disabled={busy || !supportMessage.trim()}
            onClick={() => onNeedHelp(supportMessage.trim())}
          >
            Request support
          </button>
        </div>
      </div>
    </section>
  );
}
