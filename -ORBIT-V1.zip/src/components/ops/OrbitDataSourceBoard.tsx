import { useOrbitLiveBridge } from "@/hooks/useOrbitLiveBridge";
import OrbitModuleConnectionCard from "@/components/ops/OrbitModuleConnectionCard";

export default function OrbitDataSourceBoard() {
  const report = useOrbitLiveBridge();

  return (
    <div className="space-y-6">
      <div className="grid gap-3 md:grid-cols-5">
        <StatCard label="Live bridge score" value={`${report.score}/100`} helper={report.status} />
        <StatCard label="Live modules" value={report.liveCount} helper="fully bound" />
        <StatCard label="Hybrid modules" value={report.hybridCount} helper="safe fallback" />
        <StatCard label="Mock modules" value={report.mockCount} helper="replace next" />
        <StatCard label="Missing modules" value={report.missingCount} helper="still empty" />
      </div>

      {report.nextPriority ? (
        <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4">
          <div className="text-sm text-muted-foreground">Main v2 priority</div>
          <div className="text-lg font-semibold">{report.nextPriority.label}</div>
          <div className="mt-1 text-sm text-muted-foreground">{report.nextPriority.nextAction}</div>
        </div>
      ) : null}

      <div className="grid gap-4 lg:grid-cols-2">
        {report.modules.map((module) => (
          <OrbitModuleConnectionCard key={module.key} module={module} />
        ))}
      </div>
    </div>
  );
}

function StatCard({ label, value, helper }: { label: string; value: string | number; helper: string }) {
  return (
    <div className="rounded-2xl border bg-background p-4 shadow-sm">
      <div className="text-sm text-muted-foreground">{label}</div>
      <div className="mt-1 text-2xl font-semibold">{value}</div>
      <div className="mt-1 text-xs text-muted-foreground capitalize">{helper}</div>
    </div>
  );
}
