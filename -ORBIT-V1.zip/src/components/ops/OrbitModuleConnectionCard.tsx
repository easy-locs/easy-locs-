import type { OrbitModuleConnection } from "@/lib/orbit-live-bridge";
import { Link } from "react-router-dom";

const SOURCE_STYLES: Record<OrbitModuleConnection["source"], string> = {
  live: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
  hybrid: "bg-amber-500/10 text-amber-600 border-amber-500/20",
  mock: "bg-sky-500/10 text-sky-600 border-sky-500/20",
  missing: "bg-rose-500/10 text-rose-600 border-rose-500/20",
};

export default function OrbitModuleConnectionCard({ module }: { module: OrbitModuleConnection }) {
  const pct = module.total > 0 ? Math.round((module.bound / module.total) * 100) : 0;
  return (
    <div className="rounded-2xl border bg-background p-4 shadow-sm space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-sm text-muted-foreground">{module.key}</div>
          <h3 className="text-lg font-semibold">{module.label}</h3>
        </div>
        <span className={`rounded-full border px-2.5 py-1 text-xs font-medium capitalize ${SOURCE_STYLES[module.source]}`}>
          {module.source}
        </span>
      </div>

      <div className="space-y-1">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Binding progress</span>
          <span className="font-medium">{module.bound}/{module.total} · {pct}%</span>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden">
          <div className="h-full rounded-full bg-primary" style={{ width: `${pct}%` }} />
        </div>
      </div>

      <p className="text-sm text-muted-foreground leading-6">{module.note}</p>

      <div className="rounded-xl bg-muted/40 p-3 text-sm">
        <div className="font-medium mb-1">Next clean step</div>
        <div className="text-muted-foreground">{module.nextAction}</div>
      </div>

      {module.route ? (
        <Link to={module.route} className="inline-flex text-sm font-medium text-primary hover:underline">
          Open module
        </Link>
      ) : null}
    </div>
  );
}
