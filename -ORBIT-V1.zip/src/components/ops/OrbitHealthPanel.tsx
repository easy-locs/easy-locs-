import { Link } from "react-router-dom";
import { getHardeningTone, type OrbitHardeningReport } from "@/lib/orbit-hardening";

const ROUTES: Record<string, string> = {
  storefront: "/business/studio",
  checkout: "/shop/pizza-times-marina/checkout",
  geo: "/business/shop-geo",
  translation: "/business/shop-translation",
  analytics: "/business/analytics",
  discovery: "/discover",
  search: "/search",
  deals: "/deal/demo-pizza-times-marina",
  security: "/business/shop-access",
};

export default function OrbitHealthPanel({ report }: { report: OrbitHardeningReport }) {
  return (
    <section className="rounded-3xl border border-border bg-card p-5 shadow-sm">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <div className="text-xs font-semibold uppercase tracking-[0.25em] text-muted-foreground">V1 hardening</div>
          <h2 className="mt-2 text-2xl font-semibold tracking-tight">{report.score}/100 · {getHardeningTone(report.status)}</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {report.readyCount} blocks validated, {report.watchCount} to review, {report.criticalCount} critical items.
          </p>
        </div>
        <div className="grid grid-cols-3 gap-3 text-center">
          <div className="rounded-2xl border border-border bg-background/70 px-4 py-3">
            <div className="text-xs uppercase tracking-wide text-muted-foreground">Ready</div>
            <div className="mt-1 text-xl font-semibold">{report.readyCount}</div>
          </div>
          <div className="rounded-2xl border border-amber-500/30 bg-amber-500/5 px-4 py-3">
            <div className="text-xs uppercase tracking-wide text-amber-700">Watch</div>
            <div className="mt-1 text-xl font-semibold text-amber-700">{report.watchCount}</div>
          </div>
          <div className="rounded-2xl border border-destructive/30 bg-destructive/5 px-4 py-3">
            <div className="text-xs uppercase tracking-wide text-destructive">Critical</div>
            <div className="mt-1 text-xl font-semibold text-destructive">{report.criticalCount}</div>
          </div>
        </div>
      </div>

      <div className="mt-5 grid gap-3 xl:grid-cols-2">
        {report.checks.map((check) => (
          <div key={check.key} className="rounded-2xl border border-border bg-background/70 p-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="font-medium">{check.label}</div>
                <div className="mt-1 text-sm text-muted-foreground">{check.detail}</div>
              </div>
              <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${check.ready ? "bg-emerald-500/10 text-emerald-600" : check.severity === "critical" ? "bg-destructive/10 text-destructive" : "bg-amber-500/10 text-amber-700"}`}>
                {check.ready ? "Ready" : check.severity === "critical" ? "Critical" : "Watch"}
              </span>
            </div>
            {!check.ready && (
              <div className="mt-3 flex flex-wrap items-center gap-3 text-sm">
                {check.recommendation && <span className="text-muted-foreground">{check.recommendation}</span>}
                <Link to={ROUTES[check.key] || "/business/launchpad"} className="font-medium text-primary">
                  Open related area
                </Link>
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
