import { Link } from "react-router-dom";
import { getReadinessTone, type OrbitReadinessReport } from "@/lib/orbit-readiness";

const ACTION_LINKS: Record<string, string> = {
  "Open business studio": "/business/studio",
  "Add catalog items": "/business/studio",
  "Open checkout flow": "/shop/pizza-times-marina/checkout",
  "Open share studio": "/business/shop-share",
  "Configure geo scope": "/business/shop-geo",
  "Open translation studio": "/business/shop-translation",
  "Open analytics": "/business/analytics",
  "Open access studio": "/business/shop-access",
  "Open deal room": "/deal/demo-pizza-times-marina",
};

export default function OrbitLaunchChecklist({ report }: { report: OrbitReadinessReport }) {
  return (
    <section className="rounded-3xl border border-border bg-card p-5 shadow-sm">
      <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <div>
          <div className="text-xs font-semibold uppercase tracking-[0.25em] text-muted-foreground">Launch readiness</div>
          <h2 className="mt-2 text-2xl font-semibold tracking-tight">{report.score}/100 · {getReadinessTone(report.status)}</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {report.completed} of {report.total} core blocks are ready for a clean public business launch.
          </p>
        </div>
        {report.nextPriority && (
          <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4 text-sm md:max-w-sm">
            <div className="font-medium">Next best move</div>
            <div className="mt-1">{report.nextPriority.label}</div>
            <div className="mt-1 text-muted-foreground">{report.nextPriority.detail}</div>
            <Link to={ACTION_LINKS[report.nextPriority.action] || "/business/studio"} className="mt-3 inline-flex rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
              {report.nextPriority.action}
            </Link>
          </div>
        )}
      </div>

      <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {report.items.map((item) => (
          <div key={item.key} className="rounded-2xl border border-border bg-background/70 p-4">
            <div className="flex items-center justify-between gap-3">
              <div className="font-medium">{item.label}</div>
              <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${item.done ? "bg-emerald-500/10 text-emerald-600" : "bg-amber-500/10 text-amber-600"}`}>
                {item.done ? "Ready" : "Pending"}
              </span>
            </div>
            <div className="mt-2 text-sm text-muted-foreground">{item.detail}</div>
            {!item.done && (
              <Link to={ACTION_LINKS[item.action] || "/business/studio"} className="mt-3 inline-flex text-xs font-medium text-primary">
                {item.action}
              </Link>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
