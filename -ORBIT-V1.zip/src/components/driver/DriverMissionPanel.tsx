import type { RankedDriver } from "@/lib/delivery-dispatch";

interface DriverMissionPanelProps {
  mission: {
    id: string;
    pickupLabel?: string;
    dropoffLabel?: string;
    estimatedEarningsAed?: number;
  };
  ranking?: RankedDriver | null;
  onAccept?: () => void;
  onReject?: () => void;
  disabled?: boolean;
}

export default function DriverMissionPanel({ mission, ranking, onAccept, onReject, disabled }: DriverMissionPanelProps) {
  return (
    <section className="rounded-2xl border bg-card p-4 shadow-sm" aria-label="Incoming delivery mission">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Incoming mission</p>
          <h3 className="text-lg font-semibold">Delivery #{mission.id.slice(0, 8)}</h3>
        </div>
        {ranking ? (
          <span className="rounded-full border px-2 py-1 text-xs text-muted-foreground">
            ETA {ranking.pickupEtaMinutes} min
          </span>
        ) : null}
      </div>

      <div className="mt-4 grid gap-2 text-sm">
        <p><span className="font-medium">Pickup:</span> {mission.pickupLabel ?? "Seller pickup point"}</p>
        <p><span className="font-medium">Dropoff:</span> {mission.dropoffLabel ?? "Customer destination"}</p>
        <p><span className="font-medium">Distance:</span> {ranking?.distanceKm ?? "--"} km</p>
        <p><span className="font-medium">Estimated earnings:</span> {mission.estimatedEarningsAed ?? "--"} AED</p>
      </div>

      <div className="mt-4 flex gap-2">
        <button
          type="button"
          className="rounded-xl bg-primary px-4 py-2 text-primary-foreground disabled:opacity-50"
          onClick={onAccept}
          disabled={disabled}
        >
          Accept
        </button>
        <button
          type="button"
          className="rounded-xl border px-4 py-2 disabled:opacity-50"
          onClick={onReject}
          disabled={disabled}
        >
          Reject
        </button>
      </div>
    </section>
  );
}
