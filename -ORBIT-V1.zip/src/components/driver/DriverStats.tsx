interface DriverStatsProps {
  stats: Array<{ label: string; value: string; hint?: string }>;
}

export default function DriverStats({ stats }: DriverStatsProps) {
  return (
    <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4" aria-label="Driver performance stats">
      {stats.map((stat) => (
        <article key={stat.label} className="rounded-2xl border bg-card p-4 shadow-sm">
          <p className="text-sm text-muted-foreground">{stat.label}</p>
          <p className="mt-1 text-2xl font-semibold">{stat.value}</p>
          {stat.hint ? <p className="mt-1 text-xs text-muted-foreground">{stat.hint}</p> : null}
        </article>
      ))}
    </section>
  );
}
