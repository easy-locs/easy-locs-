import type { DriverMissionItem } from "@/hooks/useDriverMissions";

interface DriverMapProps {
  currentLat?: number | null;
  currentLng?: number | null;
  missions: DriverMissionItem[];
}

function dotStyle(left: number, top: number) {
  return { left: `${left}%`, top: `${top}%` };
}

export default function DriverMap({ currentLat, currentLng, missions }: DriverMapProps) {
  const activeMissions = missions.slice(0, 4);

  return (
    <section className="rounded-2xl border bg-card p-4 shadow-sm" aria-label="Driver operations map">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold">Operations map</h2>
          <p className="text-sm text-muted-foreground">Live location, recent mission points, and demand hotspots.</p>
        </div>
        <span className="rounded-full border px-2 py-1 text-xs text-muted-foreground">Dubai ops</span>
      </div>

      <div className="relative mt-4 h-72 overflow-hidden rounded-2xl border bg-[radial-gradient(circle_at_top,_rgba(59,130,246,0.12),transparent_35%),linear-gradient(180deg,rgba(15,23,42,0.04),rgba(15,23,42,0.02))]">
        <div className="absolute inset-0 opacity-60" style={{ backgroundImage: "linear-gradient(to right, rgba(100,116,139,0.18) 1px, transparent 1px), linear-gradient(to bottom, rgba(100,116,139,0.18) 1px, transparent 1px)", backgroundSize: "48px 48px" }} />

        <div className="absolute left-[20%] top-[18%] rounded-full bg-amber-400/20 px-3 py-1 text-xs font-medium text-amber-700">Business Bay</div>
        <div className="absolute left-[63%] top-[28%] rounded-full bg-emerald-400/20 px-3 py-1 text-xs font-medium text-emerald-700">JLT / Marina</div>
        <div className="absolute left-[72%] top-[58%] rounded-full bg-rose-400/20 px-3 py-1 text-xs font-medium text-rose-700">Jumeirah</div>

        <div className="absolute h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full border-4 border-primary bg-primary/20 shadow" style={dotStyle(48, 48)} title={currentLat && currentLng ? `${currentLat.toFixed(4)}, ${currentLng.toFixed(4)}` : "Driver current position"} />

        {activeMissions.map((mission, index) => (
          <div
            key={mission.id}
            className="absolute h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-foreground/80"
            style={dotStyle(30 + index * 14, 30 + (index % 2) * 24)}
            title={`Mission ${mission.id}`}
          />
        ))}
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-3 text-sm">
        <div className="rounded-xl border p-3">
          <p className="font-medium">Current position</p>
          <p className="mt-1 text-muted-foreground">{currentLat && currentLng ? `${currentLat.toFixed(4)}, ${currentLng.toFixed(4)}` : "Location not shared yet"}</p>
        </div>
        <div className="rounded-xl border p-3">
          <p className="font-medium">Hot zone</p>
          <p className="mt-1 text-muted-foreground">Business Bay lunch rush • 12:00–15:00</p>
        </div>
        <div className="rounded-xl border p-3">
          <p className="font-medium">Suggested coverage</p>
          <p className="mt-1 text-muted-foreground">JLT / Marina tonight for higher basket orders</p>
        </div>
      </div>
    </section>
  );
}
