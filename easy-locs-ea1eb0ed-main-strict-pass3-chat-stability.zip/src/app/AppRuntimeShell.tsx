import type { ReactNode } from "react";
import { UiQualityProvider } from "@/providers/UiQualityProvider";
import UpdateNotification from "@/components/UpdateNotification";
import { AppInit } from "@/components/system/AppInit";
import { CanonicalShellRuntime } from "@/components/app/CanonicalShellRuntime";
import AppBootstrapGuardDirect from "@/components/app/AppBootstrapGuard";
import { GeoBoot } from "@/lib/geo/GeoBoot";
import { GeoDebugPanel } from "@/components/debug/GeoDebugPanel";
import { PermissionBootstrap } from "@/components/boot/PermissionBootstrap";
import { SkipLink } from "@/components/ui/a11y";
import MainBottomNav from "@/components/navigation/MainBottomNav";
import SmartInstallBanner from "@/components/pwa/SmartInstallBanner";
import { FloatingCTAButton } from "@/components/engine/FloatingCTAButton";
import { OrbitPromptOverlay } from "@/components/engine/OrbitPromptOverlay";
import SmartCloseFlowSheet from "@/components/close-flow/SmartCloseFlowSheet";
import { OrbitSessionGuard, RealtimeHubGuard, NotificationsRealtimeGuard, AppHealthGuard } from "@/components/app/AppGuards";

export function AppRuntimeShell({ children }: { children: ReactNode }) {
  return (
    <>
      <AppHealthGuard />
      <OrbitSessionGuard />
      <RealtimeHubGuard />
      <NotificationsRealtimeGuard />
      <UpdateNotification />
      <AppInit />
      <CanonicalShellRuntime />
      <UiQualityProvider>
        <GeoBoot />
        <GeoDebugPanel />
        <PermissionBootstrap />
        <AppBootstrapGuardDirect />
        <SkipLink />
        {children}
        <MainBottomNav />
        <SmartInstallBanner />
        <FloatingCTAButton />
        <OrbitPromptOverlay />
        <SmartCloseFlowSheet />
      </UiQualityProvider>
    </>
  );
}
