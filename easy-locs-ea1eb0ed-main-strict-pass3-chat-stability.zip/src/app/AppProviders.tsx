import type { ReactNode } from "react";
import { ThemeProvider } from "next-themes";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { I18nProvider } from "@/lib/i18n";
import { GlobalExperienceProvider } from "@/providers/GlobalExperienceProvider";
import BrowserTelemetryProvider from "@/components/system/BrowserTelemetryProvider";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { AuthProvider } from "@/contexts/AuthContext";
import { CallProvider } from "@/components/call/CallProvider";
import { UnifiedPaymentProvider } from "@/payments/UnifiedPaymentSystem";
import AppLockGuard from "@/components/security/AppLockGuard";
import SplashScreen from "@/components/brand/SplashScreen";
import BrandSuccessFlash from "@/components/brand/BrandSuccessFlash";
import { AppCrashBoundary } from "@/components/system/AppCrashBoundary";
import ChunkRecoveryBoundary from "@/components/system/ChunkRecoveryBoundary";
import ErrorBoundary from "@/components/ErrorBoundary";

interface AppProvidersProps {
  queryClient: QueryClient;
  children: ReactNode;
}

export function AppProviders({ queryClient, children }: AppProvidersProps) {
  return (
    <AppCrashBoundary>
      <ChunkRecoveryBoundary>
        <ErrorBoundary>
          <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange={false} storageKey="easylocs-theme">
            <QueryClientProvider client={queryClient}>
              <I18nProvider>
                <GlobalExperienceProvider>
                  <BrowserTelemetryProvider>
                    <TooltipProvider>
                      <Toaster />
                      <Sonner />
                      <AuthProvider>
                        <CallProvider>
                          <UnifiedPaymentProvider>
                            <AppLockGuard>
                              <SplashScreen>
                                <BrandSuccessFlash />
                                {children}
                              </SplashScreen>
                            </AppLockGuard>
                          </UnifiedPaymentProvider>
                        </CallProvider>
                      </AuthProvider>
                    </TooltipProvider>
                  </BrowserTelemetryProvider>
                </GlobalExperienceProvider>
              </I18nProvider>
            </QueryClientProvider>
          </ThemeProvider>
        </ErrorBoundary>
      </ChunkRecoveryBoundary>
    </AppCrashBoundary>
  );
}
