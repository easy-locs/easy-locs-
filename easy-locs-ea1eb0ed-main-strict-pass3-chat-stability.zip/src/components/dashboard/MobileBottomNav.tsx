/**
 * MobileBottomNav — V7 Bottom navigation with 5 pillars.
 * Dashboard · Radar · Orbit (center) · Wallet · Me
 * NOTE: MainBottomNav is the canonical nav. This is kept for backward compat.
 */
import { NavLink, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Home, Radar, MessageCircle, Wallet, User } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { ROUTE_ALIASES, ROUTE_PATHS, VERTICAL_ROUTE_MAP, pathStartsWith } from "@/lib/routes";

const FALLBACKS: Record<string, string> = {
  "nav.home": "Home",
  "nav.radar": "Radar",
  "nav.orbit": "Orbit",
  "nav.wallet": "Wallet",
  "nav.me": "Me",
};

const MobileBottomNav = () => {
  const { pathname } = useLocation();
  const { t } = useI18n();

  if (pathname.startsWith("/app")) return null;

  const tr = (key: string) => {
    const val = t(key);
    return val && val !== key ? val : FALLBACKS[key] || key.split(".").pop() || "";
  };

  const items = [
    {
      icon: Home, labelKey: "nav.home", path: ROUTE_PATHS.home,
      match: (p: string) => p === ROUTE_PATHS.home,
    },
    {
      icon: Radar, labelKey: "nav.radar", path: ROUTE_PATHS.radar,
      match: (p: string) =>
        p === ROUTE_PATHS.radar || pathStartsWith(p, ROUTE_ALIASES.radar) ||
        p.startsWith("/listing/") || p.startsWith("/s/") ||
        pathStartsWith(p, [VERTICAL_ROUTE_MAP.food, VERTICAL_ROUTE_MAP.grocery, VERTICAL_ROUTE_MAP.shops]),
    },
    {
      icon: MessageCircle, labelKey: "nav.orbit", path: ROUTE_PATHS.orbit,
      match: (p: string) =>
        p.startsWith(ROUTE_PATHS.orbit) || pathStartsWith(p, ROUTE_ALIASES.orbit),
      isCenter: true,
    },
    {
      icon: Wallet, labelKey: "nav.wallet", path: ROUTE_PATHS.walletHub,
      match: (p: string) =>
        p.startsWith("/wallet") || p === ROUTE_PATHS.pos || p === ROUTE_PATHS.orders ||
        p.startsWith(ROUTE_PATHS.dashboard.wallet),
    },
    {
      icon: User, labelKey: "nav.me", path: ROUTE_PATHS.me,
      match: (p: string) =>
        p === ROUTE_PATHS.me || p.startsWith("/dashboard/settings") || pathStartsWith(p, ROUTE_ALIASES.me),
    },
  ];

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-40 lg:hidden safe-bottom"
      role="tablist"
      aria-label="Main navigation"
      style={{
        background: "hsl(var(--card))",
        borderTop: "1px solid hsl(var(--border) / 0.3)",
        paddingBottom: "env(safe-area-inset-bottom, 0px)",
        boxShadow: "0 -2px 16px hsl(var(--background) / 0.3)",
      }}
    >
      <div className="flex items-stretch justify-around h-[60px]">
        {items.map((item) => {
          const active = item.match(pathname);
          const label = tr(item.labelKey);
          const isCenter = (item as any).isCenter;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              role="tab"
              aria-selected={active}
              aria-label={label}
              className={`flex flex-col items-center justify-center flex-1 gap-1 transition-all min-w-[44px] min-h-[44px] max-w-[80px] active:bg-muted/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-lg relative ${
                active ? "text-accent" : "text-muted-foreground"
              }`}
            >
              {active && !isCenter && (
                <motion.div
                  layoutId="v7-tab-indicator"
                  className="absolute top-0 left-3 right-3 h-[2.5px] rounded-full bg-accent"
                  transition={{ type: "spring", stiffness: 400, damping: 30 }}
                />
              )}
              {isCenter ? (
                <div className={`w-10 h-10 rounded-full flex items-center justify-center -mt-3 ${active ? "bg-accent" : "bg-accent/15"}`}>
                  <item.icon className={`h-5 w-5 shrink-0 ${active ? "text-accent-foreground" : "text-accent"}`} />
                </div>
              ) : (
                <item.icon className={`h-5 w-5 shrink-0 transition-colors ${active ? "text-accent" : ""}`} />
              )}
              <span className={`text-[10px] leading-tight transition-colors ${active ? "text-accent font-bold" : "font-medium"}`}>
                {label}
              </span>
            </NavLink>
          );
        })}
      </div>
    </nav>
  );
};

export default MobileBottomNav;
