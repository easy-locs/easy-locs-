/**
 * HudChatPanel — Thread Shell.
 * Thin assembly layer that composes canonical family hooks.
 * Contains NO business logic — only wiring.
 */
import { useCallback, useEffect, useMemo, useState } from "react";
import { Loader2 } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { toast } from "sonner";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { supabase } from "@/integrations/supabase/client";

// ── Canonical families ──
import { useAuth } from "@/families/auth";
import { useResolveAuthUserId } from "@/families/auth";
import { useOrbitIdentity } from "@/families/identity";
import { useOrbitEncryption } from "@/hooks/useOrbitEncryption";
import { useOfflineMessages } from "@/hooks/useOfflineMessages";
import { usePrivacySettings } from "@/hooks/usePrivacySettings";

import type { ConversationThread } from "./types";

// Canonical family hooks
import { useThreadCallFamily } from "@/hooks/orbit/families/useThreadCallFamily";
import { useThreadAttachmentFamily } from "@/hooks/orbit/families/useThreadAttachmentFamily";
import { useThreadComposerFamily } from "@/hooks/orbit/families/useThreadComposerFamily";
import { useThreadMessageFamily } from "@/hooks/orbit/families/useThreadMessageFamily";

// Canonical UI components (presentational)
import ChatHeader from "./chat/ChatHeader";
import ChatEmptyState from "./chat/ChatEmptyState";
import MessageList from "./chat/MessageList";
import MessageComposer from "@/components/orbit/MessageComposer";
import MessageContextMenu from "./MessageContextMenu";
import MessageMultiSelectToolbar from "./MessageMultiSelect";
import DealContextHeader from "./DealContextHeader";
import ChatLocationPicker from "./ChatLocationPicker";
import ForwardMessageDialog from "@/components/communication/ForwardMessageDialog";
import OrbitSafetyNumber from "@/components/orbit/OrbitSafetyNumber";
import OrbitSelectionToolbar from "@/components/orbit/OrbitSelectionToolbar";
import { useOrbitComposerStore } from "@/stores/orbit/composer.store";
import { useOrbitSelectionStore } from "@/stores/orbit/selection.store";
import OrbitSecurityPanel from "@/components/orbit/OrbitSecurityPanel";
import OrbitSmartPayment, { type PaymentConfirmation } from "@/components/orbit/payments/OrbitSmartPayment";
import { RequestMoneyModal } from "@/components/chat/RequestMoneyModal";
import { sendPaymentRequestMessageToThread, sendPaymentReceiptToThread } from "@/components/chat/ChatPaymentCards";
import { OrbitPinnedBanner } from "@/components/orbit/OrbitPinnedBanner";
import { OrbitJumpToBottomButton } from "@/components/orbit/OrbitJumpToBottomButton";
import { OrbitIncomingCallBar } from "@/components/orbit/OrbitIncomingCallBar";
import { OrbitCallControls } from "@/components/orbit/OrbitCallControls";
import { OrbitCallMiniPlayer } from "@/components/orbit/OrbitCallMiniPlayer";
import { OrbitCallPermissionBanner } from "@/components/orbit/OrbitCallPermissionBanner";
import { LocationViewerOverlay } from "@/components/communication-hub/chat/LocationViewerOverlay";
import { OrbitUploadQueuePreview } from "@/components/orbit/OrbitUploadQueuePreview";
import { OrbitAttachmentViewer } from "@/components/orbit/OrbitAttachmentViewer";
import { MediaPreviewSheet } from "@/components/orbit/MediaPreviewSheet";
import { FullscreenMediaViewer } from "@/components/orbit/FullscreenMediaViewer";
import { useMediaPreviewState } from "@/families/media/media-preview-state";
import { useMediaPreviewSend } from "@/hooks/orbit/useMediaPreviewSend";
import { ContactProfileSheet } from "@/components/orbit/ContactProfileSheet";
import { MultiPhotoSelect } from "@/components/orbit/MultiPhotoSelect";

import { useSecurityDialogs } from "./chat/useSecurityDialogs";
import { usePaymentDialogs } from "@/hooks/usePaymentDialogs";
import { useHudConversationStatus } from "@/hooks/orbit/useHudConversationStatus";
import { useHudBookingActions } from "@/hooks/orbit/useHudBookingActions";
import { useHudConversationResolver } from "@/hooks/orbit/useHudConversationResolver";

interface Props {
  thread: ConversationThread | null;
  onBack: () => void;
  onToggleContext: () => void;
  showContext: boolean;
  onThreadUpdate: (threadId: string, updates: Partial<ConversationThread>) => void;
}

export default function HudChatPanel({ thread, onBack, onToggleContext, onThreadUpdate }: Props) {
  const { user, orgId } = useAuth();
  const { t, locale } = useI18n();
  const myOrbitId = useOrbitIdentity()?.orbitId ?? null;
  const { ready: e2eReady, encrypt, decrypt } = useOrbitEncryption(user?.id);
  const offline = useOfflineMessages({ userId: user?.id, orgId: orgId || undefined, threadId: thread?.id });
  const { settings: privacySettings } = usePrivacySettings();

  const security = useSecurityDialogs();
  const currentConversationId = thread?.conversationId || thread?.id || "";
  const [showContactProfile, setShowContactProfile] = useState(false);
  const [showMultiPhoto, setShowMultiPhoto] = useState(false);
  const [peerProfileCreatedAt, setPeerProfileCreatedAt] = useState<string | null>(null);
  const peerProfileCacheRef = useMemo(() => ({ lastPeerId: null as string | null }), []);

  // ── Fetch peer profile created_at for "member since" (cached, error-safe) ──
  useEffect(() => {
    const peerId = thread?.peerUserId || null;
    if (!peerId) { setPeerProfileCreatedAt(null); return; }
    // Skip refetch if same peer
    if (peerProfileCacheRef.lastPeerId === peerId) return;
    peerProfileCacheRef.lastPeerId = peerId;

    supabase.from("profiles").select("created_at").eq("id", peerId).maybeSingle()
      .then(({ data, error }) => {
        if (error) {
          console.warn("[HudChatPanel] profile fetch error:", error.message);
          setPeerProfileCreatedAt(null);
          return;
        }
        setPeerProfileCreatedAt(data?.created_at ?? null);
      });
  }, [thread?.peerUserId]);

  const contactProfileEntity = useMemo(() => {
    if (!thread) return null;
    return {
      display_name: thread.name,
      email: thread.email,
      avatar_url: thread.avatarUrl,
      phone: (thread as any).phone || null,
      user_id: thread.peerUserId || null,
      orbit_id: thread.peerOrbitId || null,
      created_at: peerProfileCreatedAt,
    };
  }, [thread?.name, thread?.email, thread?.avatarUrl, thread?.peerUserId, thread?.peerOrbitId, peerProfileCreatedAt]);

  // ── Sync stores to active conversation ──
  const setActiveConversation = useOrbitComposerStore((s) => s.setActiveConversation);
  const globalSelectionMode = useOrbitSelectionStore((s) => s.mode);
  const globalSelectionConvId = useOrbitSelectionStore((s) => s.conversationId);
  const clearGlobalSelection = useOrbitSelectionStore((s) => s.clearSelection);

  useEffect(() => {
    setActiveConversation(currentConversationId || null);
    // Clear selection if switching to a different conversation
    if (globalSelectionConvId && globalSelectionConvId !== currentConversationId) {
      clearGlobalSelection();
    }
  }, [currentConversationId]);

  // ── Identity resolver (canonical family) ──
  const resolveAuthUserId = useResolveAuthUserId(t);
  const { resolveConversationId } = useHudConversationResolver({
    thread,
    myOrbitId,
    onThreadUpdate,
    t,
  });

  // ── FAMILY: Messages ──
  const msgFamily = useThreadMessageFamily({
    thread, orgId: orgId || null, userId: user?.id, myOrbitId, locale,
    e2eReady, encrypt, decrypt, offline, privacySettings,
    disappearTTL: security.disappearTTL,
    securityLevel: security.securityLevel as string,
    setSecurityLevel: security.setSecurityLevel as (l: string) => void,
    resolveAuthUserId, onThreadUpdate,
  });

  // ── FAMILY: Attachments ──
  const attFamily = useThreadAttachmentFamily({
    thread, orgId: orgId || null, userId: user?.id, myOrbitId, locale,
    e2eReady, encrypt, resolveAuthUserId, onThreadUpdate,
    onAfterSend: () => msgFamily.loader.loadMessages(),
  });

  // ── FAMILY: Composer (store-backed draft) ──
  const composerStore = useOrbitComposerStore();
  const storeDraft = composerStore.getDraft(currentConversationId);
  const setStoreDraft = useCallback((v: string) => composerStore.setDraft(currentConversationId, v), [composerStore, currentConversationId]);

  const compFamily = useThreadComposerFamily({
    thread, orgId: orgId || null, userId: user?.id, myOrbitId,
    e2eReady, encrypt, resolveAuthUserId, resolveConversationId,
    setUploading: attFamily.attachments.setUploading,
    disappearTTL: security.disappearTTL,
    defaultDisappearTtl: privacySettings.defaultDisappearTtl,
    setSecurityLevel: security.setSecurityLevel as (l: string) => void,
    setViewOnceNext: security.setViewOnceNext,
    setShowLocationPicker: security.setShowLocationPicker,
    setNewMessage: setStoreDraft,
    setRawMessages: msgFamily.loader.setRawMessages as any,
    t,
  });

  // ── FAMILY: Calls ──
  const callFamily = useThreadCallFamily({
    thread, currentUserId: user?.id ?? null, currentOrbitId: myOrbitId,
  });

  // ── FAMILY: Media Preview Send ──
  const mediaPreviewSend = useMediaPreviewSend({
    conversationId: thread?.conversationId ?? null,
    userId: user?.id,
    myOrbitId,
    peerOrbitId: thread?.peerOrbitId ?? null,
    orgId: orgId || null,
    resolveConversationId,
  });

  // ── FAMILY: Payments ──
  const payment = usePaymentDialogs({ thread, orgId, locale, resolveAuthUserId });

  // ── Thread-level helpers ──
  const { updateConversationStatus } = useHudConversationStatus(
    thread, msgFamily.loader.setConvStatus, onThreadUpdate
  );
  const { handleBookingAction } = useHudBookingActions(
    thread, orgId, user?.id, myOrbitId, onThreadUpdate
  );

  // ── Short aliases ──
  const { selection, messages, loader, messageSender, messageActions, threadUi, pinnedMessage } = msgFamily;

  // ── Stable callbacks (prevent rerender cascade) ──
  const stableContextMenu = useCallback((_: any, msg: any, isMe: boolean) => {
    selection.setContextMessage({
      msgId: msg.id,
      content: msg.content,
      isMe,
      createdAt: msg.created_at,
      hasAudio: !!(msg as any).audio_url,
      hasAttachment: !!msg.attachment_url,
      senderId: msg.sender_id,
      canModerate: false,
      isStarred: !!(msg as any).starred,
    });
  }, [selection.setContextMessage]);

  const stableHandleSend = useCallback(async () => {
    // ── ANTI-DOUBLE-TAP: check store lock FIRST ──
    if (composerStore.sending[currentConversationId]) return;

    const draft = composerStore.getDraft(currentConversationId);

    // ── EDIT MODE: read from composerStore (single source of truth) ──
    const activeEdit = composerStore.edits[currentConversationId];
    if (activeEdit) {
      composerStore.setSending(currentConversationId, true);
      try {
        await messageActions.editMessage(activeEdit.messageId, draft.trim());
        composerStore.clearAfterSend(currentConversationId);
      } finally {
        composerStore.setSending(currentConversationId, false);
      }
      return;
    }

    if (!draft.trim()) return;

    // ── LOCK + CLEAR immediately — before any async work ──
    composerStore.setSending(currentConversationId, true);
    composerStore.clearDraft(currentConversationId);
    composerStore.clearReply(currentConversationId);

    try {
      await messageSender.handleSend(draft);
    } finally {
      composerStore.setSending(currentConversationId, false);
    }
  }, [messageActions, messageSender, composerStore, currentConversationId]);

  if (!thread) return <ChatEmptyState t={t} />;

  return (
    <>
      <div className="flex-1 min-h-0 flex flex-col overflow-hidden" style={{ background: "hsl(var(--hud-bg))" }}>
        {/* ── HEADER FAMILY ── */}
        <ChatHeader
          thread={thread}
          convStatus={loader.convStatus}
          e2eReady={e2eReady}
          isInCall={callFamily.callState.hasActiveCall}
          isStartingCall={callFamily.callActions.busy}
          onBack={onBack}
          onStartCall={(isVideo) => void (isVideo ? callFamily.handleStartVideoCall() : callFamily.handleStartAudioCall())}
          onUpdateStatus={updateConversationStatus}
          onToggleContext={onToggleContext}
          onShowSecurityPanel={() => security.setShowSecurityPanel(true)}
          onShowSafetyNumber={() => security.setShowSafetyNumber(true)}
          onEnterSelectMode={() => { selection.clearSelection(); }}
          onAvatarTap={() => setShowContactProfile(true)}
          t={t}
        />

        <DealContextHeader dealId={thread.dealId} contextType={thread.conversationType} contextId={thread.entityId} onToggleContext={onToggleContext} />

        {/* ── CALL FAMILY UI ── */}
        <OrbitCallPermissionBanner
          mic={callFamily.devicePermissions.permissions.microphone}
          cam={callFamily.devicePermissions.permissions.camera}
          videoMode={callFamily.callState.activeCall?.mode === "video"}
          onRequestMic={() => void callFamily.devicePermissions.requestMicrophone()}
          onRequestCam={() => void callFamily.devicePermissions.requestCamera()}
        />
        <OrbitIncomingCallBar
          visible={callFamily.callState.activeCall?.uiState === "incoming"}
          peerName={callFamily.callState.activeCall?.peerName}
          mode={callFamily.callState.activeCall?.mode}
          onAccept={() => void callFamily.callActions.acceptIncomingCall()}
          onDecline={() => void callFamily.callActions.declineIncomingCall()}
        />
        {callFamily.callState.activeCall &&
          ["outgoing", "connecting", "active", "reconnecting"].includes(callFamily.callState.activeCall.uiState) && (
            <OrbitCallControls
              muted={callFamily.callState.activeCall.muted}
              speakerOn={callFamily.callState.activeCall.speakerOn}
              cameraOn={callFamily.callState.activeCall.cameraOn}
              isVideo={callFamily.callState.activeCall.mode === "video"}
              reconnecting={callFamily.callState.activeCall.uiState === "reconnecting"}
              onToggleMute={() => void callFamily.callActions.toggleMute()}
              onToggleSpeaker={() => void callFamily.callActions.toggleSpeaker()}
              onToggleCamera={() => void callFamily.callActions.toggleCamera()}
              onHangup={() => void callFamily.callActions.hangupCall()}
            />
          )}
        <OrbitCallMiniPlayer
          visible={!!callFamily.callState.activeCall && callFamily.callState.activeCall.uiState === "active"}
          peerName={callFamily.callState.activeCall?.peerName}
          state={callFamily.callState.activeCall?.uiState}
          mode={callFamily.callState.activeCall?.mode}
          muted={callFamily.callState.activeCall?.muted}
          onHangup={() => void callFamily.callActions.hangupCall()}
        />

        {/* ── PINNED MESSAGE ── */}
        <OrbitPinnedBanner
          pinnedBody={(pinnedMessage as any)?.content || null}
          onClick={() => {
            if (threadUi.pinnedMessageId) {
              document.getElementById(`msg-${threadUi.pinnedMessageId}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
            }
          }}
          onUnpin={() => {
            if (threadUi.pinnedMessageId) void messageActions.togglePinMessage(threadUi.pinnedMessageId, false);
          }}
        />

        {/* ── SELECTION FAMILY UI ── */}
        {selection.selectMode && (
          <MessageMultiSelectToolbar
            selectedIds={selection.selectedMsgIds}
            messages={messages as any[]}
            currentUserId={user?.id}
            currentContextId={thread?.entityId}
            userEmail={user?.email}
            userName={user?.user_metadata?.full_name || user?.email || "User"}
            onClearSelection={selection.clearSelection}
            onDeletedForMe={(ids) => selection.setHiddenMsgIds(prev => new Set([...prev, ...ids]))}
            onDeletedForAll={(ids) => loader.setRawMessages(prev => prev.map(m => ids.includes(m.id) ? { ...m, content: "🚫 This message was deleted", deleted_for_all: true, attachment_url: null, audio_url: null, audio_duration_seconds: null } as any : m))}
          />
        )}

        {/* ── MESSAGE LIST FAMILY UI ── */}
        <div className="relative flex-1 min-h-0 flex flex-col">
          {msgFamily.isLoadingMessages ? (
            <div className="flex-1 overflow-y-auto px-3 sm:px-4 py-3 pb-6 space-y-4" style={{ background: "hsl(var(--hud-bg))" }}>
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className={`flex ${i % 2 === 0 ? "justify-start" : "justify-end"}`}>
                  <div className="space-y-1.5" style={{ maxWidth: "75%" }}>
                    {i % 2 === 0 && <Skeleton className="h-2.5 w-16" />}
                    <Skeleton className={`h-10 rounded-2xl ${i % 2 === 0 ? "w-48 rounded-bl-md" : "w-40 rounded-br-md"}`} />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <MessageList
              ref={msgFamily.scrollRef}
              messages={messages}
              rawCount={loader.rawMessages.length}
              isDecrypting={loader.rawMessages.length > 0 && messages.length === 0}
              typingIndicator={loader.typingIndicator}
              hiddenMsgIds={selection.hiddenMsgIds}
              selectedMsgIds={selection.selectedMsgIds}
              selectMode={selection.selectMode}
              pendingOffline={loader.pendingOffline}
              userId={user?.id}
              threadName={thread.name}
              locale={locale}
              showOriginal={msgFamily.showOriginal}
              translatingMsgId={msgFamily.translatingMsgId}
              onTranslate={msgFamily.handleTranslateMessage}
              onContextMenu={stableContextMenu}
              onToggleSelect={selection.toggleMsgSelect}
              getCategoryIcon={msgFamily.getCategoryIcon}
              t={t}
              conversationId={currentConversationId}
            />
          )}
          <OrbitJumpToBottomButton visible={msgFamily.showJumpToBottom} onClick={msgFamily.jumpToBottom} />
        </div>

        {/* ── DEAL ACTIONS ── */}
        {(thread.conversationType === "booking" || thread.conversationType === "listing" || thread.conversationType === "deal") && (
          <div className="px-3 sm:px-4 py-2 shrink-0" style={{ borderTop: "1px solid hsl(var(--hud-border) / 0.06)", background: "hsl(var(--hud-surface) / 0.25)" }}>
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
              {!thread.dealId && <Button size="sm" variant="outline" className="text-[11px] h-7 min-h-[44px] sm:min-h-0 gap-1.5 rounded-full px-3 shrink-0" onClick={onToggleContext}>Deal</Button>}
              <Button size="sm" variant="outline" className="text-[11px] h-7 min-h-[44px] sm:min-h-0 gap-1.5 rounded-full px-3 shrink-0" onClick={() => payment.setPaymentLinkDialog(true)}>{t("orbit.payment") || "Payment"}</Button>
              <Button size="sm" variant="outline" className="text-[11px] h-7 min-h-[44px] sm:min-h-0 gap-1.5 rounded-full px-3 shrink-0" onClick={() => payment.setRequestMoneyDialog(true)}>Request</Button>
              {thread.bookingStatus === "pending" && <Button size="sm" className="text-[11px] h-7 min-h-[44px] sm:min-h-0 gap-1.5 rounded-full px-3 shrink-0" onClick={() => handleBookingAction("confirm")}>{t("orbit.confirm") || "Confirm"}</Button>}
              {thread.bookingStatus === "confirmed" && <Button size="sm" variant="outline" className="text-[11px] h-7 min-h-[44px] sm:min-h-0 gap-1.5 rounded-full px-3 shrink-0" onClick={() => handleBookingAction("complete")}>{t("orbit.complete") || "Complete"}</Button>}
              {!(["cancelled", "completed"].includes(thread.bookingStatus || "")) && <Button size="sm" variant="ghost" className="text-[11px] h-7 min-h-[44px] sm:min-h-0 gap-1.5 rounded-full px-3 shrink-0" onClick={() => handleBookingAction("cancel")}>{t("orbit.cancel") || "Cancel"}</Button>}
            </div>
          </div>
        )}

        {/* ── COMPOSER FAMILY UI — hidden during selection mode ── */}
        {!selection.selectMode && globalSelectionMode !== "selecting" && (
          <MessageComposer
            key={currentConversationId}
            value={storeDraft}
            sending={!!composerStore.sending[currentConversationId]}
            uploading={attFamily.attachments.uploading}
            voiceRecording={compFamily.voiceRecorder.recording}
            voicePreview={compFamily.voicePreview}
            voiceDuration={compFamily.voiceRecorder.duration}
            replyTo={composerStore.replies[currentConversationId] ? { content: composerStore.replies[currentConversationId]!.content, senderName: composerStore.replies[currentConversationId]!.senderName } : null}
            onChange={(v: string) => {
              setStoreDraft(v);
            }}
            onSend={stableHandleSend}
            onKeyDown={(e: React.KeyboardEvent<HTMLTextAreaElement | HTMLInputElement>) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void stableHandleSend();
              }
            }}
            onTyping={() => loader.broadcastTyping(privacySettings.typingIndicators)}
            attachmentActions={{
              onFileUpload: attFamily.attachments.handleFileUpload,
              onCameraCapture: attFamily.attachments.handleFileUpload,
              onLocation: () => security.setShowLocationPicker(true),
              onViewOnce: compFamily.handleViewOnceUpload,
              onMultiPhoto: () => setShowMultiPhoto(true),
            }}
            onStartVoice={compFamily.startVoice}
            onStopVoice={compFamily.stopVoice}
            onCancelVoice={compFamily.cancelVoice}
            onSendVoice={compFamily.handleVoiceSend}
            onDiscardVoice={compFamily.discardVoice}
            onClearReply={() => { composerStore.clearReply(currentConversationId); }}
          />
        )}

        {/* ── SELECTION TOOLBAR — replaces composer during selection ── */}
        {globalSelectionMode === "selecting" && (
          <OrbitSelectionToolbar
            onCopy={(ids) => { /* TODO: wire to message actions */ }}
            onForward={(ids) => { /* TODO: wire to forward dialog */ }}
            onDelete={(ids) => { ids.forEach((id) => messageActions.softDeleteMessage(id)); clearGlobalSelection(); }}
          />
        )}

        <OrbitUploadQueuePreview
          queue={attFamily.attachmentQueue.queue}
          onRemove={attFamily.attachmentQueue.removeQueueItem}
        />
        {attFamily.attachmentQueue.queue.length > 0 && (
          <div className="px-3 py-2 flex justify-end" style={{ borderTop: "1px solid hsl(var(--border) / 0.08)" }}>
            <button
              onClick={() => void attFamily.handleUploadAndSendAttachments()}
              className="rounded-xl bg-primary text-primary-foreground px-4 py-2 text-xs font-medium"
              disabled={attFamily.attachmentSend.sendingAttachments}
            >
              {attFamily.attachmentSend.sendingAttachments ? "Sending..." : "Send attachments"}
            </button>
          </div>
        )}

        <input ref={attFamily.fileInputRef} type="file" multiple className="hidden" onChange={(e) => {
          const files = e.target.files;
          if (files?.length) {
            useMediaPreviewState.getState().openWithFiles(files);
          }
          e.target.value = "";
        }} />
        <input ref={attFamily.cameraInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => {
          const files = e.target.files;
          if (files?.length) {
            useMediaPreviewState.getState().openWithFiles(files);
          }
          e.target.value = "";
        }} />
      </div>

      {/* ── PAYMENT FAMILY DIALOGS ── */}
      <Sheet open={payment.paymentLinkDialog} onOpenChange={payment.setPaymentLinkDialog}>
        <SheetContent side="bottom" className="rounded-t-2xl max-h-[85vh] overflow-y-auto p-0">
          <OrbitSmartPayment
            recipientUserId={thread.peerUserId || thread.tenantId || thread.entityId || null}
            recipientName={thread.name || "Recipient"}
            context={thread.entityType ? { type: thread.entityType as any, id: thread.entityId, label: thread.serviceTitle || thread.propertyLabel || thread.listingTitle } : undefined}
            threadId={thread.conversationId || thread.id}
            defaultCurrency={thread.currency?.toUpperCase()}
            onSuccess={(conf: PaymentConfirmation) => {
              payment.setPaymentLinkDialog(false);
              void (async () => {
                const authUserId = await resolveAuthUserId();
                if (!authUserId || !orgId) return;
                const peerId = thread.peerUserId || thread.tenantId || thread.entityId || thread.id;
                try {
                  await sendPaymentReceiptToThread({
                    threadId: thread.conversationId || thread.id,
                    senderId: authUserId,
                    orgId,
                    transactionId: conf.txnId,
                    amount: conf.amount,
                    currency: conf.currency,
                    recipientName: conf.recipientName || thread.name,
                    title: conf.status === "completed" ? "Payment sent" : "Payment initiated",
                    contextType: thread.entityType,
                    contextId: thread.entityId,
                    tenantId: thread.tenantId,
                    bookingId: thread.bookingId,
                    bookingType: thread.bookingType,
                    encrypt: e2eReady ? encrypt : undefined,
                    peerId: e2eReady ? peerId : null,
                  });
                } catch {}
              })();
              toast.success(conf.status === "completed" ? "Payment sent" : "Payment initiated");
            }}
            onCancel={() => payment.setPaymentLinkDialog(false)}
          />
        </SheetContent>
      </Sheet>

      <RequestMoneyModal
        open={payment.requestMoneyDialog}
        onClose={() => payment.setRequestMoneyDialog(false)}
        recipientId={thread.peerUserId || thread.tenantId || thread.entityId || null}
        contextId={thread.conversationId || thread.id || null}
        onCreated={async (req) => {
          const authUserId = await resolveAuthUserId();
          if (!authUserId || !orgId) return;
          const peerId = thread.peerUserId || thread.tenantId || thread.entityId || thread.id;
          try {
            await sendPaymentRequestMessageToThread({
              threadId: thread.conversationId || thread.id,
              senderId: authUserId,
              orgId,
              request: req,
              tenantId: thread.tenantId,
              bookingId: thread.bookingId,
              bookingType: thread.bookingType,
              contextType: thread.entityType,
              contextId: thread.entityId,
              encrypt: e2eReady ? encrypt : undefined,
              peerId: e2eReady ? peerId : null,
            });
          } catch {}
          toast.success(t("orbit.payment_request_sent") || "Payment request sent in chat");
        }}
      />

      {/* ── CONTEXT MENU / FORWARD / SECURITY DIALOGS ── */}
      <MessageContextMenu
        message={selection.contextMessage}
        onClose={() => selection.setContextMessage(null)}
        onDeleted={(msgId, type) => {
          if (type === "self") selection.setHiddenMsgIds(prev => new Set([...prev, msgId]));
          else loader.setRawMessages(prev => prev.map(m => m.id === msgId ? { ...m, content: "🚫 This message was deleted", message_type: "system", attachment_url: null, audio_url: undefined, audio_duration_seconds: undefined, deleted_for_all: true } as any : m));
        }}
        onCopy={() => {}}
        onEdited={(msgId, newContent) => loader.setRawMessages(prev => prev.map(m => m.id === msgId ? { ...m, content: newContent, edited_at: new Date().toISOString() } as any : m))}
        onReply={(msgId, content, senderName) => { composerStore.setReply(currentConversationId, { msgId, content, senderName }); }}
        onForward={(msgId, content) => selection.setForwardData({ messageId: msgId, content })}
        onStarToggle={(msgId, starred) => loader.setRawMessages(prev => prev.map(m => m.id === msgId ? { ...m, starred } as any : m))}
        onEnterSelectMode={selection.enterSelectMode}
      />

      <ChatLocationPicker open={security.showLocationPicker} onClose={() => security.setShowLocationPicker(false)} onSend={compFamily.handleLocationSend} />
      <OrbitSafetyNumber peerId={thread.peerUserId || thread.tenantId || thread.entityId || thread.id || ""} peerName={thread.name || "Contact"} open={security.showSafetyNumber} onOpenChange={security.setShowSafetyNumber} />
      <OrbitSecurityPanel peerId={thread.peerUserId || thread.tenantId || thread.entityId || thread.id || ""} peerName={thread.name || "Contact"} open={security.showSecurityPanel} onOpenChange={security.setShowSecurityPanel} />

      {selection.forwardData && (
        <ForwardMessageDialog
          open={!!selection.forwardData}
          onClose={() => selection.setForwardData(null)}
          messageContent={selection.forwardData.content}
          messageId={selection.forwardData.messageId}
          userId={user?.id || ""}
          userEmail={user?.email || ""}
          userName={user?.user_metadata?.full_name || user?.email || "User"}
          currentContextId={thread.entityId || ""}
        />
      )}

      <OrbitAttachmentViewer
        open={attFamily.viewerOpen}
        attachment={attFamily.viewerAttachment}
        onClose={() => { attFamily.setViewerOpen(false); attFamily.setViewerAttachment(null); }}
      />

      {/* ── LOCATION VIEWER OVERLAY ── */}
      <LocationViewerOverlay />

      {/* ── MEDIA PREVIEW BEFORE SEND ── */}
      <MediaPreviewSheet onSend={mediaPreviewSend.sendFromPreview} />

      {/* ── FULLSCREEN MEDIA VIEWER ── */}
      <FullscreenMediaViewer />

      {/* ── CONTACT PROFILE SHEET ── */}
      <ContactProfileSheet
        open={showContactProfile}
        onClose={() => setShowContactProfile(false)}
        entity={contactProfileEntity}
        onMessage={() => setShowContactProfile(false)}
        onAudioCall={() => { setShowContactProfile(false); void callFamily.handleStartAudioCall(); }}
        onVideoCall={() => { setShowContactProfile(false); void callFamily.handleStartVideoCall(); }}
      />

      {/* ── MULTI PHOTO SELECT ── */}
      <MultiPhotoSelect
        open={showMultiPhoto}
        onClose={() => setShowMultiPhoto(false)}
        onSend={(attachments, caption) => {
          const sorted = [...attachments].sort((a, b) => a.order - b.order);
          const files = sorted.map(a => a.file);
          const convId = thread?.conversationId || thread?.id;
          if (!convId || !files.length) return;

          void (async () => {
            const { orbitDispatch } = await import("@/families/orbit-dispatch/orbit-dispatch");
            const { transportUploadWithPrepare } = await import("@/families/media/transport/transport-engine");
            const { TransportPolicy } = await import("@/families/media/transport/transport-policy");

            await orbitDispatch({
              type: "send_media_batch",
              conversationId: convId,
              files,
              caption: caption || undefined,
              viewOnce: false,
              uploadFn: async (file, _path, onProgress) => {
                const decision = TransportPolicy.decide(file);
                const result = await transportUploadWithPrepare(file, {
                  pathPrefix: orgId || "orbit-media",
                  compress: decision.shouldCompress,
                  maxDimension: decision.maxDimension || undefined,
                  quality: decision.quality || undefined,
                  callbacks: { onProgress },
                });
                return result.publicUrl;
              },
              pathPrefix: orgId || "orbit-media",
            });
          })();
        }}
      />
    </>
  );
}
