/**
 * MessageMultiSelect — Multi-select toolbar for bulk message actions.
 * Supports: bulk delete (for me), bulk delete (for everyone), bulk forward, copy all.
 * Deduplicated icons: EyeOff for delete-for-me, Trash2 for delete-for-all.
 * Fully i18n-aware.
 */
import { useState } from "react";
import { Trash2, Copy, Forward, X, EyeOff } from "lucide-react";
import ForwardMessageDialog from "@/components/communication/ForwardMessageDialog";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { haptic } from "@/lib/haptics";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n";
import { platformBus } from "@/lib/shared/platform-bus";
import {
  deleteMessageForSender, deleteMessageForUser, deleteMessageForAll,
} from "@/repositories/communication.repository";

interface Props {
  selectedIds: Set<string>;
  messages: Array<{ id: string; content: string; sender_id: string; attachment_url?: string }>;
  currentUserId?: string;
  currentContextId?: string;
  userEmail?: string;
  userName?: string;
  onClearSelection: () => void;
  onDeletedForMe: (ids: string[]) => void;
  onDeletedForAll: (ids: string[]) => void;
}

export default function MessageMultiSelectToolbar({
  selectedIds, messages, currentUserId, currentContextId, userEmail, userName, onClearSelection, onDeletedForMe, onDeletedForAll,
}: Props) {
  const { t } = useI18n();
  const [confirmAction, setConfirmAction] = useState<"deleteMe" | "deleteAll" | null>(null);
  const [processing, setProcessing] = useState(false);
  const [showForward, setShowForward] = useState(false);
  const count = selectedIds.size;

  if (count === 0) return null;

  const selectedMessages = messages.filter(m => selectedIds.has(m.id));
  const allMine = selectedMessages.every(m => m.sender_id === currentUserId);

  const handleCopyAll = () => {
    const text = selectedMessages.map(m => m.content).join("\n\n");
    navigator.clipboard.writeText(text);
    haptic("light");
    toast.success(`${count} ${t("orbit.messages_copied") || "messages copied"}`);
    onClearSelection();
  };

  const handleDeleteForMe = async () => {
    setProcessing(true);
    haptic("medium");
    const ids = Array.from(selectedIds);
    try {
      for (const id of ids) {
        const msg = messages.find(m => m.id === id);
        if (msg && msg.sender_id === currentUserId) {
          await deleteMessageForSender(id);
        } else if (currentUserId) {
          await deleteMessageForUser(id, currentUserId);
        }
      }
      onDeletedForMe(ids);
      toast.success(`${count} ${t("orbit.messages_hidden") || "messages hidden"}`);
      platformBus.emit("orbit:message_sent", { type: "bulk_delete_for_me", count: ids.length }, "orbit", { userId: currentUserId });
    } catch (e: any) {
      console.error("[bulk-delete-for-me]", e);
      toast.error("Failed to hide some messages");
    }
    setConfirmAction(null);
    onClearSelection();
    setProcessing(false);
  };

  const handleDeleteForAll = async () => {
    setProcessing(true);
    haptic("medium");
    const ids = Array.from(selectedIds);
    try {
      for (const id of ids) {
        await deleteMessageForAll(id, currentUserId);
      }
      onDeletedForAll(ids);
      toast.success(`${count} ${t("orbit.messages_deleted_all") || "messages deleted for everyone"}`);
      platformBus.emit("orbit:message_sent", { type: "bulk_delete_for_all", count: ids.length }, "orbit", { userId: currentUserId });
    } catch (e: any) {
      toast.error("Failed to delete some messages");
    }
    setConfirmAction(null);
    onClearSelection();
    setProcessing(false);
  };

  return (
    <>
      <div
        className="flex items-center gap-2 px-3 py-2.5 shrink-0"
        style={{
          background: "hsl(var(--hud-surface) / 0.95)",
          borderBottom: "1px solid hsl(var(--hud-border) / 0.12)",
          backdropFilter: "blur(12px)",
        }}
      >
        <Button variant="ghost" size="icon" onClick={onClearSelection} className="h-9 w-9 rounded-full">
          <X className="h-4 w-4" style={{ color: "hsl(var(--hud-text))" }} />
        </Button>
        <span className="text-sm font-semibold flex-1" style={{ color: "hsl(var(--hud-text))" }}>
          {count} {t("orbit.selected") || "selected"}
        </span>
        <div className="flex items-center gap-1.5">
          <Button variant="ghost" size="icon" onClick={handleCopyAll} className="h-9 w-9 rounded-full" title={t("orbit.copy_text") || "Copy"}>
            <Copy className="h-4 w-4" style={{ color: "hsl(var(--hud-text-dim))" }} />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setShowForward(true)} className="h-9 w-9 rounded-full" title={t("orbit.forward") || "Forward"}>
            <Forward className="h-4 w-4" style={{ color: "hsl(var(--hud-text-dim))" }} />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setConfirmAction("deleteMe")} className="h-9 w-9 rounded-full" title={t("orbit.delete_for_me") || "Hide for me"}>
            <EyeOff className="h-4 w-4" style={{ color: "hsl(var(--hud-warning, 40 90% 60%))" }} />
          </Button>
          {allMine && (
            <Button variant="ghost" size="icon" onClick={() => setConfirmAction("deleteAll")} className="h-9 w-9 rounded-full" title={t("orbit.delete_for_all") || "Delete for everyone"}>
              <Trash2 className="h-4 w-4" style={{ color: "hsl(var(--destructive))" }} />
            </Button>
          )}
        </div>
      </div>

      <Dialog open={!!confirmAction} onOpenChange={() => setConfirmAction(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {confirmAction === "deleteMe"
                ? (t("orbit.delete_for_me_q") || "Hide for me?")
                : (t("orbit.delete_for_all_q") || "Delete for everyone?")}
            </DialogTitle>
            <DialogDescription>
              {confirmAction === "deleteMe"
                ? `${count} ${t("orbit.delete_for_me_desc") || "message(s) will be hidden from your view only."}`
                : `${count} ${t("orbit.delete_for_all_desc") || "message(s) will be deleted for all participants."}`}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmAction(null)}>{t("orbit.cancel") || "Cancel"}</Button>
            <Button
              variant="destructive"
              disabled={processing}
              onClick={confirmAction === "deleteMe" ? handleDeleteForMe : handleDeleteForAll}
            >
              {processing ? (t("orbit.deleting") || "Deleting…") : confirmAction === "deleteMe" ? (t("orbit.hide") || "Hide") : (t("orbit.delete") || "Delete")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Forward Dialog */}
      {showForward && currentUserId && (
        <ForwardMessageDialog
          open={showForward}
          onClose={() => { setShowForward(false); onClearSelection(); }}
          messageContent={
            count > 1
              ? `📨 ${count} ${t("orbit.forwarded_messages") || "forwarded messages"}:\n\n` + selectedMessages.map((m, i) => `[${i + 1}] ${m.content}`).join("\n\n")
              : selectedMessages[0]?.content || ""
          }
          messageId={selectedMessages[0]?.id || ""}
          userId={currentUserId}
          userEmail={userEmail || ""}
          userName={userName || "User"}
          currentContextId={currentContextId || ""}
        />
      )}
    </>
  );
}
