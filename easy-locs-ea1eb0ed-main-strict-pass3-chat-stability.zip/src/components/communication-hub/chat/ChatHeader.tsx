/**
 * ChatHeader — Compact messenger-first thread top bar.
 * Uses canonical identity resolution for consistent display.
 * Tap on avatar/name opens ContactProfileSheet.
 */
import { Phone, Video, MoreVertical, ArrowLeft } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { haptic } from "@/lib/haptics";
import { trackOrbitEvent } from "@/lib/orbit/orbitTelemetry";
import { resolveCanonicalDisplayIdentity } from "@/lib/orbit/canonical-helpers";
import { IdentityAvatar } from "@/components/orbit/IdentityAvatar";
import type { ConversationThread } from "../types";

interface Props {
  thread: ConversationThread;
  convStatus: string;
  e2eReady: boolean;
  isInCall: boolean;
  isStartingCall: boolean;
  onBack: () => void;
  onStartCall: (isVideo: boolean) => void;
  onUpdateStatus: (status: string) => void;
  onToggleContext: () => void;
  onShowSecurityPanel: () => void;
  onShowSafetyNumber: () => void;
  onEnterSelectMode: () => void;
  onAvatarTap?: () => void;
  t: (key: string) => string;
}

export default function ChatHeader({
  thread, isInCall, isStartingCall,
  onBack, onStartCall, onToggleContext,
  onEnterSelectMode, onAvatarTap, t,
}: Props) {
  const identity = resolveCanonicalDisplayIdentity({
    display_name: thread.name,
    email: thread.email,
    avatar_url: thread.avatarUrl,
    role: thread.conversationType === "team" ? "Team" : undefined,
    company: thread.propertyLabel || undefined,
  });
  const displayName = identity.displayName;
  const subtitle = identity.subtitle || "tap for info";

  const handleIdentityTap = () => {
    haptic("light");
    if (onAvatarTap) onAvatarTap();
    else onToggleContext();
  };

  return (
    <div className="px-2 sm:px-3 py-1.5 shrink-0" style={{
      borderBottom: "1px solid hsl(var(--hud-border) / 0.08)",
      background: "hsl(var(--hud-surface) / 0.5)",
      backdropFilter: "blur(12px)",
    }}>
      <div className="flex items-center gap-2">
        <button onClick={onBack} className="shrink-0 h-8 w-8 rounded-full flex items-center justify-center hover:bg-[hsl(var(--hud-surface-2))]">
          <ArrowLeft className="h-4 w-4" style={{ color: "hsl(var(--hud-text))" }} />
        </button>

        <button onClick={handleIdentityTap} className="shrink-0">
          <IdentityAvatar avatarUrl={identity.avatarUrl} name={displayName} size="sm" />
        </button>

        <div className="min-w-0 flex-1" onClick={handleIdentityTap} style={{ cursor: "pointer" }}>
          <p className="text-[13px] font-semibold line-clamp-1 break-words leading-tight" style={{ color: "hsl(var(--hud-text))" }}>
            {displayName}
          </p>
          <p className="text-[10px] leading-tight mt-0.5" style={{ color: "hsl(var(--hud-text-dim) / 0.6)" }}>
            {subtitle}
          </p>
        </div>

        <div className="flex items-center shrink-0">
          <button disabled={isInCall || isStartingCall} onClick={() => { trackOrbitEvent("orbit.call.started", { screen: "chat", component: "ChatHeader", action: "audio_call", result: "success" }); onStartCall(false); }}
            className="h-8 w-8 min-h-[44px] min-w-[44px] sm:min-h-0 sm:min-w-0 rounded-full flex items-center justify-center transition-colors hover:bg-[hsl(var(--hud-surface-2))] disabled:opacity-40">
            <Phone className="h-[17px] w-[17px]" style={{ color: "hsl(var(--hud-success))" }} />
          </button>
          <button disabled={isInCall || isStartingCall} onClick={() => { trackOrbitEvent("orbit.call.started", { screen: "chat", component: "ChatHeader", action: "video_call", result: "success" }); onStartCall(true); }}
            className="h-8 w-8 min-h-[44px] min-w-[44px] sm:min-h-0 sm:min-w-0 rounded-full flex items-center justify-center transition-colors hover:bg-[hsl(var(--hud-surface-2))] disabled:opacity-40">
            <Video className="h-[17px] w-[17px]" style={{ color: "hsl(var(--hud-cyan))" }} />
          </button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="h-8 w-8 min-h-[44px] min-w-[44px] sm:min-h-0 sm:min-w-0 rounded-full flex items-center justify-center transition-colors hover:bg-[hsl(var(--hud-surface-2))]">
                <MoreVertical className="h-4 w-4" style={{ color: "hsl(var(--hud-text-dim))" }} />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44" style={{ background: "hsl(var(--hud-surface))", borderColor: "hsl(var(--hud-border) / 0.2)" }}>
              <DropdownMenuItem onClick={onToggleContext}>
                {t("orbit.details") || "Details"}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => { haptic("light"); onEnterSelectMode(); }}>
                {t("orbit.select_messages") || "Select Messages"}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
}
