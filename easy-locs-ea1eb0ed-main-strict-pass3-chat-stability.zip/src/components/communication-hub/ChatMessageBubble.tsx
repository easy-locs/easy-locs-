/**
 * ChatMessageBubble — Premium Signal-grade message bubble.
 * Decomposed into isolated micro-components: BubbleMediaBlock, BubbleMetaFooter, BubbleLocationBlock.
 */
import { memo, useEffect, useState, useMemo } from "react";
import {
  CheckCheck, Globe, Loader2, Mail, WifiOff, Lock, CheckCircle2,
  ShieldCheck, CreditCard, EyeOff, Timer, Shield, FileText,
} from "lucide-react";
import { format } from "date-fns";
import VoiceMessageBubble from "@/components/communication/VoiceMessageBubble";
import { BubbleMediaBlock } from "./chat/BubbleMediaBlock";
import { BubbleMetaFooter } from "./chat/BubbleMetaFooter";
import { BubbleLocationBlock } from "./chat/BubbleLocationBlock";
import { BubbleLinkPreview } from "./chat/BubbleLinkPreview";

// haptic removed — gestures handled by OrbitMessageInteractiveWrapper
import { getMessagePolicy, shouldHideMessage, type SecurityLevel } from "@/lib/message-security";
import { ChatPaymentRequestCard, ChatPaymentReceiptCard } from "@/components/chat/ChatPaymentCards";
import ThreadActionCard, { parseActionFromMessage } from "@/components/orbit/ThreadActionCard";
import type { ChatMessage } from "./types";
import { MESSAGE_CATEGORIES } from "./types";

const SYSTEM_SENDER_ID = "00000000-0000-0000-0000-000000000000";

interface Props {
  msg: ChatMessage;
  isMe: boolean;
  threadName?: string;
  locale: string;
  showOriginal: boolean;
  translatingMsgId: string | null;
  isPendingOffline: boolean;
  isConsecutive?: boolean;
  /** @deprecated — selection visuals now handled by OrbitMessageInteractiveWrapper */
  selected?: boolean;
  /** @deprecated — selection mode now handled by OrbitMessageInteractiveWrapper */
  selectMode?: boolean;
  currentUserId?: string;
  onTranslate: (msg: ChatMessage) => void;
  onContextMenu: (e: React.MouseEvent, msg: ChatMessage, isMe: boolean) => void;
  onToggleSelect?: (id: string) => void;
  getCategoryIcon: (cat: string) => string;
}

/** Safely coerce a value to a renderable string — prevents React error #185 */
function safeStr(val: unknown): string {
  if (val == null) return "";
  if (typeof val === "string") return val;
  if (typeof val === "number" || typeof val === "boolean") return String(val);
  try { return JSON.stringify(val); } catch { return ""; }
}

function ChatMessageBubble({
  msg: rawMsg, isMe, threadName, locale, showOriginal,
  translatingMsgId, isPendingOffline, isConsecutive,
  selected, selectMode, currentUserId,
  onTranslate, onContextMenu, onToggleSelect, getCategoryIcon,
}: Props) {
  // Guard: ensure content and contact_name are always strings
  const msg = {
    ...rawMsg,
    content: safeStr(rawMsg.content),
    contact_name: safeStr(rawMsg.contact_name),
    translated_content: rawMsg.translated_content ? safeStr(rawMsg.translated_content) : rawMsg.translated_content,
  };
  // Legacy gesture handlers removed — now handled by OrbitMessageInteractiveWrapper

  const isSystem = msg.message_type === "system" || msg.sender_id === SYSTEM_SENDER_ID;
  const isDeleted = !!(msg as any).deleted_for_all;
  const isInboundEmail = msg.message_type === "inbound_email";
  const isPayment = !isDeleted && msg.content?.startsWith("💳");
  const isPaymentRequest = !isDeleted && msg.category === "payment_request";
  const isPaymentReceipt = !isDeleted && msg.category === "payment_receipt";
  const paymentRequestData = useMemo(() => {
    if (!isPaymentRequest) return null;
    try {
      const parsed = JSON.parse(msg.content);
      return parsed?._type === "payment_request_card" ? parsed : null;
    } catch { return null; }
  }, [isPaymentRequest, msg.content]);
  const paymentReceiptData = useMemo(() => {
    if (!isPaymentReceipt) return null;
    try {
      const parsed = JSON.parse(msg.content);
      if (parsed?._type === "payment_receipt_card" || parsed?._type === "payment_receipt") return parsed;
      return null;
    } catch { return null; }
  }, [isPaymentReceipt, msg.content]);
  const isVoice = !isDeleted && !!(msg as any).audio_url;
  const isViewOnce = !isDeleted && !!(msg as any).view_once;
  
  // Detect location messages (contain OSM link with coordinates)
  const osmMatch = !isDeleted && msg.content?.match(/openstreetmap\.org\/\?mlat=([\d.-]+)&mlon=([\d.-]+)/);
  const isLocation = !!osmMatch;
  const locLat = osmMatch ? osmMatch[1] : null;
  const locLng = osmMatch ? osmMatch[2] : null;
  const locLabel = isLocation ? msg.content.split("\n")[0] : null;
  
  const securityPolicy = getMessagePolicy(msg);
  const hasSecurityLevel = securityPolicy.level !== "normal";
  const transcriptText = (msg as any).transcript_text;
  const transcriptStatus = (msg as any).transcript_status;
  const translatedTranscript = (msg as any).translated_transcript_text;
  const [showTranscript, setShowTranscript] = useState(true);
  const [showTranslatedTranscript, setShowTranslatedTranscript] = useState(false);

  // Client-side expiration masking
  const [expired, setExpired] = useState(false);
  useEffect(() => {
    if (shouldHideMessage(msg)) { setExpired(true); return; }
    if ((msg as any).disappear_at) {
      const ms = new Date((msg as any).disappear_at).getTime() - Date.now();
      if (ms > 0) {
        const timer = setTimeout(() => setExpired(true), ms);
        return () => clearTimeout(timer);
      } else {
        setExpired(true);
      }
    }
  }, [(msg as any).disappear_at, (msg as any).destroyed_at]);

  // Anti-screenshot: blur on visibility change
  const [blurred, setBlurred] = useState(false);
  useEffect(() => {
    if (!securityPolicy.antiScreenshot) return;
    const handler = () => {
      if (document.hidden) setBlurred(true);
      else setTimeout(() => setBlurred(false), 500);
    };
    document.addEventListener("visibilitychange", handler);
    return () => document.removeEventListener("visibilitychange", handler);
  }, [securityPolicy.antiScreenshot]);

  if (expired) {
    return (
      <div className={`flex ${isMe ? "justify-end" : "justify-start"}`} style={{ marginTop: isConsecutive ? 2 : 8 }}>
        <div className="flex items-center gap-1.5 px-3 py-2 rounded-xl" style={{
          background: "hsl(var(--hud-surface) / 0.2)",
          border: "1px solid hsl(var(--hud-border) / 0.04)",
        }}>
          <Timer className="h-3 w-3" style={{ color: "hsl(var(--hud-text-dim) / 0.3)" }} />
          <span className="text-[11px] italic" style={{ color: "hsl(var(--hud-text-dim) / 0.4)" }}>
            Message expired
          </span>
        </div>
      </div>
    );
  }

  // Deleted message bubble — shows inline in conversation flow
  if (isDeleted && !isSystem) {
    return (
      <div
        className={`flex ${isMe ? "justify-end" : "justify-start"} group`}
        style={{ marginTop: isConsecutive ? 2 : 8 }}
      >
        <div
          className="relative max-w-[78%] sm:max-w-[60%] flex items-center gap-1.5"
          style={{
            padding: "8px 14px",
            borderRadius: isMe
              ? (isConsecutive ? "16px 4px 4px 16px" : "16px 16px 4px 16px")
              : (isConsecutive ? "4px 16px 16px 4px" : "16px 16px 16px 4px"),
            background: "hsl(var(--hud-surface) / 0.3)",
            border: "1px solid hsl(var(--hud-border) / 0.04)",
          }}
        >
          <EyeOff className="h-3 w-3 shrink-0" style={{ color: "hsl(var(--hud-text-dim) / 0.4)" }} />
          <span className="text-[12.5px] italic" style={{ color: "hsl(var(--hud-text-dim) / 0.5)" }}>
            This message was deleted
          </span>
          <span className="text-[10px] opacity-35 font-medium tabular-nums ml-2">{format(new Date(msg.created_at), "HH:mm")}</span>
        </div>
      </div>
    );
  }

  if (isSystem) {
    // Check for embedded action card
    const actionData = parseActionFromMessage(msg.content);
    
    if (actionData) {
      return (
        <div className="flex justify-center my-3 px-4">
          <div className="w-full max-w-[85%] space-y-1.5">
            <p
              className="text-[11px] text-center font-medium"
              style={{ color: "hsl(var(--hud-text-dim))" }}
            >
              {actionData.text}
              <span className="ml-2 opacity-50 text-[10px]">{format(new Date(msg.created_at), "HH:mm")}</span>
            </p>
            <ThreadActionCard payload={actionData.action} />
          </div>
        </div>
      );
    }

    return (
      <div className="flex justify-center my-3">
        <div
          className="text-[11px] px-4 py-1.5 rounded-full max-w-[85%] text-center break-words font-medium"
          style={{
            background: "hsl(var(--hud-surface) / 0.6)",
            color: "hsl(var(--hud-text-dim))",
            border: "1px solid hsl(var(--hud-border) / 0.06)",
          }}
        >
          {msg.content}
          <span className="ml-2 opacity-50 text-[10px]">{format(new Date(msg.created_at), "HH:mm")}</span>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`flex ${isMe ? "justify-end" : "justify-start"} group transition-colors duration-150`}
      style={{ marginTop: isConsecutive ? 2 : 8 }}
    >
      <div
        className="relative max-w-[75%] sm:max-w-[60%]"
        style={{
          padding: isVoice ? "6px 10px 4px" : "8px 12px 4px",
          borderRadius: isMe
            ? (isConsecutive ? "16px 4px 4px 16px" : "16px 16px 4px 16px")
            : (isConsecutive ? "4px 16px 16px 4px" : "16px 16px 16px 4px"),
          background: isPaymentReceipt
            ? "linear-gradient(135deg, hsl(var(--hud-success) / 0.08), hsl(var(--hud-success) / 0.03))"
            : isPaymentRequest
            ? "linear-gradient(135deg, hsl(var(--hud-purple) / 0.08), hsl(var(--hud-purple) / 0.03))"
            : isPayment
            ? "linear-gradient(135deg, hsl(var(--hud-cyan) / 0.08), hsl(var(--hud-cyan) / 0.03))"
            : isMe
              ? "hsl(var(--hud-cyan) / 0.08)"
              : "hsl(var(--hud-surface))",
          border: `1px solid ${
            isPaymentReceipt
              ? "hsl(var(--hud-success) / 0.12)"
              : isPayment
              ? "hsl(var(--hud-cyan) / 0.12)"
              : isMe
                ? "hsl(var(--hud-cyan) / 0.06)"
                : "hsl(var(--hud-border) / 0.06)"
          }`,
          wordBreak: "break-word",
          overflowWrap: "anywhere",
        }}
      >
        {/* Reply quote */}
        {(msg as any).reply_to_id && (msg as any).reply_to_content && (
          <div className="mb-1.5 px-2 py-1.5 rounded-lg" style={{
            background: "hsl(var(--hud-surface) / 0.5)",
            borderLeft: "2px solid hsl(var(--hud-cyan) / 0.5)",
          }}>
            <p className="text-[10px] font-semibold" style={{ color: "hsl(var(--hud-cyan) / 0.7)" }}>Reply</p>
            <p className="text-[11px] line-clamp-2" style={{ color: "hsl(var(--hud-text-dim) / 0.6)" }}>
              {((msg as any).reply_to_content || "").slice(0, 100)}
            </p>
          </div>
        )}

        {/* Sender name for received messages (first in group only) */}
        {!isMe && !isConsecutive && (
          <p className="text-[11px] font-semibold mb-0.5" style={{ color: "hsl(var(--hud-cyan))" }}>
            {msg.contact_name || threadName || "Contact"}
          </p>
        )}

        {/* Email indicator */}
        {isInboundEmail && (
          <span className="inline-flex items-center gap-1 text-[10px] font-medium mb-1 rounded-md px-1.5 py-0.5" style={{
            color: "hsl(var(--hud-cyan))",
            background: "hsl(var(--hud-cyan) / 0.08)",
          }}>
            <Mail className="h-2.5 w-2.5" /> Email
          </span>
        )}

        {/* Payment badge */}
        {(isPayment || isPaymentReceipt) && (
          <span className="inline-flex items-center gap-1 text-[10px] font-medium mb-1 rounded-md px-1.5 py-0.5" style={{
            color: isPaymentReceipt ? "hsl(var(--hud-success))" : "hsl(var(--hud-cyan))",
            background: isPaymentReceipt ? "hsl(var(--hud-success) / 0.08)" : "hsl(var(--hud-cyan) / 0.08)",
          }}>
            <CreditCard className="h-2.5 w-2.5" /> {isPaymentReceipt ? "Receipt" : "Payment"}
          </span>
        )}

        {/* Security badge */}
        {hasSecurityLevel && (
          <span className="inline-flex items-center gap-1 text-[9px] font-medium mb-1 rounded-md px-1.5 py-0.5" style={{
            color: "hsl(var(--hud-warning))",
            background: "hsl(var(--hud-warning) / 0.1)",
          }}>
            {securityPolicy.emoji} {securityPolicy.label}
          </span>
        )}

        {/* Category badge */}
        {msg.category !== "general" && !isInboundEmail && !isPayment && (
          <span className="text-[10px] opacity-50 mb-0.5 block">{getCategoryIcon(msg.category)}</span>
        )}

        {/* Media — isolated micro-component */}
        <BubbleMediaBlock
          messageId={msg.id}
          attachmentUrl={msg.attachment_url}
          isMe={isMe}
          isViewOnce={isViewOnce}
          viewOnceOpenedAt={(msg as any).view_once_opened_at}
          viewOnceOpenedBy={(msg as any).view_once_opened_by}
          currentUserId={currentUserId}
          blurred={blurred}
        />

        {isPaymentReceipt && paymentReceiptData ? (
          <ChatPaymentReceiptCard receipt={paymentReceiptData} />
        ) : isPaymentRequest && paymentRequestData ? (
          <ChatPaymentRequestCard request={paymentRequestData} />
        ) : isLocation && locLat && locLng ? (
          <BubbleLocationBlock lat={locLat} lng={locLng} label={locLabel} />
        ) : isVoice ? (
          <div>
            <VoiceMessageBubble
              url={(msg as any).audio_url}
              durationSeconds={(msg as any).audio_duration_seconds || 0}
              isMe={isMe}
              messageId={msg.id}
            />
            {/* Transcript display */}
            {transcriptStatus === "processing" && (
              <div className="flex items-center gap-1 mt-1.5 pt-1" style={{ borderTop: "1px solid hsl(var(--hud-border) / 0.06)" }}>
                <Loader2 className="h-2.5 w-2.5 animate-spin" style={{ color: "hsl(var(--hud-cyan) / 0.5)" }} />
                <span className="text-[10px]" style={{ color: "hsl(var(--hud-text-dim) / 0.5)" }}>Transcribing...</span>
              </div>
            )}
            {transcriptStatus === "error" && (
              <div className="flex items-center gap-1 mt-1.5 pt-1" style={{ borderTop: "1px solid hsl(var(--hud-border) / 0.06)" }}>
                <span className="text-[10px]" style={{ color: "hsl(var(--hud-danger) / 0.6)" }}>⚠️ Transcription failed</span>
              </div>
            )}
            {transcriptText && transcriptStatus === "completed" && (
              <div className="mt-1.5 pt-1" style={{ borderTop: "1px solid hsl(var(--hud-border) / 0.06)" }}>
                <button
                  onClick={() => setShowTranscript(!showTranscript)}
                  className="flex items-center gap-1 text-[10px] mb-0.5 hover:opacity-80 min-h-[44px] sm:min-h-0 py-1"
                  style={{ color: "hsl(var(--hud-cyan) / 0.7)" }}
                >
                  <FileText className="h-3 w-3 sm:h-2.5 sm:w-2.5" />
                  {showTranscript ? "Hide transcript" : "Show transcript"}
                </button>
                {showTranscript && (
                  <p className={`text-[12px] leading-[1.4] whitespace-pre-wrap ${blurred ? "blur-lg" : ""}`} style={{
                    color: "hsl(var(--hud-text) / 0.8)",
                  }}>
                    {showTranslatedTranscript && translatedTranscript ? translatedTranscript : transcriptText}
                  </p>
                )}
                {showTranscript && translatedTranscript && (
                  <button
                    onClick={() => setShowTranslatedTranscript(!showTranslatedTranscript)}
                    className="mt-0.5 inline-flex items-center gap-1 text-[10px] hover:opacity-80 min-h-[44px] sm:min-h-0 py-1"
                    style={{ color: "hsl(var(--hud-text-dim) / 0.5)" }}
                  >
                    <Globe className="h-3 w-3 sm:h-2.5 sm:w-2.5" />
                    {showTranslatedTranscript ? "Original" : "Translated"}
                  </button>
                )}
              </div>
            )}
          </div>
        ) : (
          /* Message content + link preview */
          <>
            <p className={`text-[13.5px] leading-[1.45] whitespace-pre-wrap ${blurred ? "blur-lg transition-all" : ""}`} style={{
              color: "hsl(var(--foreground))",
              overflowWrap: "anywhere",
              ...(securityPolicy.antiScreenshot ? { userSelect: "none" as const, WebkitUserSelect: "none" as const } : {}),
            }}>
              {isMe ? msg.content : (showOriginal ? msg.content : (msg.translated_content || msg.content))}
            </p>
            {(() => {
              const urlMatch = msg.content?.match(/https?:\/\/[^\s]+/);
              if (urlMatch && !msg.attachment_url) {
                return <BubbleLinkPreview url={urlMatch[0]} isMe={isMe} />;
              }
              return null;
            })()}
          </>
        )}

        {/* Original text preview for translated messages */}
        {!isMe && msg.translated_content && !showOriginal && !isVoice && (
          <p className="text-[11px] mt-1.5 pt-1.5 opacity-30 italic whitespace-pre-wrap" style={{ borderTop: "1px solid hsl(var(--hud-border) / 0.08)" }}>
            {msg.content.length > 100 ? msg.content.slice(0, 100) + "…" : msg.content}
          </p>
        )}

        {/* Translate button */}
        {!isMe && msg.sender_locale && msg.sender_locale !== locale && !isVoice && (
          <button onClick={() => onTranslate(msg)} className="mt-1 inline-flex items-center gap-1.5 text-[10px] hover:opacity-80 transition-opacity min-h-[44px] sm:min-h-0 py-1" style={{ color: "hsl(var(--hud-text-dim))" }}>
            {translatingMsgId === msg.id ? <Loader2 className="h-3 w-3 sm:h-2.5 sm:w-2.5 animate-spin" /> : <Globe className="h-3 w-3 sm:h-2.5 sm:w-2.5" />}
            {showOriginal ? "Translation" : msg.translated_content ? "Original" : "Translate"}
          </button>
        )}

        {/* Footer — isolated micro-component */}
        <BubbleMetaFooter
          createdAt={msg.created_at}
          isMe={isMe}
          read={msg.read}
          delivered={(msg as any).delivered}
          status={(msg as any).message_status}
          editedAt={(msg as any).edited_at}
          isPendingOffline={isPendingOffline}
          securityEmoji={hasSecurityLevel ? securityPolicy.emoji : undefined}
          securityLabel={hasSecurityLevel ? securityPolicy.label : undefined}
        />
      </div>
    </div>
  );
}

export default memo(ChatMessageBubble);

/**
 * DateSeparator — Premium date divider between message groups.
 */
export function DateSeparator({ date }: { date: string }) {
  return (
    <div className="flex items-center justify-center my-5">
      <div
        className="px-4 py-1 rounded-full text-[11px] font-semibold tracking-wide"
        style={{
          background: "hsl(var(--hud-surface) / 0.6)",
          color: "hsl(var(--hud-text-dim))",
          border: "1px solid hsl(var(--hud-border) / 0.04)",
          boxShadow: "0 1px 3px hsl(var(--foreground) / 0.04)",
        }}
      >
        {date}
      </div>
    </div>
  );
}
