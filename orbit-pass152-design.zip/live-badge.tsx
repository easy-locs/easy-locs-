// LIVE badge UI
export default function LiveBadge() {
  return (
    <div style={{
      background: "red",
      color: "white",
      padding: "2px 6px",
      borderRadius: "6px",
      fontSize: "10px"
    }}>
      LIVE
    </div>
  );
}
