// Radar pulse + glow effect
export const radarPulseStyle = {
  animation: "pulse 2s infinite",
};

export const radarGlow = {
  boxShadow: "0 0 12px rgba(0,255,255,0.6)",
};
