// Premium marker example
import L from "leaflet";

export function createPremiumMarker(emoji: string) {
  return L.divIcon({
    className: "",
    html: `<div style="background:rgba(0,0,0,0.6);border-radius:12px;padding:6px">${emoji}</div>`,
    iconSize: [36, 36],
  });
}
