PASS152 DESIGN

This package upgrades visual experience only.

Includes:
- Radar pulse animation
- Premium map markers
- Live badge UI

No backend changes required.
