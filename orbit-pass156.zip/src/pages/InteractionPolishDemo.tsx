import React from "react";
import InteractiveCard from "@/components/ui/InteractiveCard";
import LivePill from "@/components/ui/LivePill";

export default function InteractionPolishDemo() {
  return (
    <main className="mx-auto max-w-2xl space-y-4 p-4">
      <LivePill />
      <InteractiveCard>
        <div className="text-sm font-semibold">Interaction polish layer</div>
        <div className="mt-1 text-xs text-muted-foreground">Micro feedback, motion consistency, premium feel.</div>
      </InteractiveCard>
    </main>
  );
}
