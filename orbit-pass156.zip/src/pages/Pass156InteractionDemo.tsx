import React from "react";
import PremiumTapCard from "@/components/ui/PremiumTapCard";
import LiveSignalPill from "@/components/ui/LiveSignalPill";

export default function Pass156InteractionDemo() {
  return (
    <main className="min-h-screen bg-[#030712] p-4">
      <div className="mx-auto max-w-2xl space-y-4">
        <LiveSignalPill count={41} />
        <PremiumTapCard>
          <div className="text-sm font-bold text-white">Global motion layer</div>
          <div className="mt-1 text-xs text-white/60">Consistent tap feedback, shadows and premium interaction pacing.</div>
        </PremiumTapCard>
      </div>
    </main>
  );
}
