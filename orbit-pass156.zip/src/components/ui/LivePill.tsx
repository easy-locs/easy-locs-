import React from "react";

export default function LivePill({ label = "LIVE" }: { label?: string }) {
  return (
    <div className="inline-flex items-center gap-2 rounded-full border border-red-500/20 bg-red-500/10 px-2 py-1 text-[10px] font-semibold text-red-400">
      <span className="inline-block h-2 w-2 rounded-full bg-red-500" />
      {label}
    </div>
  );
}
