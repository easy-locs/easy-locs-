import React from "react";
import { interactionTokens } from "@/lib/interaction-tokens";

export default function PremiumTapCard({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="rounded-[24px] border border-white/10 bg-white/5 p-4 backdrop-blur-xl transition-all active:scale-[0.985]"
      style={{ boxShadow: interactionTokens.softShadow, transitionDuration: `${interactionTokens.normal}ms` }}
    >
      {children}
    </div>
  );
}
