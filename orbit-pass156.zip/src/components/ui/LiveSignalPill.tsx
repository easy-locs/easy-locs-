import React from "react";

export default function LiveSignalPill({ count = 28 }: { count?: number }) {
  return (
    <div className="inline-flex items-center gap-2 rounded-full border border-red-500/20 bg-red-500/10 px-3 py-1 text-[10px] font-semibold uppercase tracking-wide text-red-400">
      <span className="h-2 w-2 rounded-full bg-red-500" />
      Live · {count}
    </div>
  );
}
