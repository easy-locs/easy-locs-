import React from "react";
import { motionTokens } from "@/lib/motion-tokens";

export default function InteractiveCard({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="rounded-2xl border bg-card/80 p-4 shadow-sm transition-all"
      style={{ transitionDuration: `${motionTokens.normal}ms` }}
    >
      {children}
    </div>
  );
}
