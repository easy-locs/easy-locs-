export const motionTokens = {
  fast: 120,
  normal: 180,
  slow: 260,
  pressScale: 0.985,
  hoverScale: 1.015,
} as const;
