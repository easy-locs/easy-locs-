export const interactionTokens = {
  tapScale: 0.985,
  hoverScale: 1.02,
  fast: 120,
  normal: 180,
  slow: 260,
  softShadow: "0 10px 30px rgba(0,0,0,0.18)",
  hardShadow: "0 18px 40px rgba(0,0,0,0.24)",
} as const;
