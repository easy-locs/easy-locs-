import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { PlayCircle, MessageSquare, Store, Lock, Wallet, Film } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { buildLiveCommercePath, buildOrbitContactPath, buildVideoHubPath, buildWalletContactPath, StorefrontMediaItem, buildStorefrontAccessLabel } from "@/lib/storefront-core";
import { useI18n } from "@/lib/i18n";
import { getSecureCommerceReadiness, getSecureMediaReadiness } from "@/lib/orbit-secure-session";

type Props = {
  media: StorefrontMediaItem[];
  sellerName: string;
  storeSlug?: string | null;
  providerId?: string | null;
  visibility?: "public" | "private" | "unlisted";
};

export default function StorefrontVideoRail({ media, sellerName, storeSlug, providerId, visibility = "public" }: Props) {
  const { t } = useI18n();
  const secureCommerce = getSecureCommerceReadiness();
  const secureMedia = getSecureMediaReadiness();
  const [active, setActive] = useState(0);
  const videos = useMemo(() => media.filter((item) => item.kind === "video"), [media]);

  if (videos.length === 0) return null;
  const activeVideo = videos[Math.min(active, videos.length - 1)];

  return (
    <section className="space-y-3" dir="auto">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="text-lg font-semibold text-foreground">{t("mp.short_video_feed") || "Video showcase"}</h3>
            <Badge variant="outline"><PlayCircle className="h-3 w-3 mr-1" /> {videos.length} {t("mp.videos") || "videos"}</Badge>
            {visibility !== "public" && <Badge variant="secondary"><Lock className="h-3 w-3 mr-1" /> {t("mp.private_storefront") || "Private storefront"}</Badge>}
          </div>
          <p className="text-sm text-muted-foreground">{t("mp.watch_videos") || "Watch short videos, then continue the conversation in Orbit."}</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button size="sm" variant="outline" asChild>
            <Link to={buildOrbitContactPath({ sellerName, storeSlug, providerId, context: visibility === "public" ? "storefront_video" : "storefront_access", source: "storefront_video_rail" })}><MessageSquare className="h-4 w-4 mr-1.5" /> {visibility === "public" ? (t("mp.contact_provider") || "Contact in Orbit") : (t("orbit.request_access") || "Request access")}</Link>
          </Button>
          {providerId && secureCommerce.canOpenWallet && (
            <Button size="sm" variant={visibility === "public" ? "default" : "secondary"} asChild>
              <Link to={buildWalletContactPath({ sellerName, storeSlug, providerId, mode: visibility === "public" ? "send" : "receive", source: "storefront_video_rail" })}><Wallet className="h-4 w-4 mr-1.5" /> {buildStorefrontAccessLabel(visibility) === "pay" ? (t("orbit.pay_in_wallet") || "Pay in Wallet") : (t("orbit.request_access") || "Request access")}</Link>
            </Button>
          )}
          {providerId && !secureCommerce.canOpenWallet && (
            <Button size="sm" variant="secondary" disabled>
              <Wallet className="h-4 w-4 mr-1.5" /> Ghost locked
            </Button>
          )}
          {storeSlug && (
            <Button size="sm" variant="outline" asChild>
              <Link to={buildVideoHubPath({ storeSlug, providerId, sellerName, mode: "commerce", visibility: visibility === "public" ? "public" : "private", source: "storefront_video_rail" })}><Film className="h-4 w-4 mr-1.5" /> {t("mp.open_video_hub") || "Open video hub"}</Link>
            </Button>
          )}
          {storeSlug && (
            <Button size="sm" variant="ghost" asChild>
              <Link to={buildLiveCommercePath({ storeSlug, providerId, sellerName, mode: "commerce", visibility: visibility === "public" ? "public" : "private", source: "storefront_video_rail" })}><PlayCircle className="h-4 w-4 mr-1.5" /> {t("mp.open_live_hub") || "Open live hub"}</Link>
            </Button>
          )}
          {storeSlug && (
            <Button size="sm" asChild>
              <Link to={`/store/${storeSlug}`}><Store className="h-4 w-4 mr-1.5" /> {t("mp.open_store") || "Open store"}</Link>
            </Button>
          )}
        </div>
      </div>

      <div className="rounded-xl border border-border/60 bg-card/50 p-3 text-xs text-muted-foreground">
        <div className="flex flex-wrap items-center gap-2 mb-1">
          <Badge variant="secondary">{t("orbit.secure_commerce") || "Secure commerce path"}</Badge>
          {secureCommerce.safeAccess && <Badge variant="outline">Safe access</Badge>}
          {secureCommerce.walletMasked && <Badge variant="outline">Wallet masked</Badge>}
        </div>
        <p>{secureCommerce.summary}</p>
        <p>{secureMedia.summary}</p>
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr),280px]">
        <Card className="overflow-hidden border-border/60">
          <div className="bg-black aspect-[9/16] sm:aspect-[16/9] w-full flex items-center justify-center overflow-hidden relative">
            <video
              key={activeVideo.url}
              src={activeVideo.url}
              controls
              playsInline
              preload="metadata"
              className="h-full w-full object-contain bg-black"
            />
            {(!secureMedia.canOpenSensitiveMedia || secureMedia.messagesMasked) && (
              <div className="absolute inset-x-0 bottom-0 bg-black/70 text-white text-xs px-3 py-2">{t("orbit.safe_access") || "Safe access"}: {secureMedia.summary}</div>
            )}
          </div>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
              <Badge variant="secondary">{activeVideo.source === "profile" ? (t("mp.storefront") || "Storefront") : (t("mp.service") || "Service")}</Badge>
            </div>
            <p className="font-medium text-foreground leading-tight break-words">{activeVideo.title || sellerName}</p>
          </CardContent>
        </Card>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
          {videos.map((video, index) => (
            <button
              key={`${video.url}-${index}`}
              type="button"
              onClick={() => setActive(index)}
              className={`text-left rounded-xl border p-3 transition-all ${index === active ? "border-accent bg-accent/5" : "border-border/60 hover:border-accent/30"}`}
            >
              <div className="flex items-start gap-3">
                <div className="w-16 h-16 rounded-lg bg-muted flex items-center justify-center shrink-0">
                  <PlayCircle className="h-6 w-6 text-accent" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-foreground leading-tight break-words line-clamp-2">{video.title || sellerName}</p>
                  <p className="text-xs text-muted-foreground mt-1">{video.source === "profile" ? (t("mp.storefront") || "Storefront") : (t("mp.service") || "Service")}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
