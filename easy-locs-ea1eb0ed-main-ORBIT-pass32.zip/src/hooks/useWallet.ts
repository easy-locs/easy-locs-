/**
 * useWallet — LOCS Wallet Manager
 * Manages LOCS balance, transactions, send/request operations, and purchases.
 * 1 LOCS = 1 EUR | Non-refundable, non-withdrawable
 */
import { useState, useCallback, useEffect } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { platformBus } from "@/lib/shared/platform-bus";
import { invokeEdge, bridgeAsync } from "@/lib/shared/orbit-connection";

export interface WalletBalance {
  id: string;
  user_id: string;
  balance: number;
  currency: string;
  frozen_balance: number;
  total_purchased: number;
  total_spent: number;
  updated_at: string;
}

export interface WalletTransaction {
  id: string;
  user_id: string;
  counterpart_user_id: string | null;
  type: string;
  direction: string;
  amount: number;
  currency: string;
  description: string | null;
  status: string;
  original_amount: number | null;
  original_currency: string | null;
  fx_rate_used: number | null;
  fx_source: string | null;
  fx_timestamp: string | null;
  margin_applied: number | null;
  reference_type: string | null;
  reference_id: string | null;
  thread_id: string | null;
  metadata_json: any;
  created_at: string;
}

export function useWallet() {
  const { user } = useAuth();
  const [balance, setBalance] = useState<WalletBalance | null>(null);
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [loading, setLoading] = useState(true);

  const walletScopeFilter = useCallback(() => `user_id.eq.${user?.id},counterpart_user_id.eq.${user?.id}`, [user?.id]);

  const loadWallet = useCallback(async () => {
    if (!user?.id) { setLoading(false); return; }
    setLoading(true);

    try {
      // Load or create LOCS wallet
      const { data: existing, error: existingError } = await supabase
        .from("wallet_balances")
        .select("*")
        .eq("user_id", user.id)
        .eq("currency", "LOCS")
        .maybeSingle();

      if (existingError) throw existingError;

      if (existing) {
        setBalance(existing as unknown as WalletBalance);
        platformBus.emit("wallet:balance_updated", { balance: (existing as any).balance }, "wallet", { userId: user.id });
      } else {
        const { data: created, error: createError } = await supabase
          .from("wallet_balances")
          .insert({ user_id: user.id, balance: 0, currency: "LOCS", frozen_balance: 0, total_purchased: 0, total_spent: 0 } as any)
          .select()
          .single();
        if (createError) throw createError;
        if (created) {
          setBalance(created as unknown as WalletBalance);
          platformBus.emit("wallet:balance_updated", { balance: (created as any).balance }, "wallet", { userId: user.id });
        }
      }

      // Load transactions
      const { data: txns, error: txnError } = await supabase
        .from("wallet_transactions")
        .select("*")
        .or(walletScopeFilter())
        .order("created_at", { ascending: false })
        .limit(100);

      if (txnError) throw txnError;
      setTransactions((txns as unknown as WalletTransaction[]) || []);
    } catch (error) {
      console.error("[wallet] loadWallet failed", error);
      toast.error("Failed to refresh wallet state");
    } finally {
      setLoading(false);
    }
  }, [user?.id, walletScopeFilter]);

  useEffect(() => { loadWallet(); }, [loadWallet]);

  // Realtime
  useEffect(() => {
    if (!user?.id) return;
    const txFilter = walletScopeFilter();
    const channel = supabase
      .channel(`wallet-live-${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "wallet_transactions", filter: txFilter }, () => { loadWallet(); })
      .on("postgres_changes", { event: "*", schema: "public", table: "wallet_balances", filter: `user_id=eq.${user.id}` }, () => { loadWallet(); })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user?.id, loadWallet, walletScopeFilter]);

  /** Purchase LOCS credits via Stripe */
  const purchaseLocs = useCallback(async (amount: number, currency: string) => {
    try {
      const data = await invokeEdge<any>("purchase-locs", { amount, currency }, "POST");
      if (data?.url) {
        platformBus.emit("wallet:locs_purchased", { amount, currency, locsPreview: data.locs_preview }, "wallet", { userId: user?.id });
        window.location.href = data.url;
        return { success: true, url: data.url, locsPreview: data.locs_preview };
      }
      return { success: false, error: "No checkout URL returned" };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }, []);

  /** Send LOCS to another user via secure server-side RPC */
  const sendMoney = useCallback(async (opts: {
    recipientUserId: string;
    amount: number;
    description?: string;
    threadId?: string;
  }) => {
    if (!user?.id) return { success: false, error: "Not authenticated" };
    if (!opts.recipientUserId) return { success: false, error: "Recipient is required" };
    if (opts.recipientUserId === user.id) return { success: false, error: "You cannot send LOCS to yourself" };
    if (!Number.isFinite(opts.amount) || opts.amount <= 0) return { success: false, error: "Invalid amount" };

    const { data, error } = await bridgeAsync(supabase.rpc("transfer_locs", {
      _sender_id: user.id,
      _recipient_id: opts.recipientUserId,
      _amount: opts.amount,
      _description: opts.description || "LOCS Transfer",
      _thread_id: opts.threadId || null,
    }), "wallet:transfer_locs");

    if (error) return { success: false, error: error.message };
    if (data && typeof data === "object" && "error" in (data as any)) {
      return { success: false, error: (data as any).error };
    }

    await loadWallet();
    platformBus.emit("wallet:transfer_sent", { recipientId: opts.recipientUserId, amount: opts.amount }, "wallet", { userId: user.id });
    return { success: true, data };
  }, [user?.id, loadWallet, walletScopeFilter]);

  /** Request LOCS from another user */
  const requestMoney = useCallback(async (opts: {
    fromUserId?: string;
    fromEmail?: string;
    amount: number;
    description?: string;
    threadId?: string;
  }) => {
    if (!user?.id) return { success: false, error: "Not authenticated" };
    if ((!opts.fromUserId && !opts.fromEmail) || !Number.isFinite(opts.amount) || opts.amount <= 0) return { success: false, error: "Invalid request payload" };

    const { error } = await bridgeAsync(supabase.from("wallet_transactions").insert({
      user_id: user.id,
      counterpart_user_id: opts.fromUserId || null,
      type: "request",
      direction: "in",
      amount: opts.amount,
      currency: "LOCS",
      description: opts.description || "LOCS request",
      status: "pending",
      thread_id: opts.threadId || null,
      metadata_json: opts.fromEmail ? { recipient_email: opts.fromEmail } : {},
    } as any), "wallet:request_locs");

    if (error) return { success: false, error: error.message };
    await loadWallet();
    platformBus.emit("wallet:transfer_received", { amount: opts.amount, fromUserId: opts.fromUserId, fromEmail: opts.fromEmail }, "wallet", { userId: user.id });
    return { success: true };
  }, [user?.id, loadWallet, walletScopeFilter]);

  /** Get FX conversion preview */
  const getConversionPreview = useCallback(async (amount: number, currency: string) => {
    try {
      return await invokeEdge<any>(
        "fx-rates?action=convert&from=" + encodeURIComponent(currency) + "&amount=" + encodeURIComponent(String(amount)),
        undefined,
        "GET"
      );
    } catch (err: any) {
      return null;
    }
  }, []);

  return {
    balance,
    transactions,
    loading,
    loadWallet,
    sendMoney,
    requestMoney,
    purchaseLocs,
    getConversionPreview,
  };
}
