import { useState } from "react";
import { supabase } from "@/lib/supabase";

export default function ImageUploader({ onUpload }: any) {
  const [uploading, setUploading] = useState(false);

  const handleUpload = async (e: any) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);

    const fileName = `${Date.now()}-${file.name}`;

    const { error } = await supabase.storage
      .from("media")
      .upload(fileName, file);

    if (!error) {
      const { data } = supabase.storage
        .from("media")
        .getPublicUrl(fileName);

      onUpload(data.publicUrl);
    }

    setUploading(false);
  };

  return (
    <div>
      <input type="file" onChange={handleUpload} />
      {uploading && <p>Uploading...</p>}
    </div>
  );
}
