import { BoostSelector } from "@/components/monetization/BoostSelector";

<BoostSelector
  targetType="shop"
  targetId={shop.id}
  shopId={shop.id}
/>
