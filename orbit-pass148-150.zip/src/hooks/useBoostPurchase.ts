// PASS148 FIXED VERSION
await supabase.rpc("transfer_locs", {
  from_user: user.id,
  amount: config.locs,
  reason: "boost_purchase",
});

await supabase.from("boost_purchases").insert({
  user_id: user.id,
  target_type: opts.targetType,
  target_id: opts.targetId,
  shop_id: opts.shopId || null,
  tier: opts.tier,
  locs_spent: config.locs,
  starts_at: new Date().toISOString(),
  ends_at: endsAt.toISOString(),
  impressions_budget: config.impressions,
  status: "active",
});

await supabase
  .from("storefront_pages")
  .update({
    boost_tier: opts.tier,
    boost_until: endsAt.toISOString(),
  })
  .eq("id", opts.targetId);
