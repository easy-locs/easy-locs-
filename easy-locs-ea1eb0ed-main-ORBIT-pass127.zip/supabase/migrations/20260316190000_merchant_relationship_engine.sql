create table if not exists shop_followers (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null,
  user_id uuid not null,
  created_at timestamptz not null default now()
);

create table if not exists customer_relationship_profiles (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null,
  user_id uuid not null,
  order_count int not null default 0,
  total_spent numeric not null default 0,
  relationship_segment text not null default 'new',
  updated_at timestamptz not null default now()
);

create table if not exists private_shop_offers (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null,
  target_user_id uuid not null,
  title text not null,
  message text,
  created_at timestamptz not null default now()
);
