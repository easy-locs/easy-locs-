import { useMemo, useState } from 'react';
import { CustomerRelationshipProfile, deriveSegment, nextRelationshipAction } from '../lib/merchant-relationship-engine';

export function useMerchantRelationship(shopId: string, customerId: string) {
  const [profile, setProfile] = useState<CustomerRelationshipProfile>({
    customerId,
    shopId,
    isFollowing: false,
    isFavorite: false,
    orderCount: 0,
    totalSpent: 0,
    lastOrderAt: null,
    segment: 'new',
  });

  const action = useMemo(() => nextRelationshipAction(profile), [profile]);

  return {
    profile,
    action,
    followShop: () => setProfile((p) => ({ ...p, isFollowing: true })),
    favoriteShop: () => setProfile((p) => ({ ...p, isFavorite: true })),
    registerOrder: (amount: number) => setProfile((p) => ({
      ...p,
      orderCount: p.orderCount + 1,
      totalSpent: p.totalSpent + amount,
      lastOrderAt: new Date().toISOString(),
      segment: deriveSegment(p.orderCount + 1, p.totalSpent + amount),
    })),
  };
}
