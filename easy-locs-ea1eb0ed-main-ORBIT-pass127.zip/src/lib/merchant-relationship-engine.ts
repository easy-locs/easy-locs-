export type RelationshipAction = 'follow_shop' | 'favorite_shop' | 'reorder_fast' | 'private_offer';

export interface CustomerRelationshipProfile {
  customerId: string;
  shopId: string;
  isFollowing: boolean;
  isFavorite: boolean;
  orderCount: number;
  totalSpent: number;
  lastOrderAt?: string | null;
  segment: 'new' | 'repeat' | 'vip';
}

export function deriveSegment(orderCount: number, totalSpent: number): CustomerRelationshipProfile['segment'] {
  if (orderCount >= 5 || totalSpent >= 1000) return 'vip';
  if (orderCount >= 2) return 'repeat';
  return 'new';
}

export function nextRelationshipAction(profile: CustomerRelationshipProfile): RelationshipAction {
  if (!profile.isFollowing) return 'follow_shop';
  if (!profile.isFavorite) return 'favorite_shop';
  if (profile.orderCount >= 1) return 'reorder_fast';
  return 'private_offer';
}
