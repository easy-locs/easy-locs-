import React from 'react';
import { useMerchantRelationship } from '../../hooks/useMerchantRelationship';
import ShopFollowBar from '../../components/relationship/ShopFollowBar';
import RecurringCustomerCard from '../../components/relationship/RecurringCustomerCard';
import PrivateOfferCard from '../../components/relationship/PrivateOfferCard';

export default function MerchantRelationshipStudio() {
  const rel = useMerchantRelationship('demo-shop', 'demo-customer');

  return (
    <main>
      <h1>Merchant Relationship Studio</h1>
      <ShopFollowBar isFollowing={rel.profile.isFollowing} onFollow={rel.followShop} />
      <RecurringCustomerCard profile={rel.profile} />
      <button onClick={() => rel.registerOrder(120)}>Register repeat order</button>
      <PrivateOfferCard onSend={() => {}} />
    </main>
  );
}
