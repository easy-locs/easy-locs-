import { deriveSegment, nextRelationshipAction } from '../lib/merchant-relationship-engine';

console.assert(deriveSegment(1, 50) === 'new');
console.assert(deriveSegment(2, 50) === 'repeat');
console.assert(deriveSegment(5, 50) === 'vip');
console.assert(nextRelationshipAction({ customerId:'c', shopId:'s', isFollowing:false, isFavorite:false, orderCount:0, totalSpent:0, segment:'new'}) === 'follow_shop');
