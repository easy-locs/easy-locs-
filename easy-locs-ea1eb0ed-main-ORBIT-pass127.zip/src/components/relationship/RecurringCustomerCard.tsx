import React from 'react';
import { CustomerRelationshipProfile } from '../../lib/merchant-relationship-engine';

export default function RecurringCustomerCard({ profile }: { profile: CustomerRelationshipProfile }) {
  return (
    <div>
      <h3>Customer relationship</h3>
      <p>Segment: {profile.segment}</p>
      <p>Orders: {profile.orderCount}</p>
      <p>Total spent: {profile.totalSpent}</p>
    </div>
  );
}
