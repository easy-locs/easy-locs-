import React from 'react';

export default function PrivateOfferCard({ onSend }: { onSend: () => void }) {
  return (
    <div>
      <h3>Private offer</h3>
      <p>Reward repeat customers with a direct offer.</p>
      <button onClick={onSend}>Send private offer</button>
    </div>
  );
}
