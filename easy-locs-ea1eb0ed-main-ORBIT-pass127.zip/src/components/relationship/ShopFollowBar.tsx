import React from 'react';

export default function ShopFollowBar({ isFollowing, onFollow }: { isFollowing: boolean; onFollow: () => void }) {
  return (
    <div>
      <strong>{isFollowing ? 'Following shop' : 'Stay connected with this shop'}</strong>
      {!isFollowing && <button onClick={onFollow}>Follow shop</button>}
    </div>
  );
}
