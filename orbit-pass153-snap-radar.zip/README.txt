ORBIT PASS153 — Snap-style Map / Radar Premium Redesign

Focus:
- premium map shell
- snap-like radar HUD
- cleaner visual hierarchy
- stronger CTA bars
- mobile-first visual polish

Note:
This is a structured code scaffold for integration.
It is not runtime-validated in this environment.
