Direction:
- move map / radar from 'technical' to 'premium product'
- snap-like HUD
- stronger visual layers
- high-end CTA cards
- cleaner dark futuristic hierarchy

Next natural step:
- integrate this style into the real live map/radar components
- then polish Explore/Home to match the same language
