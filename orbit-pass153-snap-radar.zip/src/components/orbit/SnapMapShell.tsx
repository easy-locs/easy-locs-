import React from "react";

export default function SnapMapShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative overflow-hidden rounded-[28px] border border-white/10 bg-[#07111f] shadow-2xl">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(34,211,238,0.14),transparent_38%),radial-gradient(circle_at_bottom,rgba(139,92,246,0.14),transparent_34%)]" />
      <div className="pointer-events-none absolute inset-0 opacity-[0.06] [background-image:linear-gradient(to_bottom,transparent,rgba(255,255,255,0.35),transparent)] [background-size:100%_14px]" />
      <div className="relative min-h-[420px]">{children}</div>
    </div>
  );
}
