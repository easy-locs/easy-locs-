import React from "react";

export default function RadarHudHeader({
  title = "Live Radar",
  subtitle = "Real-time nearby activity",
  liveCount = 0,
}: {
  title?: string;
  subtitle?: string;
  liveCount?: number;
}) {
  return (
    <div className="absolute left-4 right-4 top-4 z-[500] flex items-start justify-between gap-3">
      <div className="rounded-2xl border border-white/10 bg-black/35 px-4 py-3 backdrop-blur-xl">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-2 rounded-full border border-red-500/20 bg-red-500/10 px-2 py-1 text-[10px] font-semibold uppercase tracking-wide text-red-400">
            <span className="h-2 w-2 rounded-full bg-red-500" />
            Live
          </span>
          <span className="text-[10px] font-medium text-cyan-300">{liveCount} active</span>
        </div>
        <div className="mt-2 text-base font-bold text-white">{title}</div>
        <div className="text-xs text-white/60">{subtitle}</div>
      </div>

      <div className="rounded-2xl border border-cyan-400/15 bg-black/35 px-3 py-2 text-right backdrop-blur-xl">
        <div className="text-[10px] uppercase tracking-wide text-cyan-300/80">Mode</div>
        <div className="text-sm font-semibold text-white">Snap-level</div>
      </div>
    </div>
  );
}
