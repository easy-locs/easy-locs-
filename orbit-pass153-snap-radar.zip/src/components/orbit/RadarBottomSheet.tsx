import React from "react";

export default function RadarBottomSheet() {
  return (
    <div className="absolute bottom-0 left-0 right-0 z-[500] rounded-t-[28px] border-t border-white/10 bg-black/45 px-4 pb-5 pt-3 backdrop-blur-2xl">
      <div className="mx-auto mb-3 h-1.5 w-12 rounded-full bg-white/20" />
      <div className="grid grid-cols-3 gap-2">
        <button className="rounded-2xl border border-white/10 bg-white/5 px-3 py-3 text-left transition-all active:scale-[0.98]">
          <div className="text-xs font-semibold text-white">Nearby</div>
          <div className="mt-1 text-[11px] text-white/55">Fast scan</div>
        </button>
        <button className="rounded-2xl border border-white/10 bg-white/5 px-3 py-3 text-left transition-all active:scale-[0.98]">
          <div className="text-xs font-semibold text-white">Drivers</div>
          <div className="mt-1 text-[11px] text-white/55">Live movement</div>
        </button>
        <button className="rounded-2xl border border-cyan-400/20 bg-cyan-400/10 px-3 py-3 text-left transition-all active:scale-[0.98]">
          <div className="text-xs font-semibold text-cyan-300">Action</div>
          <div className="mt-1 text-[11px] text-cyan-100/70">Open feed</div>
        </button>
      </div>
    </div>
  );
}
