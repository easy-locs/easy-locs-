import React from "react";

export default function PremiumEntityCard({
  title = "Entity title",
  subtitle = "Subtitle",
  meta = "2.4 km · Live",
  cta = "Open",
}: {
  title?: string;
  subtitle?: string;
  meta?: string;
  cta?: string;
}) {
  return (
    <button className="w-full rounded-[22px] border border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.09),rgba(255,255,255,0.04))] p-3 text-left shadow-[0_14px_40px_rgba(0,0,0,0.24)] backdrop-blur-xl transition-all duration-150 active:scale-[0.985]">
      <div className="flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-400/12 text-lg shadow-inner shadow-cyan-400/10">
          ✦
        </div>
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-bold text-white">{title}</div>
          <div className="truncate text-xs text-white/60">{subtitle}</div>
          <div className="mt-1 text-[11px] font-medium text-cyan-300">{meta}</div>
        </div>
        <div className="rounded-2xl bg-white px-3 py-2 text-[11px] font-semibold text-slate-900">{cta}</div>
      </div>
    </button>
  );
}
