import React from "react";
import SnapMapShell from "./SnapMapShell";
import RadarHudHeader from "./RadarHudHeader";
import RadarBottomSheet from "./RadarBottomSheet";

export default function SnapRadarScene() {
  return (
    <SnapMapShell>
      <RadarHudHeader liveCount={28} />
      <div className="absolute inset-0">
        <div className="absolute left-1/2 top-1/2 h-[320px] w-[320px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-cyan-400/12" />
        <div className="absolute left-1/2 top-1/2 h-[240px] w-[240px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-cyan-400/10" />
        <div className="absolute left-1/2 top-1/2 h-[160px] w-[160px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-cyan-400/10" />
        <div className="absolute left-1/2 top-1/2 h-[4px] w-[160px] origin-left -translate-y-1/2 rounded-full bg-gradient-to-r from-cyan-400/0 via-cyan-300/80 to-cyan-300/0 rotate-[18deg]" />
        <div className="absolute left-[28%] top-[40%] h-3 w-3 rounded-full bg-cyan-300 shadow-[0_0_18px_rgba(34,211,238,0.7)]" />
        <div className="absolute left-[62%] top-[34%] h-3 w-3 rounded-full bg-violet-400 shadow-[0_0_18px_rgba(139,92,246,0.7)]" />
        <div className="absolute left-[56%] top-[60%] h-3 w-3 rounded-full bg-emerald-400 shadow-[0_0_18px_rgba(34,197,94,0.7)]" />
      </div>
      <RadarBottomSheet />
    </SnapMapShell>
  );
}
