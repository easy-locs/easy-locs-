import React from "react";
import SnapRadarScene from "@/components/orbit/SnapRadarScene";
import PremiumEntityCard from "@/components/orbit/PremiumEntityCard";

export default function Pass153SnapRadarDemo() {
  return (
    <main className="mx-auto max-w-3xl space-y-4 p-4 bg-[#030712] min-h-screen">
      <SnapRadarScene />
      <div className="space-y-3">
        <PremiumEntityCard title="Pizza Times Live" subtitle="Fast delivery · Premium visibility" meta="1.2 km · 12 min" cta="Open" />
        <PremiumEntityCard title="Driver Alpha" subtitle="Courier nearby" meta="0.8 km · Active" cta="Track" />
      </div>
    </main>
  );
}
