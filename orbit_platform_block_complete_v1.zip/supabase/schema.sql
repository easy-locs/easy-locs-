create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id text not null,
  content text null,
  ciphertext text null,
  created_at timestamptz not null default now()
);

create table if not exists wallet_transactions (
  id uuid primary key default gen_random_uuid(),
  sender_orbit_id text not null,
  receiver_orbit_id text not null,
  amount_minor bigint not null,
  currency text not null,
  reference text not null,
  crypto_id text not null,
  status text not null default 'pending',
  signed_payload_b64 text not null,
  created_at timestamptz not null default now()
);

create table if not exists property_transactions (
  id uuid primary key default gen_random_uuid(),
  property_id text not null,
  type text not null,
  amount numeric not null,
  currency text not null,
  note text null,
  created_at timestamptz not null default now()
);

create table if not exists listings (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null,
  price numeric not null,
  shop_logo text not null,
  created_at timestamptz not null default now()
);

create table if not exists delivery_jobs (
  id uuid primary key default gen_random_uuid(),
  order_id text null,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);
