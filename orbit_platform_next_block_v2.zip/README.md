# Orbit Platform Block Complete V1

This block focuses on:
- Marketplace quality gate
- Property accounting separation
- Wallet sync
- Chat payment flow
- Delivery orchestration

## Run
1. Copy `.env.example` to `.env`
2. Fill Supabase credentials
3. Apply `supabase/schema.sql`
4. `npm install`
5. `npm run dev`
