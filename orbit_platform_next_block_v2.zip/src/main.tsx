import React from "react";
import ReactDOM from "react-dom/client";
import App from "@/App";
import "@/styles.css";
import { bootstrapApp } from "@/bootstrap";

void bootstrapApp();

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
