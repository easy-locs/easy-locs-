import { useState } from "react";
import { useMessages } from "@/hooks/useMessages";
import { emit } from "@/core/relay";

export function ChatPage() {
  const [text, setText] = useState("");
  const messages = useMessages("demo-conversation");

  function send() {
    emit("PAYMENT_IN_CHAT", {
      conversation_id: "demo-conversation",
      sender_orbit_id: "demo-user",
      receiver_orbit_id: "demo-peer",
      amount_minor: 2500,
      currency: "AED",
      reference: "TEMP",
      crypto_id: crypto.randomUUID(),
      status: "pending",
      signed_payload_b64: "demo-signature"
    });
  }

  return (
    <>
      <div className="card hero">
        <h1 className="title">Communication</h1>
        <p className="muted">Chat and payment system wired to wallet engine.</p>
      </div>
      <div className="card">
        {messages.map((m, i) => <div key={i} className="msg">{m.content ?? m.ciphertext ?? "message"}</div>)}
        <textarea className="textarea" value={text} onChange={(e)=>setText(e.target.value)} placeholder="Write..." />
        <div className="row">
          <button className="btn secondary">Send message</button>
          <button className="btn" onClick={send}>Send payment</button>
        </div>
      </div>
    </>
  );
}
