import { useState } from "react";
import { validateListing } from "@/validators/listing";
import { usePlatformStore } from "@/store/platformStore";

export function MarketplacePage() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("45");
  const [shopLogo, setShopLogo] = useState("https://logo.example");
  const setQualityScore = usePlatformStore((s) => s.setQualityScore);
  const qualityScore = usePlatformStore((s) => s.qualityScore);
  const [status, setStatus] = useState("");

  function validate() {
    try {
      const score = validateListing({
        title, description, price: Number(price), images: ["a","b"], shopLogo
      });
      setQualityScore(score);
      setStatus("Listing is clean and publishable");
    } catch (e:any) {
      setStatus(e.message);
    }
  }

  return (
    <>
      <div className="card hero"><h1 className="title">Marketplace</h1><p className="muted">Quality gating and anti-brouillon publishing.</p></div>
      <div className="card">
        <input className="input" placeholder="Title" value={title} onChange={(e)=>setTitle(e.target.value)} />
        <textarea className="textarea" placeholder="Description" value={description} onChange={(e)=>setDescription(e.target.value)} />
        <input className="input" placeholder="Price" value={price} onChange={(e)=>setPrice(e.target.value)} />
        <input className="input" placeholder="Shop logo URL" value={shopLogo} onChange={(e)=>setShopLogo(e.target.value)} />
        <div className="row">
          <button className="btn" onClick={validate}>Validate listing</button>
          <span className="pill">Score {qualityScore}</span>
        </div>
        {status && <div className="msg">{status}</div>}
      </div>
    </>
  );
}
