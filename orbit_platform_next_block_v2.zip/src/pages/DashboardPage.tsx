import { usePlatformStore } from "@/store/platformStore";

export function DashboardPage() {
  const issues = usePlatformStore((s) => s.issues);
  return (
    <>
      <div className="card hero">
        <div className="row">
          <div>
            <h1 className="title">Orbit Platform Block Complete</h1>
            <p className="muted">Marketplace + Property + Wallet sync + Delivery orchestration.</p>
          </div>
          <span className="pill">block complete</span>
        </div>
      </div>
      <div className="grid-3">
        <div className="card"><div className="h2">Marketplace</div><div className="muted">clean publish, anti-brouillon, quality gating.</div></div>
        <div className="card"><div className="h2">Property</div><div className="muted">separated dashboard and accounting.</div></div>
        <div className="card"><div className="h2">Wallet sync</div><div className="muted">payment in chat to transaction flow.</div></div>
      </div>
      <div className="card">
        <div className="h2">Runtime issues</div>
        {issues.length === 0 ? <div className="pill">No blocking runtime issues detected</div> : issues.map((i, idx) => <div key={idx} className="msg">{i.area}: {i.message}</div>)}
      </div>
    </>
  );
}
