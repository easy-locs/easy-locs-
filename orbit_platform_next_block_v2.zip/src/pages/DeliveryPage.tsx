export function DeliveryPage() {
  return (
    <>
      <div className="card hero">
        <h1 className="title">Delivery</h1>
        <p className="muted">Transaction complete should create delivery through orchestrator.</p>
      </div>
      <div className="card">
        <div className="h2">Flow</div>
        <ul>
          <li>Chat payment</li>
          <li>Wallet transaction</li>
          <li>Transaction completed</li>
          <li>Delivery created</li>
          <li>Proof and release in next pass</li>
        </ul>
      </div>
    </>
  );
}
