import { usePropertyLedger } from "@/hooks/usePropertyLedger";

export function PropertyPage() {
  const rows = usePropertyLedger("demo-property");
  const income = rows.filter((r)=>r.type==="income").reduce((s,r)=>s+Number(r.amount||0),0);
  const expenses = rows.filter((r)=>r.type==="expense").reduce((s,r)=>s+Number(r.amount||0),0);

  return (
    <>
      <div className="card hero">
        <h1 className="title">Property</h1>
        <p className="muted">Separated property management with accounting apart.</p>
      </div>
      <div className="grid-2">
        <div className="card"><div className="muted">Income</div><div className="kpi">{income.toFixed(2)}</div></div>
        <div className="card"><div className="muted">Expenses</div><div className="kpi">{expenses.toFixed(2)}</div></div>
      </div>
      <div className="card">
        <div className="h2">Ledger</div>
        {rows.map((r, i)=><div key={i} className="msg"><div className="row"><strong>{r.amount} {r.currency}</strong><span className="pill">{r.type}</span></div><div className="muted">{r.note ?? "-"}</div></div>)}
      </div>
    </>
  );
}
