import { useTransactions } from "@/hooks/useTransactions";

export function WalletPage() {
  const txs = useTransactions();
  const balance = txs.filter((t)=>t.status==="completed").reduce((s,t)=>s+(t.amount_minor||0),0);
  return (
    <>
      <div className="card hero">
        <h1 className="title">Wallet</h1>
        <p className="muted">Visible balance, references, history, payment trail.</p>
      </div>
      <div className="grid-2">
        <div className="card"><div className="muted">Balance</div><div className="kpi">{(balance/100).toFixed(2)} AED</div></div>
        <div className="card"><div className="h2">QR / Receive / Settings</div><div className="muted">Reserved block for next pass.</div></div>
      </div>
      <div className="card">
        <div className="h2">History</div>
        {txs.map((tx, i)=>(
          <div key={i} className="msg">
            <div className="row"><strong>{((tx.amount_minor||0)/100).toFixed(2)} {tx.currency}</strong><span className="pill">{tx.status}</span></div>
            <div className="code">{tx.reference}</div>
            <div className="code">{tx.crypto_id}</div>
          </div>
        ))}
      </div>
    </>
  );
}
