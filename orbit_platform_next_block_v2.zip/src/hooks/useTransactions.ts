import { useEffect, useState } from "react";
import { fetchTransactions } from "@/services/walletService";

export function useTransactions() {
  const [transactions, setTransactions] = useState<any[]>([]);
  useEffect(() => { void fetchTransactions().then(setTransactions).catch(console.error); }, []);
  return transactions;
}
