import { useEffect, useState } from "react";
import { fetchPropertyTransactions } from "@/services/propertyService";

export function usePropertyLedger(propertyId:string) {
  const [rows, setRows] = useState<any[]>([]);
  useEffect(() => { void fetchPropertyTransactions(propertyId).then(setRows).catch(console.error); }, [propertyId]);
  return rows;
}
