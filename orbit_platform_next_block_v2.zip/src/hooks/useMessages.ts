import { useEffect, useState } from "react";
import { fetchMessages } from "@/services/chatService";

export function useMessages(conversationId:string) {
  const [messages, setMessages] = useState<any[]>([]);
  useEffect(() => { void fetchMessages(conversationId).then(setMessages).catch(console.error); }, [conversationId]);
  return messages;
}
