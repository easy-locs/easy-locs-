import { emit, on } from "@/core/relay";
import { enqueue } from "@/core/queue";
import { createTransaction } from "@/services/walletService";
import { createDelivery } from "@/services/deliveryService";

let booted = false;

export function initOrchestrator() {
  if (booted) return;
  booted = true;

  on("PAYMENT_IN_CHAT", (payload:any) => {
    enqueue(async () => {
      const tx = await createTransaction(payload);
      emit("TX_CREATED", tx);
    });
  });

  on("TX_COMPLETED", (payload:any) => {
    enqueue(async () => {
      const delivery = await createDelivery(payload.order_id ?? payload.id);
      emit("DELIVERY_CREATED", delivery);
    });
  });
}
