export function validateListing(input:{title:string;description:string;images:string[];price:number;shopLogo?:string|null}) {
  if (!input.shopLogo) throw new Error("Shop logo required");
  if (input.title.trim().length < 10) throw new Error("Title too short");
  if (input.description.trim().length < 30) throw new Error("Description too short");
  if (input.images.length < 2) throw new Error("At least 2 images required");
  if (input.price <= 0) throw new Error("Price required");
  return 100;
}
