export function runtimeAudit() {
  const issues:string[] = [];
  if (!import.meta.env.VITE_SUPABASE_URL) issues.push("Missing Supabase URL");
  if (!import.meta.env.VITE_SUPABASE_ANON_KEY) issues.push("Missing Supabase anon key");
  return issues;
}
