type Task = () => Promise<void>;
const queue: Task[] = [];
let running = false;

export function enqueue(task: Task) {
  queue.push(task);
  void drain();
}

async function drain() {
  if (running) return;
  running = true;
  while (queue.length) {
    const task = queue.shift()!;
    try { await task(); }
    catch (e) { console.error("[queue]", e); queue.push(task); break; }
  }
  running = false;
}
