import { create } from "zustand";

type Issue = { area: string; message: string };
type State = {
  balance: number;
  qualityScore: number;
  issues: Issue[];
  addIssue: (issue: Issue) => void;
  setBalance: (v: number) => void;
  setQualityScore: (v: number) => void;
};

export const usePlatformStore = create<State>((set) => ({
  balance: 0,
  qualityScore: 0,
  issues: [],
  addIssue: (issue) => set((s) => ({ issues: [...s.issues, issue] })),
  setBalance: (balance) => set({ balance }),
  setQualityScore: (qualityScore) => set({ qualityScore })
}));
