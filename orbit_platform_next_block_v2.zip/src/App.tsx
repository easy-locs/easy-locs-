import { BrowserRouter, NavLink, Route, Routes } from "react-router-dom";
import { DashboardPage } from "@/pages/DashboardPage";
import { ChatPage } from "@/pages/ChatPage";
import { WalletPage } from "@/pages/WalletPage";
import { MarketplacePage } from "@/pages/MarketplacePage";
import { PropertyPage } from "@/pages/PropertyPage";
import { DeliveryPage } from "@/pages/DeliveryPage";

function BottomNav() {
  const items = [
    ["/", "Core"],
    ["/chat", "Chat"],
    ["/wallet", "Wallet"],
    ["/marketplace", "Market"],
    ["/property", "Property"],
    ["/delivery", "Delivery"]
  ] as const;
  return (
    <nav className="bottom">
      {items.map(([to, label]) => (
        <NavLink key={to} to={to} className={({ isActive }) => isActive ? "nav active" : "nav"}>
          {label}
        </NavLink>
      ))}
    </nav>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <div className="shell">
        <div className="wrap">
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/chat" element={<ChatPage />} />
            <Route path="/wallet" element={<WalletPage />} />
            <Route path="/marketplace" element={<MarketplacePage />} />
            <Route path="/property" element={<PropertyPage />} />
            <Route path="/delivery" element={<DeliveryPage />} />
          </Routes>
        </div>
        <BottomNav />
      </div>
    </BrowserRouter>
  );
}
