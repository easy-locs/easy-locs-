import { supabase } from "@/lib/supabase";

export async function createListing(payload:any) {
  const { data, error } = await supabase.from("listings").insert(payload).select().single();
  if (error) throw error;
  return data;
}
