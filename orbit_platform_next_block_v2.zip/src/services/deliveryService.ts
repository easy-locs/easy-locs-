import { supabase } from "@/lib/supabase";

export async function createDelivery(orderId:string) {
  const { data, error } = await supabase.from("delivery_jobs").insert({ order_id: orderId, status: "pending" }).select().single();
  if (error) throw error;
  return data;
}
