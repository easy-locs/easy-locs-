import { supabase } from "@/lib/supabase";

export async function fetchTransactions() {
  const { data, error } = await supabase.from("wallet_transactions").select("*").order("created_at",{ascending:false});
  if (error) throw error;
  return data ?? [];
}

export async function createTransaction(payload:any) {
  const { data, error } = await supabase.from("wallet_transactions").insert(payload).select().single();
  if (error) throw error;
  return data;
}
