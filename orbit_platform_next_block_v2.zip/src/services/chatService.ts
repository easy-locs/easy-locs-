import { supabase } from "@/lib/supabase";

export async function fetchMessages(conversationId:string) {
  const { data, error } = await supabase.from("messages").select("*").eq("conversation_id", conversationId).order("created_at",{ascending:true});
  if (error) throw error;
  return data ?? [];
}

export async function sendMessage(payload:any) {
  const { data, error } = await supabase.from("messages").insert(payload).select().single();
  if (error) throw error;
  return data;
}
