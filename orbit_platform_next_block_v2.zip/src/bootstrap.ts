import { initOrchestrator } from "@/engine/orchestrator";
import { runtimeAudit } from "@/core/audit";
import { usePlatformStore } from "@/store/platformStore";

export async function bootstrapApp() {
  initOrchestrator();
  const issues = runtimeAudit();
  issues.forEach((message) => usePlatformStore.getState().addIssue({ area: "runtime", message }));
}
