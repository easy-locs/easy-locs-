-- PASS136: Full Shell Integration scaffold
create table if not exists public.orbit_shell_preferences (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  preferred_home text default 'smart',
  quick_actions jsonb default '[]'::jsonb,
  updated_at timestamptz default now(),
  created_at timestamptz default now()
);
