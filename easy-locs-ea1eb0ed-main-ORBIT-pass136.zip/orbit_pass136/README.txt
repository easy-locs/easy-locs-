ORBIT pass136 scaffold
- Full shell integration base
- Unified bottom navigation
- Contextual quick actions
- Migration scaffold for shell preferences
