import { useMemo } from 'react';
import { resolveShellSection, shellRoutes } from '@/lib/full-shell-integration';

export function useFullShell(pathname: string) {
  const activeSection = useMemo(() => resolveShellSection(pathname), [pathname]);
  const quickActions = useMemo(() => {
    switch (activeSection) {
      case 'shops':
        return ['Open Shop', 'Add Item', 'Orders'];
      case 'orders':
        return ['Track', 'Reorder', 'Support'];
      case 'search':
        return ['Nearby', 'Top Rated', 'Deals'];
      default:
        return ['Search', 'Orders', 'Profile'];
    }
  }, [activeSection]);

  return { activeSection, routes: shellRoutes, quickActions };
}
