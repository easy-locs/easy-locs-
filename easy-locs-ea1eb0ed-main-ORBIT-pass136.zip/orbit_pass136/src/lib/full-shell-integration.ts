export type ShellSection = 'home' | 'search' | 'shops' | 'orders' | 'me';

export interface ShellRouteConfig {
  section: ShellSection;
  path: string;
  label: string;
  requiresAuth?: boolean;
}

export const shellRoutes: ShellRouteConfig[] = [
  { section: 'home', path: '/', label: 'Home' },
  { section: 'search', path: '/discover', label: 'Search' },
  { section: 'shops', path: '/dashboard/my-shop', label: 'Shops', requiresAuth: true },
  { section: 'orders', path: '/my-orders', label: 'Orders', requiresAuth: true },
  { section: 'me', path: '/profile', label: 'Me', requiresAuth: true },
];

export function resolveShellSection(pathname: string): ShellSection {
  const match = shellRoutes.find((r) => pathname === r.path || pathname.startsWith(r.path + '/'));
  return match?.section ?? 'home';
}
