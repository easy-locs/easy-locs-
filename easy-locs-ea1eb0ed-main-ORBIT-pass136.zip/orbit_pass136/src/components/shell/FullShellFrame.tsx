import React from 'react';
import { useFullShell } from '@/hooks/useFullShell';

export function FullShellFrame({ pathname, children }: { pathname: string; children: React.ReactNode }) {
  const { activeSection, routes, quickActions } = useFullShell(pathname);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-20 border-b bg-background/95 backdrop-blur px-4 py-3">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-semibold">ORBIT</div>
            <div className="text-xs opacity-70">{activeSection}</div>
          </div>
          <div className="flex gap-2 text-xs">
            {quickActions.map((item) => (
              <button key={item} className="rounded-full border px-3 py-1">{item}</button>
            ))}
          </div>
        </div>
      </header>
      <main className="pb-20">{children}</main>
      <nav className="fixed bottom-0 left-0 right-0 border-t bg-background/95 backdrop-blur px-2 py-2">
        <div className="grid grid-cols-5 gap-2">
          {routes.map((route) => (
            <button
              key={route.section}
              className={`rounded-xl px-2 py-2 text-xs ${route.section === activeSection ? 'bg-primary/10 font-semibold' : 'opacity-75'}`}
            >
              {route.label}
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
