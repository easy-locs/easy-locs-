import { resolveShellSection } from '@/lib/full-shell-integration';

console.assert(resolveShellSection('/') === 'home');
console.assert(resolveShellSection('/discover') === 'search');
console.assert(resolveShellSection('/my-orders') === 'orders');
console.assert(resolveShellSection('/dashboard/my-shop') === 'shops');
