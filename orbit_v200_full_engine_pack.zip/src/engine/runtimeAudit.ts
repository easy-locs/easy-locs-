type AuditFinding = {
  level: "info" | "warn" | "error";
  module: string;
  message: string;
};

export function runRuntimeAudit(): AuditFinding[] {
  const findings: AuditFinding[] = [];

  if (!window.indexedDB) {
    findings.push({ level: "error", module: "security", message: "IndexedDB unavailable for local key storage" });
  }

  if (!window.crypto?.subtle) {
    findings.push({ level: "error", module: "crypto", message: "Web Crypto subtle API unavailable" });
  }

  if (!navigator.onLine) {
    findings.push({ level: "warn", module: "network", message: "Device appears offline" });
  }

  return findings;
}
