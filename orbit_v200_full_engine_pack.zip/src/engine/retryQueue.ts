type QueueTask = () => Promise<void>;

const queue: QueueTask[] = [];
let running = false;

export function enqueueRetry(task: QueueTask) {
  queue.push(task);
  void flushQueue();
}

export async function flushQueue() {
  if (running) return;
  running = true;
  while (queue.length) {
    const task = queue.shift()!;
    try {
      await task();
    } catch (error) {
      console.error("[retry-queue]", error);
      queue.push(task);
      break;
    }
  }
  running = false;
}
