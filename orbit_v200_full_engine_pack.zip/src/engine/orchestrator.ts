import { emit, on } from "@/core/relay";

type Handler = (payload: any) => Promise<void> | void;

export class OrbitOrchestrator {
  private started = false;

  start() {
    if (this.started) return;
    this.started = true;

    this.handle("CHAT_MESSAGE_SENT", async (msg) => {
      if (msg?.type === "payment") {
        emit("WALLET_CREATE_TX", msg);
      }
    });

    this.handle("WALLET_TX_CREATED", async (tx) => {
      emit("CHAT_SYSTEM_MESSAGE", {
        conversationId: tx.chat_conversation_id ?? "demo-conversation",
        text: `Payment ${tx.reference} created`,
      });
    });

    this.handle("PAYMENT_CONFIRMED", async (tx) => {
      emit("DELIVERY_CREATE_FROM_PAYMENT", tx);
    });

    this.handle("DELIVERY_COMPLETED", async (job) => {
      emit("ESCROW_RELEASE_REQUEST", job);
    });

    this.handle("RUNTIME_RESYNC", async () => {
      emit("AUDIT_RUNTIME", { scope: "full-resync" });
    });
  }

  private handle(event: string, handler: Handler) {
    on(event, handler);
  }
}

export const orbitOrchestrator = new OrbitOrchestrator();
