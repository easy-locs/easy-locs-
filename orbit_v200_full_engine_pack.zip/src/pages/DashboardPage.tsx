export function DashboardPage() {
  return (
    <>
      <div className="card hero">
        <div className="row">
          <div>
            <h1 className="title">LOCS Ghost V1</h1>
            <p className="sub">UI-ready pack for Lovable with hardening layers, encrypted envelopes, wallet signing, and relay privacy model.</p>
          </div>
          <span className="pill">UI + crypto foundation</span>
        </div>
      </div>

      <div className="grid-3">
        <div className="card">
          <div className="h2">Identity</div>
          <div className="muted">Orbit ID without phone numbers, device-scoped public bundles, signed prekeys.</div>
        </div>
        <div className="card">
          <div className="h2">Chat</div>
          <div className="muted">Encrypted secure envelopes, local decrypt flow, ghost TTL state, replay guard.</div>
        </div>
        <div className="card">
          <div className="h2">Wallet</div>
          <div className="muted">Signed wallet payloads, human references, crypto IDs, chat-linked transactions.</div>
        </div>
      </div>

      <div className="card">
        <div className="h2">What this pack is for</div>
        <ul>
          <li>Push into Lovable and build the visible UI without rewriting the security boundaries.</li>
          <li>Use Supabase tables for storage and synchronization.</li>
          <li>Extend toward native keystore / WASM crypto later without breaking UI architecture.</li>
        </ul>
      </div>
    </>
  );
}
