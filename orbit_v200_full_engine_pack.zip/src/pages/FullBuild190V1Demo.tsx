import React from "react";
import OrbitPageShell from "@/components/ui/OrbitPageShell";
import GrowthHero from "@/components/growth/GrowthHero";
import OrbitFutureMenu from "@/components/navigation/OrbitFutureMenu";
import SellerMissionWorkspace from "@/components/workspace/SellerMissionWorkspace";
import CommunicationInbox from "@/components/communication/CommunicationInbox";
import GhostEntrySheet from "@/components/communication/GhostEntrySheet";
import ShopBrandGate from "@/components/shop/ShopBrandGate";
import ListingQualityGate from "@/components/listings/ListingQualityGate";
import OrbitOperationsBoard from "@/components/workspace/OrbitOperationsBoard";
import MenuImageBatchUploader from "@/components/images/MenuImageBatchUploader";
import OrbitCard from "@/components/ui/OrbitCard";
import { ORBIT_V1_STATUS } from "@/lib/app/v1-status";

export default function FullBuild190V1Demo() {
  return (
    <OrbitPageShell>
      <div className="space-y-4">
        <GrowthHero />
        <OrbitFutureMenu activeKey="communication" />

        <div className="grid gap-4 lg:grid-cols-2">
          <ShopBrandGate
            profile={{
              id: "shop-1",
              name: "Pizza Times Future",
              logoUrl: "https://example.com/logo.png",
              coverUrl: "https://example.com/cover.jpg",
              description: "Premium pizza delivery brand for fast, clean, and scalable publication inside Orbit.",
              verified: true,
              rating: 4.8,
            }}
          />
          <ListingQualityGate
            draft={{
              title: "Signature Truffle Burrata Pizza",
              description:
                "Product: wood-fired burrata pizza\nDetails: truffle cream, basil, mozzarella, black olives\nPrice: 49 AED\nDelivery: 24/7 in Dubai Marina and JLT",
              price: 49,
              category: "food",
              logoLocked: true,
              images: [{ url: "a" }, { url: "b" }],
            }}
          />
        </div>

        <div className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
          <SellerMissionWorkspace />
          <div className="space-y-4">
            <CommunicationInbox />
            <GhostEntrySheet />
          </div>
        </div>

        <MenuImageBatchUploader />
        <OrbitOperationsBoard />

        <OrbitCard className="p-4">
          <div className="text-[11px] uppercase tracking-[0.22em] text-white/55">V1 status</div>
          <div className="mt-3 grid gap-2 md:grid-cols-2">
            {ORBIT_V1_STATUS.map((item) => (
              <div key={item.id} className="rounded-2xl border border-white/10 bg-white/5 p-3">
                <div className="text-sm font-semibold text-white">{item.title}</div>
                <div className="mt-1 text-xs text-white/60">{item.status}</div>
              </div>
            ))}
          </div>
        </OrbitCard>
      </div>
    </OrbitPageShell>
  );
}
