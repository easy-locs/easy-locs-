import { useEffect } from "react";
import { emit } from "@/core/relay";
import { useChatStore } from "@/store/chatStore";

export function useMessages(conversation: { id: string } | null) {
  const envelopes = useChatStore((s) => s.envelopes);
  const plaintextById = useChatStore((s) => s.plaintextById);

  useEffect(() => {
    if (!conversation) return;
    emit("CHAT_LOAD", { conversationId: conversation.id });
    emit("CHAT_DECRYPT", { conversationId: conversation.id });
  }, [conversation?.id]);

  const messages = envelopes
    .filter((row) => row.conversation_id === conversation?.id)
    .map((row) => ({
      id: row.id ?? `${row.ratchet_counter}`,
      role: row.sender_orbit_id === "demo-self" ? "me" : "peer",
      text: plaintextById[row.id ?? `${row.ratchet_counter}`] ?? "[encrypted payload]",
      ghost: row.ghost,
      createdAt: row.created_at ?? new Date().toISOString()
    }));

  function sendMessage(text: string, opts?: { ghost?: boolean }) {
    if (!conversation) return;
    emit("CHAT_SEND", {
      conversationId: conversation.id,
      text,
      ghost: !!opts?.ghost,
      sender_orbit_id: "demo-self",
      sender_device_id: "demo-device",
      receiver_orbit_id: "demo-peer"
    });
  }

  return { messages, sendMessage };
}
