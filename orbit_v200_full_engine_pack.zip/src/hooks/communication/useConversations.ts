import { useMemo, useState } from "react";

const seed = [
  { id: "demo-conversation", title: "Orbit demo", mode: "standard" as const, peerLabel: "Demo peer" },
  { id: "ghost-conversation", title: "Ghost room", mode: "ghost" as const, peerLabel: "Ghost peer" }
];

export function useConversations() {
  const [selectedId, setSelectedId] = useState<string>("demo-conversation");
  const selectedConversation = useMemo(
    () => seed.find((c) => c.id === selectedId) ?? seed[0],
    [selectedId]
  );

  return {
    conversations: seed,
    selectedConversation,
    selectedId,
    setSelectedId
  };
}
