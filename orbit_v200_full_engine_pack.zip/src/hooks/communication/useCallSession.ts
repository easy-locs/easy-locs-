import { useState } from "react";

export function useCallSession() {
  const [active, setActive] = useState(false);
  const [mode, setMode] = useState<"audio" | "video">("audio");

  return {
    active,
    mode,
    start(nextMode: "audio" | "video" = "audio") {
      setMode(nextMode);
      setActive(true);
    },
    stop() {
      setActive(false);
    }
  };
}
