import { useEffect, useState } from "react";
import { enableGhost, disableGhost, readGhostState } from "@/security/ghost";

export function useGhostSession() {
  const [state, setState] = useState(readGhostState());

  useEffect(() => {
    const id = setInterval(() => setState(readGhostState()), 1000);
    return () => clearInterval(id);
  }, []);

  return {
    active: state.active,
    remainingMs: state.remainingMs,
    enter() {
      enableGhost();
      setState(readGhostState());
    },
    exit() {
      disableGhost();
      setState(readGhostState());
    }
  };
}
