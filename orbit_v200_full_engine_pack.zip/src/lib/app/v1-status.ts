export type V1Pass = {
  id: string;
  title: string;
  status: "done" | "partial" | "next";
};

export const ORBIT_V1_STATUS: V1Pass[] = [
  { id: "delivery-core", title: "Delivery, escrow, proof, buyer dashboard", status: "done" },
  { id: "communication-shell", title: "Orbit Communication shell + Ghost foundation", status: "done" },
  { id: "future-menu", title: "Future menu and navigation shell", status: "done" },
  { id: "listing-quality", title: "Shop logo gate + listing quality gate", status: "done" },
  { id: "runtime-connection", title: "Real backend wiring and realtime hardening", status: "partial" },
  { id: "e2ee-core", title: "Full end-to-end crypto core", status: "next" },
];
