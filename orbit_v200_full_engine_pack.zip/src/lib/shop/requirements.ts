export type ShopBrandProfile = {
  id: string;
  name: string;
  logoUrl?: string | null;
  coverUrl?: string | null;
  description?: string | null;
  verified?: boolean;
  rating?: number | null;
};

export type ShopReadiness = {
  ready: boolean;
  missing: string[];
  score: number;
};

export function evaluateShopBrand(profile: ShopBrandProfile): ShopReadiness {
  const missing: string[] = [];
  let score = 100;

  if (!profile.logoUrl) {
    missing.push("logo");
    score -= 45;
  }
  if (!profile.description || profile.description.trim().length < 30) {
    missing.push("description");
    score -= 20;
  }
  if (!profile.coverUrl) {
    missing.push("cover");
    score -= 10;
  }
  if (!profile.verified) {
    score -= 10;
  }
  if ((profile.rating ?? 0) < 4) {
    score -= 5;
  }

  return {
    ready: !missing.includes("logo") && !missing.includes("description"),
    missing,
    score: Math.max(0, score),
  };
}

export function assertShopCanPublish(profile: ShopBrandProfile): void {
  const readiness = evaluateShopBrand(profile);
  if (!readiness.ready) {
    throw new Error(`Shop not ready to publish: ${readiness.missing.join(", ")}`);
  }
}
