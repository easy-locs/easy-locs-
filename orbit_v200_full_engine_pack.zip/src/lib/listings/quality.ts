export type ListingImage = {
  url?: string;
  width?: number;
  height?: number;
};

export type ListingDraft = {
  title: string;
  description: string;
  price?: number | null;
  category?: string | null;
  logoLocked?: boolean;
  images: ListingImage[];
};

export type ListingQualityReport = {
  allowed: boolean;
  score: number;
  issues: string[];
  strengths: string[];
};

const SPAM_WORDS = ["cheap", "best best", "promo!!!", "urgent buy", "test"];

export function evaluateListingQuality(draft: ListingDraft): ListingQualityReport {
  const issues: string[] = [];
  const strengths: string[] = [];
  let score = 100;

  if (!draft.images || draft.images.length < 2) {
    issues.push("At least 2 images are required.");
    score -= 30;
  } else {
    strengths.push("Enough images for a premium listing.");
  }

  if (!draft.title || draft.title.trim().length < 10) {
    issues.push("Title is too short.");
    score -= 20;
  } else {
    strengths.push("Title length is good.");
  }

  if (!draft.description || draft.description.trim().length < 40) {
    issues.push("Description is too short.");
    score -= 20;
  } else if (!/product:|details:|price:|delivery:/i.test(draft.description)) {
    issues.push("Description should follow the structured product/details/price/delivery format.");
    score -= 10;
  } else {
    strengths.push("Structured description detected.");
  }

  if (draft.price == null || draft.price <= 0) {
    issues.push("Valid price is required.");
    score -= 10;
  }

  const lc = `${draft.title} ${draft.description}`.toLowerCase();
  if (SPAM_WORDS.some((w) => lc.includes(w))) {
    issues.push("Spam-like wording detected.");
    score -= 25;
  }

  if (draft.logoLocked) {
    strengths.push("Brand identity linked to the listing.");
  }

  return {
    allowed: score >= 70 && issues.length < 3,
    score: Math.max(0, score),
    issues,
    strengths,
  };
}
