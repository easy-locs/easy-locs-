import { fetchConversation } from "@/services/envelopeService";
import { fetchWalletTxs } from "@/services/walletService";
import { useChatStore } from "@/store/chatStore";
import { useSecurityStore } from "@/store/securityStore";

export async function syncAllModules() {
  const conversationId = useChatStore.getState().conversationId;
  const orbitId = useSecurityStore.getState().orbitId;

  if (conversationId) {
    const envelopes = await fetchConversation(conversationId);
    envelopes.forEach((row) => useChatStore.getState().addEnvelope(row));
  }

  if (orbitId) {
    const txs = await fetchWalletTxs(orbitId);
    useChatStore.getState().setTransactions(txs);
  }
}
