import React from "react";
import OrbitCard from "@/components/ui/OrbitCard";
import { evaluateShopBrand, ShopBrandProfile } from "@/lib/shop/requirements";

type Props = {
  profile: ShopBrandProfile;
};

export default function ShopBrandGate({ profile }: Props) {
  const readiness = evaluateShopBrand(profile);

  return (
    <OrbitCard className="p-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-[11px] uppercase tracking-[0.22em] text-white/55">Shop quality gate</div>
          <h3 className="mt-1 text-lg font-semibold text-white">Brand publishing readiness</h3>
          <p className="mt-1 text-sm text-white/60">
            Shops must provide a clean identity before publishing. Logo is mandatory.
          </p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-center">
          <div className="text-2xl font-bold text-white">{readiness.score}</div>
          <div className="text-[11px] uppercase tracking-[0.16em] text-white/50">score</div>
        </div>
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-3">
        <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
          <div className="text-xs text-white/50">Shop</div>
          <div className="mt-1 text-sm font-semibold text-white">{profile.name}</div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
          <div className="text-xs text-white/50">Logo</div>
          <div className="mt-1 text-sm font-semibold text-white">{profile.logoUrl ? "Provided" : "Missing"}</div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
          <div className="text-xs text-white/50">Status</div>
          <div className="mt-1 text-sm font-semibold text-white">{readiness.ready ? "Ready to publish" : "Blocked until fixed"}</div>
        </div>
      </div>

      {readiness.missing.length > 0 ? (
        <div className="mt-4 rounded-2xl border border-amber-400/20 bg-amber-400/10 p-3 text-sm text-amber-100">
          Missing: {readiness.missing.join(", ")}
        </div>
      ) : (
        <div className="mt-4 rounded-2xl border border-emerald-400/20 bg-emerald-400/10 p-3 text-sm text-emerald-100">
          Shop identity is clean enough for V1 publishing.
        </div>
      )}
    </OrbitCard>
  );
}
