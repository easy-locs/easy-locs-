import React from "react";
import OrbitCard from "@/components/ui/OrbitCard";
import { evaluateListingQuality, ListingDraft } from "@/lib/listings/quality";

type Props = {
  draft: ListingDraft;
};

export default function ListingQualityGate({ draft }: Props) {
  const report = evaluateListingQuality(draft);

  return (
    <OrbitCard className="p-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="text-[11px] uppercase tracking-[0.22em] text-white/55">Listing anti-noise</div>
          <h3 className="mt-1 text-lg font-semibold text-white">Publication quality control</h3>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-center">
          <div className="text-2xl font-bold text-white">{report.score}</div>
          <div className="text-[11px] uppercase tracking-[0.16em] text-white/50">score</div>
        </div>
      </div>

      <div className="mt-4 rounded-2xl border border-white/10 bg-white/5 p-3">
        <div className="text-sm font-semibold text-white">{report.allowed ? "Ready to publish" : "Needs cleanup before publish"}</div>
        <div className="mt-1 text-sm text-white/60">
          Top listings stay clean, structured, and visually consistent to protect the platform.
        </div>
      </div>

      {report.issues.length > 0 ? (
        <div className="mt-4 rounded-2xl border border-rose-400/20 bg-rose-400/10 p-3">
          <div className="text-xs uppercase tracking-[0.16em] text-rose-100/80">Issues</div>
          <ul className="mt-2 space-y-1 text-sm text-rose-100">
            {report.issues.map((issue) => (
              <li key={issue}>• {issue}</li>
            ))}
          </ul>
        </div>
      ) : null}

      {report.strengths.length > 0 ? (
        <div className="mt-4 rounded-2xl border border-emerald-400/20 bg-emerald-400/10 p-3">
          <div className="text-xs uppercase tracking-[0.16em] text-emerald-100/80">Strengths</div>
          <ul className="mt-2 space-y-1 text-sm text-emerald-100">
            {report.strengths.map((strength) => (
              <li key={strength}>• {strength}</li>
            ))}
          </ul>
        </div>
      ) : null}
    </OrbitCard>
  );
}
