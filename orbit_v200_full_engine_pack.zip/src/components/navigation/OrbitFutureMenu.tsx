import React from "react";
import OrbitCard from "@/components/ui/OrbitCard";

export type OrbitMenuItem = {
  key: string;
  label: string;
  icon: string;
  path: string;
  badge?: string;
  accent?: "default" | "ghost" | "wallet";
};

export const ORBIT_V1_MENU: OrbitMenuItem[] = [
  { key: "home", label: "Home", icon: "🏠", path: "/" },
  { key: "explore", label: "Explore", icon: "🧭", path: "/explore" },
  { key: "marketplace", label: "Marketplace", icon: "🛒", path: "/marketplace" },
  { key: "shop", label: "My Shop", icon: "🏪", path: "/shop", badge: "Pro" },
  { key: "orders", label: "Orders", icon: "📦", path: "/orders" },
  { key: "communication", label: "Orbit", icon: "💬", path: "/communication" },
  { key: "ghost", label: "Ghost", icon: "👻", path: "/ghost", accent: "ghost" },
  { key: "wallet", label: "Wallet", icon: "💰", path: "/wallet", accent: "wallet" },
  { key: "property", label: "Property", icon: "🏢", path: "/property" },
  { key: "settings", label: "Settings", icon: "⚙️", path: "/settings" },
];

type Props = {
  activeKey?: string;
  onNavigate?: (item: OrbitMenuItem) => void;
};

function accentClasses(item: OrbitMenuItem, active: boolean) {
  if (item.accent === "ghost") {
    return active
      ? "border-fuchsia-400/40 bg-fuchsia-400/15 text-fuchsia-100"
      : "border-fuchsia-400/15 bg-white/5 text-white/80";
  }

  if (item.accent === "wallet") {
    return active
      ? "border-emerald-400/40 bg-emerald-400/15 text-emerald-100"
      : "border-emerald-400/15 bg-white/5 text-white/80";
  }

  return active
    ? "border-cyan-400/40 bg-cyan-400/15 text-white"
    : "border-white/10 bg-white/5 text-white/75";
}

export default function OrbitFutureMenu({ activeKey, onNavigate }: Props) {
  return (
    <OrbitCard className="p-3 md:p-4">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <div className="text-[11px] uppercase tracking-[0.22em] text-cyan-200/70">
            Orbit navigation
          </div>
          <h2 className="mt-1 text-lg font-semibold text-white">Smart • Simply • Future • Easy</h2>
        </div>
        <div className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] text-white/60">
          V1 shell
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 md:grid-cols-5">
        {ORBIT_V1_MENU.map((item) => {
          const active = item.key === activeKey;
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => onNavigate?.(item)}
              className={[
                "rounded-2xl border p-3 text-left transition active:scale-[0.985]",
                accentClasses(item, active),
              ].join(" ")}
            >
              <div className="flex items-center justify-between">
                <span className="text-xl leading-none">{item.icon}</span>
                {item.badge ? (
                  <span className="rounded-full border border-white/10 px-2 py-0.5 text-[10px] uppercase tracking-[0.16em]">
                    {item.badge}
                  </span>
                ) : null}
              </div>
              <div className="mt-3 text-sm font-semibold">{item.label}</div>
              <div className="mt-1 text-[11px] text-white/55">{item.path}</div>
            </button>
          );
        })}
      </div>
    </OrbitCard>
  );
}
