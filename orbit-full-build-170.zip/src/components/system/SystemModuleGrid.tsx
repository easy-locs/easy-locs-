import React from "react";

const modules = [
  "Home", "Map", "Radar", "Checkout",
  "Orders", "Ads", "CRM", "Finance",
  "Profile", "Ghost"
];

export default function SystemModuleGrid() {
  return (
    <div className="grid grid-cols-2 gap-3">
      {modules.map((m) => (
        <div key={m} className="rounded-2xl border border-white/10 bg-white/5 p-4 shadow-lg backdrop-blur-xl">
          <div className="text-sm font-bold text-white">{m}</div>
          <div className="mt-1 text-xs text-white/55">Premium layer ready</div>
        </div>
      ))}
    </div>
  );
}
