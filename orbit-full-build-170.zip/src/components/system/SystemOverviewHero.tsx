import React from "react";

export default function SystemOverviewHero() {
  return (
    <section className="relative overflow-hidden rounded-[28px] border border-cyan-400/15 bg-[#06101b] p-5 shadow-2xl">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(34,211,238,0.10),transparent_32%),radial-gradient(circle_at_bottom_right,rgba(139,92,246,0.10),transparent_28%)]" />
      <div className="relative">
        <div className="text-[11px] font-semibold uppercase tracking-wide text-cyan-300/80">Unified premium system</div>
        <div className="mt-2 text-2xl font-bold text-white">Home, map, merchant, ads, CRM, finance and ghost aligned</div>
        <div className="mt-2 max-w-2xl text-sm text-white/55">This layer frames the product as one coherent premium experience.</div>
      </div>
    </section>
  );
}
