import React from "react";
export default function RevenueHero() {
  return (
    <section className="rounded-[28px] border border-white/10 bg-[#08111f] p-5 shadow-2xl">
      <div className="text-[11px] font-semibold uppercase tracking-wide text-emerald-300/80">Business live</div>
      <div className="mt-2 text-3xl font-bold text-white">AED 48.2k</div>
    </section>
  );
}
