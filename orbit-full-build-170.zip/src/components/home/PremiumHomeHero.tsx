import React from "react";
export default function PremiumHomeHero() {
  return (
    <section className="rounded-[28px] border border-white/10 bg-[#07111f] p-5 shadow-2xl">
      <h1 className="text-3xl font-bold tracking-tight text-white">Everything around you, in one smart shell</h1>
      <p className="mt-2 max-w-xl text-sm text-white/65">Faster discovery, stronger CTA hierarchy, smoother premium home experience.</p>
    </section>
  );
}
