import React from "react";
import SystemOverviewHero from "@/components/system/SystemOverviewHero";
import SystemModuleGrid from "@/components/system/SystemModuleGrid";

export default function FullBuild170Demo() {
  return (
    <main className="min-h-screen bg-[#030712] p-4">
      <div className="mx-auto max-w-4xl space-y-4">
        <SystemOverviewHero />
        <SystemModuleGrid />
      </div>
    </main>
  );
}
